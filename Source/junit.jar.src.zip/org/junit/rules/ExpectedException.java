/*     */ package org.junit.rules;
/*     */ 
/*     */ import org.hamcrest.CoreMatchers;
/*     */ import org.hamcrest.Matcher;
/*     */ import org.hamcrest.StringDescription;
/*     */ import org.junit.Assert;
/*     */ import org.junit.internal.AssumptionViolatedException;
/*     */ import org.junit.internal.matchers.ThrowableCauseMatcher;
/*     */ import org.junit.internal.matchers.ThrowableMessageMatcher;
/*     */ import org.junit.runner.Description;
/*     */ import org.junit.runners.model.Statement;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExpectedException
/*     */   implements TestRule
/*     */ {
/*     */   public static ExpectedException none()
/*     */   {
/*  91 */     return new ExpectedException();
/*     */   }
/*     */   
/*  94 */   private final ExpectedExceptionMatcherBuilder fMatcherBuilder = new ExpectedExceptionMatcherBuilder();
/*     */   
/*  96 */   private boolean handleAssumptionViolatedExceptions = false;
/*     */   
/*  98 */   private boolean handleAssertionErrors = false;
/*     */   
/*     */ 
/*     */ 
/*     */   public ExpectedException handleAssertionErrors()
/*     */   {
/* 104 */     this.handleAssertionErrors = true;
/* 105 */     return this;
/*     */   }
/*     */   
/*     */   public ExpectedException handleAssumptionViolatedExceptions() {
/* 109 */     this.handleAssumptionViolatedExceptions = true;
/* 110 */     return this;
/*     */   }
/*     */   
/*     */   public Statement apply(Statement base, Description description)
/*     */   {
/* 115 */     return new ExpectedExceptionStatement(base);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void expect(Matcher<?> matcher)
/*     */   {
/* 123 */     this.fMatcherBuilder.add(matcher);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void expect(Class<? extends Throwable> type)
/*     */   {
/* 131 */     expect(CoreMatchers.instanceOf(type));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void expectMessage(String substring)
/*     */   {
/* 139 */     expectMessage(CoreMatchers.containsString(substring));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void expectMessage(Matcher<String> matcher)
/*     */   {
/* 147 */     expect(ThrowableMessageMatcher.hasMessage(matcher));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void expectCause(Matcher<? extends Throwable> expectedCause)
/*     */   {
/* 155 */     expect(ThrowableCauseMatcher.hasCause(expectedCause));
/*     */   }
/*     */   
/*     */   private class ExpectedExceptionStatement extends Statement {
/*     */     private final Statement fNext;
/*     */     
/*     */     public ExpectedExceptionStatement(Statement base) {
/* 162 */       this.fNext = base;
/*     */     }
/*     */     
/*     */     public void evaluate() throws Throwable
/*     */     {
/*     */       try {
/* 168 */         this.fNext.evaluate();
/* 169 */         if (ExpectedException.this.fMatcherBuilder.expectsThrowable()) {
/* 170 */           ExpectedException.this.failDueToMissingException();
/*     */         }
/*     */       } catch (AssumptionViolatedException e) {
/* 173 */         ExpectedException.this.optionallyHandleException(e, ExpectedException.this.handleAssumptionViolatedExceptions);
/*     */       } catch (AssertionError e) {
/* 175 */         ExpectedException.this.optionallyHandleException(e, ExpectedException.this.handleAssertionErrors);
/*     */       } catch (Throwable e) {
/* 177 */         ExpectedException.this.handleException(e);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void failDueToMissingException() throws AssertionError {
/* 183 */     String expectation = StringDescription.toString(this.fMatcherBuilder.build());
/* 184 */     Assert.fail("Expected test to throw " + expectation);
/*     */   }
/*     */   
/*     */   private void optionallyHandleException(Throwable e, boolean handleException) throws Throwable
/*     */   {
/* 189 */     if (handleException) {
/* 190 */       handleException(e);
/*     */     } else {
/* 192 */       throw e;
/*     */     }
/*     */   }
/*     */   
/*     */   private void handleException(Throwable e) throws Throwable {
/* 197 */     if (this.fMatcherBuilder.expectsThrowable()) {
/* 198 */       Assert.assertThat(e, this.fMatcherBuilder.build());
/*     */     } else {
/* 200 */       throw e;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\junit.jar!\org\junit\rules\ExpectedException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */