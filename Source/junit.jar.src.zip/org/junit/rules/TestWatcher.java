/*     */ package org.junit.rules;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.junit.internal.AssumptionViolatedException;
/*     */ import org.junit.runner.Description;
/*     */ import org.junit.runners.model.MultipleFailureException;
/*     */ import org.junit.runners.model.Statement;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class TestWatcher
/*     */   implements TestRule
/*     */ {
/*     */   public Statement apply(final Statement base, final Description description)
/*     */   {
/*  48 */     new Statement()
/*     */     {
/*     */       public void evaluate() throws Throwable {
/*  51 */         List<Throwable> errors = new ArrayList();
/*     */         
/*  53 */         TestWatcher.this.startingQuietly(description, errors);
/*     */         try {
/*  55 */           base.evaluate();
/*  56 */           TestWatcher.this.succeededQuietly(description, errors);
/*     */         } catch (AssumptionViolatedException e) {
/*  58 */           errors.add(e);
/*  59 */           TestWatcher.this.skippedQuietly(e, description, errors);
/*     */         } catch (Throwable t) {
/*  61 */           errors.add(t);
/*  62 */           TestWatcher.this.failedQuietly(t, description, errors);
/*     */         } finally {
/*  64 */           TestWatcher.this.finishedQuietly(description, errors);
/*     */         }
/*     */         
/*  67 */         MultipleFailureException.assertEmpty(errors);
/*     */       }
/*     */     };
/*     */   }
/*     */   
/*     */   private void succeededQuietly(Description description, List<Throwable> errors)
/*     */   {
/*     */     try {
/*  75 */       succeeded(description);
/*     */     } catch (Throwable t) {
/*  77 */       errors.add(t);
/*     */     }
/*     */   }
/*     */   
/*     */   private void failedQuietly(Throwable t, Description description, List<Throwable> errors)
/*     */   {
/*     */     try {
/*  84 */       failed(t, description);
/*     */     } catch (Throwable t1) {
/*  86 */       errors.add(t1);
/*     */     }
/*     */   }
/*     */   
/*     */   private void skippedQuietly(AssumptionViolatedException e, Description description, List<Throwable> errors)
/*     */   {
/*     */     try {
/*  93 */       skipped(e, description);
/*     */     } catch (Throwable t) {
/*  95 */       errors.add(t);
/*     */     }
/*     */   }
/*     */   
/*     */   private void startingQuietly(Description description, List<Throwable> errors)
/*     */   {
/*     */     try {
/* 102 */       starting(description);
/*     */     } catch (Throwable t) {
/* 104 */       errors.add(t);
/*     */     }
/*     */   }
/*     */   
/*     */   private void finishedQuietly(Description description, List<Throwable> errors)
/*     */   {
/*     */     try {
/* 111 */       finished(description);
/*     */     } catch (Throwable t) {
/* 113 */       errors.add(t);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void succeeded(Description description) {}
/*     */   
/*     */   protected void failed(Throwable e, Description description) {}
/*     */   
/*     */   protected void skipped(AssumptionViolatedException e, Description description) {}
/*     */   
/*     */   protected void starting(Description description) {}
/*     */   
/*     */   protected void finished(Description description) {}
/*     */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\junit.jar!\org\junit\rules\TestWatcher.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */