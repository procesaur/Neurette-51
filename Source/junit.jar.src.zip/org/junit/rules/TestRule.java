package org.junit.rules;

import org.junit.runner.Description;
import org.junit.runners.model.Statement;

public abstract interface TestRule
{
  public abstract Statement apply(Statement paramStatement, Description paramDescription);
}


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\junit.jar!\org\junit\rules\TestRule.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */