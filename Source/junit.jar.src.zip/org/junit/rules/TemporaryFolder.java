/*     */ package org.junit.rules;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TemporaryFolder
/*     */   extends ExternalResource
/*     */ {
/*     */   private final File parentFolder;
/*     */   private File folder;
/*     */   
/*     */   public TemporaryFolder()
/*     */   {
/*  34 */     this(null);
/*     */   }
/*     */   
/*     */   public TemporaryFolder(File parentFolder) {
/*  38 */     this.parentFolder = parentFolder;
/*     */   }
/*     */   
/*     */   protected void before() throws Throwable
/*     */   {
/*  43 */     create();
/*     */   }
/*     */   
/*     */   protected void after()
/*     */   {
/*  48 */     delete();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void create()
/*     */     throws IOException
/*     */   {
/*  57 */     this.folder = createTemporaryFolderIn(this.parentFolder);
/*     */   }
/*     */   
/*     */ 
/*     */   public File newFile(String fileName)
/*     */     throws IOException
/*     */   {
/*  64 */     File file = new File(getRoot(), fileName);
/*  65 */     if (!file.createNewFile()) {
/*  66 */       throw new IOException("a file with the name '" + fileName + "' already exists in the test folder");
/*     */     }
/*     */     
/*  69 */     return file;
/*     */   }
/*     */   
/*     */ 
/*     */   public File newFile()
/*     */     throws IOException
/*     */   {
/*  76 */     return File.createTempFile("junit", null, getRoot());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public File newFolder(String folder)
/*     */     throws IOException
/*     */   {
/*  84 */     return newFolder(new String[] { folder });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public File newFolder(String... folderNames)
/*     */     throws IOException
/*     */   {
/*  92 */     File file = getRoot();
/*  93 */     for (int i = 0; i < folderNames.length; i++) {
/*  94 */       String folderName = folderNames[i];
/*  95 */       file = new File(file, folderName);
/*  96 */       if ((!file.mkdir()) && (isLastElementInArray(i, folderNames))) {
/*  97 */         throw new IOException("a folder with the name '" + folderName + "' already exists");
/*     */       }
/*     */     }
/*     */     
/* 101 */     return file;
/*     */   }
/*     */   
/*     */   private boolean isLastElementInArray(int index, String[] array) {
/* 105 */     return index == array.length - 1;
/*     */   }
/*     */   
/*     */ 
/*     */   public File newFolder()
/*     */     throws IOException
/*     */   {
/* 112 */     return createTemporaryFolderIn(getRoot());
/*     */   }
/*     */   
/*     */   private File createTemporaryFolderIn(File parentFolder) throws IOException {
/* 116 */     File createdFolder = File.createTempFile("junit", "", parentFolder);
/* 117 */     createdFolder.delete();
/* 118 */     createdFolder.mkdir();
/* 119 */     return createdFolder;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public File getRoot()
/*     */   {
/* 126 */     if (this.folder == null) {
/* 127 */       throw new IllegalStateException("the temporary folder has not yet been created");
/*     */     }
/*     */     
/* 130 */     return this.folder;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void delete()
/*     */   {
/* 138 */     if (this.folder != null) {
/* 139 */       recursiveDelete(this.folder);
/*     */     }
/*     */   }
/*     */   
/*     */   private void recursiveDelete(File file) {
/* 144 */     File[] files = file.listFiles();
/* 145 */     if (files != null) {
/* 146 */       for (File each : files) {
/* 147 */         recursiveDelete(each);
/*     */       }
/*     */     }
/* 150 */     file.delete();
/*     */   }
/*     */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\junit.jar!\org\junit\rules\TemporaryFolder.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */