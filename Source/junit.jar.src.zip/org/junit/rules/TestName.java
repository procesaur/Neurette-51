/*    */ package org.junit.rules;
/*    */ 
/*    */ import org.junit.runner.Description;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TestName
/*    */   extends TestWatcher
/*    */ {
/*    */   private String fName;
/*    */   
/*    */   protected void starting(Description d)
/*    */   {
/* 32 */     this.fName = d.getMethodName();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public String getMethodName()
/*    */   {
/* 39 */     return this.fName;
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\junit.jar!\org\junit\rules\TestName.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */