/*     */ package org.junit.runner;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Description
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  32 */   private static final Pattern METHOD_AND_CLASS_NAME_PATTERN = Pattern.compile("(.*)\\((.*)\\)");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Description createSuiteDescription(String name, Annotation... annotations)
/*     */   {
/*  44 */     return new Description(null, name, annotations);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Description createSuiteDescription(String name, Serializable uniqueId, Annotation... annotations)
/*     */   {
/*  57 */     return new Description(null, name, uniqueId, annotations);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Description createTestDescription(String className, String name, Annotation... annotations)
/*     */   {
/*  72 */     return new Description(null, formatDisplayName(name, className), annotations);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Description createTestDescription(Class<?> clazz, String name, Annotation... annotations)
/*     */   {
/*  85 */     return new Description(clazz, formatDisplayName(name, clazz.getName()), annotations);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Description createTestDescription(Class<?> clazz, String name)
/*     */   {
/*  98 */     return new Description(clazz, formatDisplayName(name, clazz.getName()), new Annotation[0]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Description createTestDescription(String className, String name, Serializable uniqueId)
/*     */   {
/* 109 */     return new Description(null, formatDisplayName(name, className), uniqueId, new Annotation[0]);
/*     */   }
/*     */   
/*     */   private static String formatDisplayName(String name, String className) {
/* 113 */     return String.format("%s(%s)", new Object[] { name, className });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Description createSuiteDescription(Class<?> testClass)
/*     */   {
/* 123 */     return new Description(testClass, testClass.getName(), testClass.getAnnotations());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 129 */   public static final Description EMPTY = new Description(null, "No Tests", new Annotation[0]);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 136 */   public static final Description TEST_MECHANISM = new Description(null, "Test mechanism", new Annotation[0]);
/*     */   
/* 138 */   private final ArrayList<Description> fChildren = new ArrayList();
/*     */   private final String fDisplayName;
/*     */   private final Serializable fUniqueId;
/*     */   private final Annotation[] fAnnotations;
/*     */   private Class<?> fTestClass;
/*     */   
/*     */   private Description(Class<?> clazz, String displayName, Annotation... annotations) {
/* 145 */     this(clazz, displayName, displayName, annotations);
/*     */   }
/*     */   
/*     */   private Description(Class<?> clazz, String displayName, Serializable uniqueId, Annotation... annotations) {
/* 149 */     if ((displayName == null) || (displayName.length() == 0)) {
/* 150 */       throw new IllegalArgumentException("The display name must not be empty.");
/*     */     }
/*     */     
/* 153 */     if (uniqueId == null) {
/* 154 */       throw new IllegalArgumentException("The unique id must not be null.");
/*     */     }
/*     */     
/* 157 */     this.fTestClass = clazz;
/* 158 */     this.fDisplayName = displayName;
/* 159 */     this.fUniqueId = uniqueId;
/* 160 */     this.fAnnotations = annotations;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getDisplayName()
/*     */   {
/* 167 */     return this.fDisplayName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addChild(Description description)
/*     */   {
/* 176 */     getChildren().add(description);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public ArrayList<Description> getChildren()
/*     */   {
/* 183 */     return this.fChildren;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isSuite()
/*     */   {
/* 190 */     return !isTest();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isTest()
/*     */   {
/* 197 */     return getChildren().isEmpty();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int testCount()
/*     */   {
/* 204 */     if (isTest()) {
/* 205 */       return 1;
/*     */     }
/* 207 */     int result = 0;
/* 208 */     for (Description child : getChildren()) {
/* 209 */       result += child.testCount();
/*     */     }
/* 211 */     return result;
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/* 216 */     return this.fUniqueId.hashCode();
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj)
/*     */   {
/* 221 */     if (!(obj instanceof Description)) {
/* 222 */       return false;
/*     */     }
/* 224 */     Description d = (Description)obj;
/* 225 */     return this.fUniqueId.equals(d.fUniqueId);
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 230 */     return getDisplayName();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isEmpty()
/*     */   {
/* 237 */     return equals(EMPTY);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Description childlessCopy()
/*     */   {
/* 245 */     return new Description(this.fTestClass, this.fDisplayName, this.fAnnotations);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public <T extends Annotation> T getAnnotation(Class<T> annotationType)
/*     */   {
/* 253 */     for (Annotation each : this.fAnnotations) {
/* 254 */       if (each.annotationType().equals(annotationType)) {
/* 255 */         return (Annotation)annotationType.cast(each);
/*     */       }
/*     */     }
/* 258 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Collection<Annotation> getAnnotations()
/*     */   {
/* 265 */     return Arrays.asList(this.fAnnotations);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Class<?> getTestClass()
/*     */   {
/* 273 */     if (this.fTestClass != null) {
/* 274 */       return this.fTestClass;
/*     */     }
/* 276 */     String name = getClassName();
/* 277 */     if (name == null) {
/* 278 */       return null;
/*     */     }
/*     */     try {
/* 281 */       this.fTestClass = Class.forName(name, false, getClass().getClassLoader());
/* 282 */       return this.fTestClass;
/*     */     } catch (ClassNotFoundException e) {}
/* 284 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getClassName()
/*     */   {
/* 293 */     return this.fTestClass != null ? this.fTestClass.getName() : methodAndClassNamePatternGroupOrDefault(2, toString());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getMethodName()
/*     */   {
/* 301 */     return methodAndClassNamePatternGroupOrDefault(1, null);
/*     */   }
/*     */   
/*     */   private String methodAndClassNamePatternGroupOrDefault(int group, String defaultString)
/*     */   {
/* 306 */     Matcher matcher = METHOD_AND_CLASS_NAME_PATTERN.matcher(toString());
/* 307 */     return matcher.matches() ? matcher.group(group) : defaultString;
/*     */   }
/*     */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\junit.jar!\org\junit\runner\Description.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */