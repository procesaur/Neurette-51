/*     */ package org.junit.runner;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import junit.framework.Test;
/*     */ import junit.runner.Version;
/*     */ import org.junit.internal.JUnitSystem;
/*     */ import org.junit.internal.RealSystem;
/*     */ import org.junit.internal.TextListener;
/*     */ import org.junit.internal.runners.JUnit38ClassRunner;
/*     */ import org.junit.runner.notification.Failure;
/*     */ import org.junit.runner.notification.RunListener;
/*     */ import org.junit.runner.notification.RunNotifier;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JUnitCore
/*     */ {
/*  29 */   private final RunNotifier fNotifier = new RunNotifier();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void main(String... args)
/*     */   {
/*  40 */     runMainAndExit(new RealSystem(), args);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static void runMainAndExit(JUnitSystem system, String... args)
/*     */   {
/*  47 */     Result result = new JUnitCore().runMain(system, args);
/*  48 */     System.exit(result.wasSuccessful() ? 0 : 1);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Result runClasses(Computer computer, Class<?>... classes)
/*     */   {
/*  61 */     return new JUnitCore().run(computer, classes);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Result runClasses(Class<?>... classes)
/*     */   {
/*  73 */     return new JUnitCore().run(defaultComputer(), classes);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private Result runMain(JUnitSystem system, String... args)
/*     */   {
/*  81 */     system.out().println("JUnit version " + Version.id());
/*  82 */     List<Class<?>> classes = new ArrayList();
/*  83 */     List<Failure> missingClasses = new ArrayList();
/*  84 */     for (String each : args) {
/*     */       try {
/*  86 */         classes.add(Class.forName(each));
/*     */       } catch (ClassNotFoundException e) {
/*  88 */         system.out().println("Could not find class: " + each);
/*  89 */         Description description = Description.createSuiteDescription(each, new Annotation[0]);
/*  90 */         Failure failure = new Failure(description, e);
/*  91 */         missingClasses.add(failure);
/*     */       }
/*     */     }
/*  94 */     RunListener listener = new TextListener(system);
/*  95 */     addListener(listener);
/*  96 */     Result result = run((Class[])classes.toArray(new Class[0]));
/*  97 */     for (Failure each : missingClasses) {
/*  98 */       result.getFailures().add(each);
/*     */     }
/* 100 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getVersion()
/*     */   {
/* 107 */     return Version.id();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Result run(Class<?>... classes)
/*     */   {
/* 117 */     return run(Request.classes(defaultComputer(), classes));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Result run(Computer computer, Class<?>... classes)
/*     */   {
/* 128 */     return run(Request.classes(computer, classes));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Result run(Request request)
/*     */   {
/* 138 */     return run(request.getRunner());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Result run(Test test)
/*     */   {
/* 148 */     return run(new JUnit38ClassRunner(test));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Result run(Runner runner)
/*     */   {
/* 155 */     Result result = new Result();
/* 156 */     RunListener listener = result.createListener();
/* 157 */     this.fNotifier.addFirstListener(listener);
/*     */     try {
/* 159 */       this.fNotifier.fireTestRunStarted(runner.getDescription());
/* 160 */       runner.run(this.fNotifier);
/* 161 */       this.fNotifier.fireTestRunFinished(result);
/*     */     } finally {
/* 163 */       removeListener(listener);
/*     */     }
/* 165 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addListener(RunListener listener)
/*     */   {
/* 175 */     this.fNotifier.addListener(listener);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeListener(RunListener listener)
/*     */   {
/* 184 */     this.fNotifier.removeListener(listener);
/*     */   }
/*     */   
/*     */   static Computer defaultComputer() {
/* 188 */     return new Computer();
/*     */   }
/*     */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\junit.jar!\org\junit\runner\JUnitCore.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */