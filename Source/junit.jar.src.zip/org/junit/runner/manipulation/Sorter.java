/*    */ package org.junit.runner.manipulation;
/*    */ 
/*    */ import java.util.Comparator;
/*    */ import org.junit.runner.Description;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Sorter
/*    */   implements Comparator<Description>
/*    */ {
/* 17 */   public static Sorter NULL = new Sorter(new Comparator() {
/*    */     public int compare(Description o1, Description o2) {
/* 19 */       return 0;
/*    */     }
/* 17 */   });
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private final Comparator<Description> fComparator;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Sorter(Comparator<Description> comparator)
/*    */   {
/* 31 */     this.fComparator = comparator;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void apply(Object object)
/*    */   {
/* 38 */     if ((object instanceof Sortable)) {
/* 39 */       Sortable sortable = (Sortable)object;
/* 40 */       sortable.sort(this);
/*    */     }
/*    */   }
/*    */   
/*    */   public int compare(Description o1, Description o2) {
/* 45 */     return this.fComparator.compare(o1, o2);
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\junit.jar!\org\junit\runner\manipulation\Sorter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */