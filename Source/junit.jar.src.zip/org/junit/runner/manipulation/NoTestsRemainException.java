package org.junit.runner.manipulation;

public class NoTestsRemainException
  extends Exception
{
  private static final long serialVersionUID = 1L;
}


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\junit.jar!\org\junit\runner\manipulation\NoTestsRemainException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */