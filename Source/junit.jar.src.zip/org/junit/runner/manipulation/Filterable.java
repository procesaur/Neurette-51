package org.junit.runner.manipulation;

public abstract interface Filterable
{
  public abstract void filter(Filter paramFilter)
    throws NoTestsRemainException;
}


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\junit.jar!\org\junit\runner\manipulation\Filterable.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */