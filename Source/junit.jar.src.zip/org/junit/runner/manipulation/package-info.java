package org.junit.runner.manipulation;

interface package-info {}


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\junit.jar!\org\junit\runner\manipulation\package-info.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */