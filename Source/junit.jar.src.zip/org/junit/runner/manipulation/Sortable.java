package org.junit.runner.manipulation;

public abstract interface Sortable
{
  public abstract void sort(Sorter paramSorter);
}


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\junit.jar!\org\junit\runner\manipulation\Sortable.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */