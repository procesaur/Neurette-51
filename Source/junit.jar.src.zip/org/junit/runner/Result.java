/*     */ package org.junit.runner;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import org.junit.runner.notification.Failure;
/*     */ import org.junit.runner.notification.RunListener;
/*     */ 
/*     */ public class Result implements java.io.Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private AtomicInteger fCount;
/*     */   private AtomicInteger fIgnoreCount;
/*     */   private final List<Failure> fFailures;
/*     */   private long fRunTime;
/*     */   private long fStartTime;
/*     */   
/*     */   public Result()
/*     */   {
/*  20 */     this.fCount = new AtomicInteger();
/*  21 */     this.fIgnoreCount = new AtomicInteger();
/*  22 */     this.fFailures = java.util.Collections.synchronizedList(new ArrayList());
/*  23 */     this.fRunTime = 0L;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getRunCount()
/*     */   {
/*  30 */     return this.fCount.get();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getFailureCount()
/*     */   {
/*  37 */     return this.fFailures.size();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public long getRunTime()
/*     */   {
/*  44 */     return this.fRunTime;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public List<Failure> getFailures()
/*     */   {
/*  51 */     return this.fFailures;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getIgnoreCount()
/*     */   {
/*  58 */     return this.fIgnoreCount.get();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean wasSuccessful()
/*     */   {
/*  65 */     return getFailureCount() == 0;
/*     */   }
/*     */   
/*     */   private class Listener extends RunListener {
/*     */     private Listener() {}
/*     */     
/*  71 */     public void testRunStarted(Description description) throws Exception { Result.this.fStartTime = System.currentTimeMillis(); }
/*     */     
/*     */     public void testRunFinished(Result result)
/*     */       throws Exception
/*     */     {
/*  76 */       long endTime = System.currentTimeMillis();
/*  77 */       Result.access$114(Result.this, endTime - Result.this.fStartTime);
/*     */     }
/*     */     
/*     */     public void testFinished(Description description) throws Exception
/*     */     {
/*  82 */       Result.this.fCount.getAndIncrement();
/*     */     }
/*     */     
/*     */     public void testFailure(Failure failure) throws Exception
/*     */     {
/*  87 */       Result.this.fFailures.add(failure);
/*     */     }
/*     */     
/*     */     public void testIgnored(Description description) throws Exception
/*     */     {
/*  92 */       Result.this.fIgnoreCount.getAndIncrement();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public void testAssumptionFailure(Failure failure) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public RunListener createListener()
/*     */   {
/* 105 */     return new Listener(null);
/*     */   }
/*     */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\junit.jar!\org\junit\runner\Result.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */