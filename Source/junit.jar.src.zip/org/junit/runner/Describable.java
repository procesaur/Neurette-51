package org.junit.runner;

public abstract interface Describable
{
  public abstract Description getDescription();
}


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\junit.jar!\org\junit\runner\Describable.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */