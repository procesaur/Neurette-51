/*     */ package org.junit.runner.notification;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.junit.runner.Description;
/*     */ import org.junit.runner.Result;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RunNotifier
/*     */ {
/*     */   private final List<RunListener> fListeners;
/*     */   private volatile boolean fPleaseStop;
/*     */   
/*     */   public RunNotifier()
/*     */   {
/*  24 */     this.fListeners = Collections.synchronizedList(new ArrayList());
/*     */     
/*  26 */     this.fPleaseStop = false;
/*     */   }
/*     */   
/*     */ 
/*     */   public void addListener(RunListener listener)
/*     */   {
/*  32 */     this.fListeners.add(listener);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void removeListener(RunListener listener)
/*     */   {
/*  39 */     this.fListeners.remove(listener);
/*     */   }
/*     */   
/*     */   private abstract class SafeNotifier {
/*     */     private final List<RunListener> fCurrentListeners;
/*     */     
/*     */     SafeNotifier() {
/*  46 */       this(RunNotifier.this.fListeners);
/*     */     }
/*     */     
/*     */     SafeNotifier() {
/*  50 */       this.fCurrentListeners = currentListeners;
/*     */     }
/*     */     
/*     */     void run() {
/*  54 */       synchronized (RunNotifier.this.fListeners) {
/*  55 */         List<RunListener> safeListeners = new ArrayList();
/*  56 */         List<Failure> failures = new ArrayList();
/*  57 */         Iterator<RunListener> all = this.fCurrentListeners.iterator();
/*  58 */         while (all.hasNext()) {
/*     */           try {
/*  60 */             RunListener listener = (RunListener)all.next();
/*  61 */             notifyListener(listener);
/*  62 */             safeListeners.add(listener);
/*     */           } catch (Exception e) {
/*  64 */             failures.add(new Failure(Description.TEST_MECHANISM, e));
/*     */           }
/*     */         }
/*  67 */         RunNotifier.this.fireTestFailures(safeListeners, failures);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */     protected abstract void notifyListener(RunListener paramRunListener)
/*     */       throws Exception;
/*     */   }
/*     */   
/*     */   public void fireTestRunStarted(final Description description)
/*     */   {
/*  78 */     new SafeNotifier(description)
/*     */     {
/*     */       protected void notifyListener(RunListener each) throws Exception {
/*  81 */         each.testRunStarted(description);
/*     */       }
/*     */     }.run();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void fireTestRunFinished(final Result result)
/*     */   {
/*  92 */     new SafeNotifier(result)
/*     */     {
/*     */       protected void notifyListener(RunListener each) throws Exception {
/*  95 */         each.testRunFinished(result);
/*     */       }
/*     */     }.run();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void fireTestStarted(final Description description)
/*     */     throws StoppedByUserException
/*     */   {
/* 109 */     if (this.fPleaseStop) {
/* 110 */       throw new StoppedByUserException();
/*     */     }
/* 112 */     new SafeNotifier(description)
/*     */     {
/*     */       protected void notifyListener(RunListener each) throws Exception {
/* 115 */         each.testStarted(description);
/*     */       }
/*     */     }.run();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void fireTestFailure(Failure failure)
/*     */   {
/* 128 */     fireTestFailures(this.fListeners, Arrays.asList(new Failure[] { failure }));
/*     */   }
/*     */   
/*     */   private void fireTestFailures(List<RunListener> listeners, final List<Failure> failures)
/*     */   {
/* 133 */     if (!failures.isEmpty()) {
/* 134 */       new SafeNotifier(listeners, failures)
/*     */       {
/*     */         protected void notifyListener(RunListener listener) throws Exception
/*     */         {
/* 138 */           for (Failure each : failures) {
/* 139 */             listener.testFailure(each);
/*     */           }
/*     */         }
/*     */       }.run();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void fireTestAssumptionFailed(final Failure failure)
/*     */   {
/* 156 */     new SafeNotifier(failure)
/*     */     {
/*     */       protected void notifyListener(RunListener each) throws Exception {
/* 159 */         each.testAssumptionFailure(failure);
/*     */       }
/*     */     }.run();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void fireTestIgnored(final Description description)
/*     */   {
/* 172 */     new SafeNotifier(description)
/*     */     {
/*     */       protected void notifyListener(RunListener each) throws Exception {
/* 175 */         each.testIgnored(description);
/*     */       }
/*     */     }.run();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void fireTestFinished(final Description description)
/*     */   {
/* 188 */     new SafeNotifier(description)
/*     */     {
/*     */       protected void notifyListener(RunListener each) throws Exception {
/* 191 */         each.testFinished(description);
/*     */       }
/*     */     }.run();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void pleaseStop()
/*     */   {
/* 205 */     this.fPleaseStop = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void addFirstListener(RunListener listener)
/*     */   {
/* 212 */     this.fListeners.add(0, listener);
/*     */   }
/*     */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\junit.jar!\org\junit\runner\notification\RunNotifier.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */