/*    */ package org.junit.runner.notification;
/*    */ 
/*    */ import java.io.PrintWriter;
/*    */ import java.io.Serializable;
/*    */ import java.io.StringWriter;
/*    */ import org.junit.runner.Description;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Failure
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private final Description fDescription;
/*    */   private final Throwable fThrownException;
/*    */   
/*    */   public Failure(Description description, Throwable thrownException)
/*    */   {
/* 30 */     this.fThrownException = thrownException;
/* 31 */     this.fDescription = description;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public String getTestHeader()
/*    */   {
/* 38 */     return this.fDescription.getDisplayName();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public Description getDescription()
/*    */   {
/* 45 */     return this.fDescription;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public Throwable getException()
/*    */   {
/* 53 */     return this.fThrownException;
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 58 */     StringBuffer buffer = new StringBuffer();
/* 59 */     buffer.append(getTestHeader() + ": " + this.fThrownException.getMessage());
/* 60 */     return buffer.toString();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getTrace()
/*    */   {
/* 69 */     StringWriter stringWriter = new StringWriter();
/* 70 */     PrintWriter writer = new PrintWriter(stringWriter);
/* 71 */     getException().printStackTrace(writer);
/* 72 */     StringBuffer buffer = stringWriter.getBuffer();
/* 73 */     return buffer.toString();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getMessage()
/*    */   {
/* 82 */     return getException().getMessage();
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\junit.jar!\org\junit\runner\notification\Failure.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */