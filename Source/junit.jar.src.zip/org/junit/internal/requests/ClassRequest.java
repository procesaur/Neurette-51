/*    */ package org.junit.internal.requests;
/*    */ 
/*    */ import org.junit.internal.builders.AllDefaultPossibilitiesBuilder;
/*    */ import org.junit.runner.Runner;
/*    */ 
/*    */ public class ClassRequest extends org.junit.runner.Request
/*    */ {
/*  8 */   private final Object fRunnerLock = new Object();
/*    */   private final Class<?> fTestClass;
/*    */   private final boolean fCanUseSuiteMethod;
/*    */   private Runner fRunner;
/*    */   
/*    */   public ClassRequest(Class<?> testClass, boolean canUseSuiteMethod) {
/* 14 */     this.fTestClass = testClass;
/* 15 */     this.fCanUseSuiteMethod = canUseSuiteMethod;
/*    */   }
/*    */   
/*    */   public ClassRequest(Class<?> testClass) {
/* 19 */     this(testClass, true);
/*    */   }
/*    */   
/*    */   public Runner getRunner()
/*    */   {
/* 24 */     synchronized (this.fRunnerLock) {
/* 25 */       if (this.fRunner == null) {
/* 26 */         this.fRunner = new AllDefaultPossibilitiesBuilder(this.fCanUseSuiteMethod).safeRunnerForClass(this.fTestClass);
/*    */       }
/* 28 */       return this.fRunner;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\junit.jar!\org\junit\internal\requests\ClassRequest.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */