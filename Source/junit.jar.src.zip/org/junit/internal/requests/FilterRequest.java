/*    */ package org.junit.internal.requests;
/*    */ 
/*    */ import org.junit.internal.runners.ErrorReportingRunner;
/*    */ import org.junit.runner.Request;
/*    */ import org.junit.runner.Runner;
/*    */ import org.junit.runner.manipulation.Filter;
/*    */ import org.junit.runner.manipulation.NoTestsRemainException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class FilterRequest
/*    */   extends Request
/*    */ {
/*    */   private final Request fRequest;
/*    */   private final Filter fFilter;
/*    */   
/*    */   public FilterRequest(Request classRequest, Filter filter)
/*    */   {
/* 24 */     this.fRequest = classRequest;
/* 25 */     this.fFilter = filter;
/*    */   }
/*    */   
/*    */   public Runner getRunner()
/*    */   {
/*    */     try {
/* 31 */       Runner runner = this.fRequest.getRunner();
/* 32 */       this.fFilter.apply(runner);
/* 33 */       return runner;
/*    */     } catch (NoTestsRemainException e) {}
/* 35 */     return new ErrorReportingRunner(Filter.class, new Exception(String.format("No tests found matching %s from %s", tmp46_36)));
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\junit.jar!\org\junit\internal\requests\FilterRequest.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */