/*    */ package org.junit.internal.runners;
/*    */ 
/*    */ import java.lang.reflect.InvocationTargetException;
/*    */ import java.lang.reflect.Method;
/*    */ import java.util.List;
/*    */ import org.junit.internal.AssumptionViolatedException;
/*    */ import org.junit.runner.Description;
/*    */ import org.junit.runner.notification.Failure;
/*    */ import org.junit.runner.notification.RunNotifier;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public class ClassRoadie
/*    */ {
/*    */   private RunNotifier fNotifier;
/*    */   private TestClass fTestClass;
/*    */   private Description fDescription;
/*    */   private final Runnable fRunnable;
/*    */   
/*    */   public ClassRoadie(RunNotifier notifier, TestClass testClass, Description description, Runnable runnable)
/*    */   {
/* 26 */     this.fNotifier = notifier;
/* 27 */     this.fTestClass = testClass;
/* 28 */     this.fDescription = description;
/* 29 */     this.fRunnable = runnable;
/*    */   }
/*    */   
/*    */   protected void runUnprotected() {
/* 33 */     this.fRunnable.run();
/*    */   }
/*    */   
/*    */ 
/*    */   protected void addFailure(Throwable targetException)
/*    */   {
/* 39 */     this.fNotifier.fireTestFailure(new Failure(this.fDescription, targetException));
/*    */   }
/*    */   
/*    */   public void runProtected() {
/*    */     try {
/* 44 */       runBefores();
/* 45 */       runUnprotected();
/*    */     }
/*    */     catch (FailedBefore e) {}finally {
/* 48 */       runAfters();
/*    */     }
/*    */   }
/*    */   
/*    */   private void runBefores() throws FailedBefore {
/*    */     try {
/*    */       try {
/* 55 */         List<Method> befores = this.fTestClass.getBefores();
/* 56 */         for (Method before : befores) {
/* 57 */           before.invoke(null, new Object[0]);
/*    */         }
/*    */       } catch (InvocationTargetException e) {
/* 60 */         throw e.getTargetException();
/*    */       }
/*    */     } catch (AssumptionViolatedException e) {
/* 63 */       throw new FailedBefore();
/*    */     } catch (Throwable e) {
/* 65 */       addFailure(e);
/* 66 */       throw new FailedBefore();
/*    */     }
/*    */   }
/*    */   
/*    */   private void runAfters() {
/* 71 */     List<Method> afters = this.fTestClass.getAfters();
/* 72 */     for (Method after : afters) {
/*    */       try {
/* 74 */         after.invoke(null, new Object[0]);
/*    */       } catch (InvocationTargetException e) {
/* 76 */         addFailure(e.getTargetException());
/*    */       } catch (Throwable e) {
/* 78 */         addFailure(e);
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\junit.jar!\org\junit\internal\runners\ClassRoadie.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */