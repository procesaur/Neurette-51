/*     */ package org.junit.internal.runners;
/*     */ 
/*     */ import junit.extensions.TestDecorator;
/*     */ import junit.framework.Test;
/*     */ import junit.framework.TestCase;
/*     */ import junit.framework.TestListener;
/*     */ import junit.framework.TestResult;
/*     */ import junit.framework.TestSuite;
/*     */ import org.junit.runner.Describable;
/*     */ import org.junit.runner.Description;
/*     */ import org.junit.runner.manipulation.Filter;
/*     */ import org.junit.runner.manipulation.Filterable;
/*     */ import org.junit.runner.manipulation.Sortable;
/*     */ import org.junit.runner.notification.Failure;
/*     */ import org.junit.runner.notification.RunNotifier;
/*     */ 
/*     */ public class JUnit38ClassRunner extends org.junit.runner.Runner implements Filterable, Sortable
/*     */ {
/*     */   private Test fTest;
/*     */   
/*     */   private final class OldTestClassAdaptingListener implements TestListener
/*     */   {
/*     */     private final RunNotifier fNotifier;
/*     */     
/*     */     private OldTestClassAdaptingListener(RunNotifier notifier)
/*     */     {
/*  27 */       this.fNotifier = notifier;
/*     */     }
/*     */     
/*     */     public void endTest(Test test) {
/*  31 */       this.fNotifier.fireTestFinished(asDescription(test));
/*     */     }
/*     */     
/*     */     public void startTest(Test test) {
/*  35 */       this.fNotifier.fireTestStarted(asDescription(test));
/*     */     }
/*     */     
/*     */     public void addError(Test test, Throwable t)
/*     */     {
/*  40 */       Failure failure = new Failure(asDescription(test), t);
/*  41 */       this.fNotifier.fireTestFailure(failure);
/*     */     }
/*     */     
/*     */     private Description asDescription(Test test) {
/*  45 */       if ((test instanceof Describable)) {
/*  46 */         Describable facade = (Describable)test;
/*  47 */         return facade.getDescription();
/*     */       }
/*  49 */       return Description.createTestDescription(getEffectiveClass(test), getName(test));
/*     */     }
/*     */     
/*     */     private Class<? extends Test> getEffectiveClass(Test test) {
/*  53 */       return test.getClass();
/*     */     }
/*     */     
/*     */     private String getName(Test test) {
/*  57 */       if ((test instanceof TestCase)) {
/*  58 */         return ((TestCase)test).getName();
/*     */       }
/*  60 */       return test.toString();
/*     */     }
/*     */     
/*     */     public void addFailure(Test test, junit.framework.AssertionFailedError t)
/*     */     {
/*  65 */       addError(test, t);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public JUnit38ClassRunner(Class<?> klass)
/*     */   {
/*  72 */     this(new TestSuite(klass.asSubclass(TestCase.class)));
/*     */   }
/*     */   
/*     */   public JUnit38ClassRunner(Test test)
/*     */   {
/*  77 */     setTest(test);
/*     */   }
/*     */   
/*     */   public void run(RunNotifier notifier)
/*     */   {
/*  82 */     TestResult result = new TestResult();
/*  83 */     result.addListener(createAdaptingListener(notifier));
/*  84 */     getTest().run(result);
/*     */   }
/*     */   
/*     */   public TestListener createAdaptingListener(RunNotifier notifier) {
/*  88 */     return new OldTestClassAdaptingListener(notifier, null);
/*     */   }
/*     */   
/*     */   public Description getDescription()
/*     */   {
/*  93 */     return makeDescription(getTest());
/*     */   }
/*     */   
/*     */   private static Description makeDescription(Test test) {
/*  97 */     if ((test instanceof TestCase)) {
/*  98 */       TestCase tc = (TestCase)test;
/*  99 */       return Description.createTestDescription(tc.getClass(), tc.getName()); }
/* 100 */     if ((test instanceof TestSuite)) {
/* 101 */       TestSuite ts = (TestSuite)test;
/* 102 */       String name = ts.getName() == null ? createSuiteDescription(ts) : ts.getName();
/* 103 */       Description description = Description.createSuiteDescription(name, new java.lang.annotation.Annotation[0]);
/* 104 */       int n = ts.testCount();
/* 105 */       for (int i = 0; i < n; i++) {
/* 106 */         Description made = makeDescription(ts.testAt(i));
/* 107 */         description.addChild(made);
/*     */       }
/* 109 */       return description; }
/* 110 */     if ((test instanceof Describable)) {
/* 111 */       Describable adapter = (Describable)test;
/* 112 */       return adapter.getDescription(); }
/* 113 */     if ((test instanceof TestDecorator)) {
/* 114 */       TestDecorator decorator = (TestDecorator)test;
/* 115 */       return makeDescription(decorator.getTest());
/*     */     }
/*     */     
/* 118 */     return Description.createSuiteDescription(test.getClass());
/*     */   }
/*     */   
/*     */   private static String createSuiteDescription(TestSuite ts)
/*     */   {
/* 123 */     int count = ts.countTestCases();
/* 124 */     String example = count == 0 ? "" : String.format(" [example: %s]", new Object[] { ts.testAt(0) });
/* 125 */     return String.format("TestSuite with %s tests%s", new Object[] { Integer.valueOf(count), example });
/*     */   }
/*     */   
/*     */   public void filter(Filter filter) throws org.junit.runner.manipulation.NoTestsRemainException {
/* 129 */     if ((getTest() instanceof Filterable)) {
/* 130 */       Filterable adapter = (Filterable)getTest();
/* 131 */       adapter.filter(filter);
/* 132 */     } else if ((getTest() instanceof TestSuite)) {
/* 133 */       TestSuite suite = (TestSuite)getTest();
/* 134 */       TestSuite filtered = new TestSuite(suite.getName());
/* 135 */       int n = suite.testCount();
/* 136 */       for (int i = 0; i < n; i++) {
/* 137 */         Test test = suite.testAt(i);
/* 138 */         if (filter.shouldRun(makeDescription(test))) {
/* 139 */           filtered.addTest(test);
/*     */         }
/*     */       }
/* 142 */       setTest(filtered);
/*     */     }
/*     */   }
/*     */   
/*     */   public void sort(org.junit.runner.manipulation.Sorter sorter) {
/* 147 */     if ((getTest() instanceof Sortable)) {
/* 148 */       Sortable adapter = (Sortable)getTest();
/* 149 */       adapter.sort(sorter);
/*     */     }
/*     */   }
/*     */   
/*     */   private void setTest(Test test) {
/* 154 */     this.fTest = test;
/*     */   }
/*     */   
/*     */   private Test getTest() {
/* 158 */     return this.fTest;
/*     */   }
/*     */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\junit.jar!\org\junit\internal\runners\JUnit38ClassRunner.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */