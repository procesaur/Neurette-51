/*    */ package org.junit.internal.runners;
/*    */ 
/*    */ import java.lang.reflect.InvocationTargetException;
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ import org.junit.runner.Description;
/*    */ import org.junit.runner.Runner;
/*    */ import org.junit.runner.notification.Failure;
/*    */ import org.junit.runner.notification.RunNotifier;
/*    */ 
/*    */ public class ErrorReportingRunner
/*    */   extends Runner
/*    */ {
/*    */   private final List<Throwable> fCauses;
/*    */   private final Class<?> fTestClass;
/*    */   
/*    */   public ErrorReportingRunner(Class<?> testClass, Throwable cause)
/*    */   {
/* 19 */     this.fTestClass = testClass;
/* 20 */     this.fCauses = getCauses(cause);
/*    */   }
/*    */   
/*    */   public Description getDescription()
/*    */   {
/* 25 */     Description description = Description.createSuiteDescription(this.fTestClass);
/* 26 */     for (Throwable each : this.fCauses) {
/* 27 */       description.addChild(describeCause(each));
/*    */     }
/* 29 */     return description;
/*    */   }
/*    */   
/*    */   public void run(RunNotifier notifier)
/*    */   {
/* 34 */     for (Throwable each : this.fCauses) {
/* 35 */       runCause(each, notifier);
/*    */     }
/*    */   }
/*    */   
/*    */   private List<Throwable> getCauses(Throwable cause)
/*    */   {
/* 41 */     if ((cause instanceof InvocationTargetException)) {
/* 42 */       return getCauses(cause.getCause());
/*    */     }
/* 44 */     if ((cause instanceof org.junit.runners.model.InitializationError)) {
/* 45 */       return ((org.junit.runners.model.InitializationError)cause).getCauses();
/*    */     }
/* 47 */     if ((cause instanceof InitializationError)) {
/* 48 */       return ((InitializationError)cause).getCauses();
/*    */     }
/*    */     
/* 51 */     return Arrays.asList(new Throwable[] { cause });
/*    */   }
/*    */   
/*    */   private Description describeCause(Throwable child) {
/* 55 */     return Description.createTestDescription(this.fTestClass, "initializationError");
/*    */   }
/*    */   
/*    */   private void runCause(Throwable child, RunNotifier notifier)
/*    */   {
/* 60 */     Description description = describeCause(child);
/* 61 */     notifier.fireTestStarted(description);
/* 62 */     notifier.fireTestFailure(new Failure(description, child));
/* 63 */     notifier.fireTestFinished(description);
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\junit.jar!\org\junit\internal\runners\ErrorReportingRunner.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */