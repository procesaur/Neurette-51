/*    */ package org.junit.internal.runners.statements;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import org.junit.runners.model.FrameworkMethod;
/*    */ import org.junit.runners.model.MultipleFailureException;
/*    */ import org.junit.runners.model.Statement;
/*    */ 
/*    */ public class RunAfters extends Statement
/*    */ {
/*    */   private final Statement fNext;
/*    */   private final Object fTarget;
/*    */   private final List<FrameworkMethod> fAfters;
/*    */   
/*    */   public RunAfters(Statement next, List<FrameworkMethod> afters, Object target)
/*    */   {
/* 18 */     this.fNext = next;
/* 19 */     this.fAfters = afters;
/* 20 */     this.fTarget = target;
/*    */   }
/*    */   
/*    */   public void evaluate() throws Throwable
/*    */   {
/* 25 */     List<Throwable> errors = new ArrayList();
/*    */     try {
/* 27 */       this.fNext.evaluate(); } catch (Throwable e) { Iterator i$;
/*    */       FrameworkMethod each;
/* 29 */       errors.add(e); } finally { Iterator i$;
/*    */       FrameworkMethod each;
/* 31 */       for (FrameworkMethod each : this.fAfters) {
/*    */         try {
/* 33 */           each.invokeExplosively(this.fTarget, new Object[0]);
/*    */         } catch (Throwable e) {
/* 35 */           errors.add(e);
/*    */         }
/*    */       }
/*    */     }
/* 39 */     MultipleFailureException.assertEmpty(errors);
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\junit.jar!\org\junit\internal\runners\statements\RunAfters.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */