/*    */ package org.junit.internal.runners.statements;
/*    */ 
/*    */ import org.junit.runners.model.FrameworkMethod;
/*    */ 
/*    */ public class InvokeMethod extends org.junit.runners.model.Statement
/*    */ {
/*    */   private final FrameworkMethod fTestMethod;
/*    */   private Object fTarget;
/*    */   
/*    */   public InvokeMethod(FrameworkMethod testMethod, Object target) {
/* 11 */     this.fTestMethod = testMethod;
/* 12 */     this.fTarget = target;
/*    */   }
/*    */   
/*    */   public void evaluate() throws Throwable
/*    */   {
/* 17 */     this.fTestMethod.invokeExplosively(this.fTarget, new Object[0]);
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\junit.jar!\org\junit\internal\runners\statements\InvokeMethod.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */