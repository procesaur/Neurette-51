/*    */ package org.junit.internal.runners.statements;
/*    */ 
/*    */ import org.junit.runners.model.Statement;
/*    */ 
/*    */ public class Fail extends Statement {
/*    */   private final Throwable fError;
/*    */   
/*    */   public Fail(Throwable e) {
/*  9 */     this.fError = e;
/*    */   }
/*    */   
/*    */   public void evaluate() throws Throwable
/*    */   {
/* 14 */     throw this.fError;
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\junit.jar!\org\junit\internal\runners\statements\Fail.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */