/*    */ package org.junit.internal.runners.statements;
/*    */ 
/*    */ import org.junit.runners.model.Statement;
/*    */ 
/*    */ public class ExpectException extends Statement
/*    */ {
/*    */   private Statement fNext;
/*    */   private final Class<? extends Throwable> fExpected;
/*    */   
/*    */   public ExpectException(Statement next, Class<? extends Throwable> expected) {
/* 11 */     this.fNext = next;
/* 12 */     this.fExpected = expected;
/*    */   }
/*    */   
/*    */   public void evaluate() throws Exception
/*    */   {
/* 17 */     boolean complete = false;
/*    */     try {
/* 19 */       this.fNext.evaluate();
/* 20 */       complete = true;
/*    */     } catch (org.junit.internal.AssumptionViolatedException e) {
/* 22 */       throw e;
/*    */     } catch (Throwable e) {
/* 24 */       if (!this.fExpected.isAssignableFrom(e.getClass())) {
/* 25 */         String message = "Unexpected exception, expected<" + this.fExpected.getName() + "> but was<" + e.getClass().getName() + ">";
/*    */         
/*    */ 
/* 28 */         throw new Exception(message, e);
/*    */       }
/*    */     }
/* 31 */     if (complete) {
/* 32 */       throw new AssertionError("Expected exception: " + this.fExpected.getName());
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\junit.jar!\org\junit\internal\runners\statements\ExpectException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */