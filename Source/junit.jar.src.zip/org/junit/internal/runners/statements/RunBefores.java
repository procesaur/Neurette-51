/*    */ package org.junit.internal.runners.statements;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.junit.runners.model.FrameworkMethod;
/*    */ import org.junit.runners.model.Statement;
/*    */ 
/*    */ public class RunBefores
/*    */   extends Statement
/*    */ {
/*    */   private final Statement fNext;
/*    */   private final Object fTarget;
/*    */   private final List<FrameworkMethod> fBefores;
/*    */   
/*    */   public RunBefores(Statement next, List<FrameworkMethod> befores, Object target)
/*    */   {
/* 16 */     this.fNext = next;
/* 17 */     this.fBefores = befores;
/* 18 */     this.fTarget = target;
/*    */   }
/*    */   
/*    */   public void evaluate() throws Throwable
/*    */   {
/* 23 */     for (FrameworkMethod before : this.fBefores) {
/* 24 */       before.invokeExplosively(this.fTarget, new Object[0]);
/*    */     }
/* 26 */     this.fNext.evaluate();
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\junit.jar!\org\junit\internal\runners\statements\RunBefores.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */