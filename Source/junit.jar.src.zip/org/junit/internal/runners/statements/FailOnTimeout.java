/*    */ package org.junit.internal.runners.statements;
/*    */ 
/*    */ import org.junit.runners.model.Statement;
/*    */ 
/*    */ public class FailOnTimeout extends Statement
/*    */ {
/*    */   private final Statement fOriginalStatement;
/*    */   private final long fTimeout;
/*    */   
/*    */   public FailOnTimeout(Statement originalStatement, long timeout) {
/* 11 */     this.fOriginalStatement = originalStatement;
/* 12 */     this.fTimeout = timeout;
/*    */   }
/*    */   
/*    */   public void evaluate() throws Throwable
/*    */   {
/* 17 */     StatementThread thread = evaluateStatement();
/* 18 */     if (!thread.fFinished) {
/* 19 */       throwExceptionForUnfinishedThread(thread);
/*    */     }
/*    */   }
/*    */   
/*    */   private StatementThread evaluateStatement() throws InterruptedException {
/* 24 */     StatementThread thread = new StatementThread(this.fOriginalStatement);
/* 25 */     thread.start();
/* 26 */     thread.join(this.fTimeout);
/* 27 */     if (!thread.fFinished) {
/* 28 */       thread.recordStackTrace();
/*    */     }
/* 30 */     thread.interrupt();
/* 31 */     return thread;
/*    */   }
/*    */   
/*    */   private void throwExceptionForUnfinishedThread(StatementThread thread) throws Throwable
/*    */   {
/* 36 */     if (thread.fExceptionThrownByOriginalStatement != null) {
/* 37 */       throw thread.fExceptionThrownByOriginalStatement;
/*    */     }
/* 39 */     throwTimeoutException(thread);
/*    */   }
/*    */   
/*    */   private void throwTimeoutException(StatementThread thread) throws Exception
/*    */   {
/* 44 */     Exception exception = new Exception(String.format("test timed out after %d milliseconds", new Object[] { Long.valueOf(this.fTimeout) }));
/*    */     
/* 46 */     exception.setStackTrace(thread.getRecordedStackTrace());
/* 47 */     throw exception;
/*    */   }
/*    */   
/*    */   private static class StatementThread extends Thread
/*    */   {
/*    */     private final Statement fStatement;
/* 53 */     private boolean fFinished = false;
/*    */     
/* 55 */     private Throwable fExceptionThrownByOriginalStatement = null;
/*    */     
/* 57 */     private StackTraceElement[] fRecordedStackTrace = null;
/*    */     
/*    */     public StatementThread(Statement statement) {
/* 60 */       this.fStatement = statement;
/*    */     }
/*    */     
/*    */     public void recordStackTrace() {
/* 64 */       this.fRecordedStackTrace = getStackTrace();
/*    */     }
/*    */     
/*    */     public StackTraceElement[] getRecordedStackTrace() {
/* 68 */       return this.fRecordedStackTrace;
/*    */     }
/*    */     
/*    */     public void run()
/*    */     {
/*    */       try {
/* 74 */         this.fStatement.evaluate();
/* 75 */         this.fFinished = true;
/*    */       }
/*    */       catch (InterruptedException e) {}catch (Throwable e)
/*    */       {
/* 79 */         this.fExceptionThrownByOriginalStatement = e;
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\junit.jar!\org\junit\internal\runners\statements\FailOnTimeout.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */