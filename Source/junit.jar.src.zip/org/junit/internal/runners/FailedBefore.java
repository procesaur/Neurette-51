package org.junit.internal.runners;

@Deprecated
class FailedBefore
  extends Exception
{
  private static final long serialVersionUID = 1L;
}


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\junit.jar!\org\junit\internal\runners\FailedBefore.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */