/*     */ package org.junit.internal.runners;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.Future;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.TimeoutException;
/*     */ import org.junit.internal.AssumptionViolatedException;
/*     */ import org.junit.runner.Description;
/*     */ import org.junit.runner.notification.Failure;
/*     */ import org.junit.runner.notification.RunNotifier;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class MethodRoadie
/*     */ {
/*     */   private final Object fTest;
/*     */   private final RunNotifier fNotifier;
/*     */   private final Description fDescription;
/*     */   private TestMethod fTestMethod;
/*     */   
/*     */   public MethodRoadie(Object test, TestMethod method, RunNotifier notifier, Description description)
/*     */   {
/*  32 */     this.fTest = test;
/*  33 */     this.fNotifier = notifier;
/*  34 */     this.fDescription = description;
/*  35 */     this.fTestMethod = method;
/*     */   }
/*     */   
/*     */   public void run() {
/*  39 */     if (this.fTestMethod.isIgnored()) {
/*  40 */       this.fNotifier.fireTestIgnored(this.fDescription);
/*  41 */       return;
/*     */     }
/*  43 */     this.fNotifier.fireTestStarted(this.fDescription);
/*     */     try {
/*  45 */       long timeout = this.fTestMethod.getTimeout();
/*  46 */       if (timeout > 0L) {
/*  47 */         runWithTimeout(timeout);
/*     */       } else {
/*  49 */         runTest();
/*     */       }
/*     */     } finally {
/*  52 */       this.fNotifier.fireTestFinished(this.fDescription);
/*     */     }
/*     */   }
/*     */   
/*     */   private void runWithTimeout(final long timeout) {
/*  57 */     runBeforesThenTestThenAfters(new Runnable()
/*     */     {
/*     */       public void run() {
/*  60 */         ExecutorService service = Executors.newSingleThreadExecutor();
/*  61 */         Callable<Object> callable = new Callable() {
/*     */           public Object call() throws Exception {
/*  63 */             MethodRoadie.this.runTestMethod();
/*  64 */             return null;
/*     */           }
/*  66 */         };
/*  67 */         Future<Object> result = service.submit(callable);
/*  68 */         service.shutdown();
/*     */         try {
/*  70 */           boolean terminated = service.awaitTermination(timeout, TimeUnit.MILLISECONDS);
/*     */           
/*  72 */           if (!terminated) {
/*  73 */             service.shutdownNow();
/*     */           }
/*  75 */           result.get(0L, TimeUnit.MILLISECONDS);
/*     */         } catch (TimeoutException e) {
/*  77 */           MethodRoadie.this.addFailure(new Exception(String.format("test timed out after %d milliseconds", new Object[] { Long.valueOf(timeout) })));
/*     */         } catch (Exception e) {
/*  79 */           MethodRoadie.this.addFailure(e);
/*     */         }
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */   public void runTest() {
/*  86 */     runBeforesThenTestThenAfters(new Runnable() {
/*     */       public void run() {
/*  88 */         MethodRoadie.this.runTestMethod();
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */   public void runBeforesThenTestThenAfters(Runnable test) {
/*     */     try {
/*  95 */       runBefores();
/*  96 */       test.run();
/*     */     }
/*     */     catch (FailedBefore e) {}catch (Exception e) {
/*  99 */       throw new RuntimeException("test should never throw an exception to this level");
/*     */     } finally {
/* 101 */       runAfters();
/*     */     }
/*     */   }
/*     */   
/*     */   protected void runTestMethod() {
/*     */     try {
/* 107 */       this.fTestMethod.invoke(this.fTest);
/* 108 */       if (this.fTestMethod.expectsException()) {
/* 109 */         addFailure(new AssertionError("Expected exception: " + this.fTestMethod.getExpectedException().getName()));
/*     */       }
/*     */     } catch (InvocationTargetException e) {
/* 112 */       Throwable actual = e.getTargetException();
/* 113 */       if ((actual instanceof AssumptionViolatedException))
/* 114 */         return;
/* 115 */       if (!this.fTestMethod.expectsException()) {
/* 116 */         addFailure(actual);
/* 117 */       } else if (this.fTestMethod.isUnexpected(actual)) {
/* 118 */         String message = "Unexpected exception, expected<" + this.fTestMethod.getExpectedException().getName() + "> but was<" + actual.getClass().getName() + ">";
/*     */         
/* 120 */         addFailure(new Exception(message, actual));
/*     */       }
/*     */     } catch (Throwable e) {
/* 123 */       addFailure(e);
/*     */     }
/*     */   }
/*     */   
/*     */   private void runBefores() throws FailedBefore {
/*     */     try {
/*     */       try {
/* 130 */         List<Method> befores = this.fTestMethod.getBefores();
/* 131 */         for (Method before : befores) {
/* 132 */           before.invoke(this.fTest, new Object[0]);
/*     */         }
/*     */       } catch (InvocationTargetException e) {
/* 135 */         throw e.getTargetException();
/*     */       }
/*     */     } catch (AssumptionViolatedException e) {
/* 138 */       throw new FailedBefore();
/*     */     } catch (Throwable e) {
/* 140 */       addFailure(e);
/* 141 */       throw new FailedBefore();
/*     */     }
/*     */   }
/*     */   
/*     */   private void runAfters() {
/* 146 */     List<Method> afters = this.fTestMethod.getAfters();
/* 147 */     for (Method after : afters) {
/*     */       try {
/* 149 */         after.invoke(this.fTest, new Object[0]);
/*     */       } catch (InvocationTargetException e) {
/* 151 */         addFailure(e.getTargetException());
/*     */       } catch (Throwable e) {
/* 153 */         addFailure(e);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addFailure(Throwable e) {
/* 159 */     this.fNotifier.fireTestFailure(new Failure(this.fDescription, e));
/*     */   }
/*     */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\junit.jar!\org\junit\internal\runners\MethodRoadie.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */