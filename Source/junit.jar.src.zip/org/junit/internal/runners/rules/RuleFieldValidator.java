/*     */ package org.junit.internal.runners.rules;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.List;
/*     */ import org.junit.ClassRule;
/*     */ import org.junit.Rule;
/*     */ import org.junit.rules.MethodRule;
/*     */ import org.junit.rules.TestRule;
/*     */ import org.junit.runners.model.FrameworkMember;
/*     */ import org.junit.runners.model.TestClass;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum RuleFieldValidator
/*     */ {
/*  30 */   CLASS_RULE_VALIDATOR(ClassRule.class, false, true), 
/*     */   
/*     */ 
/*     */ 
/*  34 */   RULE_VALIDATOR(Rule.class, false, false), 
/*     */   
/*     */ 
/*     */ 
/*  38 */   CLASS_RULE_METHOD_VALIDATOR(ClassRule.class, true, true), 
/*     */   
/*     */ 
/*     */ 
/*  42 */   RULE_METHOD_VALIDATOR(Rule.class, true, false);
/*     */   
/*     */ 
/*     */   private final Class<? extends Annotation> fAnnotation;
/*     */   private final boolean fStaticMembers;
/*     */   private final boolean fMethods;
/*     */   
/*     */   private RuleFieldValidator(Class<? extends Annotation> annotation, boolean methods, boolean fStaticMembers)
/*     */   {
/*  51 */     this.fAnnotation = annotation;
/*  52 */     this.fStaticMembers = fStaticMembers;
/*  53 */     this.fMethods = methods;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void validate(TestClass target, List<Throwable> errors)
/*     */   {
/*  64 */     List<? extends FrameworkMember<?>> members = this.fMethods ? target.getAnnotatedMethods(this.fAnnotation) : target.getAnnotatedFields(this.fAnnotation);
/*     */     
/*     */ 
/*  67 */     for (FrameworkMember<?> each : members) {
/*  68 */       validateMember(each, errors);
/*     */     }
/*     */   }
/*     */   
/*     */   private void validateMember(FrameworkMember<?> member, List<Throwable> errors) {
/*  73 */     validateStatic(member, errors);
/*  74 */     validatePublic(member, errors);
/*  75 */     validateTestRuleOrMethodRule(member, errors);
/*     */   }
/*     */   
/*     */   private void validateStatic(FrameworkMember<?> member, List<Throwable> errors)
/*     */   {
/*  80 */     if ((this.fStaticMembers) && (!member.isStatic())) {
/*  81 */       addError(errors, member, "must be static.");
/*     */     }
/*  83 */     if ((!this.fStaticMembers) && (member.isStatic())) {
/*  84 */       addError(errors, member, "must not be static.");
/*     */     }
/*     */   }
/*     */   
/*     */   private void validatePublic(FrameworkMember<?> member, List<Throwable> errors) {
/*  89 */     if (!member.isPublic()) {
/*  90 */       addError(errors, member, "must be public.");
/*     */     }
/*     */   }
/*     */   
/*     */   private void validateTestRuleOrMethodRule(FrameworkMember<?> member, List<Throwable> errors)
/*     */   {
/*  96 */     if ((!isMethodRule(member)) && (!isTestRule(member))) {
/*  97 */       addError(errors, member, this.fMethods ? "must return an implementation of MethodRule or TestRule." : "must implement MethodRule or TestRule.");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private boolean isTestRule(FrameworkMember<?> member)
/*     */   {
/* 104 */     return TestRule.class.isAssignableFrom(member.getType());
/*     */   }
/*     */   
/*     */   private boolean isMethodRule(FrameworkMember<?> member)
/*     */   {
/* 109 */     return MethodRule.class.isAssignableFrom(member.getType());
/*     */   }
/*     */   
/*     */   private void addError(List<Throwable> errors, FrameworkMember<?> member, String suffix)
/*     */   {
/* 114 */     String message = "The @" + this.fAnnotation.getSimpleName() + " '" + member.getName() + "' " + suffix;
/*     */     
/* 116 */     errors.add(new Exception(message));
/*     */   }
/*     */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\junit.jar!\org\junit\internal\runners\rules\RuleFieldValidator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */