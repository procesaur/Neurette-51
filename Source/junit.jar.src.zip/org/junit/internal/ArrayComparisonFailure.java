/*    */ package org.junit.internal;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ArrayComparisonFailure
/*    */   extends AssertionError
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/* 17 */   private List<Integer> fIndices = new ArrayList();
/*    */   
/*    */ 
/*    */ 
/*    */   private final String fMessage;
/*    */   
/*    */ 
/*    */   private final AssertionError fCause;
/*    */   
/*    */ 
/*    */ 
/*    */   public ArrayComparisonFailure(String message, AssertionError cause, int index)
/*    */   {
/* 30 */     this.fMessage = message;
/* 31 */     this.fCause = cause;
/* 32 */     addDimension(index);
/*    */   }
/*    */   
/*    */   public void addDimension(int index) {
/* 36 */     this.fIndices.add(0, Integer.valueOf(index));
/*    */   }
/*    */   
/*    */   public String getMessage()
/*    */   {
/* 41 */     StringBuilder builder = new StringBuilder();
/* 42 */     if (this.fMessage != null) {
/* 43 */       builder.append(this.fMessage);
/*    */     }
/* 45 */     builder.append("arrays first differed at element ");
/* 46 */     for (Iterator i$ = this.fIndices.iterator(); i$.hasNext();) { int each = ((Integer)i$.next()).intValue();
/* 47 */       builder.append("[");
/* 48 */       builder.append(each);
/* 49 */       builder.append("]");
/*    */     }
/* 51 */     builder.append("; ");
/* 52 */     builder.append(this.fCause.getMessage());
/* 53 */     return builder.toString();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public String toString()
/*    */   {
/* 61 */     return getMessage();
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\junit.jar!\org\junit\internal\ArrayComparisonFailure.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */