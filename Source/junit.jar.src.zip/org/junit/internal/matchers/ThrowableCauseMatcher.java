/*    */ package org.junit.internal.matchers;
/*    */ 
/*    */ import org.hamcrest.Description;
/*    */ import org.hamcrest.Factory;
/*    */ import org.hamcrest.Matcher;
/*    */ import org.hamcrest.TypeSafeMatcher;
/*    */ 
/*    */ public class ThrowableCauseMatcher<T extends Throwable> extends TypeSafeMatcher<T>
/*    */ {
/*    */   private final Matcher<T> fMatcher;
/*    */   
/*    */   public ThrowableCauseMatcher(Matcher<T> matcher)
/*    */   {
/* 14 */     this.fMatcher = matcher;
/*    */   }
/*    */   
/*    */   public void describeTo(Description description) {
/* 18 */     description.appendText("exception with cause ");
/* 19 */     description.appendDescriptionOf(this.fMatcher);
/*    */   }
/*    */   
/*    */   protected boolean matchesSafely(T item)
/*    */   {
/* 24 */     return this.fMatcher.matches(item.getCause());
/*    */   }
/*    */   
/*    */   protected void describeMismatchSafely(T item, Description description)
/*    */   {
/* 29 */     description.appendText("cause ");
/* 30 */     this.fMatcher.describeMismatch(item.getCause(), description);
/*    */   }
/*    */   
/*    */   @Factory
/*    */   public static <T extends Throwable> Matcher<T> hasCause(Matcher<T> matcher) {
/* 35 */     return new ThrowableCauseMatcher(matcher);
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\junit.jar!\org\junit\internal\matchers\ThrowableCauseMatcher.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */