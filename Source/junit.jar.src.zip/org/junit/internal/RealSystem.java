/*   */ package org.junit.internal;
/*   */ 
/*   */ import java.io.PrintStream;
/*   */ 
/*   */ public class RealSystem implements JUnitSystem {
/*   */   public PrintStream out() {
/* 7 */     return System.out;
/*   */   }
/*   */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\junit.jar!\org\junit\internal\RealSystem.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */