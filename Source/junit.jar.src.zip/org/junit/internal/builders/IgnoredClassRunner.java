/*    */ package org.junit.internal.builders;
/*    */ 
/*    */ import org.junit.runner.notification.RunNotifier;
/*    */ 
/*    */ public class IgnoredClassRunner extends org.junit.runner.Runner
/*    */ {
/*    */   private final Class<?> fTestClass;
/*    */   
/*    */   public IgnoredClassRunner(Class<?> testClass)
/*    */   {
/* 11 */     this.fTestClass = testClass;
/*    */   }
/*    */   
/*    */   public void run(RunNotifier notifier)
/*    */   {
/* 16 */     notifier.fireTestIgnored(getDescription());
/*    */   }
/*    */   
/*    */   public org.junit.runner.Description getDescription()
/*    */   {
/* 21 */     return org.junit.runner.Description.createSuiteDescription(this.fTestClass);
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\junit.jar!\org\junit\internal\builders\IgnoredClassRunner.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */