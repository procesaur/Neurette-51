/*    */ package org.junit.internal;
/*    */ 
/*    */ import java.lang.reflect.Array;
/*    */ import org.junit.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ComparisonCriteria
/*    */ {
/*    */   public void arrayEquals(String message, Object expecteds, Object actuals)
/*    */     throws ArrayComparisonFailure
/*    */   {
/* 27 */     if (expecteds == actuals) {
/* 28 */       return;
/*    */     }
/* 30 */     String header = message + ": ";
/*    */     
/* 32 */     int expectedsLength = assertArraysAreSameLength(expecteds, actuals, header);
/*    */     
/*    */ 
/* 35 */     for (int i = 0; i < expectedsLength; i++) {
/* 36 */       Object expected = Array.get(expecteds, i);
/* 37 */       Object actual = Array.get(actuals, i);
/*    */       
/* 39 */       if ((isArray(expected)) && (isArray(actual))) {
/*    */         try {
/* 41 */           arrayEquals(message, expected, actual);
/*    */         } catch (ArrayComparisonFailure e) {
/* 43 */           e.addDimension(i);
/* 44 */           throw e;
/*    */         }
/*    */       } else {
/*    */         try {
/* 48 */           assertElementsEqual(expected, actual);
/*    */         } catch (AssertionError e) {
/* 50 */           throw new ArrayComparisonFailure(header, e, i);
/*    */         }
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   private boolean isArray(Object expected) {
/* 57 */     return (expected != null) && (expected.getClass().isArray());
/*    */   }
/*    */   
/*    */   private int assertArraysAreSameLength(Object expecteds, Object actuals, String header)
/*    */   {
/* 62 */     if (expecteds == null) {
/* 63 */       Assert.fail(header + "expected array was null");
/*    */     }
/* 65 */     if (actuals == null) {
/* 66 */       Assert.fail(header + "actual array was null");
/*    */     }
/* 68 */     int actualsLength = Array.getLength(actuals);
/* 69 */     int expectedsLength = Array.getLength(expecteds);
/* 70 */     if (actualsLength != expectedsLength) {
/* 71 */       Assert.fail(header + "array lengths differed, expected.length=" + expectedsLength + " actual.length=" + actualsLength);
/*    */     }
/*    */     
/* 74 */     return expectedsLength;
/*    */   }
/*    */   
/*    */   protected abstract void assertElementsEqual(Object paramObject1, Object paramObject2);
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\junit.jar!\org\junit\internal\ComparisonCriteria.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */