/*    */ package org.junit.internal;
/*    */ 
/*    */ import org.hamcrest.Description;
/*    */ import org.hamcrest.Matcher;
/*    */ import org.hamcrest.SelfDescribing;
/*    */ import org.hamcrest.StringDescription;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AssumptionViolatedException
/*    */   extends RuntimeException
/*    */   implements SelfDescribing
/*    */ {
/*    */   private static final long serialVersionUID = 2L;
/*    */   private final String fAssumption;
/*    */   private final boolean fValueMatcher;
/*    */   private final Object fValue;
/*    */   private final Matcher<?> fMatcher;
/*    */   
/*    */   public AssumptionViolatedException(String assumption, boolean valueMatcher, Object value, Matcher<?> matcher)
/*    */   {
/* 26 */     super((value instanceof Throwable) ? (Throwable)value : null);
/* 27 */     this.fAssumption = assumption;
/* 28 */     this.fValue = value;
/* 29 */     this.fMatcher = matcher;
/* 30 */     this.fValueMatcher = valueMatcher;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public AssumptionViolatedException(Object value, Matcher<?> matcher)
/*    */   {
/* 38 */     this(null, true, value, matcher);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public AssumptionViolatedException(String assumption, Object value, Matcher<?> matcher)
/*    */   {
/* 46 */     this(assumption, true, value, matcher);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public AssumptionViolatedException(String assumption)
/*    */   {
/* 53 */     this(assumption, false, null, null);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public AssumptionViolatedException(String assumption, Throwable t)
/*    */   {
/* 60 */     this(assumption, false, t, null);
/*    */   }
/*    */   
/*    */   public String getMessage()
/*    */   {
/* 65 */     return StringDescription.asString(this);
/*    */   }
/*    */   
/*    */   public void describeTo(Description description) {
/* 69 */     if (this.fAssumption != null) {
/* 70 */       description.appendText(this.fAssumption);
/*    */     }
/*    */     
/* 73 */     if (this.fValueMatcher) {
/* 74 */       if (this.fAssumption != null) {
/* 75 */         description.appendText(": ");
/*    */       }
/*    */       
/* 78 */       description.appendText("got: ");
/* 79 */       description.appendValue(this.fValue);
/*    */       
/* 81 */       if (this.fMatcher != null) {
/* 82 */         description.appendText(", expected: ");
/* 83 */         description.appendDescriptionOf(this.fMatcher);
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\junit.jar!\org\junit\internal\AssumptionViolatedException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */