/*     */ package org.junit.experimental.categories;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.annotation.Retention;
/*     */ import java.lang.annotation.RetentionPolicy;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import org.junit.runner.Description;
/*     */ import org.junit.runner.manipulation.Filter;
/*     */ import org.junit.runner.manipulation.NoTestsRemainException;
/*     */ import org.junit.runners.Suite;
/*     */ import org.junit.runners.model.InitializationError;
/*     */ import org.junit.runners.model.RunnerBuilder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Categories
/*     */   extends Suite
/*     */ {
/*     */   public static class CategoryFilter
/*     */     extends Filter
/*     */   {
/*     */     private final Class<?> fIncluded;
/*     */     private final Class<?> fExcluded;
/*     */     
/*     */     public static CategoryFilter include(Class<?> categoryType)
/*     */     {
/*  79 */       return new CategoryFilter(categoryType, null);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public CategoryFilter(Class<?> includedCategory, Class<?> excludedCategory)
/*     */     {
/*  88 */       this.fIncluded = includedCategory;
/*  89 */       this.fExcluded = excludedCategory;
/*     */     }
/*     */     
/*     */     public String describe()
/*     */     {
/*  94 */       return "category " + this.fIncluded;
/*     */     }
/*     */     
/*     */     public boolean shouldRun(Description description)
/*     */     {
/*  99 */       if (hasCorrectCategoryAnnotation(description)) {
/* 100 */         return true;
/*     */       }
/* 102 */       for (Description each : description.getChildren()) {
/* 103 */         if (shouldRun(each)) {
/* 104 */           return true;
/*     */         }
/*     */       }
/* 107 */       return false;
/*     */     }
/*     */     
/*     */     private boolean hasCorrectCategoryAnnotation(Description description) {
/* 111 */       List<Class<?>> categories = categories(description);
/* 112 */       if (categories.isEmpty()) {
/* 113 */         return this.fIncluded == null;
/*     */       }
/* 115 */       for (Class<?> each : categories) {
/* 116 */         if ((this.fExcluded != null) && (this.fExcluded.isAssignableFrom(each))) {
/* 117 */           return false;
/*     */         }
/*     */       }
/* 120 */       for (Class<?> each : categories) {
/* 121 */         if ((this.fIncluded == null) || (this.fIncluded.isAssignableFrom(each))) {
/* 122 */           return true;
/*     */         }
/*     */       }
/* 125 */       return false;
/*     */     }
/*     */     
/*     */     private List<Class<?>> categories(Description description) {
/* 129 */       ArrayList<Class<?>> categories = new ArrayList();
/* 130 */       categories.addAll(Arrays.asList(directCategories(description)));
/* 131 */       categories.addAll(Arrays.asList(directCategories(parentDescription(description))));
/* 132 */       return categories;
/*     */     }
/*     */     
/*     */     private Description parentDescription(Description description) {
/* 136 */       Class<?> testClass = description.getTestClass();
/* 137 */       if (testClass == null) {
/* 138 */         return null;
/*     */       }
/* 140 */       return Description.createSuiteDescription(testClass);
/*     */     }
/*     */     
/*     */     private Class<?>[] directCategories(Description description) {
/* 144 */       if (description == null) {
/* 145 */         return new Class[0];
/*     */       }
/* 147 */       Category annotation = (Category)description.getAnnotation(Category.class);
/* 148 */       if (annotation == null) {
/* 149 */         return new Class[0];
/*     */       }
/* 151 */       return annotation.value();
/*     */     }
/*     */   }
/*     */   
/*     */   public Categories(Class<?> klass, RunnerBuilder builder) throws InitializationError
/*     */   {
/* 157 */     super(klass, builder);
/*     */     try {
/* 159 */       filter(new CategoryFilter(getIncludedCategory(klass), getExcludedCategory(klass)));
/*     */     }
/*     */     catch (NoTestsRemainException e) {
/* 162 */       throw new InitializationError(e);
/*     */     }
/* 164 */     assertNoCategorizedDescendentsOfUncategorizeableParents(getDescription());
/*     */   }
/*     */   
/*     */   private Class<?> getIncludedCategory(Class<?> klass) {
/* 168 */     IncludeCategory annotation = (IncludeCategory)klass.getAnnotation(IncludeCategory.class);
/* 169 */     return annotation == null ? null : annotation.value();
/*     */   }
/*     */   
/*     */   private Class<?> getExcludedCategory(Class<?> klass) {
/* 173 */     ExcludeCategory annotation = (ExcludeCategory)klass.getAnnotation(ExcludeCategory.class);
/* 174 */     return annotation == null ? null : annotation.value();
/*     */   }
/*     */   
/*     */   private void assertNoCategorizedDescendentsOfUncategorizeableParents(Description description) throws InitializationError {
/* 178 */     if (!canHaveCategorizedChildren(description)) {
/* 179 */       assertNoDescendantsHaveCategoryAnnotations(description);
/*     */     }
/* 181 */     for (Description each : description.getChildren()) {
/* 182 */       assertNoCategorizedDescendentsOfUncategorizeableParents(each);
/*     */     }
/*     */   }
/*     */   
/*     */   private void assertNoDescendantsHaveCategoryAnnotations(Description description) throws InitializationError {
/* 187 */     for (Description each : description.getChildren()) {
/* 188 */       if (each.getAnnotation(Category.class) != null) {
/* 189 */         throw new InitializationError("Category annotations on Parameterized classes are not supported on individual methods.");
/*     */       }
/* 191 */       assertNoDescendantsHaveCategoryAnnotations(each);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private static boolean canHaveCategorizedChildren(Description description)
/*     */   {
/* 198 */     for (Description each : description.getChildren()) {
/* 199 */       if (each.getTestClass() == null) {
/* 200 */         return false;
/*     */       }
/*     */     }
/* 203 */     return true;
/*     */   }
/*     */   
/*     */   @Retention(RetentionPolicy.RUNTIME)
/*     */   public static @interface ExcludeCategory
/*     */   {
/*     */     Class<?> value();
/*     */   }
/*     */   
/*     */   @Retention(RetentionPolicy.RUNTIME)
/*     */   public static @interface IncludeCategory
/*     */   {
/*     */     Class<?> value();
/*     */   }
/*     */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\junit.jar!\org\junit\experimental\categories\Categories.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */