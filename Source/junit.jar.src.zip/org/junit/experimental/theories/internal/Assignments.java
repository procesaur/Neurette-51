/*     */ package org.junit.experimental.theories.internal;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.junit.experimental.theories.ParameterSignature;
/*     */ import org.junit.experimental.theories.ParameterSupplier;
/*     */ import org.junit.experimental.theories.ParametersSuppliedBy;
/*     */ import org.junit.experimental.theories.PotentialAssignment;
/*     */ import org.junit.experimental.theories.PotentialAssignment.CouldNotGenerateValueException;
/*     */ import org.junit.runners.model.TestClass;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Assignments
/*     */ {
/*     */   private List<PotentialAssignment> fAssigned;
/*     */   private final List<ParameterSignature> fUnassigned;
/*     */   private final TestClass fClass;
/*     */   
/*     */   private Assignments(List<PotentialAssignment> assigned, List<ParameterSignature> unassigned, TestClass testClass)
/*     */   {
/*  27 */     this.fUnassigned = unassigned;
/*  28 */     this.fAssigned = assigned;
/*  29 */     this.fClass = testClass;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Assignments allUnassigned(Method testMethod, TestClass testClass)
/*     */     throws Exception
/*     */   {
/*  39 */     List<ParameterSignature> signatures = ParameterSignature.signatures(testClass.getOnlyConstructor());
/*     */     
/*  41 */     signatures.addAll(ParameterSignature.signatures(testMethod));
/*  42 */     return new Assignments(new ArrayList(), signatures, testClass);
/*     */   }
/*     */   
/*     */   public boolean isComplete()
/*     */   {
/*  47 */     return this.fUnassigned.size() == 0;
/*     */   }
/*     */   
/*     */   public ParameterSignature nextUnassigned() {
/*  51 */     return (ParameterSignature)this.fUnassigned.get(0);
/*     */   }
/*     */   
/*     */   public Assignments assignNext(PotentialAssignment source) {
/*  55 */     List<PotentialAssignment> assigned = new ArrayList(this.fAssigned);
/*     */     
/*  57 */     assigned.add(source);
/*     */     
/*  59 */     return new Assignments(assigned, this.fUnassigned.subList(1, this.fUnassigned.size()), this.fClass);
/*     */   }
/*     */   
/*     */   public Object[] getActualValues(int start, int stop, boolean nullsOk)
/*     */     throws PotentialAssignment.CouldNotGenerateValueException
/*     */   {
/*  65 */     Object[] values = new Object[stop - start];
/*  66 */     for (int i = start; i < stop; i++) {
/*  67 */       Object value = ((PotentialAssignment)this.fAssigned.get(i)).getValue();
/*  68 */       if ((value == null) && (!nullsOk)) {
/*  69 */         throw new PotentialAssignment.CouldNotGenerateValueException();
/*     */       }
/*  71 */       values[(i - start)] = value;
/*     */     }
/*  73 */     return values;
/*     */   }
/*     */   
/*     */   public List<PotentialAssignment> potentialsForNextUnassigned() throws InstantiationException, IllegalAccessException
/*     */   {
/*  78 */     ParameterSignature unassigned = nextUnassigned();
/*  79 */     return getSupplier(unassigned).getValueSources(unassigned);
/*     */   }
/*     */   
/*     */   public ParameterSupplier getSupplier(ParameterSignature unassigned) throws InstantiationException, IllegalAccessException
/*     */   {
/*  84 */     ParameterSupplier supplier = getAnnotatedSupplier(unassigned);
/*  85 */     if (supplier != null) {
/*  86 */       return supplier;
/*     */     }
/*     */     
/*  89 */     return new AllMembersSupplier(this.fClass);
/*     */   }
/*     */   
/*     */   public ParameterSupplier getAnnotatedSupplier(ParameterSignature unassigned) throws InstantiationException, IllegalAccessException
/*     */   {
/*  94 */     ParametersSuppliedBy annotation = (ParametersSuppliedBy)unassigned.findDeepAnnotation(ParametersSuppliedBy.class);
/*     */     
/*  96 */     if (annotation == null) {
/*  97 */       return null;
/*     */     }
/*  99 */     return (ParameterSupplier)annotation.value().newInstance();
/*     */   }
/*     */   
/*     */   public Object[] getConstructorArguments(boolean nullsOk) throws PotentialAssignment.CouldNotGenerateValueException
/*     */   {
/* 104 */     return getActualValues(0, getConstructorParameterCount(), nullsOk);
/*     */   }
/*     */   
/*     */   public Object[] getMethodArguments(boolean nullsOk) throws PotentialAssignment.CouldNotGenerateValueException
/*     */   {
/* 109 */     return getActualValues(getConstructorParameterCount(), this.fAssigned.size(), nullsOk);
/*     */   }
/*     */   
/*     */   public Object[] getAllArguments(boolean nullsOk)
/*     */     throws PotentialAssignment.CouldNotGenerateValueException
/*     */   {
/* 115 */     return getActualValues(0, this.fAssigned.size(), nullsOk);
/*     */   }
/*     */   
/*     */   private int getConstructorParameterCount() {
/* 119 */     List<ParameterSignature> signatures = ParameterSignature.signatures(this.fClass.getOnlyConstructor());
/*     */     
/* 121 */     int constructorParameterCount = signatures.size();
/* 122 */     return constructorParameterCount;
/*     */   }
/*     */   
/*     */   public Object[] getArgumentStrings(boolean nullsOk) throws PotentialAssignment.CouldNotGenerateValueException
/*     */   {
/* 127 */     Object[] values = new Object[this.fAssigned.size()];
/* 128 */     for (int i = 0; i < values.length; i++) {
/* 129 */       values[i] = ((PotentialAssignment)this.fAssigned.get(i)).getDescription();
/*     */     }
/* 131 */     return values;
/*     */   }
/*     */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\junit.jar!\org\junit\experimental\theories\internal\Assignments.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */