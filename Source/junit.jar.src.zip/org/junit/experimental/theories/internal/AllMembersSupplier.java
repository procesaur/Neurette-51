/*     */ package org.junit.experimental.theories.internal;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.List;
/*     */ import org.junit.experimental.theories.DataPoint;
/*     */ import org.junit.experimental.theories.DataPoints;
/*     */ import org.junit.experimental.theories.ParameterSignature;
/*     */ import org.junit.experimental.theories.PotentialAssignment;
/*     */ import org.junit.experimental.theories.PotentialAssignment.CouldNotGenerateValueException;
/*     */ import org.junit.runners.model.FrameworkMethod;
/*     */ import org.junit.runners.model.TestClass;
/*     */ 
/*     */ public class AllMembersSupplier extends org.junit.experimental.theories.ParameterSupplier
/*     */ {
/*     */   private final TestClass fClass;
/*     */   
/*     */   static class MethodParameterValue extends PotentialAssignment
/*     */   {
/*     */     private final FrameworkMethod fMethod;
/*     */     
/*     */     private MethodParameterValue(FrameworkMethod dataPointMethod)
/*     */     {
/*  25 */       this.fMethod = dataPointMethod;
/*     */     }
/*     */     
/*     */     public Object getValue() throws PotentialAssignment.CouldNotGenerateValueException
/*     */     {
/*     */       try {
/*  31 */         return this.fMethod.invokeExplosively(null, new Object[0]);
/*     */       } catch (IllegalArgumentException e) {
/*  33 */         throw new RuntimeException("unexpected: argument length is checked");
/*     */       }
/*     */       catch (IllegalAccessException e) {
/*  36 */         throw new RuntimeException("unexpected: getMethods returned an inaccessible method");
/*     */       }
/*     */       catch (Throwable e) {
/*  39 */         throw new PotentialAssignment.CouldNotGenerateValueException();
/*     */       }
/*     */     }
/*     */     
/*     */     public String getDescription()
/*     */       throws PotentialAssignment.CouldNotGenerateValueException
/*     */     {
/*  46 */       return this.fMethod.getName();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AllMembersSupplier(TestClass type)
/*     */   {
/*  56 */     this.fClass = type;
/*     */   }
/*     */   
/*     */   public List<PotentialAssignment> getValueSources(ParameterSignature sig)
/*     */   {
/*  61 */     List<PotentialAssignment> list = new java.util.ArrayList();
/*     */     
/*  63 */     addFields(sig, list);
/*  64 */     addSinglePointMethods(sig, list);
/*  65 */     addMultiPointMethods(sig, list);
/*     */     
/*  67 */     return list;
/*     */   }
/*     */   
/*     */   private void addMultiPointMethods(ParameterSignature sig, List<PotentialAssignment> list) {
/*  71 */     for (FrameworkMethod dataPointsMethod : this.fClass.getAnnotatedMethods(DataPoints.class)) {
/*     */       try
/*     */       {
/*  74 */         addMultiPointArrayValues(sig, dataPointsMethod.getName(), list, dataPointsMethod.invokeExplosively(null, new Object[0]));
/*     */       }
/*     */       catch (Throwable e) {}
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private void addSinglePointMethods(ParameterSignature sig, List<PotentialAssignment> list)
/*     */   {
/*  83 */     for (FrameworkMethod dataPointMethod : this.fClass.getAnnotatedMethods(DataPoint.class))
/*     */     {
/*  85 */       if (isCorrectlyTyped(sig, dataPointMethod.getType())) {
/*  86 */         list.add(new MethodParameterValue(dataPointMethod, null));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void addFields(ParameterSignature sig, List<PotentialAssignment> list)
/*     */   {
/*  93 */     for (Field field : this.fClass.getJavaClass().getFields()) {
/*  94 */       if (Modifier.isStatic(field.getModifiers())) {
/*  95 */         Class<?> type = field.getType();
/*  96 */         if ((sig.canAcceptArrayType(type)) && (field.getAnnotation(DataPoints.class) != null)) {
/*     */           try
/*     */           {
/*  99 */             addArrayValues(field.getName(), list, getStaticFieldValue(field));
/*     */ 
/*     */           }
/*     */           catch (Throwable e) {}
/* 103 */         } else if ((sig.canAcceptType(type)) && (field.getAnnotation(DataPoint.class) != null))
/*     */         {
/* 105 */           list.add(PotentialAssignment.forValue(field.getName(), getStaticFieldValue(field)));
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void addArrayValues(String name, List<PotentialAssignment> list, Object array)
/*     */   {
/* 113 */     for (int i = 0; i < Array.getLength(array); i++) {
/* 114 */       list.add(PotentialAssignment.forValue(name + "[" + i + "]", Array.get(array, i)));
/*     */     }
/*     */   }
/*     */   
/*     */   private void addMultiPointArrayValues(ParameterSignature sig, String name, List<PotentialAssignment> list, Object array) throws Throwable
/*     */   {
/* 120 */     for (int i = 0; i < Array.getLength(array); i++) {
/* 121 */       if (!isCorrectlyTyped(sig, Array.get(array, i).getClass())) {
/* 122 */         return;
/*     */       }
/* 124 */       list.add(PotentialAssignment.forValue(name + "[" + i + "]", Array.get(array, i)));
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean isCorrectlyTyped(ParameterSignature parameterSignature, Class<?> type)
/*     */   {
/* 130 */     return parameterSignature.canAcceptType(type);
/*     */   }
/*     */   
/*     */   private Object getStaticFieldValue(Field field) {
/*     */     try {
/* 135 */       return field.get(null);
/*     */     } catch (IllegalArgumentException e) {
/* 137 */       throw new RuntimeException("unexpected: field from getClass doesn't exist on object");
/*     */     }
/*     */     catch (IllegalAccessException e) {
/* 140 */       throw new RuntimeException("unexpected: getFields returned an inaccessible field");
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\junit.jar!\org\junit\experimental\theories\internal\AllMembersSupplier.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */