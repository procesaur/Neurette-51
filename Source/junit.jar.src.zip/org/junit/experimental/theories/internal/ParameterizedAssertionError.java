/*    */ package org.junit.experimental.theories.internal;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import java.util.Iterator;
/*    */ 
/*    */ public class ParameterizedAssertionError extends RuntimeException
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public ParameterizedAssertionError(Throwable targetException, String methodName, Object... params)
/*    */   {
/* 12 */     super(String.format("%s(%s)", new Object[] { methodName, join(", ", params) }), targetException);
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean equals(Object obj)
/*    */   {
/* 18 */     return toString().equals(obj.toString());
/*    */   }
/*    */   
/*    */   public static String join(String delimiter, Object... params) {
/* 22 */     return join(delimiter, java.util.Arrays.asList(params));
/*    */   }
/*    */   
/*    */   public static String join(String delimiter, Collection<Object> values)
/*    */   {
/* 27 */     StringBuffer buffer = new StringBuffer();
/* 28 */     Iterator<Object> iter = values.iterator();
/* 29 */     while (iter.hasNext()) {
/* 30 */       Object next = iter.next();
/* 31 */       buffer.append(stringValueOf(next));
/* 32 */       if (iter.hasNext()) {
/* 33 */         buffer.append(delimiter);
/*    */       }
/*    */     }
/* 36 */     return buffer.toString();
/*    */   }
/*    */   
/*    */   private static String stringValueOf(Object next) {
/*    */     try {
/* 41 */       return String.valueOf(next);
/*    */     } catch (Throwable e) {}
/* 43 */     return "[toString failed]";
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\junit.jar!\org\junit\experimental\theories\internal\ParameterizedAssertionError.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */