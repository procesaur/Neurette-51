/*     */ package org.junit.experimental.theories;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.junit.Assert;
/*     */ import org.junit.experimental.theories.internal.Assignments;
/*     */ import org.junit.internal.AssumptionViolatedException;
/*     */ import org.junit.runners.BlockJUnit4ClassRunner;
/*     */ import org.junit.runners.model.FrameworkMethod;
/*     */ import org.junit.runners.model.InitializationError;
/*     */ import org.junit.runners.model.Statement;
/*     */ import org.junit.runners.model.TestClass;
/*     */ 
/*     */ public class Theories extends BlockJUnit4ClassRunner
/*     */ {
/*     */   public Theories(Class<?> klass) throws InitializationError
/*     */   {
/*  22 */     super(klass);
/*     */   }
/*     */   
/*     */   protected void collectInitializationErrors(List<Throwable> errors)
/*     */   {
/*  27 */     super.collectInitializationErrors(errors);
/*  28 */     validateDataPointFields(errors);
/*     */   }
/*     */   
/*     */   private void validateDataPointFields(List<Throwable> errors) {
/*  32 */     Field[] fields = getTestClass().getJavaClass().getDeclaredFields();
/*     */     
/*  34 */     for (Field field : fields) {
/*  35 */       if (field.getAnnotation(DataPoint.class) != null)
/*     */       {
/*     */ 
/*  38 */         if (!Modifier.isStatic(field.getModifiers())) {
/*  39 */           errors.add(new Error("DataPoint field " + field.getName() + " must be static"));
/*     */         }
/*  41 */         if (!Modifier.isPublic(field.getModifiers())) {
/*  42 */           errors.add(new Error("DataPoint field " + field.getName() + " must be public"));
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   protected void validateConstructor(List<Throwable> errors) {
/*  49 */     validateOnlyOneConstructor(errors);
/*     */   }
/*     */   
/*     */   protected void validateTestMethods(List<Throwable> errors)
/*     */   {
/*  54 */     for (FrameworkMethod each : computeTestMethods()) {
/*  55 */       if (each.getAnnotation(Theory.class) != null) {
/*  56 */         each.validatePublicVoid(false, errors);
/*     */       } else {
/*  58 */         each.validatePublicVoidNoArg(false, errors);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   protected List<FrameworkMethod> computeTestMethods()
/*     */   {
/*  65 */     List<FrameworkMethod> testMethods = super.computeTestMethods();
/*  66 */     List<FrameworkMethod> theoryMethods = getTestClass().getAnnotatedMethods(Theory.class);
/*  67 */     testMethods.removeAll(theoryMethods);
/*  68 */     testMethods.addAll(theoryMethods);
/*  69 */     return testMethods;
/*     */   }
/*     */   
/*     */   public Statement methodBlock(FrameworkMethod method)
/*     */   {
/*  74 */     return new TheoryAnchor(method, getTestClass());
/*     */   }
/*     */   
/*     */   public static class TheoryAnchor extends Statement {
/*  78 */     private int successes = 0;
/*     */     
/*     */     private FrameworkMethod fTestMethod;
/*     */     
/*     */     private TestClass fTestClass;
/*  83 */     private List<AssumptionViolatedException> fInvalidParameters = new ArrayList();
/*     */     
/*     */     public TheoryAnchor(FrameworkMethod method, TestClass testClass) {
/*  86 */       this.fTestMethod = method;
/*  87 */       this.fTestClass = testClass;
/*     */     }
/*     */     
/*     */     private TestClass getTestClass() {
/*  91 */       return this.fTestClass;
/*     */     }
/*     */     
/*     */     public void evaluate() throws Throwable
/*     */     {
/*  96 */       runWithAssignment(Assignments.allUnassigned(this.fTestMethod.getMethod(), getTestClass()));
/*     */       
/*     */ 
/*  99 */       if (this.successes == 0) {
/* 100 */         Assert.fail("Never found parameters that satisfied method assumptions.  Violated assumptions: " + this.fInvalidParameters);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */     protected void runWithAssignment(Assignments parameterAssignment)
/*     */       throws Throwable
/*     */     {
/* 108 */       if (!parameterAssignment.isComplete()) {
/* 109 */         runWithIncompleteAssignment(parameterAssignment);
/*     */       } else {
/* 111 */         runWithCompleteAssignment(parameterAssignment);
/*     */       }
/*     */     }
/*     */     
/*     */     protected void runWithIncompleteAssignment(Assignments incomplete)
/*     */       throws InstantiationException, IllegalAccessException, Throwable
/*     */     {
/* 118 */       for (PotentialAssignment source : incomplete.potentialsForNextUnassigned())
/*     */       {
/* 120 */         runWithAssignment(incomplete.assignNext(source));
/*     */       }
/*     */     }
/*     */     
/*     */     protected void runWithCompleteAssignment(final Assignments complete)
/*     */       throws InstantiationException, IllegalAccessException, java.lang.reflect.InvocationTargetException, NoSuchMethodException, Throwable
/*     */     {
/* 127 */       new BlockJUnit4ClassRunner(getTestClass().getJavaClass())
/*     */       {
/*     */         protected void collectInitializationErrors(List<Throwable> errors) {}
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */         public Statement methodBlock(FrameworkMethod method)
/*     */         {
/* 136 */           final Statement statement = super.methodBlock(method);
/* 137 */           new Statement()
/*     */           {
/*     */             public void evaluate() throws Throwable {
/*     */               try {
/* 141 */                 statement.evaluate();
/* 142 */                 Theories.TheoryAnchor.this.handleDataPointSuccess();
/*     */               } catch (AssumptionViolatedException e) {
/* 144 */                 Theories.TheoryAnchor.this.handleAssumptionViolation(e);
/*     */               } catch (Throwable e) {
/* 146 */                 Theories.TheoryAnchor.this.reportParameterizedError(e, Theories.TheoryAnchor.1.this.val$complete.getArgumentStrings(Theories.TheoryAnchor.this.nullsOk()));
/*     */               }
/*     */             }
/*     */           };
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */         protected Statement methodInvoker(FrameworkMethod method, Object test)
/*     */         {
/* 156 */           return Theories.TheoryAnchor.this.methodCompletesWithParameters(method, complete, test);
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 161 */         public Object createTest() throws Exception { return getTestClass().getOnlyConstructor().newInstance(complete.getConstructorArguments(Theories.TheoryAnchor.this.nullsOk())); } }.methodBlock(this.fTestMethod).evaluate();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     private Statement methodCompletesWithParameters(final FrameworkMethod method, final Assignments complete, final Object freshInstance)
/*     */     {
/* 169 */       new Statement()
/*     */       {
/*     */         public void evaluate() throws Throwable {
/*     */           try {
/* 173 */             Object[] values = complete.getMethodArguments(Theories.TheoryAnchor.this.nullsOk());
/*     */             
/* 175 */             method.invokeExplosively(freshInstance, values);
/*     */           }
/*     */           catch (PotentialAssignment.CouldNotGenerateValueException e) {}
/*     */         }
/*     */       };
/*     */     }
/*     */     
/*     */     protected void handleAssumptionViolation(AssumptionViolatedException e)
/*     */     {
/* 184 */       this.fInvalidParameters.add(e);
/*     */     }
/*     */     
/*     */     protected void reportParameterizedError(Throwable e, Object... params) throws Throwable
/*     */     {
/* 189 */       if (params.length == 0) {
/* 190 */         throw e;
/*     */       }
/* 192 */       throw new org.junit.experimental.theories.internal.ParameterizedAssertionError(e, this.fTestMethod.getName(), params);
/*     */     }
/*     */     
/*     */     private boolean nullsOk()
/*     */     {
/* 197 */       Theory annotation = (Theory)this.fTestMethod.getMethod().getAnnotation(Theory.class);
/*     */       
/* 199 */       if (annotation == null) {
/* 200 */         return false;
/*     */       }
/* 202 */       return annotation.nullsAccepted();
/*     */     }
/*     */     
/*     */     protected void handleDataPointSuccess() {
/* 206 */       this.successes += 1;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\junit.jar!\org\junit\experimental\theories\Theories.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */