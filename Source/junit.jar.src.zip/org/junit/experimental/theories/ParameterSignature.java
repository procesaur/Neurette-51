/*    */ package org.junit.experimental.theories;
/*    */ 
/*    */ import java.lang.annotation.Annotation;
/*    */ 
/*    */ public class ParameterSignature
/*    */ {
/*    */   private final Class<?> type;
/*    */   private final Annotation[] annotations;
/*    */   
/*    */   public static java.util.ArrayList<ParameterSignature> signatures(java.lang.reflect.Method method)
/*    */   {
/* 12 */     return signatures(method.getParameterTypes(), method.getParameterAnnotations());
/*    */   }
/*    */   
/*    */   public static java.util.List<ParameterSignature> signatures(java.lang.reflect.Constructor<?> constructor)
/*    */   {
/* 17 */     return signatures(constructor.getParameterTypes(), constructor.getParameterAnnotations());
/*    */   }
/*    */   
/*    */ 
/*    */   private static java.util.ArrayList<ParameterSignature> signatures(Class<?>[] parameterTypes, Annotation[][] parameterAnnotations)
/*    */   {
/* 23 */     java.util.ArrayList<ParameterSignature> sigs = new java.util.ArrayList();
/* 24 */     for (int i = 0; i < parameterTypes.length; i++) {
/* 25 */       sigs.add(new ParameterSignature(parameterTypes[i], parameterAnnotations[i]));
/*    */     }
/*    */     
/* 28 */     return sigs;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   private ParameterSignature(Class<?> type, Annotation[] annotations)
/*    */   {
/* 36 */     this.type = type;
/* 37 */     this.annotations = annotations;
/*    */   }
/*    */   
/*    */   public boolean canAcceptType(Class<?> candidate) {
/* 41 */     return this.type.isAssignableFrom(candidate);
/*    */   }
/*    */   
/*    */   public Class<?> getType() {
/* 45 */     return this.type;
/*    */   }
/*    */   
/*    */   public java.util.List<Annotation> getAnnotations() {
/* 49 */     return java.util.Arrays.asList(this.annotations);
/*    */   }
/*    */   
/*    */   public boolean canAcceptArrayType(Class<?> type) {
/* 53 */     return (type.isArray()) && (canAcceptType(type.getComponentType()));
/*    */   }
/*    */   
/*    */   public boolean hasAnnotation(Class<? extends Annotation> type) {
/* 57 */     return getAnnotation(type) != null;
/*    */   }
/*    */   
/*    */   public <T extends Annotation> T findDeepAnnotation(Class<T> annotationType) {
/* 61 */     Annotation[] annotations2 = this.annotations;
/* 62 */     return findDeepAnnotation(annotations2, annotationType, 3);
/*    */   }
/*    */   
/*    */   private <T extends Annotation> T findDeepAnnotation(Annotation[] annotations, Class<T> annotationType, int depth)
/*    */   {
/* 67 */     if (depth == 0) {
/* 68 */       return null;
/*    */     }
/* 70 */     for (Annotation each : annotations) {
/* 71 */       if (annotationType.isInstance(each)) {
/* 72 */         return (Annotation)annotationType.cast(each);
/*    */       }
/* 74 */       Annotation candidate = findDeepAnnotation(each.annotationType().getAnnotations(), annotationType, depth - 1);
/*    */       
/* 76 */       if (candidate != null) {
/* 77 */         return (Annotation)annotationType.cast(candidate);
/*    */       }
/*    */     }
/*    */     
/* 81 */     return null;
/*    */   }
/*    */   
/*    */   public <T extends Annotation> T getAnnotation(Class<T> annotationType) {
/* 85 */     for (Annotation each : getAnnotations()) {
/* 86 */       if (annotationType.isInstance(each)) {
/* 87 */         return (Annotation)annotationType.cast(each);
/*    */       }
/*    */     }
/* 90 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\junit.jar!\org\junit\experimental\theories\ParameterSignature.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */