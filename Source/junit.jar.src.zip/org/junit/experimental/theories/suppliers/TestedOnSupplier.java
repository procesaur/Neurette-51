/*    */ package org.junit.experimental.theories.suppliers;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.junit.experimental.theories.ParameterSignature;
/*    */ import org.junit.experimental.theories.ParameterSupplier;
/*    */ import org.junit.experimental.theories.PotentialAssignment;
/*    */ 
/*    */ public class TestedOnSupplier extends ParameterSupplier
/*    */ {
/*    */   public List<PotentialAssignment> getValueSources(ParameterSignature sig)
/*    */   {
/* 13 */     List<PotentialAssignment> list = new ArrayList();
/* 14 */     TestedOn testedOn = (TestedOn)sig.getAnnotation(TestedOn.class);
/* 15 */     int[] ints = testedOn.ints();
/* 16 */     for (int i : ints) {
/* 17 */       list.add(PotentialAssignment.forValue("ints", Integer.valueOf(i)));
/*    */     }
/* 19 */     return list;
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\junit.jar!\org\junit\experimental\theories\suppliers\TestedOnSupplier.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */