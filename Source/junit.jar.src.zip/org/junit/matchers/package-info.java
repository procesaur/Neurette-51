package org.junit.matchers;

interface package-info {}


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\junit.jar!\org\junit\matchers\package-info.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */