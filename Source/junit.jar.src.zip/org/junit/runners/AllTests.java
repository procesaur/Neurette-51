/*    */ package org.junit.runners;
/*    */ 
/*    */ import org.junit.internal.runners.SuiteMethod;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AllTests
/*    */   extends SuiteMethod
/*    */ {
/*    */   public AllTests(Class<?> klass)
/*    */     throws Throwable
/*    */   {
/* 25 */     super(klass);
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\junit.jar!\org\junit\runners\AllTests.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */