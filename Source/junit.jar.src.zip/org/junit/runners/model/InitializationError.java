/*    */ package org.junit.runners.model;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InitializationError
/*    */   extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private final List<Throwable> fErrors;
/*    */   
/*    */   public InitializationError(List<Throwable> errors)
/*    */   {
/* 20 */     this.fErrors = errors;
/*    */   }
/*    */   
/*    */   public InitializationError(Throwable error) {
/* 24 */     this(Arrays.asList(new Throwable[] { error }));
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public InitializationError(String string)
/*    */   {
/* 32 */     this(new Exception(string));
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public List<Throwable> getCauses()
/*    */   {
/* 39 */     return this.fErrors;
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\junit.jar!\org\junit\runners\model\InitializationError.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */