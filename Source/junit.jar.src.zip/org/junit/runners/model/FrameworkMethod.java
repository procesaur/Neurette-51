/*     */ package org.junit.runners.model;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.List;
/*     */ import org.junit.internal.runners.model.ReflectiveCallable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FrameworkMethod
/*     */   extends FrameworkMember<FrameworkMethod>
/*     */ {
/*     */   final Method fMethod;
/*     */   
/*     */   public FrameworkMethod(Method method)
/*     */   {
/*  27 */     this.fMethod = method;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Method getMethod()
/*     */   {
/*  34 */     return this.fMethod;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object invokeExplosively(final Object target, final Object... params)
/*     */     throws Throwable
/*     */   {
/*  44 */     new ReflectiveCallable()
/*     */     {
/*     */       protected Object runReflectiveCall() throws Throwable {
/*  47 */         return FrameworkMethod.this.fMethod.invoke(target, params);
/*     */       }
/*     */     }.run();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getName()
/*     */   {
/*  57 */     return this.fMethod.getName();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void validatePublicVoidNoArg(boolean isStatic, List<Throwable> errors)
/*     */   {
/*  70 */     validatePublicVoid(isStatic, errors);
/*  71 */     if (this.fMethod.getParameterTypes().length != 0) {
/*  72 */       errors.add(new Exception("Method " + this.fMethod.getName() + " should have no parameters"));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void validatePublicVoid(boolean isStatic, List<Throwable> errors)
/*     */   {
/*  86 */     if (Modifier.isStatic(this.fMethod.getModifiers()) != isStatic) {
/*  87 */       String state = isStatic ? "should" : "should not";
/*  88 */       errors.add(new Exception("Method " + this.fMethod.getName() + "() " + state + " be static"));
/*     */     }
/*  90 */     if (!Modifier.isPublic(this.fMethod.getDeclaringClass().getModifiers())) {
/*  91 */       errors.add(new Exception("Class " + this.fMethod.getDeclaringClass().getName() + " should be public"));
/*     */     }
/*  93 */     if (!Modifier.isPublic(this.fMethod.getModifiers())) {
/*  94 */       errors.add(new Exception("Method " + this.fMethod.getName() + "() should be public"));
/*     */     }
/*  96 */     if (this.fMethod.getReturnType() != Void.TYPE) {
/*  97 */       errors.add(new Exception("Method " + this.fMethod.getName() + "() should be void"));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isStatic()
/*     */   {
/* 106 */     return Modifier.isStatic(this.fMethod.getModifiers());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isPublic()
/*     */   {
/* 114 */     return Modifier.isPublic(this.fMethod.getModifiers());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Class<?> getReturnType()
/*     */   {
/* 121 */     return this.fMethod.getReturnType();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Class<?> getType()
/*     */   {
/* 129 */     return getReturnType();
/*     */   }
/*     */   
/*     */   public void validateNoTypeParametersOnArgs(List<Throwable> errors) {
/* 133 */     new NoGenericTypeParametersValidator(this.fMethod).validate(errors);
/*     */   }
/*     */   
/*     */   public boolean isShadowedBy(FrameworkMethod other)
/*     */   {
/* 138 */     if (!other.getName().equals(getName())) {
/* 139 */       return false;
/*     */     }
/* 141 */     if (other.getParameterTypes().length != getParameterTypes().length) {
/* 142 */       return false;
/*     */     }
/* 144 */     for (int i = 0; i < other.getParameterTypes().length; i++) {
/* 145 */       if (!other.getParameterTypes()[i].equals(getParameterTypes()[i])) {
/* 146 */         return false;
/*     */       }
/*     */     }
/* 149 */     return true;
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj)
/*     */   {
/* 154 */     if (!FrameworkMethod.class.isInstance(obj)) {
/* 155 */       return false;
/*     */     }
/* 157 */     return ((FrameworkMethod)obj).fMethod.equals(this.fMethod);
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/* 162 */     return this.fMethod.hashCode();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public boolean producesType(Type type)
/*     */   {
/* 176 */     return (getParameterTypes().length == 0) && ((type instanceof Class)) && (((Class)type).isAssignableFrom(this.fMethod.getReturnType()));
/*     */   }
/*     */   
/*     */   private Class<?>[] getParameterTypes()
/*     */   {
/* 181 */     return this.fMethod.getParameterTypes();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Annotation[] getAnnotations()
/*     */   {
/* 189 */     return this.fMethod.getAnnotations();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public <T extends Annotation> T getAnnotation(Class<T> annotationType)
/*     */   {
/* 197 */     return this.fMethod.getAnnotation(annotationType);
/*     */   }
/*     */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\junit.jar!\org\junit\runners\model\FrameworkMethod.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */