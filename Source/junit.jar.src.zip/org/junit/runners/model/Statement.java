package org.junit.runners.model;

public abstract class Statement
{
  public abstract void evaluate()
    throws Throwable;
}


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\junit.jar!\org\junit\runners\model\Statement.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */