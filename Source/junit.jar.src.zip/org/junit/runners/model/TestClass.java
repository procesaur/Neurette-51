/*     */ package org.junit.runners.model;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.junit.Assert;
/*     */ import org.junit.Before;
/*     */ import org.junit.BeforeClass;
/*     */ import org.junit.internal.MethodSorter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TestClass
/*     */ {
/*     */   private final Class<?> fClass;
/*  27 */   private Map<Class<?>, List<FrameworkMethod>> fMethodsForAnnotations = new HashMap();
/*     */   
/*  29 */   private Map<Class<?>, List<FrameworkField>> fFieldsForAnnotations = new HashMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TestClass(Class<?> klass)
/*     */   {
/*  38 */     this.fClass = klass;
/*  39 */     if ((klass != null) && (klass.getConstructors().length > 1)) {
/*  40 */       throw new IllegalArgumentException("Test class can only have one constructor");
/*     */     }
/*     */     
/*     */ 
/*  44 */     for (Class<?> eachClass : getSuperClasses(this.fClass)) {
/*  45 */       for (Method eachMethod : MethodSorter.getDeclaredMethods(eachClass)) {
/*  46 */         addToAnnotationLists(new FrameworkMethod(eachMethod), this.fMethodsForAnnotations);
/*     */       }
/*     */       
/*  49 */       for (Field eachField : eachClass.getDeclaredFields()) {
/*  50 */         addToAnnotationLists(new FrameworkField(eachField), this.fFieldsForAnnotations);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private <T extends FrameworkMember<T>> void addToAnnotationLists(T member, Map<Class<?>, List<T>> map)
/*     */   {
/*  58 */     for (Annotation each : member.getAnnotations()) {
/*  59 */       Class<? extends Annotation> type = each.annotationType();
/*  60 */       List<T> members = getAnnotatedMembers(map, type);
/*  61 */       if (member.isShadowedBy(members)) {
/*  62 */         return;
/*     */       }
/*  64 */       if (runsTopToBottom(type)) {
/*  65 */         members.add(0, member);
/*     */       } else {
/*  67 */         members.add(member);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<FrameworkMethod> getAnnotatedMethods(Class<? extends Annotation> annotationClass)
/*     */   {
/*  78 */     return getAnnotatedMembers(this.fMethodsForAnnotations, annotationClass);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<FrameworkField> getAnnotatedFields(Class<? extends Annotation> annotationClass)
/*     */   {
/*  87 */     return getAnnotatedMembers(this.fFieldsForAnnotations, annotationClass);
/*     */   }
/*     */   
/*     */   private <T> List<T> getAnnotatedMembers(Map<Class<?>, List<T>> map, Class<? extends Annotation> type)
/*     */   {
/*  92 */     if (!map.containsKey(type)) {
/*  93 */       map.put(type, new ArrayList());
/*     */     }
/*  95 */     return (List)map.get(type);
/*     */   }
/*     */   
/*     */   private boolean runsTopToBottom(Class<? extends Annotation> annotation) {
/*  99 */     return (annotation.equals(Before.class)) || (annotation.equals(BeforeClass.class));
/*     */   }
/*     */   
/*     */   private List<Class<?>> getSuperClasses(Class<?> testClass)
/*     */   {
/* 104 */     ArrayList<Class<?>> results = new ArrayList();
/* 105 */     Class<?> current = testClass;
/* 106 */     while (current != null) {
/* 107 */       results.add(current);
/* 108 */       current = current.getSuperclass();
/*     */     }
/* 110 */     return results;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Class<?> getJavaClass()
/*     */   {
/* 117 */     return this.fClass;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getName()
/*     */   {
/* 124 */     if (this.fClass == null) {
/* 125 */       return "null";
/*     */     }
/* 127 */     return this.fClass.getName();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Constructor<?> getOnlyConstructor()
/*     */   {
/* 136 */     Constructor<?>[] constructors = this.fClass.getConstructors();
/* 137 */     Assert.assertEquals(1L, constructors.length);
/* 138 */     return constructors[0];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Annotation[] getAnnotations()
/*     */   {
/* 145 */     if (this.fClass == null) {
/* 146 */       return new Annotation[0];
/*     */     }
/* 148 */     return this.fClass.getAnnotations();
/*     */   }
/*     */   
/*     */   public <T> List<T> getAnnotatedFieldValues(Object test, Class<? extends Annotation> annotationClass, Class<T> valueClass)
/*     */   {
/* 153 */     List<T> results = new ArrayList();
/* 154 */     for (FrameworkField each : getAnnotatedFields(annotationClass)) {
/*     */       try {
/* 156 */         Object fieldValue = each.get(test);
/* 157 */         if (valueClass.isInstance(fieldValue)) {
/* 158 */           results.add(valueClass.cast(fieldValue));
/*     */         }
/*     */       } catch (IllegalAccessException e) {
/* 161 */         throw new RuntimeException("How did getFields return a field we couldn't access?", e);
/*     */       }
/*     */     }
/*     */     
/* 165 */     return results;
/*     */   }
/*     */   
/*     */   public <T> List<T> getAnnotatedMethodValues(Object test, Class<? extends Annotation> annotationClass, Class<T> valueClass)
/*     */   {
/* 170 */     List<T> results = new ArrayList();
/* 171 */     for (FrameworkMethod each : getAnnotatedMethods(annotationClass)) {
/*     */       try {
/* 173 */         Object fieldValue = each.invokeExplosively(test, new Object[0]);
/* 174 */         if (valueClass.isInstance(fieldValue)) {
/* 175 */           results.add(valueClass.cast(fieldValue));
/*     */         }
/*     */       } catch (Throwable e) {
/* 178 */         throw new RuntimeException("Exception in " + each.getName(), e);
/*     */       }
/*     */     }
/*     */     
/* 182 */     return results;
/*     */   }
/*     */   
/*     */   public boolean isANonStaticInnerClass() {
/* 186 */     return (this.fClass.isMemberClass()) && (!Modifier.isStatic(this.fClass.getModifiers()));
/*     */   }
/*     */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\junit.jar!\org\junit\runners\model\TestClass.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */