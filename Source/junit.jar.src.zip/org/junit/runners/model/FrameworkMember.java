/*    */ package org.junit.runners.model;
/*    */ 
/*    */ import java.lang.annotation.Annotation;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class FrameworkMember<T extends FrameworkMember<T>>
/*    */ {
/*    */   abstract Annotation[] getAnnotations();
/*    */   
/*    */   abstract boolean isShadowedBy(T paramT);
/*    */   
/*    */   boolean isShadowedBy(List<T> members)
/*    */   {
/* 20 */     for (T each : members) {
/* 21 */       if (isShadowedBy(each)) {
/* 22 */         return true;
/*    */       }
/*    */     }
/* 25 */     return false;
/*    */   }
/*    */   
/*    */   public abstract boolean isPublic();
/*    */   
/*    */   public abstract boolean isStatic();
/*    */   
/*    */   public abstract String getName();
/*    */   
/*    */   public abstract Class<?> getType();
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\junit.jar!\org\junit\runners\model\FrameworkMember.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */