/*    */ package org.junit.runners.model;
/*    */ 
/*    */ import java.lang.annotation.Annotation;
/*    */ import java.lang.reflect.Field;
/*    */ import java.lang.reflect.Modifier;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FrameworkField
/*    */   extends FrameworkMember<FrameworkField>
/*    */ {
/*    */   private final Field fField;
/*    */   
/*    */   FrameworkField(Field field)
/*    */   {
/* 19 */     this.fField = field;
/*    */   }
/*    */   
/*    */   public String getName()
/*    */   {
/* 24 */     return getField().getName();
/*    */   }
/*    */   
/*    */   public Annotation[] getAnnotations()
/*    */   {
/* 29 */     return this.fField.getAnnotations();
/*    */   }
/*    */   
/*    */   public boolean isPublic()
/*    */   {
/* 34 */     int modifiers = this.fField.getModifiers();
/* 35 */     return Modifier.isPublic(modifiers);
/*    */   }
/*    */   
/*    */   public boolean isShadowedBy(FrameworkField otherMember)
/*    */   {
/* 40 */     return otherMember.getName().equals(getName());
/*    */   }
/*    */   
/*    */   public boolean isStatic()
/*    */   {
/* 45 */     int modifiers = this.fField.getModifiers();
/* 46 */     return Modifier.isStatic(modifiers);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public Field getField()
/*    */   {
/* 53 */     return this.fField;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Class<?> getType()
/*    */   {
/* 62 */     return this.fField.getType();
/*    */   }
/*    */   
/*    */ 
/*    */   public Object get(Object target)
/*    */     throws IllegalArgumentException, IllegalAccessException
/*    */   {
/* 69 */     return this.fField.get(target);
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\junit.jar!\org\junit\runners\model\FrameworkField.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */