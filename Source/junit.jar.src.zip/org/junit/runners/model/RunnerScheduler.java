package org.junit.runners.model;

public abstract interface RunnerScheduler
{
  public abstract void schedule(Runnable paramRunnable);
  
  public abstract void finished();
}


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\junit.jar!\org\junit\runners\model\RunnerScheduler.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */