/*     */ package org.junit.runners;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.util.List;
/*     */ import org.junit.After;
/*     */ import org.junit.Before;
/*     */ import org.junit.Ignore;
/*     */ import org.junit.Rule;
/*     */ import org.junit.Test;
/*     */ import org.junit.Test.None;
/*     */ import org.junit.internal.runners.model.ReflectiveCallable;
/*     */ import org.junit.internal.runners.rules.RuleFieldValidator;
/*     */ import org.junit.internal.runners.statements.ExpectException;
/*     */ import org.junit.internal.runners.statements.Fail;
/*     */ import org.junit.internal.runners.statements.FailOnTimeout;
/*     */ import org.junit.internal.runners.statements.InvokeMethod;
/*     */ import org.junit.internal.runners.statements.RunAfters;
/*     */ import org.junit.internal.runners.statements.RunBefores;
/*     */ import org.junit.rules.MethodRule;
/*     */ import org.junit.rules.RunRules;
/*     */ import org.junit.rules.TestRule;
/*     */ import org.junit.runner.Description;
/*     */ import org.junit.runner.notification.RunNotifier;
/*     */ import org.junit.runners.model.FrameworkMethod;
/*     */ import org.junit.runners.model.InitializationError;
/*     */ import org.junit.runners.model.Statement;
/*     */ import org.junit.runners.model.TestClass;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BlockJUnit4ClassRunner
/*     */   extends ParentRunner<FrameworkMethod>
/*     */ {
/*     */   public BlockJUnit4ClassRunner(Class<?> klass)
/*     */     throws InitializationError
/*     */   {
/*  57 */     super(klass);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void runChild(FrameworkMethod method, RunNotifier notifier)
/*     */   {
/*  66 */     Description description = describeChild(method);
/*  67 */     if (method.getAnnotation(Ignore.class) != null) {
/*  68 */       notifier.fireTestIgnored(description);
/*     */     } else {
/*  70 */       runLeaf(methodBlock(method), description, notifier);
/*     */     }
/*     */   }
/*     */   
/*     */   protected Description describeChild(FrameworkMethod method)
/*     */   {
/*  76 */     return Description.createTestDescription(getTestClass().getJavaClass(), testName(method), method.getAnnotations());
/*     */   }
/*     */   
/*     */ 
/*     */   protected List<FrameworkMethod> getChildren()
/*     */   {
/*  82 */     return computeTestMethods();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected List<FrameworkMethod> computeTestMethods()
/*     */   {
/*  95 */     return getTestClass().getAnnotatedMethods(Test.class);
/*     */   }
/*     */   
/*     */   protected void collectInitializationErrors(List<Throwable> errors)
/*     */   {
/* 100 */     super.collectInitializationErrors(errors);
/*     */     
/* 102 */     validateNoNonStaticInnerClass(errors);
/* 103 */     validateConstructor(errors);
/* 104 */     validateInstanceMethods(errors);
/* 105 */     validateFields(errors);
/* 106 */     validateMethods(errors);
/*     */   }
/*     */   
/*     */   protected void validateNoNonStaticInnerClass(List<Throwable> errors) {
/* 110 */     if (getTestClass().isANonStaticInnerClass()) {
/* 111 */       String gripe = "The inner class " + getTestClass().getName() + " is not static.";
/*     */       
/* 113 */       errors.add(new Exception(gripe));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void validateConstructor(List<Throwable> errors)
/*     */   {
/* 123 */     validateOnlyOneConstructor(errors);
/* 124 */     validateZeroArgConstructor(errors);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void validateOnlyOneConstructor(List<Throwable> errors)
/*     */   {
/* 132 */     if (!hasOneConstructor()) {
/* 133 */       String gripe = "Test class should have exactly one public constructor";
/* 134 */       errors.add(new Exception(gripe));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void validateZeroArgConstructor(List<Throwable> errors)
/*     */   {
/* 143 */     if ((!getTestClass().isANonStaticInnerClass()) && (hasOneConstructor()) && (getTestClass().getOnlyConstructor().getParameterTypes().length != 0))
/*     */     {
/*     */ 
/* 146 */       String gripe = "Test class should have exactly one public zero-argument constructor";
/* 147 */       errors.add(new Exception(gripe));
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean hasOneConstructor() {
/* 152 */     return getTestClass().getJavaClass().getConstructors().length == 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   protected void validateInstanceMethods(List<Throwable> errors)
/*     */   {
/* 164 */     validatePublicVoidNoArgMethods(After.class, false, errors);
/* 165 */     validatePublicVoidNoArgMethods(Before.class, false, errors);
/* 166 */     validateTestMethods(errors);
/*     */     
/* 168 */     if (computeTestMethods().size() == 0) {
/* 169 */       errors.add(new Exception("No runnable methods"));
/*     */     }
/*     */   }
/*     */   
/*     */   protected void validateFields(List<Throwable> errors) {
/* 174 */     RuleFieldValidator.RULE_VALIDATOR.validate(getTestClass(), errors);
/*     */   }
/*     */   
/*     */   private void validateMethods(List<Throwable> errors) {
/* 178 */     RuleFieldValidator.RULE_METHOD_VALIDATOR.validate(getTestClass(), errors);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void validateTestMethods(List<Throwable> errors)
/*     */   {
/* 186 */     validatePublicVoidNoArgMethods(Test.class, false, errors);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Object createTest()
/*     */     throws Exception
/*     */   {
/* 195 */     return getTestClass().getOnlyConstructor().newInstance(new Object[0]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String testName(FrameworkMethod method)
/*     */   {
/* 203 */     return method.getName();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Statement methodBlock(FrameworkMethod method)
/*     */   {
/*     */     Object test;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/* 241 */       test = new ReflectiveCallable()
/*     */       {
/*     */         protected Object runReflectiveCall() throws Throwable {
/* 244 */           return BlockJUnit4ClassRunner.this.createTest();
/*     */         }
/*     */       }.run();
/*     */     } catch (Throwable e) {
/* 248 */       return new Fail(e);
/*     */     }
/*     */     
/* 251 */     Statement statement = methodInvoker(method, test);
/* 252 */     statement = possiblyExpectingExceptions(method, test, statement);
/* 253 */     statement = withPotentialTimeout(method, test, statement);
/* 254 */     statement = withBefores(method, test, statement);
/* 255 */     statement = withAfters(method, test, statement);
/* 256 */     statement = withRules(method, test, statement);
/* 257 */     return statement;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Statement methodInvoker(FrameworkMethod method, Object test)
/*     */   {
/* 268 */     return new InvokeMethod(method, test);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   protected Statement possiblyExpectingExceptions(FrameworkMethod method, Object test, Statement next)
/*     */   {
/* 282 */     Test annotation = (Test)method.getAnnotation(Test.class);
/* 283 */     return expectsException(annotation) ? new ExpectException(next, getExpectedException(annotation)) : next;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   protected Statement withPotentialTimeout(FrameworkMethod method, Object test, Statement next)
/*     */   {
/* 297 */     long timeout = getTimeout((Test)method.getAnnotation(Test.class));
/* 298 */     return timeout > 0L ? new FailOnTimeout(next, timeout) : next;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   protected Statement withBefores(FrameworkMethod method, Object target, Statement statement)
/*     */   {
/* 311 */     List<FrameworkMethod> befores = getTestClass().getAnnotatedMethods(Before.class);
/*     */     
/* 313 */     return befores.isEmpty() ? statement : new RunBefores(statement, befores, target);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   protected Statement withAfters(FrameworkMethod method, Object target, Statement statement)
/*     */   {
/* 329 */     List<FrameworkMethod> afters = getTestClass().getAnnotatedMethods(After.class);
/*     */     
/* 331 */     return afters.isEmpty() ? statement : new RunAfters(statement, afters, target);
/*     */   }
/*     */   
/*     */ 
/*     */   private Statement withRules(FrameworkMethod method, Object target, Statement statement)
/*     */   {
/* 337 */     List<TestRule> testRules = getTestRules(target);
/* 338 */     Statement result = statement;
/* 339 */     result = withMethodRules(method, testRules, target, result);
/* 340 */     result = withTestRules(method, testRules, result);
/*     */     
/* 342 */     return result;
/*     */   }
/*     */   
/*     */   private Statement withMethodRules(FrameworkMethod method, List<TestRule> testRules, Object target, Statement result)
/*     */   {
/* 347 */     for (MethodRule each : getMethodRules(target)) {
/* 348 */       if (!testRules.contains(each)) {
/* 349 */         result = each.apply(result, method, target);
/*     */       }
/*     */     }
/* 352 */     return result;
/*     */   }
/*     */   
/*     */   private List<MethodRule> getMethodRules(Object target) {
/* 356 */     return rules(target);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected List<MethodRule> rules(Object target)
/*     */   {
/* 365 */     return getTestClass().getAnnotatedFieldValues(target, Rule.class, MethodRule.class);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Statement withTestRules(FrameworkMethod method, List<TestRule> testRules, Statement statement)
/*     */   {
/* 379 */     return testRules.isEmpty() ? statement : new RunRules(statement, testRules, describeChild(method));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected List<TestRule> getTestRules(Object target)
/*     */   {
/* 389 */     List<TestRule> result = getTestClass().getAnnotatedMethodValues(target, Rule.class, TestRule.class);
/*     */     
/*     */ 
/* 392 */     result.addAll(getTestClass().getAnnotatedFieldValues(target, Rule.class, TestRule.class));
/*     */     
/*     */ 
/* 395 */     return result;
/*     */   }
/*     */   
/*     */   private Class<? extends Throwable> getExpectedException(Test annotation) {
/* 399 */     if ((annotation == null) || (annotation.expected() == Test.None.class)) {
/* 400 */       return null;
/*     */     }
/* 402 */     return annotation.expected();
/*     */   }
/*     */   
/*     */   private boolean expectsException(Test annotation)
/*     */   {
/* 407 */     return getExpectedException(annotation) != null;
/*     */   }
/*     */   
/*     */   private long getTimeout(Test annotation) {
/* 411 */     if (annotation == null) {
/* 412 */       return 0L;
/*     */     }
/* 414 */     return annotation.timeout();
/*     */   }
/*     */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\junit.jar!\org\junit\runners\BlockJUnit4ClassRunner.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */