/*     */ package org.junit.runners;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.junit.AfterClass;
/*     */ import org.junit.BeforeClass;
/*     */ import org.junit.ClassRule;
/*     */ import org.junit.internal.AssumptionViolatedException;
/*     */ import org.junit.internal.runners.model.EachTestNotifier;
/*     */ import org.junit.internal.runners.rules.RuleFieldValidator;
/*     */ import org.junit.internal.runners.statements.RunAfters;
/*     */ import org.junit.internal.runners.statements.RunBefores;
/*     */ import org.junit.rules.RunRules;
/*     */ import org.junit.rules.TestRule;
/*     */ import org.junit.runner.Description;
/*     */ import org.junit.runner.Runner;
/*     */ import org.junit.runner.manipulation.Filter;
/*     */ import org.junit.runner.manipulation.Filterable;
/*     */ import org.junit.runner.manipulation.NoTestsRemainException;
/*     */ import org.junit.runner.manipulation.Sortable;
/*     */ import org.junit.runner.manipulation.Sorter;
/*     */ import org.junit.runner.notification.RunNotifier;
/*     */ import org.junit.runner.notification.StoppedByUserException;
/*     */ import org.junit.runners.model.FrameworkMethod;
/*     */ import org.junit.runners.model.InitializationError;
/*     */ import org.junit.runners.model.RunnerScheduler;
/*     */ import org.junit.runners.model.Statement;
/*     */ import org.junit.runners.model.TestClass;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ParentRunner<T>
/*     */   extends Runner
/*     */   implements Filterable, Sortable
/*     */ {
/*     */   private final TestClass fTestClass;
/*  57 */   private Sorter fSorter = Sorter.NULL;
/*     */   
/*  59 */   private List<T> fFilteredChildren = null;
/*     */   
/*  61 */   private RunnerScheduler fScheduler = new RunnerScheduler() {
/*     */     public void schedule(Runnable childStatement) {
/*  63 */       childStatement.run();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public void finished() {}
/*     */   };
/*     */   
/*     */ 
/*     */   protected ParentRunner(Class<?> testClass)
/*     */     throws InitializationError
/*     */   {
/*  75 */     this.fTestClass = new TestClass(testClass);
/*  76 */     validate();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract List<T> getChildren();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract Description describeChild(T paramT);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract void runChild(T paramT, RunNotifier paramRunNotifier);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void collectInitializationErrors(List<Throwable> errors)
/*     */   {
/* 113 */     validatePublicVoidNoArgMethods(BeforeClass.class, true, errors);
/* 114 */     validatePublicVoidNoArgMethods(AfterClass.class, true, errors);
/* 115 */     validateClassRules(errors);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void validatePublicVoidNoArgMethods(Class<? extends Annotation> annotation, boolean isStatic, List<Throwable> errors)
/*     */   {
/* 130 */     List<FrameworkMethod> methods = getTestClass().getAnnotatedMethods(annotation);
/*     */     
/* 132 */     for (FrameworkMethod eachTestMethod : methods) {
/* 133 */       eachTestMethod.validatePublicVoidNoArg(isStatic, errors);
/*     */     }
/*     */   }
/*     */   
/*     */   private void validateClassRules(List<Throwable> errors) {
/* 138 */     RuleFieldValidator.CLASS_RULE_VALIDATOR.validate(getTestClass(), errors);
/* 139 */     RuleFieldValidator.CLASS_RULE_METHOD_VALIDATOR.validate(getTestClass(), errors);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Statement classBlock(RunNotifier notifier)
/*     */   {
/* 160 */     Statement statement = childrenInvoker(notifier);
/* 161 */     statement = withBeforeClasses(statement);
/* 162 */     statement = withAfterClasses(statement);
/* 163 */     statement = withClassRules(statement);
/* 164 */     return statement;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Statement withBeforeClasses(Statement statement)
/*     */   {
/* 173 */     List<FrameworkMethod> befores = this.fTestClass.getAnnotatedMethods(BeforeClass.class);
/*     */     
/* 175 */     return befores.isEmpty() ? statement : new RunBefores(statement, befores, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Statement withAfterClasses(Statement statement)
/*     */   {
/* 187 */     List<FrameworkMethod> afters = this.fTestClass.getAnnotatedMethods(AfterClass.class);
/*     */     
/* 189 */     return afters.isEmpty() ? statement : new RunAfters(statement, afters, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Statement withClassRules(Statement statement)
/*     */   {
/* 203 */     List<TestRule> classRules = classRules();
/* 204 */     return classRules.isEmpty() ? statement : new RunRules(statement, classRules, getDescription());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected List<TestRule> classRules()
/*     */   {
/* 213 */     List<TestRule> result = this.fTestClass.getAnnotatedMethodValues(null, ClassRule.class, TestRule.class);
/*     */     
/* 215 */     result.addAll(this.fTestClass.getAnnotatedFieldValues(null, ClassRule.class, TestRule.class));
/*     */     
/* 217 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Statement childrenInvoker(final RunNotifier notifier)
/*     */   {
/* 226 */     new Statement()
/*     */     {
/*     */       public void evaluate() {
/* 229 */         ParentRunner.this.runChildren(notifier);
/*     */       }
/*     */     };
/*     */   }
/*     */   
/*     */   private void runChildren(final RunNotifier notifier) {
/* 235 */     for (final T each : getFilteredChildren()) {
/* 236 */       this.fScheduler.schedule(new Runnable() {
/*     */         public void run() {
/* 238 */           ParentRunner.this.runChild(each, notifier);
/*     */         }
/*     */       });
/*     */     }
/* 242 */     this.fScheduler.finished();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected String getName()
/*     */   {
/* 249 */     return this.fTestClass.getName();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final TestClass getTestClass()
/*     */   {
/* 260 */     return this.fTestClass;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final void runLeaf(Statement statement, Description description, RunNotifier notifier)
/*     */   {
/* 268 */     EachTestNotifier eachNotifier = new EachTestNotifier(notifier, description);
/* 269 */     eachNotifier.fireTestStarted();
/*     */     try {
/* 271 */       statement.evaluate();
/*     */     } catch (AssumptionViolatedException e) {
/* 273 */       eachNotifier.addFailedAssumption(e);
/*     */     } catch (Throwable e) {
/* 275 */       eachNotifier.addFailure(e);
/*     */     } finally {
/* 277 */       eachNotifier.fireTestFinished();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Annotation[] getRunnerAnnotations()
/*     */   {
/* 286 */     return this.fTestClass.getAnnotations();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Description getDescription()
/*     */   {
/* 295 */     Description description = Description.createSuiteDescription(getName(), getRunnerAnnotations());
/*     */     
/* 297 */     for (T child : getFilteredChildren()) {
/* 298 */       description.addChild(describeChild(child));
/*     */     }
/* 300 */     return description;
/*     */   }
/*     */   
/*     */   public void run(RunNotifier notifier)
/*     */   {
/* 305 */     EachTestNotifier testNotifier = new EachTestNotifier(notifier, getDescription());
/*     */     try
/*     */     {
/* 308 */       Statement statement = classBlock(notifier);
/* 309 */       statement.evaluate();
/*     */     } catch (AssumptionViolatedException e) {
/* 311 */       testNotifier.fireTestIgnored();
/*     */     } catch (StoppedByUserException e) {
/* 313 */       throw e;
/*     */     } catch (Throwable e) {
/* 315 */       testNotifier.addFailure(e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void filter(Filter filter)
/*     */     throws NoTestsRemainException
/*     */   {
/* 324 */     for (Iterator<T> iter = getFilteredChildren().iterator(); iter.hasNext();) {
/* 325 */       T each = iter.next();
/* 326 */       if (shouldRun(filter, each)) {
/*     */         try {
/* 328 */           filter.apply(each);
/*     */         } catch (NoTestsRemainException e) {
/* 330 */           iter.remove();
/*     */         }
/*     */       } else {
/* 333 */         iter.remove();
/*     */       }
/*     */     }
/* 336 */     if (getFilteredChildren().isEmpty()) {
/* 337 */       throw new NoTestsRemainException();
/*     */     }
/*     */   }
/*     */   
/*     */   public void sort(Sorter sorter) {
/* 342 */     this.fSorter = sorter;
/* 343 */     for (T each : getFilteredChildren()) {
/* 344 */       sortChild(each);
/*     */     }
/* 346 */     Collections.sort(getFilteredChildren(), comparator());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void validate()
/*     */     throws InitializationError
/*     */   {
/* 354 */     List<Throwable> errors = new ArrayList();
/* 355 */     collectInitializationErrors(errors);
/* 356 */     if (!errors.isEmpty()) {
/* 357 */       throw new InitializationError(errors);
/*     */     }
/*     */   }
/*     */   
/*     */   private List<T> getFilteredChildren() {
/* 362 */     if (this.fFilteredChildren == null) {
/* 363 */       this.fFilteredChildren = new ArrayList(getChildren());
/*     */     }
/* 365 */     return this.fFilteredChildren;
/*     */   }
/*     */   
/*     */   private void sortChild(T child) {
/* 369 */     this.fSorter.apply(child);
/*     */   }
/*     */   
/*     */   private boolean shouldRun(Filter filter, T each) {
/* 373 */     return filter.shouldRun(describeChild(each));
/*     */   }
/*     */   
/*     */   private Comparator<? super T> comparator() {
/* 377 */     new Comparator() {
/*     */       public int compare(T o1, T o2) {
/* 379 */         return ParentRunner.this.fSorter.compare(ParentRunner.this.describeChild(o1), ParentRunner.this.describeChild(o2));
/*     */       }
/*     */     };
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setScheduler(RunnerScheduler scheduler)
/*     */   {
/* 389 */     this.fScheduler = scheduler;
/*     */   }
/*     */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\junit.jar!\org\junit\runners\ParentRunner.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */