/*     */ package org.junit.runners;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.annotation.Retention;
/*     */ import java.lang.annotation.RetentionPolicy;
/*     */ import java.lang.annotation.Target;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Field;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.junit.runner.Runner;
/*     */ import org.junit.runner.notification.RunNotifier;
/*     */ import org.junit.runners.model.FrameworkField;
/*     */ import org.junit.runners.model.FrameworkMethod;
/*     */ import org.junit.runners.model.InitializationError;
/*     */ import org.junit.runners.model.Statement;
/*     */ import org.junit.runners.model.TestClass;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Parameterized
/*     */   extends Suite
/*     */ {
/*     */   private class TestClassRunnerForParameters
/*     */     extends BlockJUnit4ClassRunner
/*     */   {
/*     */     private final Object[] fParameters;
/*     */     private final String fName;
/*     */     
/*     */     TestClassRunnerForParameters(Object[] type, String parameters)
/*     */       throws InitializationError
/*     */     {
/* 171 */       super();
/* 172 */       this.fParameters = parameters;
/* 173 */       this.fName = name;
/*     */     }
/*     */     
/*     */     public Object createTest() throws Exception
/*     */     {
/* 178 */       if (Parameterized.this.fieldsAreAnnotated()) {
/* 179 */         return createTestUsingFieldInjection();
/*     */       }
/* 181 */       return createTestUsingConstructorInjection();
/*     */     }
/*     */     
/*     */     private Object createTestUsingConstructorInjection() throws Exception
/*     */     {
/* 186 */       return getTestClass().getOnlyConstructor().newInstance(this.fParameters);
/*     */     }
/*     */     
/*     */     private Object createTestUsingFieldInjection() throws Exception {
/* 190 */       List<FrameworkField> annotatedFieldsByParameter = Parameterized.this.getAnnotatedFieldsByParameter();
/* 191 */       if (annotatedFieldsByParameter.size() != this.fParameters.length) {
/* 192 */         throw new Exception("Wrong number of parameters and @Parameter fields. @Parameter fields counted: " + annotatedFieldsByParameter.size() + ", available parameters: " + this.fParameters.length + ".");
/*     */       }
/*     */       
/* 195 */       Object testClassInstance = getTestClass().getJavaClass().newInstance();
/* 196 */       for (FrameworkField each : annotatedFieldsByParameter) {
/* 197 */         Field field = each.getField();
/* 198 */         Parameterized.Parameter annotation = (Parameterized.Parameter)field.getAnnotation(Parameterized.Parameter.class);
/* 199 */         int index = annotation.value();
/*     */         try {
/* 201 */           field.set(testClassInstance, this.fParameters[index]);
/*     */         } catch (IllegalArgumentException iare) {
/* 203 */           throw new Exception(getTestClass().getName() + ": Trying to set " + field.getName() + " with the value " + this.fParameters[index] + " that is not the right type (" + this.fParameters[index].getClass().getSimpleName() + " instead of " + field.getType().getSimpleName() + ").", iare);
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 209 */       return testClassInstance;
/*     */     }
/*     */     
/*     */     protected String getName()
/*     */     {
/* 214 */       return this.fName;
/*     */     }
/*     */     
/*     */     protected String testName(FrameworkMethod method)
/*     */     {
/* 219 */       return method.getName() + getName();
/*     */     }
/*     */     
/*     */     protected void validateConstructor(List<Throwable> errors)
/*     */     {
/* 224 */       validateOnlyOneConstructor(errors);
/* 225 */       if (Parameterized.this.fieldsAreAnnotated()) {
/* 226 */         validateZeroArgConstructor(errors);
/*     */       }
/*     */     }
/*     */     
/*     */     protected void validateFields(List<Throwable> errors)
/*     */     {
/* 232 */       super.validateFields(errors);
/* 233 */       if (Parameterized.this.fieldsAreAnnotated()) {
/* 234 */         List<FrameworkField> annotatedFieldsByParameter = Parameterized.this.getAnnotatedFieldsByParameter();
/* 235 */         int[] usedIndices = new int[annotatedFieldsByParameter.size()];
/* 236 */         for (FrameworkField each : annotatedFieldsByParameter) {
/* 237 */           int index = ((Parameterized.Parameter)each.getField().getAnnotation(Parameterized.Parameter.class)).value();
/* 238 */           if ((index < 0) || (index > annotatedFieldsByParameter.size() - 1)) {
/* 239 */             errors.add(new Exception("Invalid @Parameter value: " + index + ". @Parameter fields counted: " + annotatedFieldsByParameter.size() + ". Please use an index between 0 and " + (annotatedFieldsByParameter.size() - 1) + "."));
/*     */ 
/*     */           }
/*     */           else
/*     */           {
/*     */ 
/* 245 */             usedIndices[index] += 1;
/*     */           }
/*     */         }
/* 248 */         for (int index = 0; index < usedIndices.length; index++) {
/* 249 */           int numberOfUse = usedIndices[index];
/* 250 */           if (numberOfUse == 0) {
/* 251 */             errors.add(new Exception("@Parameter(" + index + ") is never used."));
/* 252 */           } else if (numberOfUse > 1) {
/* 253 */             errors.add(new Exception("@Parameter(" + index + ") is used more than once (" + numberOfUse + ")."));
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */     protected Statement classBlock(RunNotifier notifier)
/*     */     {
/* 261 */       return childrenInvoker(notifier);
/*     */     }
/*     */     
/*     */     protected Annotation[] getRunnerAnnotations()
/*     */     {
/* 266 */       return new Annotation[0];
/*     */     }
/*     */   }
/*     */   
/* 270 */   private static final List<Runner> NO_RUNNERS = ;
/*     */   
/*     */ 
/* 273 */   private final ArrayList<Runner> runners = new ArrayList();
/*     */   
/*     */ 
/*     */   public Parameterized(Class<?> klass)
/*     */     throws Throwable
/*     */   {
/* 279 */     super(klass, NO_RUNNERS);
/* 280 */     Parameters parameters = (Parameters)getParametersMethod().getAnnotation(Parameters.class);
/*     */     
/* 282 */     createRunnersForParameters(allParameters(), parameters.name());
/*     */   }
/*     */   
/*     */   protected List<Runner> getChildren()
/*     */   {
/* 287 */     return this.runners;
/*     */   }
/*     */   
/*     */   private Iterable<Object[]> allParameters() throws Throwable
/*     */   {
/* 292 */     Object parameters = getParametersMethod().invokeExplosively(null, new Object[0]);
/* 293 */     if ((parameters instanceof Iterable)) {
/* 294 */       return (Iterable)parameters;
/*     */     }
/* 296 */     throw parametersMethodReturnedWrongType();
/*     */   }
/*     */   
/*     */   private FrameworkMethod getParametersMethod() throws Exception
/*     */   {
/* 301 */     List<FrameworkMethod> methods = getTestClass().getAnnotatedMethods(Parameters.class);
/*     */     
/* 303 */     for (FrameworkMethod each : methods) {
/* 304 */       if ((each.isStatic()) && (each.isPublic())) {
/* 305 */         return each;
/*     */       }
/*     */     }
/*     */     
/* 309 */     throw new Exception("No public static parameters method on class " + getTestClass().getName());
/*     */   }
/*     */   
/*     */   private void createRunnersForParameters(Iterable<Object[]> allParameters, String namePattern) throws InitializationError, Exception
/*     */   {
/*     */     try
/*     */     {
/* 316 */       i = 0;
/* 317 */       for (Object[] parametersOfSingleTest : allParameters) {
/* 318 */         String name = nameFor(namePattern, i, parametersOfSingleTest);
/* 319 */         TestClassRunnerForParameters runner = new TestClassRunnerForParameters(getTestClass().getJavaClass(), parametersOfSingleTest, name);
/*     */         
/*     */ 
/* 322 */         this.runners.add(runner);
/* 323 */         i++;
/*     */       }
/*     */     } catch (ClassCastException e) { int i;
/* 326 */       throw parametersMethodReturnedWrongType();
/*     */     }
/*     */   }
/*     */   
/*     */   private String nameFor(String namePattern, int index, Object[] parameters) {
/* 331 */     String finalPattern = namePattern.replaceAll("\\{index\\}", Integer.toString(index));
/*     */     
/* 333 */     String name = MessageFormat.format(finalPattern, parameters);
/* 334 */     return "[" + name + "]";
/*     */   }
/*     */   
/*     */   private Exception parametersMethodReturnedWrongType() throws Exception {
/* 338 */     String className = getTestClass().getName();
/* 339 */     String methodName = getParametersMethod().getName();
/* 340 */     String message = MessageFormat.format("{0}.{1}() must return an Iterable of arrays.", new Object[] { className, methodName });
/*     */     
/*     */ 
/* 343 */     return new Exception(message);
/*     */   }
/*     */   
/*     */   private List<FrameworkField> getAnnotatedFieldsByParameter() {
/* 347 */     return getTestClass().getAnnotatedFields(Parameter.class);
/*     */   }
/*     */   
/*     */   private boolean fieldsAreAnnotated() {
/* 351 */     return !getAnnotatedFieldsByParameter().isEmpty();
/*     */   }
/*     */   
/*     */   @Retention(RetentionPolicy.RUNTIME)
/*     */   @Target({java.lang.annotation.ElementType.FIELD})
/*     */   public static @interface Parameter
/*     */   {
/*     */     int value() default 0;
/*     */   }
/*     */   
/*     */   @Retention(RetentionPolicy.RUNTIME)
/*     */   @Target({java.lang.annotation.ElementType.METHOD})
/*     */   public static @interface Parameters
/*     */   {
/*     */     String name() default "{index}";
/*     */   }
/*     */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\junit.jar!\org\junit\runners\Parameterized.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */