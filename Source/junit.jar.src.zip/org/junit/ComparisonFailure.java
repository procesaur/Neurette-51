/*     */ package org.junit;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ComparisonFailure
/*     */   extends AssertionError
/*     */ {
/*     */   private static final int MAX_CONTEXT_LENGTH = 20;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final long serialVersionUID = 1L;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String fExpected;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String fActual;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ComparisonFailure(String message, String expected, String actual)
/*     */   {
/*  32 */     super(message);
/*  33 */     this.fExpected = expected;
/*  34 */     this.fActual = actual;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getMessage()
/*     */   {
/*  45 */     return new ComparisonCompactor(20, this.fExpected, this.fActual).compact(super.getMessage());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getActual()
/*     */   {
/*  54 */     return this.fActual;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getExpected()
/*     */   {
/*  63 */     return this.fExpected;
/*     */   }
/*     */   
/*     */ 
/*     */   private static class ComparisonCompactor
/*     */   {
/*     */     private static final String ELLIPSIS = "...";
/*     */     
/*     */     private static final String DELTA_END = "]";
/*     */     
/*     */     private static final String DELTA_START = "[";
/*     */     
/*     */     private int fContextLength;
/*     */     
/*     */     private String fExpected;
/*     */     
/*     */     private String fActual;
/*     */     
/*     */     private int fPrefix;
/*     */     
/*     */     private int fSuffix;
/*     */     
/*     */ 
/*     */     public ComparisonCompactor(int contextLength, String expected, String actual)
/*     */     {
/*  88 */       this.fContextLength = contextLength;
/*  89 */       this.fExpected = expected;
/*  90 */       this.fActual = actual;
/*     */     }
/*     */     
/*     */     private String compact(String message) {
/*  94 */       if ((this.fExpected == null) || (this.fActual == null) || (areStringsEqual())) {
/*  95 */         return Assert.format(message, this.fExpected, this.fActual);
/*     */       }
/*     */       
/*  98 */       findCommonPrefix();
/*  99 */       findCommonSuffix();
/* 100 */       String expected = compactString(this.fExpected);
/* 101 */       String actual = compactString(this.fActual);
/* 102 */       return Assert.format(message, expected, actual);
/*     */     }
/*     */     
/*     */     private String compactString(String source) {
/* 106 */       String result = "[" + source.substring(this.fPrefix, source.length() - this.fSuffix + 1) + "]";
/* 107 */       if (this.fPrefix > 0) {
/* 108 */         result = computeCommonPrefix() + result;
/*     */       }
/* 110 */       if (this.fSuffix > 0) {
/* 111 */         result = result + computeCommonSuffix();
/*     */       }
/* 113 */       return result;
/*     */     }
/*     */     
/*     */     private void findCommonPrefix() {
/* 117 */       this.fPrefix = 0;
/* 118 */       int end = Math.min(this.fExpected.length(), this.fActual.length());
/* 119 */       while ((this.fPrefix < end) && 
/* 120 */         (this.fExpected.charAt(this.fPrefix) == this.fActual.charAt(this.fPrefix))) {
/* 119 */         this.fPrefix += 1;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     private void findCommonSuffix()
/*     */     {
/* 127 */       int expectedSuffix = this.fExpected.length() - 1;
/* 128 */       int actualSuffix = this.fActual.length() - 1;
/* 129 */       for (; (actualSuffix >= this.fPrefix) && (expectedSuffix >= this.fPrefix); expectedSuffix--) {
/* 130 */         if (this.fExpected.charAt(expectedSuffix) != this.fActual.charAt(actualSuffix)) {
/*     */           break;
/*     */         }
/* 129 */         actualSuffix--;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 134 */       this.fSuffix = (this.fExpected.length() - expectedSuffix);
/*     */     }
/*     */     
/*     */     private String computeCommonPrefix() {
/* 138 */       return (this.fPrefix > this.fContextLength ? "..." : "") + this.fExpected.substring(Math.max(0, this.fPrefix - this.fContextLength), this.fPrefix);
/*     */     }
/*     */     
/*     */     private String computeCommonSuffix() {
/* 142 */       int end = Math.min(this.fExpected.length() - this.fSuffix + 1 + this.fContextLength, this.fExpected.length());
/* 143 */       return this.fExpected.substring(this.fExpected.length() - this.fSuffix + 1, end) + (this.fExpected.length() - this.fSuffix + 1 < this.fExpected.length() - this.fContextLength ? "..." : "");
/*     */     }
/*     */     
/*     */     private boolean areStringsEqual() {
/* 147 */       return this.fExpected.equals(this.fActual);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\junit.jar!\org\junit\ComparisonFailure.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */