/*     */ package org.junit;
/*     */ 
/*     */ import org.hamcrest.Matcher;
/*     */ import org.hamcrest.MatcherAssert;
/*     */ import org.junit.internal.ArrayComparisonFailure;
/*     */ import org.junit.internal.ExactComparisonCriteria;
/*     */ import org.junit.internal.InexactComparisonCriteria;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Assert
/*     */ {
/*     */   public static void assertTrue(String message, boolean condition)
/*     */   {
/*  40 */     if (!condition) {
/*  41 */       fail(message);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertTrue(boolean condition)
/*     */   {
/*  52 */     assertTrue(null, condition);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertFalse(String message, boolean condition)
/*     */   {
/*  64 */     assertTrue(message, !condition);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertFalse(boolean condition)
/*     */   {
/*  74 */     assertFalse(null, condition);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void fail(String message)
/*     */   {
/*  85 */     if (message == null) {
/*  86 */       throw new AssertionError();
/*     */     }
/*  88 */     throw new AssertionError(message);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static void fail()
/*     */   {
/*  95 */     fail(null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertEquals(String message, Object expected, Object actual)
/*     */   {
/* 111 */     if (equalsRegardingNull(expected, actual))
/* 112 */       return;
/* 113 */     if (((expected instanceof String)) && ((actual instanceof String))) {
/* 114 */       String cleanMessage = message == null ? "" : message;
/* 115 */       throw new ComparisonFailure(cleanMessage, (String)expected, (String)actual);
/*     */     }
/*     */     
/* 118 */     failNotEquals(message, expected, actual);
/*     */   }
/*     */   
/*     */   private static boolean equalsRegardingNull(Object expected, Object actual)
/*     */   {
/* 123 */     if (expected == null) {
/* 124 */       return actual == null;
/*     */     }
/*     */     
/* 127 */     return isEquals(expected, actual);
/*     */   }
/*     */   
/*     */   private static boolean isEquals(Object expected, Object actual) {
/* 131 */     return expected.equals(actual);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertEquals(Object expected, Object actual)
/*     */   {
/* 144 */     assertEquals(null, expected, actual);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertNotEquals(String message, Object first, Object second)
/*     */   {
/* 160 */     if (equalsRegardingNull(first, second)) {
/* 161 */       failEquals(message, first);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertNotEquals(Object first, Object second)
/*     */   {
/* 175 */     assertNotEquals(null, first, second);
/*     */   }
/*     */   
/*     */   private static void failEquals(String message, Object actual) {
/* 179 */     String formatted = "Values should be different. ";
/* 180 */     if (message != null) {
/* 181 */       formatted = message + ". ";
/*     */     }
/*     */     
/* 184 */     formatted = formatted + "Actual: " + actual;
/* 185 */     fail(formatted);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertNotEquals(String message, long first, long second)
/*     */   {
/* 198 */     assertNotEquals(message, Long.valueOf(first), Long.valueOf(second));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertNotEquals(long first, long second)
/*     */   {
/* 209 */     assertNotEquals(null, first, second);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertNotEquals(String message, double first, double second, double delta)
/*     */   {
/* 229 */     if (!doubleIsDifferent(first, second, delta)) {
/* 230 */       failEquals(message, new Double(first));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertNotEquals(double first, double second, double delta)
/*     */   {
/* 247 */     assertNotEquals(null, first, second, delta);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertArrayEquals(String message, Object[] expecteds, Object[] actuals)
/*     */     throws ArrayComparisonFailure
/*     */   {
/* 265 */     internalArrayEquals(message, expecteds, actuals);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertArrayEquals(Object[] expecteds, Object[] actuals)
/*     */   {
/* 280 */     assertArrayEquals(null, expecteds, actuals);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertArrayEquals(String message, byte[] expecteds, byte[] actuals)
/*     */     throws ArrayComparisonFailure
/*     */   {
/* 294 */     internalArrayEquals(message, expecteds, actuals);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertArrayEquals(byte[] expecteds, byte[] actuals)
/*     */   {
/* 305 */     assertArrayEquals(null, expecteds, actuals);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertArrayEquals(String message, char[] expecteds, char[] actuals)
/*     */     throws ArrayComparisonFailure
/*     */   {
/* 319 */     internalArrayEquals(message, expecteds, actuals);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertArrayEquals(char[] expecteds, char[] actuals)
/*     */   {
/* 330 */     assertArrayEquals(null, expecteds, actuals);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertArrayEquals(String message, short[] expecteds, short[] actuals)
/*     */     throws ArrayComparisonFailure
/*     */   {
/* 344 */     internalArrayEquals(message, expecteds, actuals);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertArrayEquals(short[] expecteds, short[] actuals)
/*     */   {
/* 355 */     assertArrayEquals(null, expecteds, actuals);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertArrayEquals(String message, int[] expecteds, int[] actuals)
/*     */     throws ArrayComparisonFailure
/*     */   {
/* 369 */     internalArrayEquals(message, expecteds, actuals);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertArrayEquals(int[] expecteds, int[] actuals)
/*     */   {
/* 380 */     assertArrayEquals(null, expecteds, actuals);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertArrayEquals(String message, long[] expecteds, long[] actuals)
/*     */     throws ArrayComparisonFailure
/*     */   {
/* 394 */     internalArrayEquals(message, expecteds, actuals);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertArrayEquals(long[] expecteds, long[] actuals)
/*     */   {
/* 405 */     assertArrayEquals(null, expecteds, actuals);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertArrayEquals(String message, double[] expecteds, double[] actuals, double delta)
/*     */     throws ArrayComparisonFailure
/*     */   {
/* 419 */     new InexactComparisonCriteria(delta).arrayEquals(message, expecteds, actuals);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertArrayEquals(double[] expecteds, double[] actuals, double delta)
/*     */   {
/* 430 */     assertArrayEquals(null, expecteds, actuals, delta);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertArrayEquals(String message, float[] expecteds, float[] actuals, float delta)
/*     */     throws ArrayComparisonFailure
/*     */   {
/* 444 */     new InexactComparisonCriteria(delta).arrayEquals(message, expecteds, actuals);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertArrayEquals(float[] expecteds, float[] actuals, float delta)
/*     */   {
/* 455 */     assertArrayEquals(null, expecteds, actuals, delta);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void internalArrayEquals(String message, Object expecteds, Object actuals)
/*     */     throws ArrayComparisonFailure
/*     */   {
/* 473 */     new ExactComparisonCriteria().arrayEquals(message, expecteds, actuals);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertEquals(String message, double expected, double actual, double delta)
/*     */   {
/* 493 */     if (doubleIsDifferent(expected, actual, delta)) {
/* 494 */       failNotEquals(message, new Double(expected), new Double(actual));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertEquals(String message, float expected, float actual, float delta)
/*     */   {
/* 515 */     if (Float.compare(expected, actual) == 0) {
/* 516 */       return;
/*     */     }
/* 518 */     if (Math.abs(expected - actual) > delta) {
/* 519 */       failNotEquals(message, new Float(expected), new Float(actual));
/*     */     }
/*     */   }
/*     */   
/*     */   private static boolean doubleIsDifferent(double d1, double d2, double delta) {
/* 524 */     if (Double.compare(d1, d2) == 0) {
/* 525 */       return false;
/*     */     }
/* 527 */     if (Math.abs(d1 - d2) <= delta) {
/* 528 */       return false;
/*     */     }
/*     */     
/* 531 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertEquals(long expected, long actual)
/*     */   {
/* 542 */     assertEquals(null, expected, actual);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertEquals(String message, long expected, long actual)
/*     */   {
/* 555 */     assertEquals(message, Long.valueOf(expected), Long.valueOf(actual));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public static void assertEquals(double expected, double actual)
/*     */   {
/* 565 */     assertEquals(null, expected, actual);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public static void assertEquals(String message, double expected, double actual)
/*     */   {
/* 576 */     fail("Use assertEquals(expected, actual, delta) to compare floating-point numbers");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertEquals(double expected, double actual, double delta)
/*     */   {
/* 592 */     assertEquals(null, expected, actual, delta);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertEquals(float expected, float actual, float delta)
/*     */   {
/* 609 */     assertEquals(null, expected, actual, delta);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertNotNull(String message, Object object)
/*     */   {
/* 621 */     assertTrue(message, object != null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertNotNull(Object object)
/*     */   {
/* 631 */     assertNotNull(null, object);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertNull(String message, Object object)
/*     */   {
/* 643 */     if (object == null) {
/* 644 */       return;
/*     */     }
/* 646 */     failNotNull(message, object);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertNull(Object object)
/*     */   {
/* 656 */     assertNull(null, object);
/*     */   }
/*     */   
/*     */   private static void failNotNull(String message, Object actual) {
/* 660 */     String formatted = "";
/* 661 */     if (message != null) {
/* 662 */       formatted = message + " ";
/*     */     }
/* 664 */     fail(formatted + "expected null, but was:<" + actual + ">");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertSame(String message, Object expected, Object actual)
/*     */   {
/* 677 */     if (expected == actual) {
/* 678 */       return;
/*     */     }
/* 680 */     failNotSame(message, expected, actual);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertSame(Object expected, Object actual)
/*     */   {
/* 691 */     assertSame(null, expected, actual);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertNotSame(String message, Object unexpected, Object actual)
/*     */   {
/* 706 */     if (unexpected == actual) {
/* 707 */       failSame(message);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void assertNotSame(Object unexpected, Object actual)
/*     */   {
/* 720 */     assertNotSame(null, unexpected, actual);
/*     */   }
/*     */   
/*     */   private static void failSame(String message) {
/* 724 */     String formatted = "";
/* 725 */     if (message != null) {
/* 726 */       formatted = message + " ";
/*     */     }
/* 728 */     fail(formatted + "expected not same");
/*     */   }
/*     */   
/*     */   private static void failNotSame(String message, Object expected, Object actual)
/*     */   {
/* 733 */     String formatted = "";
/* 734 */     if (message != null) {
/* 735 */       formatted = message + " ";
/*     */     }
/* 737 */     fail(formatted + "expected same:<" + expected + "> was not:<" + actual + ">");
/*     */   }
/*     */   
/*     */ 
/*     */   private static void failNotEquals(String message, Object expected, Object actual)
/*     */   {
/* 743 */     fail(format(message, expected, actual));
/*     */   }
/*     */   
/*     */   static String format(String message, Object expected, Object actual) {
/* 747 */     String formatted = "";
/* 748 */     if ((message != null) && (!message.equals(""))) {
/* 749 */       formatted = message + " ";
/*     */     }
/* 751 */     String expectedString = String.valueOf(expected);
/* 752 */     String actualString = String.valueOf(actual);
/* 753 */     if (expectedString.equals(actualString)) {
/* 754 */       return formatted + "expected: " + formatClassAndValue(expected, expectedString) + " but was: " + formatClassAndValue(actual, actualString);
/*     */     }
/*     */     
/*     */ 
/* 758 */     return formatted + "expected:<" + expectedString + "> but was:<" + actualString + ">";
/*     */   }
/*     */   
/*     */ 
/*     */   private static String formatClassAndValue(Object value, String valueString)
/*     */   {
/* 764 */     String className = value == null ? "null" : value.getClass().getName();
/* 765 */     return className + "<" + valueString + ">";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public static void assertEquals(String message, Object[] expecteds, Object[] actuals)
/*     */   {
/* 785 */     assertArrayEquals(message, expecteds, actuals);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public static void assertEquals(Object[] expecteds, Object[] actuals)
/*     */   {
/* 802 */     assertArrayEquals(expecteds, actuals);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static <T> void assertThat(T actual, Matcher<? super T> matcher)
/*     */   {
/* 832 */     assertThat("", actual, matcher);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static <T> void assertThat(String reason, T actual, Matcher<? super T> matcher)
/*     */   {
/* 865 */     MatcherAssert.assertThat(reason, actual, matcher);
/*     */   }
/*     */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\junit.jar!\org\junit\Assert.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */