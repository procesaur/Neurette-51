/*     */ package junit.framework;
/*     */ 
/*     */ import java.io.PrintWriter;
/*     */ import java.io.StringWriter;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Enumeration;
/*     */ import java.util.List;
/*     */ import java.util.Vector;
/*     */ import org.junit.internal.MethodSorter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TestSuite
/*     */   implements Test
/*     */ {
/*     */   private String fName;
/*     */   
/*     */   public static Test createTest(Class<?> theClass, String name)
/*     */   {
/*     */     Constructor<?> constructor;
/*     */     try
/*     */     {
/*  56 */       constructor = getTestConstructor(theClass);
/*     */     } catch (NoSuchMethodException e) {
/*  58 */       return warning("Class " + theClass.getName() + " has no public constructor TestCase(String name) or TestCase()");
/*     */     }
/*     */     Object test;
/*     */     try {
/*  62 */       if (constructor.getParameterTypes().length == 0) {
/*  63 */         Object test = constructor.newInstance(new Object[0]);
/*  64 */         if ((test instanceof TestCase)) {
/*  65 */           ((TestCase)test).setName(name);
/*     */         }
/*     */       } else {
/*  68 */         test = constructor.newInstance(new Object[] { name });
/*     */       }
/*     */     } catch (InstantiationException e) {
/*  71 */       return warning("Cannot instantiate test case: " + name + " (" + exceptionToString(e) + ")");
/*     */     } catch (InvocationTargetException e) {
/*  73 */       return warning("Exception in constructor: " + name + " (" + exceptionToString(e.getTargetException()) + ")");
/*     */     } catch (IllegalAccessException e) {
/*  75 */       return warning("Cannot access test case: " + name + " (" + exceptionToString(e) + ")");
/*     */     }
/*  77 */     return (Test)test;
/*     */   }
/*     */   
/*     */ 
/*     */   public static Constructor<?> getTestConstructor(Class<?> theClass)
/*     */     throws NoSuchMethodException
/*     */   {
/*     */     try
/*     */     {
/*  86 */       return theClass.getConstructor(new Class[] { String.class });
/*     */     }
/*     */     catch (NoSuchMethodException e) {}
/*     */     
/*  90 */     return theClass.getConstructor(new Class[0]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static Test warning(final String message)
/*     */   {
/*  97 */     new TestCase("warning")
/*     */     {
/*     */       protected void runTest() {
/* 100 */         fail(message);
/*     */       }
/*     */     };
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static String exceptionToString(Throwable t)
/*     */   {
/* 109 */     StringWriter stringWriter = new StringWriter();
/* 110 */     PrintWriter writer = new PrintWriter(stringWriter);
/* 111 */     t.printStackTrace(writer);
/* 112 */     return stringWriter.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/* 117 */   private Vector<Test> fTests = new Vector(10);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TestSuite() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TestSuite(Class<?> theClass)
/*     */   {
/* 132 */     addTestsFromTestCase(theClass);
/*     */   }
/*     */   
/*     */   private void addTestsFromTestCase(Class<?> theClass) {
/* 136 */     this.fName = theClass.getName();
/*     */     try {
/* 138 */       getTestConstructor(theClass);
/*     */     } catch (NoSuchMethodException e) {
/* 140 */       addTest(warning("Class " + theClass.getName() + " has no public constructor TestCase(String name) or TestCase()"));
/* 141 */       return;
/*     */     }
/*     */     
/* 144 */     if (!Modifier.isPublic(theClass.getModifiers())) {
/* 145 */       addTest(warning("Class " + theClass.getName() + " is not public"));
/* 146 */       return;
/*     */     }
/*     */     
/* 149 */     Class<?> superClass = theClass;
/* 150 */     List<String> names = new ArrayList();
/* 151 */     while (Test.class.isAssignableFrom(superClass)) {
/* 152 */       for (Method each : MethodSorter.getDeclaredMethods(superClass)) {
/* 153 */         addTestMethod(each, names, theClass);
/*     */       }
/* 155 */       superClass = superClass.getSuperclass();
/*     */     }
/* 157 */     if (this.fTests.size() == 0) {
/* 158 */       addTest(warning("No tests found in " + theClass.getName()));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TestSuite(Class<? extends TestCase> theClass, String name)
/*     */   {
/* 168 */     this(theClass);
/* 169 */     setName(name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public TestSuite(String name)
/*     */   {
/* 176 */     setName(name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TestSuite(Class<?>... classes)
/*     */   {
/* 185 */     for (Class<?> each : classes) {
/* 186 */       addTest(testCaseForClass(each));
/*     */     }
/*     */   }
/*     */   
/*     */   private Test testCaseForClass(Class<?> each) {
/* 191 */     if (TestCase.class.isAssignableFrom(each)) {
/* 192 */       return new TestSuite(each.asSubclass(TestCase.class));
/*     */     }
/* 194 */     return warning(each.getCanonicalName() + " does not extend TestCase");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TestSuite(Class<? extends TestCase>[] classes, String name)
/*     */   {
/* 204 */     this(classes);
/* 205 */     setName(name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void addTest(Test test)
/*     */   {
/* 212 */     this.fTests.add(test);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void addTestSuite(Class<? extends TestCase> testClass)
/*     */   {
/* 219 */     addTest(new TestSuite(testClass));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int countTestCases()
/*     */   {
/* 226 */     int count = 0;
/* 227 */     for (Test each : this.fTests) {
/* 228 */       count += each.countTestCases();
/*     */     }
/* 230 */     return count;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getName()
/*     */   {
/* 239 */     return this.fName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void run(TestResult result)
/*     */   {
/* 246 */     for (Test each : this.fTests) {
/* 247 */       if (result.shouldStop()) {
/*     */         break;
/*     */       }
/* 250 */       runTest(each, result);
/*     */     }
/*     */   }
/*     */   
/*     */   public void runTest(Test test, TestResult result) {
/* 255 */     test.run(result);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setName(String name)
/*     */   {
/* 264 */     this.fName = name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Test testAt(int index)
/*     */   {
/* 271 */     return (Test)this.fTests.get(index);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int testCount()
/*     */   {
/* 278 */     return this.fTests.size();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Enumeration<Test> tests()
/*     */   {
/* 285 */     return this.fTests.elements();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 292 */     if (getName() != null) {
/* 293 */       return getName();
/*     */     }
/* 295 */     return super.toString();
/*     */   }
/*     */   
/*     */   private void addTestMethod(Method m, List<String> names, Class<?> theClass) {
/* 299 */     String name = m.getName();
/* 300 */     if (names.contains(name)) {
/* 301 */       return;
/*     */     }
/* 303 */     if (!isPublicTestMethod(m)) {
/* 304 */       if (isTestMethod(m)) {
/* 305 */         addTest(warning("Test method isn't public: " + m.getName() + "(" + theClass.getCanonicalName() + ")"));
/*     */       }
/* 307 */       return;
/*     */     }
/* 309 */     names.add(name);
/* 310 */     addTest(createTest(theClass, name));
/*     */   }
/*     */   
/*     */   private boolean isPublicTestMethod(Method m) {
/* 314 */     return (isTestMethod(m)) && (Modifier.isPublic(m.getModifiers()));
/*     */   }
/*     */   
/*     */   private boolean isTestMethod(Method m) {
/* 318 */     return (m.getParameterTypes().length == 0) && (m.getName().startsWith("test")) && (m.getReturnType().equals(Void.TYPE));
/*     */   }
/*     */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\junit.jar!\junit\framework\TestSuite.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */