/*    */ package junit.framework;
/*    */ 
/*    */ import java.io.PrintWriter;
/*    */ import java.io.StringWriter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TestFailure
/*    */ {
/*    */   protected Test fFailedTest;
/*    */   protected Throwable fThrownException;
/*    */   
/*    */   public TestFailure(Test failedTest, Throwable thrownException)
/*    */   {
/* 22 */     this.fFailedTest = failedTest;
/* 23 */     this.fThrownException = thrownException;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public Test failedTest()
/*    */   {
/* 30 */     return this.fFailedTest;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public Throwable thrownException()
/*    */   {
/* 37 */     return this.fThrownException;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public String toString()
/*    */   {
/* 45 */     StringBuffer buffer = new StringBuffer();
/* 46 */     buffer.append(this.fFailedTest + ": " + this.fThrownException.getMessage());
/* 47 */     return buffer.toString();
/*    */   }
/*    */   
/*    */   public String trace() {
/* 51 */     StringWriter stringWriter = new StringWriter();
/* 52 */     PrintWriter writer = new PrintWriter(stringWriter);
/* 53 */     thrownException().printStackTrace(writer);
/* 54 */     StringBuffer buffer = stringWriter.getBuffer();
/* 55 */     return buffer.toString();
/*    */   }
/*    */   
/*    */   public String exceptionMessage() {
/* 59 */     return thrownException().getMessage();
/*    */   }
/*    */   
/*    */   public boolean isFailure() {
/* 63 */     return thrownException() instanceof AssertionFailedError;
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\junit.jar!\junit\framework\TestFailure.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */