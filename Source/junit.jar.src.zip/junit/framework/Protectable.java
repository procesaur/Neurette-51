package junit.framework;

public abstract interface Protectable
{
  public abstract void protect()
    throws Throwable;
}


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\junit.jar!\junit\framework\Protectable.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */