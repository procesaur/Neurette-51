package junit.framework;

public abstract interface Test
{
  public abstract int countTestCases();
  
  public abstract void run(TestResult paramTestResult);
}


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\junit.jar!\junit\framework\Test.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */