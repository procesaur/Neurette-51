/*    */ package junit.runner;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Version
/*    */ {
/*    */   public static String id()
/*    */   {
/* 12 */     return "4.11";
/*    */   }
/*    */   
/*    */   public static void main(String[] args) {
/* 16 */     System.out.println(id());
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\junit.jar!\junit\runner\Version.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */