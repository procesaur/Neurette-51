package org.slf4j;

public abstract interface ILoggerFactory
{
  public abstract Logger getLogger(String paramString);
}


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\slf4j-api-1.7.5.jar!\org\slf4j\ILoggerFactory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */