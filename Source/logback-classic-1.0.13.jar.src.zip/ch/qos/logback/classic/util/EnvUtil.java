/*    */ package ch.qos.logback.classic.util;
/*    */ 
/*    */ import ch.qos.logback.core.util.Loader;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EnvUtil
/*    */ {
/*    */   public static boolean isGroovyAvailable()
/*    */   {
/* 25 */     ClassLoader classLoader = Loader.getClassLoaderOfClass(EnvUtil.class);
/*    */     try {
/* 27 */       Class bindingClass = classLoader.loadClass("groovy.lang.Binding");
/* 28 */       return bindingClass != null;
/*    */     } catch (ClassNotFoundException e) {}
/* 30 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\logback-classic-1.0.13.jar!\ch\qos\logback\classic\util\EnvUtil.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */