package ch.qos.logback.classic.net.server;

import ch.qos.logback.classic.LoggerContext;
import ch.qos.logback.core.net.server.Client;

abstract interface RemoteAppenderClient
  extends Client
{
  public abstract void setLoggerContext(LoggerContext paramLoggerContext);
}


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\logback-classic-1.0.13.jar!\ch\qos\logback\classic\net\server\RemoteAppenderClient.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */