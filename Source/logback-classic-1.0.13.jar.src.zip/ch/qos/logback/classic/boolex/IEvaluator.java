package ch.qos.logback.classic.boolex;

import ch.qos.logback.classic.spi.ILoggingEvent;

public abstract interface IEvaluator
{
  public abstract boolean doEvaluate(ILoggingEvent paramILoggingEvent);
}


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\logback-classic-1.0.13.jar!\ch\qos\logback\classic\boolex\IEvaluator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */