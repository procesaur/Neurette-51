/*    */ package ch.qos.logback.classic.gaffer;
/*    */ 
/*    */ import ch.qos.logback.core.Appender;
/*    */ import org.codehaus.groovy.runtime.callsite.CallSite;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AppenderDelegate
/*    */   extends ComponentDelegate
/*    */ {
/*    */   public AppenderDelegate(Appender appender)
/*    */   {
/* 25 */     super(appender);
/*    */   }
/*    */   
/*    */   public String getLabel() {
/* 29 */     CallSite[] arrayOfCallSite = $getCallSiteArray();return "appender";return null;
/*    */   }
/*    */   
/*    */   static
/*    */   {
/*    */     __$swapInit();
/*    */     long l1 = 0L;
/*    */     __timeStamp__239_neverHappen1368189067731 = l1;
/*    */     long l2 = 1368189067731L;
/*    */     __timeStamp = l2;
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\logback-classic-1.0.13.jar!\ch\qos\logback\classic\gaffer\AppenderDelegate.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */