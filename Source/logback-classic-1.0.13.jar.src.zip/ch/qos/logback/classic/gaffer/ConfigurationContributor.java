package ch.qos.logback.classic.gaffer;

import java.util.Map;

public abstract interface ConfigurationContributor
{
  public abstract Map<String, String> getMappings();
}


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\logback-classic-1.0.13.jar!\ch\qos\logback\classic\gaffer\ConfigurationContributor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */