/*    */ package ch.qos.logback.classic.pattern;
/*    */ 
/*    */ import ch.qos.logback.classic.spi.ILoggingEvent;
/*    */ import ch.qos.logback.classic.spi.StackTraceElementProxy;
/*    */ import ch.qos.logback.classic.spi.ThrowableProxyUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ExtendedThrowableProxyConverter
/*    */   extends ThrowableProxyConverter
/*    */ {
/*    */   protected void extraData(StringBuilder builder, StackTraceElementProxy step)
/*    */   {
/* 24 */     if (step != null) {
/* 25 */       ThrowableProxyUtil.subjoinPackagingData(builder, step);
/*    */     }
/*    */   }
/*    */   
/*    */   protected void prepareLoggingEvent(ILoggingEvent event) {}
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\logback-classic-1.0.13.jar!\ch\qos\logback\classic\pattern\ExtendedThrowableProxyConverter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */