package ch.qos.logback.classic.pattern;

import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.pattern.DynamicConverter;

public abstract class ClassicConverter
  extends DynamicConverter<ILoggingEvent>
{}


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\logback-classic-1.0.13.jar!\ch\qos\logback\classic\pattern\ClassicConverter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */