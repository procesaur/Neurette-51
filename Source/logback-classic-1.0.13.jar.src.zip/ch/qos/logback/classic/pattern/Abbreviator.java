package ch.qos.logback.classic.pattern;

public abstract interface Abbreviator
{
  public abstract String abbreviate(String paramString);
}


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\logback-classic-1.0.13.jar!\ch\qos\logback\classic\pattern\Abbreviator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */