package ch.qos.logback.classic.spi;

import ch.qos.logback.classic.LoggerContext;
import ch.qos.logback.core.spi.ContextAware;

public abstract interface LoggerContextAware
  extends ContextAware
{
  public abstract void setLoggerContext(LoggerContext paramLoggerContext);
}


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\logback-classic-1.0.13.jar!\ch\qos\logback\classic\spi\LoggerContextAware.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */