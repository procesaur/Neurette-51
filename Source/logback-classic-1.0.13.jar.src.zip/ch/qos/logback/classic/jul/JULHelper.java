/*    */ package ch.qos.logback.classic.jul;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JULHelper
/*    */ {
/*    */   public static final boolean isRegularNonRootLogger(java.util.logging.Logger julLogger)
/*    */   {
/* 23 */     if (julLogger == null)
/* 24 */       return false;
/* 25 */     return !julLogger.getName().equals("");
/*    */   }
/*    */   
/*    */   public static final boolean isRoot(java.util.logging.Logger julLogger) {
/* 29 */     if (julLogger == null)
/* 30 */       return false;
/* 31 */     return julLogger.getName().equals("");
/*    */   }
/*    */   
/*    */   public static java.util.logging.Level asJULLevel(ch.qos.logback.classic.Level lbLevel) {
/* 35 */     switch (lbLevel.levelInt) {
/*    */     case -2147483648: 
/* 37 */       return java.util.logging.Level.ALL;
/*    */     case 5000: 
/* 39 */       return java.util.logging.Level.FINEST;
/*    */     case 10000: 
/* 41 */       return java.util.logging.Level.FINE;
/*    */     case 20000: 
/* 43 */       return java.util.logging.Level.INFO;
/*    */     case 30000: 
/* 45 */       return java.util.logging.Level.WARNING;
/*    */     case 40000: 
/* 47 */       return java.util.logging.Level.SEVERE;
/*    */     case 2147483647: 
/* 49 */       return java.util.logging.Level.OFF;
/*    */     }
/* 51 */     throw new IllegalArgumentException("Unexpected level [" + lbLevel + "]");
/*    */   }
/*    */   
/*    */   public static String asJULLoggerName(String loggerName)
/*    */   {
/* 56 */     if ("ROOT".equals(loggerName)) {
/* 57 */       return "";
/*    */     }
/* 59 */     return loggerName;
/*    */   }
/*    */   
/*    */   public static java.util.logging.Logger asJULLogger(String loggerName) {
/* 63 */     String julLoggerName = asJULLoggerName(loggerName);
/* 64 */     return java.util.logging.Logger.getLogger(julLoggerName);
/*    */   }
/*    */   
/*    */   public static java.util.logging.Logger asJULLogger(ch.qos.logback.classic.Logger logger) {
/* 68 */     return asJULLogger(logger.getName());
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\logback-classic-1.0.13.jar!\ch\qos\logback\classic\jul\JULHelper.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */