package ch.qos.logback.classic.db.names;

public abstract interface DBNameResolver
{
  public abstract <N extends Enum<?>> String getTableName(N paramN);
  
  public abstract <N extends Enum<?>> String getColumnName(N paramN);
}


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\logback-classic-1.0.13.jar!\ch\qos\logback\classic\db\names\DBNameResolver.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */