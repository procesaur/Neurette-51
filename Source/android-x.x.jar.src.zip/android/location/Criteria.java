/*    */ package android.location;
/*    */ 
/*    */ import android.os.Parcel;
/*    */ 
/*  5 */ public class Criteria implements android.os.Parcelable { public Criteria() { throw new RuntimeException("Stub!"); }
/*  6 */   public Criteria(Criteria criteria) { throw new RuntimeException("Stub!"); }
/*  7 */   public void setAccuracy(int accuracy) { throw new RuntimeException("Stub!"); }
/*  8 */   public int getAccuracy() { throw new RuntimeException("Stub!"); }
/*  9 */   public void setPowerRequirement(int level) { throw new RuntimeException("Stub!"); }
/* 10 */   public int getPowerRequirement() { throw new RuntimeException("Stub!"); }
/* 11 */   public void setCostAllowed(boolean costAllowed) { throw new RuntimeException("Stub!"); }
/* 12 */   public boolean isCostAllowed() { throw new RuntimeException("Stub!"); }
/* 13 */   public void setAltitudeRequired(boolean altitudeRequired) { throw new RuntimeException("Stub!"); }
/* 14 */   public boolean isAltitudeRequired() { throw new RuntimeException("Stub!"); }
/* 15 */   public void setSpeedRequired(boolean speedRequired) { throw new RuntimeException("Stub!"); }
/* 16 */   public boolean isSpeedRequired() { throw new RuntimeException("Stub!"); }
/* 17 */   public void setBearingRequired(boolean bearingRequired) { throw new RuntimeException("Stub!"); }
/* 18 */   public boolean isBearingRequired() { throw new RuntimeException("Stub!"); }
/* 19 */   public int describeContents() { throw new RuntimeException("Stub!"); }
/* 20 */   public void writeToParcel(Parcel parcel, int flags) { throw new RuntimeException("Stub!"); }
/*    */   
/*    */   public static final int NO_REQUIREMENT = 0;
/*    */   public static final int POWER_LOW = 1;
/*    */   public static final int POWER_MEDIUM = 2;
/*    */   public static final int POWER_HIGH = 3;
/*    */   public static final int ACCURACY_FINE = 1;
/*    */   public static final int ACCURACY_COARSE = 2;
/* 28 */   public static final android.os.Parcelable.Creator<Criteria> CREATOR = null;
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\location\Criteria.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */