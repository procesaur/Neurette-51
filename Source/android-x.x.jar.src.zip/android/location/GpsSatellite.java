/*    */ package android.location;
/*    */ 
/*    */ public final class GpsSatellite {
/*  4 */   GpsSatellite() { throw new RuntimeException("Stub!"); }
/*  5 */   public int getPrn() { throw new RuntimeException("Stub!"); }
/*  6 */   public float getSnr() { throw new RuntimeException("Stub!"); }
/*  7 */   public float getElevation() { throw new RuntimeException("Stub!"); }
/*  8 */   public float getAzimuth() { throw new RuntimeException("Stub!"); }
/*  9 */   public boolean hasEphemeris() { throw new RuntimeException("Stub!"); }
/* 10 */   public boolean hasAlmanac() { throw new RuntimeException("Stub!"); }
/* 11 */   public boolean usedInFix() { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\location\GpsSatellite.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */