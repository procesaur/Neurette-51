/*   */ package android.text.method;
/*   */ 
/*   */ import android.view.View;
/*   */ 
/* 5 */ public class QwertyKeyListener extends BaseKeyListener { public QwertyKeyListener(TextKeyListener.Capitalize cap, boolean autotext) { throw new RuntimeException("Stub!"); }
/* 6 */   public static QwertyKeyListener getInstance(boolean autotext, TextKeyListener.Capitalize cap) { throw new RuntimeException("Stub!"); }
/* 7 */   public int getInputType() { throw new RuntimeException("Stub!"); }
/* 8 */   public boolean onKeyDown(View view, android.text.Editable content, int keyCode, android.view.KeyEvent event) { throw new RuntimeException("Stub!"); }
/* 9 */   public static void markAsReplaced(android.text.Spannable content, int start, int end, String original) { throw new RuntimeException("Stub!"); }
/*   */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\text\method\QwertyKeyListener.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */