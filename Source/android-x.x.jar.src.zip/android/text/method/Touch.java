/*   */ package android.text.method;
/*   */ import android.widget.TextView;
/*   */ 
/* 4 */ public class Touch { Touch() { throw new RuntimeException("Stub!"); }
/* 5 */   public static void scrollTo(TextView widget, android.text.Layout layout, int x, int y) { throw new RuntimeException("Stub!"); }
/* 6 */   public static boolean onTouchEvent(TextView widget, android.text.Spannable buffer, android.view.MotionEvent event) { throw new RuntimeException("Stub!"); }
/* 7 */   public static int getInitialScrollX(TextView widget, android.text.Spannable buffer) { throw new RuntimeException("Stub!"); }
/* 8 */   public static int getInitialScrollY(TextView widget, android.text.Spannable buffer) { throw new RuntimeException("Stub!"); }
/*   */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\text\method\Touch.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */