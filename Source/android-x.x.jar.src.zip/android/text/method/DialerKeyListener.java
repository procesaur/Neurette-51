/*    */ package android.text.method;
/*    */ 
/*    */ import android.text.Spannable;
/*    */ 
/*  5 */ public class DialerKeyListener extends NumberKeyListener { public DialerKeyListener() { throw new RuntimeException("Stub!"); }
/*  6 */   protected char[] getAcceptedChars() { throw new RuntimeException("Stub!"); }
/*  7 */   public static DialerKeyListener getInstance() { throw new RuntimeException("Stub!"); }
/*  8 */   public int getInputType() { throw new RuntimeException("Stub!"); }
/*  9 */   protected int lookup(android.view.KeyEvent event, Spannable content) { throw new RuntimeException("Stub!"); }
/* 10 */   public static final char[] CHARACTERS = null;
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\text\method\DialerKeyListener.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */