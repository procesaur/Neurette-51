/*   */ package android.text.method;
/*   */ 
/*   */ import android.view.View;
/*   */ 
/*   */ public class CharacterPickerDialog extends android.app.Dialog implements android.widget.AdapterView.OnItemClickListener, android.view.View.OnClickListener {
/* 6 */   public CharacterPickerDialog(android.content.Context context, View view, android.text.Editable text, String options, boolean insert) { super((android.content.Context)null, false, (android.content.DialogInterface.OnCancelListener)null);throw new RuntimeException("Stub!"); }
/* 7 */   protected void onCreate(android.os.Bundle savedInstanceState) { throw new RuntimeException("Stub!"); }
/* 8 */   public void onItemClick(android.widget.AdapterView parent, View view, int position, long id) { throw new RuntimeException("Stub!"); }
/* 9 */   public void onClick(View v) { throw new RuntimeException("Stub!"); }
/*   */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\text\method\CharacterPickerDialog.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */