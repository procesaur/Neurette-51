/*   */ package android.text.method;
/*   */ 
/*   */ public class HideReturnsTransformationMethod
/*   */   extends ReplacementTransformationMethod {
/* 5 */   public HideReturnsTransformationMethod() { throw new RuntimeException("Stub!"); }
/* 6 */   protected char[] getOriginal() { throw new RuntimeException("Stub!"); }
/* 7 */   protected char[] getReplacement() { throw new RuntimeException("Stub!"); }
/* 8 */   public static HideReturnsTransformationMethod getInstance() { throw new RuntimeException("Stub!"); }
/*   */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\text\method\HideReturnsTransformationMethod.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */