/*   */ package android.text.method;
/*   */ 
/*   */ public class DateTimeKeyListener
/*   */   extends NumberKeyListener {
/* 5 */   public DateTimeKeyListener() { throw new RuntimeException("Stub!"); }
/* 6 */   public int getInputType() { throw new RuntimeException("Stub!"); }
/* 7 */   protected char[] getAcceptedChars() { throw new RuntimeException("Stub!"); }
/* 8 */   public static DateTimeKeyListener getInstance() { throw new RuntimeException("Stub!"); }
/* 9 */   public static final char[] CHARACTERS = null;
/*   */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\text\method\DateTimeKeyListener.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */