/*    */ package android.text.method;
/*    */ 
/*    */ import android.widget.TextView;
/*    */ 
/*  5 */ public class ArrowKeyMovementMethod implements MovementMethod { public ArrowKeyMovementMethod() { throw new RuntimeException("Stub!"); }
/*  6 */   public boolean onKeyDown(TextView widget, android.text.Spannable buffer, int keyCode, android.view.KeyEvent event) { throw new RuntimeException("Stub!"); }
/*  7 */   public boolean onKeyUp(TextView widget, android.text.Spannable buffer, int keyCode, android.view.KeyEvent event) { throw new RuntimeException("Stub!"); }
/*  8 */   public boolean onKeyOther(TextView view, android.text.Spannable text, android.view.KeyEvent event) { throw new RuntimeException("Stub!"); }
/*  9 */   public boolean onTrackballEvent(TextView widget, android.text.Spannable text, android.view.MotionEvent event) { throw new RuntimeException("Stub!"); }
/* 10 */   public boolean onTouchEvent(TextView widget, android.text.Spannable buffer, android.view.MotionEvent event) { throw new RuntimeException("Stub!"); }
/* 11 */   public boolean canSelectArbitrarily() { throw new RuntimeException("Stub!"); }
/* 12 */   public void initialize(TextView widget, android.text.Spannable text) { throw new RuntimeException("Stub!"); }
/* 13 */   public void onTakeFocus(TextView view, android.text.Spannable text, int dir) { throw new RuntimeException("Stub!"); }
/* 14 */   public static MovementMethod getInstance() { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\text\method\ArrowKeyMovementMethod.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */