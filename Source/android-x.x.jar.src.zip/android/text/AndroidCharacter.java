/*   */ package android.text;
/*   */ 
/*   */ public class AndroidCharacter {
/* 4 */   public AndroidCharacter() { throw new RuntimeException("Stub!"); }
/*   */   
/*   */   public static native void getDirectionalities(char[] paramArrayOfChar, byte[] paramArrayOfByte, int paramInt);
/*   */   
/*   */   public static native boolean mirror(char[] paramArrayOfChar, int paramInt1, int paramInt2);
/*   */   
/*   */   public static native char getMirror(char paramChar);
/*   */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\text\AndroidCharacter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */