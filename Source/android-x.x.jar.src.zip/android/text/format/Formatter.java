/*   */ package android.text.format;
/*   */ import android.content.Context;
/*   */ 
/* 4 */ public final class Formatter { public Formatter() { throw new RuntimeException("Stub!"); }
/* 5 */   public static String formatFileSize(Context context, long number) { throw new RuntimeException("Stub!"); }
/* 6 */   public static String formatShortFileSize(Context context, long number) { throw new RuntimeException("Stub!"); }
/* 7 */   public static String formatIpAddress(int addr) { throw new RuntimeException("Stub!"); }
/*   */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\text\format\Formatter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */