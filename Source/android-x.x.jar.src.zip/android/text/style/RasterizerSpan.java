/*   */ package android.text.style;
/*   */ 
/*   */ import android.graphics.Rasterizer;
/*   */ 
/*   */ public class RasterizerSpan extends CharacterStyle implements UpdateAppearance {
/* 6 */   public RasterizerSpan(Rasterizer r) { throw new RuntimeException("Stub!"); }
/* 7 */   public Rasterizer getRasterizer() { throw new RuntimeException("Stub!"); }
/* 8 */   public void updateDrawState(android.text.TextPaint ds) { throw new RuntimeException("Stub!"); }
/*   */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\text\style\RasterizerSpan.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */