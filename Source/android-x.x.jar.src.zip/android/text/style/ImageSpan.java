/*    */ package android.text.style;
/*    */ 
/*    */ import android.content.Context;
/*    */ 
/*  5 */ public class ImageSpan extends DynamicDrawableSpan { public ImageSpan(android.graphics.Bitmap b) { throw new RuntimeException("Stub!"); }
/*  6 */   public ImageSpan(android.graphics.Bitmap b, int verticalAlignment) { throw new RuntimeException("Stub!"); }
/*  7 */   public ImageSpan(Context context, android.graphics.Bitmap b) { throw new RuntimeException("Stub!"); }
/*  8 */   public ImageSpan(Context context, android.graphics.Bitmap b, int verticalAlignment) { throw new RuntimeException("Stub!"); }
/*  9 */   public ImageSpan(android.graphics.drawable.Drawable d) { throw new RuntimeException("Stub!"); }
/* 10 */   public ImageSpan(android.graphics.drawable.Drawable d, int verticalAlignment) { throw new RuntimeException("Stub!"); }
/* 11 */   public ImageSpan(android.graphics.drawable.Drawable d, String source) { throw new RuntimeException("Stub!"); }
/* 12 */   public ImageSpan(android.graphics.drawable.Drawable d, String source, int verticalAlignment) { throw new RuntimeException("Stub!"); }
/* 13 */   public ImageSpan(Context context, android.net.Uri uri) { throw new RuntimeException("Stub!"); }
/* 14 */   public ImageSpan(Context context, android.net.Uri uri, int verticalAlignment) { throw new RuntimeException("Stub!"); }
/* 15 */   public ImageSpan(Context context, int resourceId) { throw new RuntimeException("Stub!"); }
/* 16 */   public ImageSpan(Context context, int resourceId, int verticalAlignment) { throw new RuntimeException("Stub!"); }
/* 17 */   public android.graphics.drawable.Drawable getDrawable() { throw new RuntimeException("Stub!"); }
/* 18 */   public String getSource() { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\text\style\ImageSpan.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */