/*    */ package android.text.style;
/*    */ 
/*    */ import android.text.TextPaint;
/*    */ 
/*    */ public class RelativeSizeSpan extends MetricAffectingSpan implements android.text.ParcelableSpan {
/*  6 */   public RelativeSizeSpan(float proportion) { throw new RuntimeException("Stub!"); }
/*  7 */   public RelativeSizeSpan(android.os.Parcel src) { throw new RuntimeException("Stub!"); }
/*  8 */   public int getSpanTypeId() { throw new RuntimeException("Stub!"); }
/*  9 */   public int describeContents() { throw new RuntimeException("Stub!"); }
/* 10 */   public void writeToParcel(android.os.Parcel dest, int flags) { throw new RuntimeException("Stub!"); }
/* 11 */   public float getSizeChange() { throw new RuntimeException("Stub!"); }
/* 12 */   public void updateDrawState(TextPaint ds) { throw new RuntimeException("Stub!"); }
/* 13 */   public void updateMeasureState(TextPaint ds) { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\text\style\RelativeSizeSpan.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */