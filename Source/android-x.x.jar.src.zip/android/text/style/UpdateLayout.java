package android.text.style;

public abstract interface UpdateLayout
  extends UpdateAppearance
{}


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\text\style\UpdateLayout.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */