/*   */ package android.text.style;
/*   */ 
/*   */ import android.graphics.MaskFilter;
/*   */ 
/*   */ public class MaskFilterSpan extends CharacterStyle implements UpdateAppearance {
/* 6 */   public MaskFilterSpan(MaskFilter filter) { throw new RuntimeException("Stub!"); }
/* 7 */   public MaskFilter getMaskFilter() { throw new RuntimeException("Stub!"); }
/* 8 */   public void updateDrawState(android.text.TextPaint ds) { throw new RuntimeException("Stub!"); }
/*   */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\text\style\MaskFilterSpan.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */