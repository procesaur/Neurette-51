/*   */ package android.text;
/*   */ 
/*   */ public abstract interface NoCopySpan
/*   */ {
/*   */   public static class Concrete implements NoCopySpan {
/*   */     public Concrete() {
/* 7 */       throw new RuntimeException("Stub!");
/*   */     }
/*   */   }
/*   */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\text\NoCopySpan.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */