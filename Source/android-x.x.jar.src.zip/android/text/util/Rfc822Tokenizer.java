/*   */ package android.text.util;
/*   */ 
/*   */ import android.widget.MultiAutoCompleteTextView.Tokenizer;
/*   */ 
/* 5 */ public class Rfc822Tokenizer implements MultiAutoCompleteTextView.Tokenizer { public Rfc822Tokenizer() { throw new RuntimeException("Stub!"); }
/* 6 */   public static Rfc822Token[] tokenize(CharSequence text) { throw new RuntimeException("Stub!"); }
/* 7 */   public int findTokenStart(CharSequence text, int cursor) { throw new RuntimeException("Stub!"); }
/* 8 */   public int findTokenEnd(CharSequence text, int cursor) { throw new RuntimeException("Stub!"); }
/* 9 */   public CharSequence terminateToken(CharSequence text) { throw new RuntimeException("Stub!"); }
/*   */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\text\util\Rfc822Tokenizer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */