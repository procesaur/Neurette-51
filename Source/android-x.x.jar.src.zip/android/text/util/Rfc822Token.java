/*    */ package android.text.util;
/*    */ 
/*    */ public class Rfc822Token {
/*  4 */   public Rfc822Token(String name, String address, String comment) { throw new RuntimeException("Stub!"); }
/*  5 */   public String getName() { throw new RuntimeException("Stub!"); }
/*  6 */   public String getAddress() { throw new RuntimeException("Stub!"); }
/*  7 */   public String getComment() { throw new RuntimeException("Stub!"); }
/*  8 */   public void setName(String name) { throw new RuntimeException("Stub!"); }
/*  9 */   public void setAddress(String address) { throw new RuntimeException("Stub!"); }
/* 10 */   public void setComment(String comment) { throw new RuntimeException("Stub!"); }
/* 11 */   public String toString() { throw new RuntimeException("Stub!"); }
/* 12 */   public static String quoteNameIfNecessary(String name) { throw new RuntimeException("Stub!"); }
/* 13 */   public static String quoteName(String name) { throw new RuntimeException("Stub!"); }
/* 14 */   public static String quoteComment(String comment) { throw new RuntimeException("Stub!"); }
/* 15 */   public int hashCode() { throw new RuntimeException("Stub!"); }
/* 16 */   public boolean equals(Object o) { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\text\util\Rfc822Token.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */