package android.text;

import android.os.Parcelable;

public abstract interface ParcelableSpan
  extends Parcelable
{
  public abstract int getSpanTypeId();
}


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\text\ParcelableSpan.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */