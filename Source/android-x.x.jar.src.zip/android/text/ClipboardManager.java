/*   */ package android.text;
/*   */ 
/*   */ public class ClipboardManager {
/* 4 */   ClipboardManager() { throw new RuntimeException("Stub!"); }
/* 5 */   public CharSequence getText() { throw new RuntimeException("Stub!"); }
/* 6 */   public void setText(CharSequence text) { throw new RuntimeException("Stub!"); }
/* 7 */   public boolean hasText() { throw new RuntimeException("Stub!"); }
/*   */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\text\ClipboardManager.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */