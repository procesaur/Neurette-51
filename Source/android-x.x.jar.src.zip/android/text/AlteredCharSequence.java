/*    */ package android.text;
/*    */ 
/*    */ public class AlteredCharSequence
/*    */   implements CharSequence, GetChars {
/*  5 */   AlteredCharSequence() { throw new RuntimeException("Stub!"); }
/*  6 */   public static AlteredCharSequence make(CharSequence source, char[] sub, int substart, int subend) { throw new RuntimeException("Stub!"); }
/*  7 */   public char charAt(int off) { throw new RuntimeException("Stub!"); }
/*  8 */   public int length() { throw new RuntimeException("Stub!"); }
/*  9 */   public CharSequence subSequence(int start, int end) { throw new RuntimeException("Stub!"); }
/* 10 */   public void getChars(int start, int end, char[] dest, int off) { throw new RuntimeException("Stub!"); }
/* 11 */   public String toString() { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\text\AlteredCharSequence.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */