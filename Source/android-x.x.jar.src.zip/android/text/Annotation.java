/*    */ package android.text;
/*    */ 
/*    */ import android.os.Parcel;
/*    */ 
/*  5 */ public class Annotation implements ParcelableSpan { public Annotation(String key, String value) { throw new RuntimeException("Stub!"); }
/*  6 */   public Annotation(Parcel src) { throw new RuntimeException("Stub!"); }
/*  7 */   public int getSpanTypeId() { throw new RuntimeException("Stub!"); }
/*  8 */   public int describeContents() { throw new RuntimeException("Stub!"); }
/*  9 */   public void writeToParcel(Parcel dest, int flags) { throw new RuntimeException("Stub!"); }
/* 10 */   public String getKey() { throw new RuntimeException("Stub!"); }
/* 11 */   public String getValue() { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\text\Annotation.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */