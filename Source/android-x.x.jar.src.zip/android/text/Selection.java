/*    */ package android.text;
/*    */ 
/*    */ public class Selection {
/*  4 */   Selection() { throw new RuntimeException("Stub!"); }
/*  5 */   public static final int getSelectionStart(CharSequence text) { throw new RuntimeException("Stub!"); }
/*  6 */   public static final int getSelectionEnd(CharSequence text) { throw new RuntimeException("Stub!"); }
/*  7 */   public static void setSelection(Spannable text, int start, int stop) { throw new RuntimeException("Stub!"); }
/*  8 */   public static final void setSelection(Spannable text, int index) { throw new RuntimeException("Stub!"); }
/*  9 */   public static final void selectAll(Spannable text) { throw new RuntimeException("Stub!"); }
/* 10 */   public static final void extendSelection(Spannable text, int index) { throw new RuntimeException("Stub!"); }
/* 11 */   public static final void removeSelection(Spannable text) { throw new RuntimeException("Stub!"); }
/* 12 */   public static boolean moveUp(Spannable text, Layout layout) { throw new RuntimeException("Stub!"); }
/* 13 */   public static boolean moveDown(Spannable text, Layout layout) { throw new RuntimeException("Stub!"); }
/* 14 */   public static boolean moveLeft(Spannable text, Layout layout) { throw new RuntimeException("Stub!"); }
/* 15 */   public static boolean moveRight(Spannable text, Layout layout) { throw new RuntimeException("Stub!"); }
/* 16 */   public static boolean extendUp(Spannable text, Layout layout) { throw new RuntimeException("Stub!"); }
/* 17 */   public static boolean extendDown(Spannable text, Layout layout) { throw new RuntimeException("Stub!"); }
/* 18 */   public static boolean extendLeft(Spannable text, Layout layout) { throw new RuntimeException("Stub!"); }
/* 19 */   public static boolean extendRight(Spannable text, Layout layout) { throw new RuntimeException("Stub!"); }
/* 20 */   public static boolean extendToLeftEdge(Spannable text, Layout layout) { throw new RuntimeException("Stub!"); }
/* 21 */   public static boolean extendToRightEdge(Spannable text, Layout layout) { throw new RuntimeException("Stub!"); }
/* 22 */   public static boolean moveToLeftEdge(Spannable text, Layout layout) { throw new RuntimeException("Stub!"); }
/* 23 */   public static boolean moveToRightEdge(Spannable text, Layout layout) { throw new RuntimeException("Stub!"); }
/*    */   
/*    */ 
/* 26 */   public static final Object SELECTION_END = null; public static final Object SELECTION_START = null;
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\text\Selection.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */