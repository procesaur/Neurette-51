package android.text;

public abstract interface GetChars
  extends CharSequence
{
  public abstract void getChars(int paramInt1, int paramInt2, char[] paramArrayOfChar, int paramInt3);
}


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\text\GetChars.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */