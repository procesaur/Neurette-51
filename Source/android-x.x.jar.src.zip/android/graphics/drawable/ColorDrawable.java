/*    */ package android.graphics.drawable;
/*    */ 
/*    */ import android.graphics.Canvas;
/*    */ 
/*  5 */ public class ColorDrawable extends Drawable { public ColorDrawable() { throw new RuntimeException("Stub!"); }
/*  6 */   public ColorDrawable(int color) { throw new RuntimeException("Stub!"); }
/*  7 */   public int getChangingConfigurations() { throw new RuntimeException("Stub!"); }
/*  8 */   public void draw(Canvas canvas) { throw new RuntimeException("Stub!"); }
/*  9 */   public int getAlpha() { throw new RuntimeException("Stub!"); }
/* 10 */   public void setAlpha(int alpha) { throw new RuntimeException("Stub!"); }
/* 11 */   public void setColorFilter(android.graphics.ColorFilter colorFilter) { throw new RuntimeException("Stub!"); }
/* 12 */   public int getOpacity() { throw new RuntimeException("Stub!"); }
/* 13 */   public void inflate(android.content.res.Resources r, org.xmlpull.v1.XmlPullParser parser, android.util.AttributeSet attrs) throws org.xmlpull.v1.XmlPullParserException, java.io.IOException { throw new RuntimeException("Stub!"); }
/* 14 */   public Drawable.ConstantState getConstantState() { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\graphics\drawable\ColorDrawable.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */