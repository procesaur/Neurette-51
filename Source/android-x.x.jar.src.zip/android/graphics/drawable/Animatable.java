package android.graphics.drawable;

public abstract interface Animatable
{
  public abstract void start();
  
  public abstract void stop();
  
  public abstract boolean isRunning();
}


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\graphics\drawable\Animatable.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */