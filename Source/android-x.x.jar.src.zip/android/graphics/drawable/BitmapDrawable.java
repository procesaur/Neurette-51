/*    */ package android.graphics.drawable;
/*    */ 
/*    */ import android.graphics.Shader.TileMode;
/*    */ 
/*  5 */ public class BitmapDrawable extends Drawable { public BitmapDrawable() { throw new RuntimeException("Stub!"); }
/*  6 */   public BitmapDrawable(android.content.res.Resources res) { throw new RuntimeException("Stub!"); }
/*  7 */   public BitmapDrawable(android.graphics.Bitmap bitmap) { throw new RuntimeException("Stub!"); }
/*  8 */   public BitmapDrawable(android.content.res.Resources res, android.graphics.Bitmap bitmap) { throw new RuntimeException("Stub!"); }
/*  9 */   public BitmapDrawable(String filepath) { throw new RuntimeException("Stub!"); }
/* 10 */   public BitmapDrawable(android.content.res.Resources res, String filepath) { throw new RuntimeException("Stub!"); }
/* 11 */   public BitmapDrawable(java.io.InputStream is) { throw new RuntimeException("Stub!"); }
/* 12 */   public BitmapDrawable(android.content.res.Resources res, java.io.InputStream is) { throw new RuntimeException("Stub!"); }
/* 13 */   public final android.graphics.Paint getPaint() { throw new RuntimeException("Stub!"); }
/* 14 */   public final android.graphics.Bitmap getBitmap() { throw new RuntimeException("Stub!"); }
/* 15 */   public void setTargetDensity(android.graphics.Canvas canvas) { throw new RuntimeException("Stub!"); }
/* 16 */   public void setTargetDensity(android.util.DisplayMetrics metrics) { throw new RuntimeException("Stub!"); }
/* 17 */   public void setTargetDensity(int density) { throw new RuntimeException("Stub!"); }
/* 18 */   public int getGravity() { throw new RuntimeException("Stub!"); }
/* 19 */   public void setGravity(int gravity) { throw new RuntimeException("Stub!"); }
/* 20 */   public void setAntiAlias(boolean aa) { throw new RuntimeException("Stub!"); }
/* 21 */   public void setFilterBitmap(boolean filter) { throw new RuntimeException("Stub!"); }
/* 22 */   public void setDither(boolean dither) { throw new RuntimeException("Stub!"); }
/* 23 */   public Shader.TileMode getTileModeX() { throw new RuntimeException("Stub!"); }
/* 24 */   public Shader.TileMode getTileModeY() { throw new RuntimeException("Stub!"); }
/* 25 */   public void setTileModeX(Shader.TileMode mode) { throw new RuntimeException("Stub!"); }
/* 26 */   public final void setTileModeY(Shader.TileMode mode) { throw new RuntimeException("Stub!"); }
/* 27 */   public void setTileModeXY(Shader.TileMode xmode, Shader.TileMode ymode) { throw new RuntimeException("Stub!"); }
/* 28 */   public int getChangingConfigurations() { throw new RuntimeException("Stub!"); }
/* 29 */   protected void onBoundsChange(android.graphics.Rect bounds) { throw new RuntimeException("Stub!"); }
/* 30 */   public void draw(android.graphics.Canvas canvas) { throw new RuntimeException("Stub!"); }
/* 31 */   public void setAlpha(int alpha) { throw new RuntimeException("Stub!"); }
/* 32 */   public void setColorFilter(android.graphics.ColorFilter cf) { throw new RuntimeException("Stub!"); }
/* 33 */   public Drawable mutate() { throw new RuntimeException("Stub!"); }
/* 34 */   public void inflate(android.content.res.Resources r, org.xmlpull.v1.XmlPullParser parser, android.util.AttributeSet attrs) throws org.xmlpull.v1.XmlPullParserException, java.io.IOException { throw new RuntimeException("Stub!"); }
/* 35 */   public int getIntrinsicWidth() { throw new RuntimeException("Stub!"); }
/* 36 */   public int getIntrinsicHeight() { throw new RuntimeException("Stub!"); }
/* 37 */   public int getOpacity() { throw new RuntimeException("Stub!"); }
/* 38 */   public final Drawable.ConstantState getConstantState() { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\graphics\drawable\BitmapDrawable.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */