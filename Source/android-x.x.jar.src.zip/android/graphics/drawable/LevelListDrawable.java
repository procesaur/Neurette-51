/*   */ package android.graphics.drawable;
/*   */ 
/*   */ import org.xmlpull.v1.XmlPullParser;
/*   */ 
/* 5 */ public class LevelListDrawable extends DrawableContainer { public LevelListDrawable() { throw new RuntimeException("Stub!"); }
/* 6 */   public void addLevel(int low, int high, Drawable drawable) { throw new RuntimeException("Stub!"); }
/* 7 */   protected boolean onLevelChange(int level) { throw new RuntimeException("Stub!"); }
/* 8 */   public void inflate(android.content.res.Resources r, XmlPullParser parser, android.util.AttributeSet attrs) throws org.xmlpull.v1.XmlPullParserException, java.io.IOException { throw new RuntimeException("Stub!"); }
/* 9 */   public Drawable mutate() { throw new RuntimeException("Stub!"); }
/*   */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\graphics\drawable\LevelListDrawable.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */