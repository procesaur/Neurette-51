/*    */ package android.graphics.drawable;
/*    */ 
/*    */ import org.xmlpull.v1.XmlPullParser;
/*    */ 
/*    */ public class AnimationDrawable extends DrawableContainer implements Runnable, Animatable {
/*  6 */   public AnimationDrawable() { throw new RuntimeException("Stub!"); }
/*  7 */   public boolean setVisible(boolean visible, boolean restart) { throw new RuntimeException("Stub!"); }
/*  8 */   public void start() { throw new RuntimeException("Stub!"); }
/*  9 */   public void stop() { throw new RuntimeException("Stub!"); }
/* 10 */   public boolean isRunning() { throw new RuntimeException("Stub!"); }
/* 11 */   public void run() { throw new RuntimeException("Stub!"); }
/* 12 */   public void unscheduleSelf(Runnable what) { throw new RuntimeException("Stub!"); }
/* 13 */   public int getNumberOfFrames() { throw new RuntimeException("Stub!"); }
/* 14 */   public Drawable getFrame(int index) { throw new RuntimeException("Stub!"); }
/* 15 */   public int getDuration(int i) { throw new RuntimeException("Stub!"); }
/* 16 */   public boolean isOneShot() { throw new RuntimeException("Stub!"); }
/* 17 */   public void setOneShot(boolean oneShot) { throw new RuntimeException("Stub!"); }
/* 18 */   public void addFrame(Drawable frame, int duration) { throw new RuntimeException("Stub!"); }
/* 19 */   public void inflate(android.content.res.Resources r, XmlPullParser parser, android.util.AttributeSet attrs) throws org.xmlpull.v1.XmlPullParserException, java.io.IOException { throw new RuntimeException("Stub!"); }
/* 20 */   public Drawable mutate() { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\graphics\drawable\AnimationDrawable.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */