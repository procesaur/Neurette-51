/*   */ package android.graphics.drawable.shapes;
/*   */ 
/*   */ import android.graphics.RectF;
/*   */ 
/* 5 */ public class RoundRectShape extends RectShape { public RoundRectShape(float[] outerRadii, RectF inset, float[] innerRadii) { throw new RuntimeException("Stub!"); }
/* 6 */   public void draw(android.graphics.Canvas canvas, android.graphics.Paint paint) { throw new RuntimeException("Stub!"); }
/* 7 */   protected void onResize(float w, float h) { throw new RuntimeException("Stub!"); }
/* 8 */   public RoundRectShape clone() throws CloneNotSupportedException { throw new RuntimeException("Stub!"); }
/*   */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\graphics\drawable\shapes\RoundRectShape.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */