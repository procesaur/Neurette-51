/*   */ package android.graphics.drawable.shapes;
/*   */ 
/*   */ import android.graphics.Canvas;
/*   */ 
/* 5 */ public class OvalShape extends RectShape { public OvalShape() { throw new RuntimeException("Stub!"); }
/* 6 */   public void draw(Canvas canvas, android.graphics.Paint paint) { throw new RuntimeException("Stub!"); }
/*   */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\graphics\drawable\shapes\OvalShape.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */