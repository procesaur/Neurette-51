/*   */ package android.graphics.drawable.shapes;
/*   */ 
/*   */ import android.graphics.Canvas;
/*   */ 
/* 5 */ public class PathShape extends Shape { public PathShape(android.graphics.Path path, float stdWidth, float stdHeight) { throw new RuntimeException("Stub!"); }
/* 6 */   public void draw(Canvas canvas, android.graphics.Paint paint) { throw new RuntimeException("Stub!"); }
/* 7 */   protected void onResize(float width, float height) { throw new RuntimeException("Stub!"); }
/* 8 */   public PathShape clone() throws CloneNotSupportedException { throw new RuntimeException("Stub!"); }
/*   */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\graphics\drawable\shapes\PathShape.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */