/*   */ package android.graphics.drawable;
/*   */ 
/*   */ import org.xmlpull.v1.XmlPullParser;
/*   */ 
/* 5 */ public class PaintDrawable extends ShapeDrawable { public PaintDrawable() { throw new RuntimeException("Stub!"); }
/* 6 */   public PaintDrawable(int color) { throw new RuntimeException("Stub!"); }
/* 7 */   public void setCornerRadius(float radius) { throw new RuntimeException("Stub!"); }
/* 8 */   public void setCornerRadii(float[] radii) { throw new RuntimeException("Stub!"); }
/* 9 */   protected boolean inflateTag(String name, android.content.res.Resources r, XmlPullParser parser, android.util.AttributeSet attrs) { throw new RuntimeException("Stub!"); }
/*   */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\graphics\drawable\PaintDrawable.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */