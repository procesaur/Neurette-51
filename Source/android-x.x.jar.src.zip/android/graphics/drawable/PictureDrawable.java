/*    */ package android.graphics.drawable;
/*    */ 
/*    */ import android.graphics.Picture;
/*    */ 
/*  5 */ public class PictureDrawable extends Drawable { public PictureDrawable(Picture picture) { throw new RuntimeException("Stub!"); }
/*  6 */   public Picture getPicture() { throw new RuntimeException("Stub!"); }
/*  7 */   public void setPicture(Picture picture) { throw new RuntimeException("Stub!"); }
/*  8 */   public void draw(android.graphics.Canvas canvas) { throw new RuntimeException("Stub!"); }
/*  9 */   public int getIntrinsicWidth() { throw new RuntimeException("Stub!"); }
/* 10 */   public int getIntrinsicHeight() { throw new RuntimeException("Stub!"); }
/* 11 */   public int getOpacity() { throw new RuntimeException("Stub!"); }
/* 12 */   public void setFilterBitmap(boolean filter) { throw new RuntimeException("Stub!"); }
/* 13 */   public void setDither(boolean dither) { throw new RuntimeException("Stub!"); }
/* 14 */   public void setColorFilter(android.graphics.ColorFilter colorFilter) { throw new RuntimeException("Stub!"); }
/* 15 */   public void setAlpha(int alpha) { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\graphics\drawable\PictureDrawable.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */