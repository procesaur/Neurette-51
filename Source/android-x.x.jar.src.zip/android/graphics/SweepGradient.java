/*   */ package android.graphics;
/*   */ 
/*   */ public class SweepGradient
/*   */   extends Shader {
/* 5 */   public SweepGradient(float cx, float cy, int[] colors, float[] positions) { throw new RuntimeException("Stub!"); }
/* 6 */   public SweepGradient(float cx, float cy, int color0, int color1) { throw new RuntimeException("Stub!"); }
/*   */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\graphics\SweepGradient.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */