/*   */ package android.graphics;
/*   */ 
/*   */ public class PorterDuffColorFilter extends ColorFilter {
/*   */   public PorterDuffColorFilter(int srcColor, PorterDuff.Mode mode) {
/* 5 */     throw new RuntimeException("Stub!");
/*   */   }
/*   */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\graphics\PorterDuffColorFilter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */