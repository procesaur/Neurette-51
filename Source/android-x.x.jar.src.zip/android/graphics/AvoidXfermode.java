/*    */ package android.graphics;
/*    */ 
/*    */ public class AvoidXfermode extends Xfermode
/*    */ {
/*    */   public static enum Mode
/*    */   {
/*  7 */     AVOID, 
/*  8 */     TARGET;
/*    */     private Mode() {} }
/* 10 */   public AvoidXfermode(int opColor, int tolerance, Mode mode) { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\graphics\AvoidXfermode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */