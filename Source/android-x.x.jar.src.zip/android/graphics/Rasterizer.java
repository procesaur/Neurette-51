/*   */ package android.graphics;
/*   */ 
/*   */ public class Rasterizer {
/* 4 */   public Rasterizer() { throw new RuntimeException("Stub!"); }
/* 5 */   protected void finalize() throws Throwable { throw new RuntimeException("Stub!"); }
/*   */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\graphics\Rasterizer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */