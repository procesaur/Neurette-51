/*    */ package android.graphics;
/*    */ 
/*    */ public class PorterDuff
/*    */ {
/*    */   public static enum Mode {
/*  6 */     CLEAR, 
/*  7 */     DARKEN, 
/*  8 */     DST, 
/*  9 */     DST_ATOP, 
/* 10 */     DST_IN, 
/* 11 */     DST_OUT, 
/* 12 */     DST_OVER, 
/* 13 */     LIGHTEN, 
/* 14 */     MULTIPLY, 
/* 15 */     SCREEN, 
/* 16 */     SRC, 
/* 17 */     SRC_ATOP, 
/* 18 */     SRC_IN, 
/* 19 */     SRC_OUT, 
/* 20 */     SRC_OVER, 
/* 21 */     XOR;
/*    */     private Mode() {} }
/* 23 */   public PorterDuff() { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\graphics\PorterDuff.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */