/*   */ package android.graphics;
/*   */ 
/*   */ public class EmbossMaskFilter extends MaskFilter {
/*   */   public EmbossMaskFilter(float[] direction, float ambient, float specular, float blurRadius) {
/* 5 */     throw new RuntimeException("Stub!");
/*   */   }
/*   */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\graphics\EmbossMaskFilter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */