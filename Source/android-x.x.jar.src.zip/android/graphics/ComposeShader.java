/*   */ package android.graphics;
/*   */ 
/*   */ public class ComposeShader
/*   */   extends Shader {
/* 5 */   public ComposeShader(Shader shaderA, Shader shaderB, Xfermode mode) { throw new RuntimeException("Stub!"); }
/* 6 */   public ComposeShader(Shader shaderA, Shader shaderB, PorterDuff.Mode mode) { throw new RuntimeException("Stub!"); }
/*   */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\graphics\ComposeShader.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */