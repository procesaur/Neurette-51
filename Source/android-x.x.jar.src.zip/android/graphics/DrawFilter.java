/*   */ package android.graphics;
/*   */ 
/*   */ public class DrawFilter {
/* 4 */   public DrawFilter() { throw new RuntimeException("Stub!"); }
/* 5 */   protected void finalize() throws Throwable { throw new RuntimeException("Stub!"); }
/*   */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\graphics\DrawFilter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */