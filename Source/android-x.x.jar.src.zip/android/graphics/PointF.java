/*    */ package android.graphics;
/*    */ 
/*    */ public class PointF {
/*  4 */   public PointF() { throw new RuntimeException("Stub!"); }
/*  5 */   public PointF(float x, float y) { throw new RuntimeException("Stub!"); }
/*  6 */   public PointF(Point p) { throw new RuntimeException("Stub!"); }
/*  7 */   public final void set(float x, float y) { throw new RuntimeException("Stub!"); }
/*  8 */   public final void set(PointF p) { throw new RuntimeException("Stub!"); }
/*  9 */   public final void negate() { throw new RuntimeException("Stub!"); }
/* 10 */   public final void offset(float dx, float dy) { throw new RuntimeException("Stub!"); }
/* 11 */   public final boolean equals(float x, float y) { throw new RuntimeException("Stub!"); }
/* 12 */   public final float length() { throw new RuntimeException("Stub!"); }
/* 13 */   public static float length(float x, float y) { throw new RuntimeException("Stub!"); }
/*    */   
/*    */   public float x;
/*    */   public float y;
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\graphics\PointF.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */