/*   */ package android.graphics;
/*   */ 
/*   */ public class LayerRasterizer
/*   */   extends Rasterizer {
/* 5 */   public LayerRasterizer() { throw new RuntimeException("Stub!"); }
/* 6 */   public void addLayer(Paint paint, float dx, float dy) { throw new RuntimeException("Stub!"); }
/* 7 */   public void addLayer(Paint paint) { throw new RuntimeException("Stub!"); }
/*   */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\graphics\LayerRasterizer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */