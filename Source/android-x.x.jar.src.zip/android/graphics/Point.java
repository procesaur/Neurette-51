/*    */ package android.graphics;
/*    */ 
/*    */ public class Point {
/*  4 */   public Point() { throw new RuntimeException("Stub!"); }
/*  5 */   public Point(int x, int y) { throw new RuntimeException("Stub!"); }
/*  6 */   public Point(Point src) { throw new RuntimeException("Stub!"); }
/*  7 */   public void set(int x, int y) { throw new RuntimeException("Stub!"); }
/*  8 */   public final void negate() { throw new RuntimeException("Stub!"); }
/*  9 */   public final void offset(int dx, int dy) { throw new RuntimeException("Stub!"); }
/* 10 */   public final boolean equals(int x, int y) { throw new RuntimeException("Stub!"); }
/* 11 */   public boolean equals(Object o) { throw new RuntimeException("Stub!"); }
/* 12 */   public int hashCode() { throw new RuntimeException("Stub!"); }
/* 13 */   public String toString() { throw new RuntimeException("Stub!"); }
/*    */   
/*    */   public int x;
/*    */   public int y;
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\graphics\Point.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */