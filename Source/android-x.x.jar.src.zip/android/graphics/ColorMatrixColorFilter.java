/*   */ package android.graphics;
/*   */ 
/*   */ public class ColorMatrixColorFilter
/*   */   extends ColorFilter {
/* 5 */   public ColorMatrixColorFilter(ColorMatrix matrix) { throw new RuntimeException("Stub!"); }
/* 6 */   public ColorMatrixColorFilter(float[] array) { throw new RuntimeException("Stub!"); }
/*   */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\graphics\ColorMatrixColorFilter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */