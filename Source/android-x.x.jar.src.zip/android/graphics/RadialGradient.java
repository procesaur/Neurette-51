/*   */ package android.graphics;
/*   */ 
/*   */ public class RadialGradient
/*   */   extends Shader {
/* 5 */   public RadialGradient(float x, float y, float radius, int[] colors, float[] positions, Shader.TileMode tile) { throw new RuntimeException("Stub!"); }
/* 6 */   public RadialGradient(float x, float y, float radius, int color0, int color1, Shader.TileMode tile) { throw new RuntimeException("Stub!"); }
/*   */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\graphics\RadialGradient.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */