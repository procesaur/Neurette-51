/*    */ package android.appwidget;
/*    */ 
/*    */ import android.view.View;
/*    */ 
/*  5 */ public class AppWidgetHostView extends android.widget.FrameLayout { public AppWidgetHostView(android.content.Context context) { super((android.content.Context)null, (android.util.AttributeSet)null, 0);throw new RuntimeException("Stub!"); }
/*  6 */   public AppWidgetHostView(android.content.Context context, int animationIn, int animationOut) { super((android.content.Context)null, (android.util.AttributeSet)null, 0);throw new RuntimeException("Stub!"); }
/*  7 */   public void setAppWidget(int appWidgetId, AppWidgetProviderInfo info) { throw new RuntimeException("Stub!"); }
/*  8 */   public int getAppWidgetId() { throw new RuntimeException("Stub!"); }
/*  9 */   public AppWidgetProviderInfo getAppWidgetInfo() { throw new RuntimeException("Stub!"); }
/* 10 */   protected void dispatchSaveInstanceState(android.util.SparseArray<android.os.Parcelable> container) { throw new RuntimeException("Stub!"); }
/* 11 */   protected void dispatchRestoreInstanceState(android.util.SparseArray<android.os.Parcelable> container) { throw new RuntimeException("Stub!"); }
/* 12 */   public android.widget.FrameLayout.LayoutParams generateLayoutParams(android.util.AttributeSet attrs) { throw new RuntimeException("Stub!"); }
/* 13 */   public void updateAppWidget(android.widget.RemoteViews remoteViews) { throw new RuntimeException("Stub!"); }
/* 14 */   protected boolean drawChild(android.graphics.Canvas canvas, View child, long drawingTime) { throw new RuntimeException("Stub!"); }
/* 15 */   protected void prepareView(View view) { throw new RuntimeException("Stub!"); }
/* 16 */   protected View getDefaultView() { throw new RuntimeException("Stub!"); }
/* 17 */   protected View getErrorView() { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\appwidget\AppWidgetHostView.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */