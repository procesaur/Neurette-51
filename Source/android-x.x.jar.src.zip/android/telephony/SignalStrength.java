/*    */ package android.telephony;
/*    */ 
/*    */ import android.os.Parcel;
/*    */ 
/*  5 */ public class SignalStrength implements android.os.Parcelable { SignalStrength() { throw new RuntimeException("Stub!"); }
/*  6 */   public void writeToParcel(Parcel out, int flags) { throw new RuntimeException("Stub!"); }
/*  7 */   public int describeContents() { throw new RuntimeException("Stub!"); }
/*  8 */   public int getGsmSignalStrength() { throw new RuntimeException("Stub!"); }
/*  9 */   public int getGsmBitErrorRate() { throw new RuntimeException("Stub!"); }
/* 10 */   public int getCdmaDbm() { throw new RuntimeException("Stub!"); }
/* 11 */   public int getCdmaEcio() { throw new RuntimeException("Stub!"); }
/* 12 */   public int getEvdoDbm() { throw new RuntimeException("Stub!"); }
/* 13 */   public int getEvdoEcio() { throw new RuntimeException("Stub!"); }
/* 14 */   public int getEvdoSnr() { throw new RuntimeException("Stub!"); }
/* 15 */   public boolean isGsm() { throw new RuntimeException("Stub!"); }
/* 16 */   public int hashCode() { throw new RuntimeException("Stub!"); }
/* 17 */   public boolean equals(Object o) { throw new RuntimeException("Stub!"); }
/* 18 */   public String toString() { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\telephony\SignalStrength.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */