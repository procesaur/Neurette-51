/*   */ package android.telephony;
/*   */ 
/*   */ public abstract class CellLocation {
/* 4 */   public CellLocation() { throw new RuntimeException("Stub!"); }
/* 5 */   public static void requestLocationUpdate() { throw new RuntimeException("Stub!"); }
/* 6 */   public static CellLocation getEmpty() { throw new RuntimeException("Stub!"); }
/*   */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\telephony\CellLocation.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */