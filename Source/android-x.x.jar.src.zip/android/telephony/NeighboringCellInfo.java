/*    */ package android.telephony;
/*    */ 
/*    */ import android.os.Parcel;
/*    */ 
/*  5 */ public class NeighboringCellInfo implements android.os.Parcelable { public NeighboringCellInfo() { throw new RuntimeException("Stub!"); }
/*  6 */   public NeighboringCellInfo(int rssi, int cid) { throw new RuntimeException("Stub!"); }
/*  7 */   public NeighboringCellInfo(int rssi, String location, int radioType) { throw new RuntimeException("Stub!"); }
/*  8 */   public NeighboringCellInfo(Parcel in) { throw new RuntimeException("Stub!"); }
/*  9 */   public int getRssi() { throw new RuntimeException("Stub!"); }
/* 10 */   public int getLac() { throw new RuntimeException("Stub!"); }
/* 11 */   public int getCid() { throw new RuntimeException("Stub!"); }
/* 12 */   public int getPsc() { throw new RuntimeException("Stub!"); }
/* 13 */   public int getNetworkType() { throw new RuntimeException("Stub!"); }
/* 14 */   public void setCid(int cid) { throw new RuntimeException("Stub!"); }
/* 15 */   public void setRssi(int rssi) { throw new RuntimeException("Stub!"); }
/* 16 */   public String toString() { throw new RuntimeException("Stub!"); }
/* 17 */   public int describeContents() { throw new RuntimeException("Stub!"); }
/* 18 */   public void writeToParcel(Parcel dest, int flags) { throw new RuntimeException("Stub!"); }
/*    */   
/*    */   public static final int UNKNOWN_RSSI = 99;
/*    */   public static final int UNKNOWN_CID = -1;
/* 22 */   public static final android.os.Parcelable.Creator<NeighboringCellInfo> CREATOR = null;
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\telephony\NeighboringCellInfo.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */