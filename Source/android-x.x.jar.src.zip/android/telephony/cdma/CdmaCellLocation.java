/*    */ package android.telephony.cdma;
/*    */ 
/*    */ import android.os.Bundle;
/*    */ 
/*  5 */ public class CdmaCellLocation extends android.telephony.CellLocation { public CdmaCellLocation() { throw new RuntimeException("Stub!"); }
/*  6 */   public CdmaCellLocation(Bundle bundleWithValues) { throw new RuntimeException("Stub!"); }
/*  7 */   public int getBaseStationId() { throw new RuntimeException("Stub!"); }
/*  8 */   public int getBaseStationLatitude() { throw new RuntimeException("Stub!"); }
/*  9 */   public int getBaseStationLongitude() { throw new RuntimeException("Stub!"); }
/* 10 */   public int getSystemId() { throw new RuntimeException("Stub!"); }
/* 11 */   public int getNetworkId() { throw new RuntimeException("Stub!"); }
/* 12 */   public void setStateInvalid() { throw new RuntimeException("Stub!"); }
/* 13 */   public void setCellLocationData(int baseStationId, int baseStationLatitude, int baseStationLongitude) { throw new RuntimeException("Stub!"); }
/* 14 */   public void setCellLocationData(int baseStationId, int baseStationLatitude, int baseStationLongitude, int systemId, int networkId) { throw new RuntimeException("Stub!"); }
/* 15 */   public int hashCode() { throw new RuntimeException("Stub!"); }
/* 16 */   public boolean equals(Object o) { throw new RuntimeException("Stub!"); }
/* 17 */   public String toString() { throw new RuntimeException("Stub!"); }
/* 18 */   public void fillInNotifierBundle(Bundle bundleToFill) { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\telephony\cdma\CdmaCellLocation.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */