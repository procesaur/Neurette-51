/*   */ package android.telephony;
/*   */ 
/*   */ import android.text.Editable;
/*   */ 
/* 5 */ public class PhoneNumberFormattingTextWatcher implements android.text.TextWatcher { public PhoneNumberFormattingTextWatcher() { throw new RuntimeException("Stub!"); }
/* 6 */   public synchronized void afterTextChanged(Editable text) { throw new RuntimeException("Stub!"); }
/* 7 */   public void beforeTextChanged(CharSequence s, int start, int count, int after) { throw new RuntimeException("Stub!"); }
/* 8 */   public void onTextChanged(CharSequence s, int start, int before, int count) { throw new RuntimeException("Stub!"); }
/*   */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\telephony\PhoneNumberFormattingTextWatcher.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */