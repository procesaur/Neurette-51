/*    */ package android.telephony.gsm;
/*    */ 
/*    */ import android.os.Bundle;
/*    */ 
/*  5 */ public class GsmCellLocation extends android.telephony.CellLocation { public GsmCellLocation() { throw new RuntimeException("Stub!"); }
/*  6 */   public GsmCellLocation(Bundle bundle) { throw new RuntimeException("Stub!"); }
/*  7 */   public int getLac() { throw new RuntimeException("Stub!"); }
/*  8 */   public int getCid() { throw new RuntimeException("Stub!"); }
/*  9 */   public void setStateInvalid() { throw new RuntimeException("Stub!"); }
/* 10 */   public void setLacAndCid(int lac, int cid) { throw new RuntimeException("Stub!"); }
/* 11 */   public int hashCode() { throw new RuntimeException("Stub!"); }
/* 12 */   public boolean equals(Object o) { throw new RuntimeException("Stub!"); }
/* 13 */   public String toString() { throw new RuntimeException("Stub!"); }
/* 14 */   public void fillInNotifierBundle(Bundle m) { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\telephony\gsm\GsmCellLocation.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */