/*   */ package android.content;
/*   */ import android.os.Bundle;
/*   */ 
/* 4 */ public abstract class AbstractThreadedSyncAdapter { public AbstractThreadedSyncAdapter(Context context, boolean autoInitialize) { throw new RuntimeException("Stub!"); }
/* 5 */   public Context getContext() { throw new RuntimeException("Stub!"); }
/* 6 */   public final android.os.IBinder getSyncAdapterBinder() { throw new RuntimeException("Stub!"); }
/*   */   
/*   */   public static final int LOG_SYNC_DETAILS = 2743;
/*   */   public abstract void onPerformSync(android.accounts.Account paramAccount, Bundle paramBundle, String paramString, ContentProviderClient paramContentProviderClient, SyncResult paramSyncResult);
/*   */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\content\AbstractThreadedSyncAdapter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */