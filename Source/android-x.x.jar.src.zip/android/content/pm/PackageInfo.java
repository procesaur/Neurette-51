/*    */ package android.content.pm;
/*    */ import android.os.Parcel;
/*    */ 
/*    */ public class PackageInfo implements android.os.Parcelable { public String packageName; public int versionCode; public String versionName;
/*  5 */   public PackageInfo() { throw new RuntimeException("Stub!"); }
/*  6 */   public String toString() { throw new RuntimeException("Stub!"); }
/*  7 */   public int describeContents() { throw new RuntimeException("Stub!"); }
/*  8 */   public void writeToParcel(Parcel dest, int parcelableFlags) { throw new RuntimeException("Stub!"); }
/*    */   
/*    */ 
/*    */   public String sharedUserId;
/*    */   
/*    */   public int sharedUserLabel;
/*    */   public ApplicationInfo applicationInfo;
/* 15 */   public int[] gids = null;
/* 16 */   public ActivityInfo[] activities = null;
/* 17 */   public ActivityInfo[] receivers = null;
/* 18 */   public ServiceInfo[] services = null;
/* 19 */   public ProviderInfo[] providers = null;
/* 20 */   public InstrumentationInfo[] instrumentation = null;
/* 21 */   public PermissionInfo[] permissions = null;
/* 22 */   public String[] requestedPermissions = null;
/* 23 */   public Signature[] signatures = null;
/* 24 */   public ConfigurationInfo[] configPreferences = null;
/* 25 */   public FeatureInfo[] reqFeatures = null;
/*    */   
/* 27 */   public static final android.os.Parcelable.Creator<PackageInfo> CREATOR = null;
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\content\pm\PackageInfo.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */