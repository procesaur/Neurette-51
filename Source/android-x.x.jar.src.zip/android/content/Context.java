/*    */ package android.content;
/*    */ import android.net.Uri;
/*    */ 
/*  4 */ public abstract class Context { public Context() { throw new RuntimeException("Stub!"); }
/*    */   public abstract android.content.res.AssetManager getAssets();
/*    */   public abstract android.content.res.Resources getResources();
/*    */   public abstract android.content.pm.PackageManager getPackageManager();
/*    */   public abstract ContentResolver getContentResolver();
/*    */   public abstract android.os.Looper getMainLooper();
/*    */   public abstract Context getApplicationContext();
/* 11 */   public final CharSequence getText(int resId) { throw new RuntimeException("Stub!"); }
/* 12 */   public final String getString(int resId) { throw new RuntimeException("Stub!"); }
/* 13 */   public final String getString(int resId, Object... formatArgs) { throw new RuntimeException("Stub!"); }
/*    */   public abstract void setTheme(int paramInt);
/*    */   public abstract android.content.res.Resources.Theme getTheme();
/* 16 */   public final android.content.res.TypedArray obtainStyledAttributes(int[] attrs) { throw new RuntimeException("Stub!"); }
/* 17 */   public final android.content.res.TypedArray obtainStyledAttributes(int resid, int[] attrs) throws android.content.res.Resources.NotFoundException { throw new RuntimeException("Stub!"); }
/* 18 */   public final android.content.res.TypedArray obtainStyledAttributes(android.util.AttributeSet set, int[] attrs) { throw new RuntimeException("Stub!"); }
/* 19 */   public final android.content.res.TypedArray obtainStyledAttributes(android.util.AttributeSet set, int[] attrs, int defStyleAttr, int defStyleRes) { throw new RuntimeException("Stub!"); }
/*    */   public abstract ClassLoader getClassLoader();
/*    */   public abstract String getPackageName();
/*    */   public abstract android.content.pm.ApplicationInfo getApplicationInfo();
/*    */   public abstract SharedPreferences getSharedPreferences(String paramString, int paramInt);
/*    */   public abstract java.io.FileInputStream openFileInput(String paramString) throws java.io.FileNotFoundException;
/*    */   public abstract java.io.FileOutputStream openFileOutput(String paramString, int paramInt) throws java.io.FileNotFoundException;
/*    */   public abstract boolean deleteFile(String paramString);
/*    */   public abstract java.io.File getFileStreamPath(String paramString);
/*    */   public abstract java.io.File getFilesDir();
/*    */   public abstract java.io.File getCacheDir();
/*    */   public abstract String[] fileList();
/*    */   public abstract java.io.File getDir(String paramString, int paramInt);
/*    */   public abstract android.database.sqlite.SQLiteDatabase openOrCreateDatabase(String paramString, int paramInt, android.database.sqlite.SQLiteDatabase.CursorFactory paramCursorFactory);
/*    */   public abstract boolean deleteDatabase(String paramString);
/*    */   public abstract java.io.File getDatabasePath(String paramString);
/*    */   public abstract String[] databaseList();
/*    */   public abstract android.graphics.drawable.Drawable getWallpaper();
/*    */   public abstract android.graphics.drawable.Drawable peekWallpaper();
/*    */   public abstract int getWallpaperDesiredMinimumWidth();
/*    */   public abstract int getWallpaperDesiredMinimumHeight();
/*    */   public abstract void setWallpaper(android.graphics.Bitmap paramBitmap) throws java.io.IOException;
/*    */   public abstract void setWallpaper(java.io.InputStream paramInputStream) throws java.io.IOException;
/*    */   public abstract void clearWallpaper() throws java.io.IOException;
/*    */   public abstract void startActivity(Intent paramIntent);
/*    */   public abstract void startIntentSender(IntentSender paramIntentSender, Intent paramIntent, int paramInt1, int paramInt2, int paramInt3) throws IntentSender.SendIntentException;
/*    */   public abstract void sendBroadcast(Intent paramIntent);
/*    */   public abstract void sendBroadcast(Intent paramIntent, String paramString);
/*    */   public abstract void sendOrderedBroadcast(Intent paramIntent, String paramString);
/*    */   public abstract void sendOrderedBroadcast(Intent paramIntent, String paramString1, BroadcastReceiver paramBroadcastReceiver, android.os.Handler paramHandler, int paramInt, String paramString2, android.os.Bundle paramBundle);
/*    */   public abstract void sendStickyBroadcast(Intent paramIntent);
/*    */   public abstract void sendStickyOrderedBroadcast(Intent paramIntent, BroadcastReceiver paramBroadcastReceiver, android.os.Handler paramHandler, int paramInt, String paramString, android.os.Bundle paramBundle);
/*    */   public abstract void removeStickyBroadcast(Intent paramIntent);
/*    */   public abstract Intent registerReceiver(BroadcastReceiver paramBroadcastReceiver, IntentFilter paramIntentFilter);
/*    */   public abstract Intent registerReceiver(BroadcastReceiver paramBroadcastReceiver, IntentFilter paramIntentFilter, String paramString, android.os.Handler paramHandler);
/*    */   public abstract void unregisterReceiver(BroadcastReceiver paramBroadcastReceiver);
/*    */   public abstract ComponentName startService(Intent paramIntent);
/*    */   public abstract boolean stopService(Intent paramIntent);
/*    */   public abstract boolean bindService(Intent paramIntent, ServiceConnection paramServiceConnection, int paramInt);
/*    */   public abstract void unbindService(ServiceConnection paramServiceConnection);
/*    */   public abstract boolean startInstrumentation(ComponentName paramComponentName, String paramString, android.os.Bundle paramBundle);
/*    */   public abstract Object getSystemService(String paramString);
/*    */   public abstract int checkPermission(String paramString, int paramInt1, int paramInt2);
/*    */   public abstract int checkCallingPermission(String paramString);
/*    */   public abstract int checkCallingOrSelfPermission(String paramString);
/*    */   public abstract void enforcePermission(String paramString1, int paramInt1, int paramInt2, String paramString2);
/*    */   public abstract void enforceCallingPermission(String paramString1, String paramString2);
/*    */   public abstract void enforceCallingOrSelfPermission(String paramString1, String paramString2);
/*    */   public abstract void grantUriPermission(String paramString, Uri paramUri, int paramInt);
/*    */   public abstract void revokeUriPermission(Uri paramUri, int paramInt);
/*    */   public abstract int checkUriPermission(Uri paramUri, int paramInt1, int paramInt2, int paramInt3);
/*    */   public abstract int checkCallingUriPermission(Uri paramUri, int paramInt);
/*    */   public abstract int checkCallingOrSelfUriPermission(Uri paramUri, int paramInt);
/*    */   public abstract int checkUriPermission(Uri paramUri, String paramString1, String paramString2, int paramInt1, int paramInt2, int paramInt3);
/*    */   public abstract void enforceUriPermission(Uri paramUri, int paramInt1, int paramInt2, int paramInt3, String paramString);
/*    */   public abstract void enforceCallingUriPermission(Uri paramUri, int paramInt, String paramString);
/*    */   public abstract void enforceCallingOrSelfUriPermission(Uri paramUri, int paramInt, String paramString);
/*    */   public abstract void enforceUriPermission(Uri paramUri, String paramString1, String paramString2, int paramInt1, int paramInt2, int paramInt3, String paramString3);
/*    */   public abstract Context createPackageContext(String paramString, int paramInt) throws android.content.pm.PackageManager.NameNotFoundException;
/* 78 */   public boolean isRestricted() { throw new RuntimeException("Stub!"); }
/*    */   
/*    */   public static final int MODE_PRIVATE = 0;
/*    */   public static final int MODE_WORLD_READABLE = 1;
/*    */   public static final int MODE_WORLD_WRITEABLE = 2;
/*    */   public static final int MODE_APPEND = 32768;
/*    */   public static final int BIND_AUTO_CREATE = 1;
/*    */   public static final int BIND_DEBUG_UNBIND = 2;
/*    */   public static final String POWER_SERVICE = "power";
/*    */   public static final String WINDOW_SERVICE = "window";
/*    */   public static final String LAYOUT_INFLATER_SERVICE = "layout_inflater";
/*    */   public static final String ACCOUNT_SERVICE = "account";
/*    */   public static final String ACTIVITY_SERVICE = "activity";
/*    */   public static final String ALARM_SERVICE = "alarm";
/*    */   public static final String NOTIFICATION_SERVICE = "notification";
/*    */   public static final String ACCESSIBILITY_SERVICE = "accessibility";
/*    */   public static final String KEYGUARD_SERVICE = "keyguard";
/*    */   public static final String LOCATION_SERVICE = "location";
/*    */   public static final String SEARCH_SERVICE = "search";
/*    */   public static final String SENSOR_SERVICE = "sensor";
/*    */   public static final String WALLPAPER_SERVICE = "wallpaper";
/*    */   public static final String VIBRATOR_SERVICE = "vibrator";
/*    */   public static final String CONNECTIVITY_SERVICE = "connectivity";
/*    */   public static final String WIFI_SERVICE = "wifi";
/*    */   public static final String AUDIO_SERVICE = "audio";
/*    */   public static final String TELEPHONY_SERVICE = "phone";
/*    */   public static final String CLIPBOARD_SERVICE = "clipboard";
/*    */   public static final String INPUT_METHOD_SERVICE = "input_method";
/*    */   public static final int CONTEXT_INCLUDE_CODE = 1;
/*    */   public static final int CONTEXT_IGNORE_SECURITY = 2;
/*    */   public static final int CONTEXT_RESTRICTED = 4;
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\content\Context.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */