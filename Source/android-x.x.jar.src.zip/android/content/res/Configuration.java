/*    */ package android.content.res;
/*    */ 
/*    */ import android.os.Parcel;
/*    */ 
/*  5 */ public final class Configuration implements android.os.Parcelable, Comparable<Configuration> { public Configuration() { throw new RuntimeException("Stub!"); }
/*  6 */   public Configuration(Configuration o) { throw new RuntimeException("Stub!"); }
/*  7 */   public String toString() { throw new RuntimeException("Stub!"); }
/*  8 */   public void setToDefaults() { throw new RuntimeException("Stub!"); }
/*  9 */   public int updateFrom(Configuration delta) { throw new RuntimeException("Stub!"); }
/* 10 */   public int diff(Configuration delta) { throw new RuntimeException("Stub!"); }
/* 11 */   public static boolean needNewResources(int configChanges, int interestingChanges) { throw new RuntimeException("Stub!"); }
/* 12 */   public int describeContents() { throw new RuntimeException("Stub!"); }
/* 13 */   public void writeToParcel(Parcel dest, int flags) { throw new RuntimeException("Stub!"); }
/* 14 */   public int compareTo(Configuration that) { throw new RuntimeException("Stub!"); }
/* 15 */   public boolean equals(Configuration that) { throw new RuntimeException("Stub!"); }
/* 16 */   public boolean equals(Object that) { throw new RuntimeException("Stub!"); }
/* 17 */   public int hashCode() { throw new RuntimeException("Stub!"); }
/*    */   
/*    */   public float fontScale;
/*    */   public int mcc;
/*    */   public int mnc;
/*    */   public java.util.Locale locale;
/*    */   public static final int SCREENLAYOUT_SIZE_MASK = 15;
/*    */   public static final int SCREENLAYOUT_SIZE_UNDEFINED = 0;
/*    */   public static final int SCREENLAYOUT_SIZE_SMALL = 1;
/*    */   public static final int SCREENLAYOUT_SIZE_NORMAL = 2;
/*    */   public static final int SCREENLAYOUT_SIZE_LARGE = 3;
/*    */   public static final int SCREENLAYOUT_LONG_MASK = 48;
/*    */   public static final int SCREENLAYOUT_LONG_UNDEFINED = 0;
/*    */   public static final int SCREENLAYOUT_LONG_NO = 16;
/*    */   public static final int SCREENLAYOUT_LONG_YES = 32;
/*    */   public int screenLayout;
/*    */   public static final int TOUCHSCREEN_UNDEFINED = 0;
/*    */   public static final int TOUCHSCREEN_NOTOUCH = 1;
/*    */   public static final int TOUCHSCREEN_STYLUS = 2;
/*    */   public static final int TOUCHSCREEN_FINGER = 3;
/*    */   public int touchscreen;
/*    */   public static final int KEYBOARD_UNDEFINED = 0;
/*    */   public static final int KEYBOARD_NOKEYS = 1;
/*    */   public static final int KEYBOARD_QWERTY = 2;
/*    */   public static final int KEYBOARD_12KEY = 3;
/*    */   public int keyboard;
/*    */   public static final int KEYBOARDHIDDEN_UNDEFINED = 0;
/*    */   public static final int KEYBOARDHIDDEN_NO = 1;
/*    */   public static final int KEYBOARDHIDDEN_YES = 2;
/*    */   public int keyboardHidden;
/*    */   public static final int HARDKEYBOARDHIDDEN_UNDEFINED = 0;
/*    */   public static final int HARDKEYBOARDHIDDEN_NO = 1;
/*    */   public static final int HARDKEYBOARDHIDDEN_YES = 2;
/*    */   public int hardKeyboardHidden;
/*    */   public static final int NAVIGATION_UNDEFINED = 0;
/*    */   public static final int NAVIGATION_NONAV = 1;
/*    */   public static final int NAVIGATION_DPAD = 2;
/*    */   public static final int NAVIGATION_TRACKBALL = 3;
/*    */   public static final int NAVIGATION_WHEEL = 4;
/*    */   public int navigation;
/*    */   public static final int NAVIGATIONHIDDEN_UNDEFINED = 0;
/*    */   public static final int NAVIGATIONHIDDEN_NO = 1;
/*    */   public static final int NAVIGATIONHIDDEN_YES = 2;
/*    */   public int navigationHidden;
/*    */   public static final int ORIENTATION_UNDEFINED = 0;
/*    */   public static final int ORIENTATION_PORTRAIT = 1;
/*    */   public static final int ORIENTATION_LANDSCAPE = 2;
/*    */   public static final int ORIENTATION_SQUARE = 3;
/*    */   public int orientation;
/* 66 */   public static final android.os.Parcelable.Creator<Configuration> CREATOR = null;
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\content\res\Configuration.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */