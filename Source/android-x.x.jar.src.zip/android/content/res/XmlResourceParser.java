package android.content.res;

import android.util.AttributeSet;
import org.xmlpull.v1.XmlPullParser;

public abstract interface XmlResourceParser
  extends XmlPullParser, AttributeSet
{
  public abstract void close();
}


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\content\res\XmlResourceParser.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */