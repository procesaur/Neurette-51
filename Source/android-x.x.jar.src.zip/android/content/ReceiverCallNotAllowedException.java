/*   */ package android.content;
/*   */ 
/*   */ import android.util.AndroidRuntimeException;
/*   */ 
/* 5 */ public class ReceiverCallNotAllowedException extends AndroidRuntimeException { public ReceiverCallNotAllowedException(String msg) { throw new RuntimeException("Stub!"); }
/*   */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\content\ReceiverCallNotAllowedException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */