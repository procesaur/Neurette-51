package android.content;

public abstract interface SyncStatusObserver
{
  public abstract void onStatusChanged(int paramInt);
}


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\content\SyncStatusObserver.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */