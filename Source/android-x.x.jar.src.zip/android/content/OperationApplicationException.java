/*    */ package android.content;
/*    */ 
/*    */ public class OperationApplicationException
/*    */   extends Exception {
/*  5 */   public OperationApplicationException() { throw new RuntimeException("Stub!"); }
/*  6 */   public OperationApplicationException(String message) { throw new RuntimeException("Stub!"); }
/*  7 */   public OperationApplicationException(String message, Throwable cause) { throw new RuntimeException("Stub!"); }
/*  8 */   public OperationApplicationException(Throwable cause) { throw new RuntimeException("Stub!"); }
/*  9 */   public OperationApplicationException(int numSuccessfulYieldPoints) { throw new RuntimeException("Stub!"); }
/* 10 */   public OperationApplicationException(String message, int numSuccessfulYieldPoints) { throw new RuntimeException("Stub!"); }
/* 11 */   public int getNumSuccessfulYieldPoints() { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\content\OperationApplicationException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */