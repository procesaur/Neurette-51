/*    */ package android.content;
/*    */ import android.os.Bundle;
/*    */ 
/*  4 */ public abstract class BroadcastReceiver { public BroadcastReceiver() { throw new RuntimeException("Stub!"); }
/*    */   public abstract void onReceive(Context paramContext, Intent paramIntent);
/*  6 */   public android.os.IBinder peekService(Context myContext, Intent service) { throw new RuntimeException("Stub!"); }
/*  7 */   public final void setResultCode(int code) { throw new RuntimeException("Stub!"); }
/*  8 */   public final int getResultCode() { throw new RuntimeException("Stub!"); }
/*  9 */   public final void setResultData(String data) { throw new RuntimeException("Stub!"); }
/* 10 */   public final String getResultData() { throw new RuntimeException("Stub!"); }
/* 11 */   public final void setResultExtras(Bundle extras) { throw new RuntimeException("Stub!"); }
/* 12 */   public final Bundle getResultExtras(boolean makeMap) { throw new RuntimeException("Stub!"); }
/* 13 */   public final void setResult(int code, String data, Bundle extras) { throw new RuntimeException("Stub!"); }
/* 14 */   public final boolean getAbortBroadcast() { throw new RuntimeException("Stub!"); }
/* 15 */   public final void abortBroadcast() { throw new RuntimeException("Stub!"); }
/* 16 */   public final void clearAbortBroadcast() { throw new RuntimeException("Stub!"); }
/* 17 */   public final boolean isOrderedBroadcast() { throw new RuntimeException("Stub!"); }
/* 18 */   public final boolean isInitialStickyBroadcast() { throw new RuntimeException("Stub!"); }
/* 19 */   public final void setOrderedHint(boolean isOrdered) { throw new RuntimeException("Stub!"); }
/* 20 */   public final void setDebugUnregister(boolean debug) { throw new RuntimeException("Stub!"); }
/* 21 */   public final boolean getDebugUnregister() { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\content\BroadcastReceiver.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */