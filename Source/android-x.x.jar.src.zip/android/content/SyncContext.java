/*   */ package android.content;
/*   */ import android.os.IBinder;
/*   */ 
/* 4 */ public class SyncContext { SyncContext() { throw new RuntimeException("Stub!"); }
/* 5 */   public void onFinished(SyncResult result) { throw new RuntimeException("Stub!"); }
/* 6 */   public IBinder getSyncContextBinder() { throw new RuntimeException("Stub!"); }
/*   */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\content\SyncContext.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */