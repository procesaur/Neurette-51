/*    */ package android.content;
/*    */ import android.net.Uri;
/*    */ 
/*  4 */ public class ContentProviderClient { ContentProviderClient() { throw new RuntimeException("Stub!"); }
/*  5 */   public android.database.Cursor query(Uri url, String[] projection, String selection, String[] selectionArgs, String sortOrder) throws android.os.RemoteException { throw new RuntimeException("Stub!"); }
/*  6 */   public String getType(Uri url) throws android.os.RemoteException { throw new RuntimeException("Stub!"); }
/*  7 */   public Uri insert(Uri url, ContentValues initialValues) throws android.os.RemoteException { throw new RuntimeException("Stub!"); }
/*  8 */   public int bulkInsert(Uri url, ContentValues[] initialValues) throws android.os.RemoteException { throw new RuntimeException("Stub!"); }
/*  9 */   public int delete(Uri url, String selection, String[] selectionArgs) throws android.os.RemoteException { throw new RuntimeException("Stub!"); }
/* 10 */   public int update(Uri url, ContentValues values, String selection, String[] selectionArgs) throws android.os.RemoteException { throw new RuntimeException("Stub!"); }
/* 11 */   public android.os.ParcelFileDescriptor openFile(Uri url, String mode) throws android.os.RemoteException, java.io.FileNotFoundException { throw new RuntimeException("Stub!"); }
/* 12 */   public android.content.res.AssetFileDescriptor openAssetFile(Uri url, String mode) throws android.os.RemoteException, java.io.FileNotFoundException { throw new RuntimeException("Stub!"); }
/* 13 */   public ContentProviderResult[] applyBatch(java.util.ArrayList<ContentProviderOperation> operations) throws android.os.RemoteException, OperationApplicationException { throw new RuntimeException("Stub!"); }
/* 14 */   public boolean release() { throw new RuntimeException("Stub!"); }
/* 15 */   public ContentProvider getLocalContentProvider() { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\content\ContentProviderClient.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */