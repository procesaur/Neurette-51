/*   */ package android.content;
/*   */ import android.net.Uri;
/*   */ 
/* 4 */ public class ContentUris { public ContentUris() { throw new RuntimeException("Stub!"); }
/* 5 */   public static long parseId(Uri contentUri) { throw new RuntimeException("Stub!"); }
/* 6 */   public static android.net.Uri.Builder appendId(android.net.Uri.Builder builder, long id) { throw new RuntimeException("Stub!"); }
/* 7 */   public static Uri withAppendedId(Uri contentUri, long id) { throw new RuntimeException("Stub!"); }
/*   */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\content\ContentUris.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */