/*   */ package android.content;
/*   */ 
/*   */ public class ActivityNotFoundException
/*   */   extends RuntimeException {
/* 5 */   public ActivityNotFoundException() { throw new RuntimeException("Stub!"); }
/* 6 */   public ActivityNotFoundException(String name) { throw new RuntimeException("Stub!"); }
/*   */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\content\ActivityNotFoundException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */