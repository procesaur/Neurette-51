/*   */ package android.content;
/*   */ 
/*   */ public class MutableContextWrapper extends ContextWrapper {
/*   */   public MutableContextWrapper(Context base) {
/* 5 */     super((Context)null);throw new RuntimeException("Stub!"); }
/* 6 */   public void setBaseContext(Context base) { throw new RuntimeException("Stub!"); }
/*   */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\content\MutableContextWrapper.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */