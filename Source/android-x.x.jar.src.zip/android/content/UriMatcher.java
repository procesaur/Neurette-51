/*   */ package android.content;
/*   */ import android.net.Uri;
/*   */ 
/* 4 */ public class UriMatcher { public UriMatcher(int code) { throw new RuntimeException("Stub!"); }
/* 5 */   public void addURI(String authority, String path, int code) { throw new RuntimeException("Stub!"); }
/* 6 */   public int match(Uri uri) { throw new RuntimeException("Stub!"); }
/*   */   
/*   */   public static final int NO_MATCH = -1;
/*   */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\content\UriMatcher.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */