/*    */ package android.content;
/*    */ 
/*    */ import android.net.Uri;
/*    */ 
/*  5 */ public abstract class ContentProvider implements ComponentCallbacks { public ContentProvider() { throw new RuntimeException("Stub!"); }
/*  6 */   public final Context getContext() { throw new RuntimeException("Stub!"); }
/*  7 */   protected final void setReadPermission(String permission) { throw new RuntimeException("Stub!"); }
/*  8 */   public final String getReadPermission() { throw new RuntimeException("Stub!"); }
/*  9 */   protected final void setWritePermission(String permission) { throw new RuntimeException("Stub!"); }
/* 10 */   public final String getWritePermission() { throw new RuntimeException("Stub!"); }
/* 11 */   protected final void setPathPermissions(android.content.pm.PathPermission[] permissions) { throw new RuntimeException("Stub!"); }
/* 12 */   public final android.content.pm.PathPermission[] getPathPermissions() { throw new RuntimeException("Stub!"); }
/*    */   public abstract boolean onCreate();
/* 14 */   public void onConfigurationChanged(android.content.res.Configuration newConfig) { throw new RuntimeException("Stub!"); }
/* 15 */   public void onLowMemory() { throw new RuntimeException("Stub!"); }
/*    */   public abstract android.database.Cursor query(Uri paramUri, String[] paramArrayOfString1, String paramString1, String[] paramArrayOfString2, String paramString2);
/*    */   public abstract String getType(Uri paramUri);
/*    */   public abstract Uri insert(Uri paramUri, ContentValues paramContentValues);
/* 19 */   public int bulkInsert(Uri uri, ContentValues[] values) { throw new RuntimeException("Stub!"); }
/*    */   public abstract int delete(Uri paramUri, String paramString, String[] paramArrayOfString);
/*    */   public abstract int update(Uri paramUri, ContentValues paramContentValues, String paramString, String[] paramArrayOfString);
/* 22 */   public android.os.ParcelFileDescriptor openFile(Uri uri, String mode) throws java.io.FileNotFoundException { throw new RuntimeException("Stub!"); }
/* 23 */   public android.content.res.AssetFileDescriptor openAssetFile(Uri uri, String mode) throws java.io.FileNotFoundException { throw new RuntimeException("Stub!"); }
/* 24 */   protected final android.os.ParcelFileDescriptor openFileHelper(Uri uri, String mode) throws java.io.FileNotFoundException { throw new RuntimeException("Stub!"); }
/* 25 */   protected boolean isTemporary() { throw new RuntimeException("Stub!"); }
/* 26 */   public void attachInfo(Context context, android.content.pm.ProviderInfo info) { throw new RuntimeException("Stub!"); }
/* 27 */   public ContentProviderResult[] applyBatch(java.util.ArrayList<ContentProviderOperation> operations) throws OperationApplicationException { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\content\ContentProvider.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */