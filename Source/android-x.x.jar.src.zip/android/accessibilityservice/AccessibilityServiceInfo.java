/*    */ package android.accessibilityservice;
/*    */ import android.os.Parcel;
/*    */ 
/*    */ public class AccessibilityServiceInfo implements android.os.Parcelable { public static final int FEEDBACK_SPOKEN = 1; public static final int FEEDBACK_HAPTIC = 2; public static final int FEEDBACK_AUDIBLE = 4; public static final int FEEDBACK_VISUAL = 8;
/*  5 */   public AccessibilityServiceInfo() { throw new RuntimeException("Stub!"); }
/*  6 */   public int describeContents() { throw new RuntimeException("Stub!"); }
/*  7 */   public void writeToParcel(Parcel parcel, int flags) { throw new RuntimeException("Stub!"); }
/*    */   
/*    */ 
/*    */   public static final int FEEDBACK_GENERIC = 16;
/*    */   
/*    */   public static final int DEFAULT = 1;
/*    */   
/*    */   public int eventTypes;
/* 15 */   public String[] packageNames = null;
/*    */   
/*    */   public int feedbackType;
/*    */   public long notificationTimeout;
/*    */   public int flags;
/* 20 */   public static final android.os.Parcelable.Creator<AccessibilityServiceInfo> CREATOR = null;
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\accessibilityservice\AccessibilityServiceInfo.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */