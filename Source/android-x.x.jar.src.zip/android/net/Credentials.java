/*   */ package android.net;
/*   */ 
/*   */ public class Credentials {
/* 4 */   public Credentials(int pid, int uid, int gid) { throw new RuntimeException("Stub!"); }
/* 5 */   public int getPid() { throw new RuntimeException("Stub!"); }
/* 6 */   public int getUid() { throw new RuntimeException("Stub!"); }
/* 7 */   public int getGid() { throw new RuntimeException("Stub!"); }
/*   */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\net\Credentials.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */