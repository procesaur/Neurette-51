/*   */ package android.net;
/*   */ 
/*   */ public class ParseException extends RuntimeException { public String response;
/*   */   
/* 5 */   ParseException() { throw new RuntimeException("Stub!"); }
/*   */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\net\ParseException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */