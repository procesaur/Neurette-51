/*    */ package android.net;
/*    */ 
/*    */ import java.net.InetAddress;
/*    */ 
/*  5 */ public class SSLCertificateSocketFactory extends javax.net.ssl.SSLSocketFactory { public SSLCertificateSocketFactory(int socketReadTimeoutForSslHandshake) throws java.security.NoSuchAlgorithmException, java.security.KeyManagementException { throw new RuntimeException("Stub!"); }
/*  6 */   public static javax.net.SocketFactory getDefault(int socketReadTimeoutForSslHandshake) { throw new RuntimeException("Stub!"); }
/*  7 */   public java.net.Socket createSocket(java.net.Socket socket, String s, int i, boolean flag) throws java.io.IOException { throw new RuntimeException("Stub!"); }
/*  8 */   public java.net.Socket createSocket(InetAddress inaddr, int i, InetAddress inaddr2, int j) throws java.io.IOException { throw new RuntimeException("Stub!"); }
/*  9 */   public java.net.Socket createSocket(InetAddress inaddr, int i) throws java.io.IOException { throw new RuntimeException("Stub!"); }
/* 10 */   public java.net.Socket createSocket(String s, int i, InetAddress inaddr, int j) throws java.io.IOException { throw new RuntimeException("Stub!"); }
/* 11 */   public java.net.Socket createSocket(String s, int i) throws java.io.IOException { throw new RuntimeException("Stub!"); }
/* 12 */   public String[] getDefaultCipherSuites() { throw new RuntimeException("Stub!"); }
/* 13 */   public String[] getSupportedCipherSuites() { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\net\SSLCertificateSocketFactory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */