/*    */ package android.net;
/*    */ 
/*    */ import android.os.Parcel;
/*    */ 
/*    */ public class NetworkInfo implements android.os.Parcelable {
/*    */   public static enum State {
/*  7 */     CONNECTED, 
/*  8 */     CONNECTING, 
/*  9 */     DISCONNECTED, 
/* 10 */     DISCONNECTING, 
/* 11 */     SUSPENDED, 
/* 12 */     UNKNOWN;
/*    */     
/*    */     private State() {} }
/*    */   
/* 16 */   public static enum DetailedState { AUTHENTICATING, 
/* 17 */     CONNECTED, 
/* 18 */     CONNECTING, 
/* 19 */     DISCONNECTED, 
/* 20 */     DISCONNECTING, 
/* 21 */     FAILED, 
/* 22 */     IDLE, 
/* 23 */     OBTAINING_IPADDR, 
/* 24 */     SCANNING, 
/* 25 */     SUSPENDED;
/*    */     private DetailedState() {} }
/* 27 */   NetworkInfo() { throw new RuntimeException("Stub!"); }
/* 28 */   public int getType() { throw new RuntimeException("Stub!"); }
/* 29 */   public int getSubtype() { throw new RuntimeException("Stub!"); }
/* 30 */   public String getTypeName() { throw new RuntimeException("Stub!"); }
/* 31 */   public String getSubtypeName() { throw new RuntimeException("Stub!"); }
/* 32 */   public boolean isConnectedOrConnecting() { throw new RuntimeException("Stub!"); }
/* 33 */   public boolean isConnected() { throw new RuntimeException("Stub!"); }
/* 34 */   public boolean isAvailable() { throw new RuntimeException("Stub!"); }
/* 35 */   public boolean isFailover() { throw new RuntimeException("Stub!"); }
/* 36 */   public boolean isRoaming() { throw new RuntimeException("Stub!"); }
/* 37 */   public State getState() { throw new RuntimeException("Stub!"); }
/* 38 */   public DetailedState getDetailedState() { throw new RuntimeException("Stub!"); }
/* 39 */   public String getReason() { throw new RuntimeException("Stub!"); }
/* 40 */   public String getExtraInfo() { throw new RuntimeException("Stub!"); }
/* 41 */   public String toString() { throw new RuntimeException("Stub!"); }
/* 42 */   public int describeContents() { throw new RuntimeException("Stub!"); }
/* 43 */   public void writeToParcel(Parcel dest, int flags) { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\net\NetworkInfo.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */