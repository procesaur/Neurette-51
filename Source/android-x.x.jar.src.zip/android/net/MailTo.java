/*    */ package android.net;
/*    */ import java.util.Map;
/*    */ 
/*  4 */ public class MailTo { MailTo() { throw new RuntimeException("Stub!"); }
/*  5 */   public static boolean isMailTo(String url) { throw new RuntimeException("Stub!"); }
/*  6 */   public static MailTo parse(String url) throws ParseException { throw new RuntimeException("Stub!"); }
/*  7 */   public String getTo() { throw new RuntimeException("Stub!"); }
/*  8 */   public String getCc() { throw new RuntimeException("Stub!"); }
/*  9 */   public String getSubject() { throw new RuntimeException("Stub!"); }
/* 10 */   public String getBody() { throw new RuntimeException("Stub!"); }
/* 11 */   public Map<String, String> getHeaders() { throw new RuntimeException("Stub!"); }
/* 12 */   public String toString() { throw new RuntimeException("Stub!"); }
/*    */   
/*    */   public static final String MAILTO_SCHEME = "mailto:";
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\net\MailTo.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */