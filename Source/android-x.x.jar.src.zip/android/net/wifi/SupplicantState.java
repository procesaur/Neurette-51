/*    */ package android.net.wifi;
/*    */ 
/*    */ import android.os.Parcel;
/*    */ 
/*  5 */ public enum SupplicantState implements android.os.Parcelable { ASSOCIATED, 
/*  6 */   ASSOCIATING, 
/*  7 */   COMPLETED, 
/*  8 */   DISCONNECTED, 
/*  9 */   DORMANT, 
/* 10 */   FOUR_WAY_HANDSHAKE, 
/* 11 */   GROUP_HANDSHAKE, 
/* 12 */   INACTIVE, 
/* 13 */   INVALID, 
/* 14 */   SCANNING, 
/* 15 */   UNINITIALIZED;
/* 16 */   private SupplicantState() {} public static boolean isValidState(SupplicantState state) { throw new RuntimeException("Stub!"); }
/* 17 */   public int describeContents() { throw new RuntimeException("Stub!"); }
/* 18 */   public void writeToParcel(Parcel dest, int flags) { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\net\wifi\SupplicantState.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */