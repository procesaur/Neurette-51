/*   */ package android.net;
/*   */ import android.content.Context;
/*   */ 
/* 4 */ public final class Proxy { public Proxy() { throw new RuntimeException("Stub!"); }
/* 5 */   public static final String getHost(Context ctx) { throw new RuntimeException("Stub!"); }
/* 6 */   public static final int getPort(Context ctx) { throw new RuntimeException("Stub!"); }
/* 7 */   public static final String getDefaultHost() { throw new RuntimeException("Stub!"); }
/* 8 */   public static final int getDefaultPort() { throw new RuntimeException("Stub!"); }
/*   */   
/*   */   public static final String PROXY_CHANGE_ACTION = "android.intent.action.PROXY_CHANGE";
/*   */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\net\Proxy.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */