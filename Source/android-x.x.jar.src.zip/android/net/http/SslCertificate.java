/*    */ package android.net.http;
/*    */ 
/*    */ import android.os.Bundle;
/*    */ 
/*    */ public class SslCertificate {
/*  6 */   public class DName { public DName(String dName) { throw new RuntimeException("Stub!"); }
/*  7 */     public String getDName() { throw new RuntimeException("Stub!"); }
/*  8 */     public String getCName() { throw new RuntimeException("Stub!"); }
/*  9 */     public String getOName() { throw new RuntimeException("Stub!"); }
/* 10 */     public String getUName() { throw new RuntimeException("Stub!"); } }
/*    */   
/* 12 */   public SslCertificate(String issuedTo, String issuedBy, String validNotBefore, String validNotAfter) { throw new RuntimeException("Stub!"); }
/* 13 */   public SslCertificate(java.security.cert.X509Certificate certificate) { throw new RuntimeException("Stub!"); }
/* 14 */   public static Bundle saveState(SslCertificate certificate) { throw new RuntimeException("Stub!"); }
/* 15 */   public static SslCertificate restoreState(Bundle bundle) { throw new RuntimeException("Stub!"); }
/* 16 */   public String getValidNotBefore() { throw new RuntimeException("Stub!"); }
/* 17 */   public String getValidNotAfter() { throw new RuntimeException("Stub!"); }
/* 18 */   public DName getIssuedTo() { throw new RuntimeException("Stub!"); }
/* 19 */   public DName getIssuedBy() { throw new RuntimeException("Stub!"); }
/* 20 */   public String toString() { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\net\http\SslCertificate.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */