/*   */ package android.net;
/*   */ import java.io.IOException;
/*   */ 
/* 4 */ public class LocalServerSocket { public LocalServerSocket(String name) throws IOException { throw new RuntimeException("Stub!"); }
/* 5 */   public LocalServerSocket(java.io.FileDescriptor fd) throws IOException { throw new RuntimeException("Stub!"); }
/* 6 */   public LocalSocketAddress getLocalSocketAddress() { throw new RuntimeException("Stub!"); }
/* 7 */   public LocalSocket accept() throws IOException { throw new RuntimeException("Stub!"); }
/* 8 */   public java.io.FileDescriptor getFileDescriptor() { throw new RuntimeException("Stub!"); }
/* 9 */   public void close() throws IOException { throw new RuntimeException("Stub!"); }
/*   */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\net\LocalServerSocket.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */