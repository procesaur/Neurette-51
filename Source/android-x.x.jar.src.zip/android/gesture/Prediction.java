/*   */ package android.gesture;
/*   */ 
/*   */ public class Prediction {
/* 4 */   Prediction() { throw new RuntimeException("Stub!"); }
/* 5 */   public String toString() { throw new RuntimeException("Stub!"); }
/*   */   
/*   */   public final String name;
/*   */   public double score;
/*   */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\gesture\Prediction.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */