/*   */ package android.gesture;
/*   */ import android.content.Context;
/*   */ 
/* 4 */ public final class GestureLibraries { GestureLibraries() { throw new RuntimeException("Stub!"); }
/* 5 */   public static GestureLibrary fromFile(String path) { throw new RuntimeException("Stub!"); }
/* 6 */   public static GestureLibrary fromFile(java.io.File path) { throw new RuntimeException("Stub!"); }
/* 7 */   public static GestureLibrary fromPrivateFile(Context context, String name) { throw new RuntimeException("Stub!"); }
/* 8 */   public static GestureLibrary fromRawResource(Context context, int resourceId) { throw new RuntimeException("Stub!"); }
/*   */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\gesture\GestureLibraries.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */