/*   */ package android.gesture;
/*   */ 
/*   */ public class OrientedBoundingBox {
/* 4 */   OrientedBoundingBox() { throw new RuntimeException("Stub!"); }
/*   */   
/*   */   public final float squareness;
/*   */   public final float width;
/*   */   public final float height;
/*   */   public final float orientation;
/*   */   public final float centerX;
/*   */   public final float centerY;
/*   */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\gesture\OrientedBoundingBox.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */