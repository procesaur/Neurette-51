/*   */ package android.gesture;
/*   */ 
/*   */ public class GesturePoint {
/* 4 */   public GesturePoint(float x, float y, long t) { throw new RuntimeException("Stub!"); }
/*   */   
/*   */   public final float x;
/*   */   public final float y;
/*   */   public final long timestamp;
/*   */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\gesture\GesturePoint.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */