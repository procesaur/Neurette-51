package android.hardware;

public abstract interface SensorEventListener
{
  public abstract void onSensorChanged(SensorEvent paramSensorEvent);
  
  public abstract void onAccuracyChanged(Sensor paramSensor, int paramInt);
}


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\hardware\SensorEventListener.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */