/*   */ package android.hardware;
/*   */ 
/*   */ public class SensorEvent {
/* 4 */   SensorEvent() { throw new RuntimeException("Stub!"); }
/* 5 */   public final float[] values = null;
/*   */   public Sensor sensor;
/*   */   public int accuracy;
/*   */   public long timestamp;
/*   */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\hardware\SensorEvent.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */