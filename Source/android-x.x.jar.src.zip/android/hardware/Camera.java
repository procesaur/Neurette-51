/*     */ package android.hardware;
/*     */ 
/*     */ import java.util.List;
/*     */ 
/*     */ public class Camera { public static final int CAMERA_ERROR_UNKNOWN = 1;
/*     */   public static final int CAMERA_ERROR_SERVER_DIED = 100;
/*     */   
/*     */   public static abstract interface PreviewCallback { public abstract void onPreviewFrame(byte[] paramArrayOfByte, Camera paramCamera);
/*     */   }
/*     */   
/*     */   public static abstract interface AutoFocusCallback { public abstract void onAutoFocus(boolean paramBoolean, Camera paramCamera);
/*     */   }
/*     */   
/*     */   public static abstract interface ShutterCallback { public abstract void onShutter();
/*     */   }
/*     */   
/*     */   public static abstract interface PictureCallback { public abstract void onPictureTaken(byte[] paramArrayOfByte, Camera paramCamera);
/*     */   }
/*     */   
/*     */   public static abstract interface ErrorCallback { public abstract void onError(int paramInt, Camera paramCamera);
/*     */   }
/*     */   
/*     */   public class Size { public int width;
/*     */     public int height;
/*     */     
/*  26 */     public Size(int w, int h) { throw new RuntimeException("Stub!"); }
/*     */   }
/*     */   
/*     */   public class Parameters { public static final String WHITE_BALANCE_AUTO = "auto";
/*     */     public static final String WHITE_BALANCE_INCANDESCENT = "incandescent";
/*     */     
/*  32 */     Parameters() { throw new RuntimeException("Stub!"); }
/*  33 */     public String flatten() { throw new RuntimeException("Stub!"); }
/*  34 */     public void unflatten(String flattened) { throw new RuntimeException("Stub!"); }
/*  35 */     public void remove(String key) { throw new RuntimeException("Stub!"); }
/*  36 */     public void set(String key, String value) { throw new RuntimeException("Stub!"); }
/*  37 */     public void set(String key, int value) { throw new RuntimeException("Stub!"); }
/*  38 */     public String get(String key) { throw new RuntimeException("Stub!"); }
/*  39 */     public int getInt(String key) { throw new RuntimeException("Stub!"); }
/*  40 */     public void setPreviewSize(int width, int height) { throw new RuntimeException("Stub!"); }
/*  41 */     public Camera.Size getPreviewSize() { throw new RuntimeException("Stub!"); }
/*  42 */     public List<Camera.Size> getSupportedPreviewSizes() { throw new RuntimeException("Stub!"); }
/*  43 */     public void setJpegThumbnailSize(int width, int height) { throw new RuntimeException("Stub!"); }
/*  44 */     public Camera.Size getJpegThumbnailSize() { throw new RuntimeException("Stub!"); }
/*  45 */     public void setJpegThumbnailQuality(int quality) { throw new RuntimeException("Stub!"); }
/*  46 */     public int getJpegThumbnailQuality() { throw new RuntimeException("Stub!"); }
/*  47 */     public void setJpegQuality(int quality) { throw new RuntimeException("Stub!"); }
/*  48 */     public int getJpegQuality() { throw new RuntimeException("Stub!"); }
/*  49 */     public void setPreviewFrameRate(int fps) { throw new RuntimeException("Stub!"); }
/*  50 */     public int getPreviewFrameRate() { throw new RuntimeException("Stub!"); }
/*  51 */     public List<Integer> getSupportedPreviewFrameRates() { throw new RuntimeException("Stub!"); }
/*  52 */     public void setPreviewFormat(int pixel_format) { throw new RuntimeException("Stub!"); }
/*  53 */     public int getPreviewFormat() { throw new RuntimeException("Stub!"); }
/*  54 */     public List<Integer> getSupportedPreviewFormats() { throw new RuntimeException("Stub!"); }
/*  55 */     public void setPictureSize(int width, int height) { throw new RuntimeException("Stub!"); }
/*  56 */     public Camera.Size getPictureSize() { throw new RuntimeException("Stub!"); }
/*  57 */     public List<Camera.Size> getSupportedPictureSizes() { throw new RuntimeException("Stub!"); }
/*  58 */     public void setPictureFormat(int pixel_format) { throw new RuntimeException("Stub!"); }
/*  59 */     public int getPictureFormat() { throw new RuntimeException("Stub!"); }
/*  60 */     public List<Integer> getSupportedPictureFormats() { throw new RuntimeException("Stub!"); }
/*  61 */     public void setRotation(int rotation) { throw new RuntimeException("Stub!"); }
/*  62 */     public void setGpsLatitude(double latitude) { throw new RuntimeException("Stub!"); }
/*  63 */     public void setGpsLongitude(double longitude) { throw new RuntimeException("Stub!"); }
/*  64 */     public void setGpsAltitude(double altitude) { throw new RuntimeException("Stub!"); }
/*  65 */     public void setGpsTimestamp(long timestamp) { throw new RuntimeException("Stub!"); }
/*  66 */     public void removeGpsData() { throw new RuntimeException("Stub!"); }
/*  67 */     public String getWhiteBalance() { throw new RuntimeException("Stub!"); }
/*  68 */     public void setWhiteBalance(String value) { throw new RuntimeException("Stub!"); }
/*  69 */     public List<String> getSupportedWhiteBalance() { throw new RuntimeException("Stub!"); }
/*  70 */     public String getColorEffect() { throw new RuntimeException("Stub!"); }
/*  71 */     public void setColorEffect(String value) { throw new RuntimeException("Stub!"); }
/*  72 */     public List<String> getSupportedColorEffects() { throw new RuntimeException("Stub!"); }
/*  73 */     public String getAntibanding() { throw new RuntimeException("Stub!"); }
/*  74 */     public void setAntibanding(String antibanding) { throw new RuntimeException("Stub!"); }
/*  75 */     public List<String> getSupportedAntibanding() { throw new RuntimeException("Stub!"); }
/*  76 */     public String getSceneMode() { throw new RuntimeException("Stub!"); }
/*  77 */     public void setSceneMode(String value) { throw new RuntimeException("Stub!"); }
/*  78 */     public List<String> getSupportedSceneModes() { throw new RuntimeException("Stub!"); }
/*  79 */     public String getFlashMode() { throw new RuntimeException("Stub!"); }
/*  80 */     public void setFlashMode(String value) { throw new RuntimeException("Stub!"); }
/*  81 */     public List<String> getSupportedFlashModes() { throw new RuntimeException("Stub!"); }
/*  82 */     public String getFocusMode() { throw new RuntimeException("Stub!"); }
/*  83 */     public void setFocusMode(String value) { throw new RuntimeException("Stub!"); }
/*  84 */     public List<String> getSupportedFocusModes() { throw new RuntimeException("Stub!"); }
/*     */     
/*     */     public static final String WHITE_BALANCE_FLUORESCENT = "fluorescent";
/*     */     public static final String WHITE_BALANCE_WARM_FLUORESCENT = "warm-fluorescent";
/*     */     public static final String WHITE_BALANCE_DAYLIGHT = "daylight";
/*     */     public static final String WHITE_BALANCE_CLOUDY_DAYLIGHT = "cloudy-daylight";
/*     */     public static final String WHITE_BALANCE_TWILIGHT = "twilight";
/*     */     public static final String WHITE_BALANCE_SHADE = "shade";
/*     */     public static final String EFFECT_NONE = "none";
/*     */     public static final String EFFECT_MONO = "mono";
/*     */     public static final String EFFECT_NEGATIVE = "negative";
/*     */     public static final String EFFECT_SOLARIZE = "solarize";
/*     */     public static final String EFFECT_SEPIA = "sepia";
/*     */     public static final String EFFECT_POSTERIZE = "posterize";
/*     */     public static final String EFFECT_WHITEBOARD = "whiteboard";
/*     */     public static final String EFFECT_BLACKBOARD = "blackboard";
/*     */     public static final String EFFECT_AQUA = "aqua";
/*     */     public static final String ANTIBANDING_AUTO = "auto";
/*     */     public static final String ANTIBANDING_50HZ = "50hz";
/*     */     public static final String ANTIBANDING_60HZ = "60hz";
/*     */     public static final String ANTIBANDING_OFF = "off";
/*     */     public static final String FLASH_MODE_OFF = "off";
/*     */     public static final String FLASH_MODE_AUTO = "auto";
/*     */     public static final String FLASH_MODE_ON = "on";
/*     */     public static final String FLASH_MODE_RED_EYE = "red-eye";
/*     */     public static final String FLASH_MODE_TORCH = "torch";
/*     */     public static final String SCENE_MODE_AUTO = "auto";
/*     */     public static final String SCENE_MODE_ACTION = "action";
/*     */     public static final String SCENE_MODE_PORTRAIT = "portrait";
/*     */     public static final String SCENE_MODE_LANDSCAPE = "landscape";
/*     */     public static final String SCENE_MODE_NIGHT = "night";
/*     */     public static final String SCENE_MODE_NIGHT_PORTRAIT = "night-portrait";
/*     */     public static final String SCENE_MODE_THEATRE = "theatre";
/*     */     public static final String SCENE_MODE_BEACH = "beach";
/*     */     public static final String SCENE_MODE_SNOW = "snow";
/*     */     public static final String SCENE_MODE_SUNSET = "sunset";
/*     */     public static final String SCENE_MODE_STEADYPHOTO = "steadyphoto";
/*     */     public static final String SCENE_MODE_FIREWORKS = "fireworks";
/*     */     public static final String SCENE_MODE_SPORTS = "sports";
/*     */     public static final String SCENE_MODE_PARTY = "party";
/*     */     public static final String SCENE_MODE_CANDLELIGHT = "candlelight";
/*     */     public static final String FOCUS_MODE_AUTO = "auto";
/*     */     public static final String FOCUS_MODE_INFINITY = "infinity";
/*     */     public static final String FOCUS_MODE_MACRO = "macro";
/*     */     public static final String FOCUS_MODE_FIXED = "fixed";
/*     */   }
/*     */   
/* 131 */   Camera() { throw new RuntimeException("Stub!"); }
/* 132 */   public static Camera open() { throw new RuntimeException("Stub!"); }
/* 133 */   protected void finalize() { throw new RuntimeException("Stub!"); }
/* 134 */   public final void release() { throw new RuntimeException("Stub!"); }
/*     */   public final native void lock();
/*     */   public final native void unlock();
/* 137 */   public final void setPreviewDisplay(android.view.SurfaceHolder holder) throws java.io.IOException { throw new RuntimeException("Stub!"); }
/*     */   public final native void startPreview();
/*     */   public final native void stopPreview();
/* 140 */   public final void setPreviewCallback(PreviewCallback cb) { throw new RuntimeException("Stub!"); }
/* 141 */   public final void setOneShotPreviewCallback(PreviewCallback cb) { throw new RuntimeException("Stub!"); }
/* 142 */   public final void autoFocus(AutoFocusCallback cb) { throw new RuntimeException("Stub!"); }
/* 143 */   public final void cancelAutoFocus() { throw new RuntimeException("Stub!"); }
/* 144 */   public final void takePicture(ShutterCallback shutter, PictureCallback raw, PictureCallback jpeg) { throw new RuntimeException("Stub!"); }
/* 145 */   public final void takePicture(ShutterCallback shutter, PictureCallback raw, PictureCallback postview, PictureCallback jpeg) { throw new RuntimeException("Stub!"); }
/* 146 */   public final void setErrorCallback(ErrorCallback cb) { throw new RuntimeException("Stub!"); }
/* 147 */   public void setParameters(Parameters params) { throw new RuntimeException("Stub!"); }
/* 148 */   public Parameters getParameters() { throw new RuntimeException("Stub!"); }
/*     */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\hardware\Camera.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */