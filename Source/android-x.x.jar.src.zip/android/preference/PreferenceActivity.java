/*    */ package android.preference;
/*    */ 
/*    */ import android.os.Bundle;
/*    */ 
/*  5 */ public abstract class PreferenceActivity extends android.app.ListActivity { public PreferenceActivity() { throw new RuntimeException("Stub!"); }
/*  6 */   protected void onCreate(Bundle savedInstanceState) { throw new RuntimeException("Stub!"); }
/*  7 */   protected void onStop() { throw new RuntimeException("Stub!"); }
/*  8 */   protected void onDestroy() { throw new RuntimeException("Stub!"); }
/*  9 */   protected void onSaveInstanceState(Bundle outState) { throw new RuntimeException("Stub!"); }
/* 10 */   protected void onRestoreInstanceState(Bundle state) { throw new RuntimeException("Stub!"); }
/* 11 */   protected void onActivityResult(int requestCode, int resultCode, android.content.Intent data) { throw new RuntimeException("Stub!"); }
/* 12 */   public void onContentChanged() { throw new RuntimeException("Stub!"); }
/* 13 */   public PreferenceManager getPreferenceManager() { throw new RuntimeException("Stub!"); }
/* 14 */   public void setPreferenceScreen(PreferenceScreen preferenceScreen) { throw new RuntimeException("Stub!"); }
/* 15 */   public PreferenceScreen getPreferenceScreen() { throw new RuntimeException("Stub!"); }
/* 16 */   public void addPreferencesFromIntent(android.content.Intent intent) { throw new RuntimeException("Stub!"); }
/* 17 */   public void addPreferencesFromResource(int preferencesResId) { throw new RuntimeException("Stub!"); }
/* 18 */   public boolean onPreferenceTreeClick(PreferenceScreen preferenceScreen, Preference preference) { throw new RuntimeException("Stub!"); }
/* 19 */   public Preference findPreference(CharSequence key) { throw new RuntimeException("Stub!"); }
/* 20 */   protected void onNewIntent(android.content.Intent intent) { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\preference\PreferenceActivity.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */