/*    */ package android.preference;
/*    */ 
/*    */ import android.content.Context;
/*    */ import android.os.Parcelable;
/*    */ import android.util.AttributeSet;
/*    */ import android.view.View;
/*    */ 
/*    */ public class Preference implements Comparable<Preference>
/*    */ {
/*    */   public static final int DEFAULT_ORDER = Integer.MAX_VALUE;
/*    */   
/*    */   public static class BaseSavedState extends android.view.AbsSavedState
/*    */   {
/*    */     public BaseSavedState(android.os.Parcel source)
/*    */     {
/* 16 */       super();throw new RuntimeException("Stub!"); }
/* 17 */     public BaseSavedState(Parcelable superState) { super();throw new RuntimeException("Stub!"); }
/*    */     
/* 19 */     public static final android.os.Parcelable.Creator<BaseSavedState> CREATOR = null; }
/*    */   
/* 21 */   public Preference(Context context, AttributeSet attrs, int defStyle) { throw new RuntimeException("Stub!"); }
/* 22 */   public Preference(Context context, AttributeSet attrs) { throw new RuntimeException("Stub!"); }
/* 23 */   public Preference(Context context) { throw new RuntimeException("Stub!"); }
/* 24 */   protected Object onGetDefaultValue(android.content.res.TypedArray a, int index) { throw new RuntimeException("Stub!"); }
/* 25 */   public void setIntent(android.content.Intent intent) { throw new RuntimeException("Stub!"); }
/* 26 */   public android.content.Intent getIntent() { throw new RuntimeException("Stub!"); }
/* 27 */   public void setLayoutResource(int layoutResId) { throw new RuntimeException("Stub!"); }
/* 28 */   public int getLayoutResource() { throw new RuntimeException("Stub!"); }
/* 29 */   public void setWidgetLayoutResource(int widgetLayoutResId) { throw new RuntimeException("Stub!"); }
/* 30 */   public int getWidgetLayoutResource() { throw new RuntimeException("Stub!"); }
/* 31 */   public View getView(View convertView, android.view.ViewGroup parent) { throw new RuntimeException("Stub!"); }
/* 32 */   protected View onCreateView(android.view.ViewGroup parent) { throw new RuntimeException("Stub!"); }
/* 33 */   protected void onBindView(View view) { throw new RuntimeException("Stub!"); }
/* 34 */   public void setOrder(int order) { throw new RuntimeException("Stub!"); }
/* 35 */   public int getOrder() { throw new RuntimeException("Stub!"); }
/* 36 */   public void setTitle(CharSequence title) { throw new RuntimeException("Stub!"); }
/* 37 */   public void setTitle(int titleResId) { throw new RuntimeException("Stub!"); }
/* 38 */   public CharSequence getTitle() { throw new RuntimeException("Stub!"); }
/* 39 */   public CharSequence getSummary() { throw new RuntimeException("Stub!"); }
/* 40 */   public void setSummary(CharSequence summary) { throw new RuntimeException("Stub!"); }
/* 41 */   public void setSummary(int summaryResId) { throw new RuntimeException("Stub!"); }
/* 42 */   public void setEnabled(boolean enabled) { throw new RuntimeException("Stub!"); }
/* 43 */   public boolean isEnabled() { throw new RuntimeException("Stub!"); }
/* 44 */   public void setSelectable(boolean selectable) { throw new RuntimeException("Stub!"); }
/* 45 */   public boolean isSelectable() { throw new RuntimeException("Stub!"); }
/* 46 */   public void setShouldDisableView(boolean shouldDisableView) { throw new RuntimeException("Stub!"); }
/* 47 */   public boolean getShouldDisableView() { throw new RuntimeException("Stub!"); }
/* 48 */   protected void onClick() { throw new RuntimeException("Stub!"); }
/* 49 */   public void setKey(String key) { throw new RuntimeException("Stub!"); }
/* 50 */   public String getKey() { throw new RuntimeException("Stub!"); }
/* 51 */   public boolean hasKey() { throw new RuntimeException("Stub!"); }
/* 52 */   public boolean isPersistent() { throw new RuntimeException("Stub!"); }
/* 53 */   protected boolean shouldPersist() { throw new RuntimeException("Stub!"); }
/* 54 */   public void setPersistent(boolean persistent) { throw new RuntimeException("Stub!"); }
/* 55 */   protected boolean callChangeListener(Object newValue) { throw new RuntimeException("Stub!"); }
/* 56 */   public void setOnPreferenceChangeListener(OnPreferenceChangeListener onPreferenceChangeListener) { throw new RuntimeException("Stub!"); }
/* 57 */   public OnPreferenceChangeListener getOnPreferenceChangeListener() { throw new RuntimeException("Stub!"); }
/* 58 */   public void setOnPreferenceClickListener(OnPreferenceClickListener onPreferenceClickListener) { throw new RuntimeException("Stub!"); }
/* 59 */   public OnPreferenceClickListener getOnPreferenceClickListener() { throw new RuntimeException("Stub!"); }
/* 60 */   public Context getContext() { throw new RuntimeException("Stub!"); }
/* 61 */   public android.content.SharedPreferences getSharedPreferences() { throw new RuntimeException("Stub!"); }
/* 62 */   public android.content.SharedPreferences.Editor getEditor() { throw new RuntimeException("Stub!"); }
/* 63 */   public boolean shouldCommit() { throw new RuntimeException("Stub!"); }
/* 64 */   public int compareTo(Preference another) { throw new RuntimeException("Stub!"); }
/* 65 */   protected void notifyChanged() { throw new RuntimeException("Stub!"); }
/* 66 */   protected void notifyHierarchyChanged() { throw new RuntimeException("Stub!"); }
/* 67 */   public PreferenceManager getPreferenceManager() { throw new RuntimeException("Stub!"); }
/* 68 */   protected void onAttachedToHierarchy(PreferenceManager preferenceManager) { throw new RuntimeException("Stub!"); }
/* 69 */   protected void onAttachedToActivity() { throw new RuntimeException("Stub!"); }
/* 70 */   protected Preference findPreferenceInHierarchy(String key) { throw new RuntimeException("Stub!"); }
/* 71 */   public void notifyDependencyChange(boolean disableDependents) { throw new RuntimeException("Stub!"); }
/* 72 */   public void onDependencyChanged(Preference dependency, boolean disableDependent) { throw new RuntimeException("Stub!"); }
/* 73 */   public boolean shouldDisableDependents() { throw new RuntimeException("Stub!"); }
/* 74 */   public void setDependency(String dependencyKey) { throw new RuntimeException("Stub!"); }
/* 75 */   public String getDependency() { throw new RuntimeException("Stub!"); }
/* 76 */   protected void onPrepareForRemoval() { throw new RuntimeException("Stub!"); }
/* 77 */   public void setDefaultValue(Object defaultValue) { throw new RuntimeException("Stub!"); }
/* 78 */   protected void onSetInitialValue(boolean restorePersistedValue, Object defaultValue) { throw new RuntimeException("Stub!"); }
/* 79 */   protected boolean persistString(String value) { throw new RuntimeException("Stub!"); }
/* 80 */   protected String getPersistedString(String defaultReturnValue) { throw new RuntimeException("Stub!"); }
/* 81 */   protected boolean persistInt(int value) { throw new RuntimeException("Stub!"); }
/* 82 */   protected int getPersistedInt(int defaultReturnValue) { throw new RuntimeException("Stub!"); }
/* 83 */   protected boolean persistFloat(float value) { throw new RuntimeException("Stub!"); }
/* 84 */   protected float getPersistedFloat(float defaultReturnValue) { throw new RuntimeException("Stub!"); }
/* 85 */   protected boolean persistLong(long value) { throw new RuntimeException("Stub!"); }
/* 86 */   protected long getPersistedLong(long defaultReturnValue) { throw new RuntimeException("Stub!"); }
/* 87 */   protected boolean persistBoolean(boolean value) { throw new RuntimeException("Stub!"); }
/* 88 */   protected boolean getPersistedBoolean(boolean defaultReturnValue) { throw new RuntimeException("Stub!"); }
/* 89 */   public String toString() { throw new RuntimeException("Stub!"); }
/* 90 */   public void saveHierarchyState(android.os.Bundle container) { throw new RuntimeException("Stub!"); }
/* 91 */   protected Parcelable onSaveInstanceState() { throw new RuntimeException("Stub!"); }
/* 92 */   public void restoreHierarchyState(android.os.Bundle container) { throw new RuntimeException("Stub!"); }
/* 93 */   protected void onRestoreInstanceState(Parcelable state) { throw new RuntimeException("Stub!"); }
/*    */   
/*    */   public static abstract interface OnPreferenceClickListener
/*    */   {
/*    */     public abstract boolean onPreferenceClick(Preference paramPreference);
/*    */   }
/*    */   
/*    */   public static abstract interface OnPreferenceChangeListener
/*    */   {
/*    */     public abstract boolean onPreferenceChange(Preference paramPreference, Object paramObject);
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\preference\Preference.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */