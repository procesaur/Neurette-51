/*   */ package android.preference;
/*   */ 
/*   */ import android.content.Context;
/*   */ 
/* 5 */ public class PreferenceCategory extends PreferenceGroup { public PreferenceCategory(Context context, android.util.AttributeSet attrs, int defStyle) { super((Context)null, (android.util.AttributeSet)null);throw new RuntimeException("Stub!"); }
/* 6 */   public PreferenceCategory(Context context, android.util.AttributeSet attrs) { super((Context)null, (android.util.AttributeSet)null);throw new RuntimeException("Stub!"); }
/* 7 */   public PreferenceCategory(Context context) { super((Context)null, (android.util.AttributeSet)null);throw new RuntimeException("Stub!"); }
/* 8 */   protected boolean onPrepareAddPreference(Preference preference) { throw new RuntimeException("Stub!"); }
/* 9 */   public boolean isEnabled() { throw new RuntimeException("Stub!"); }
/*   */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\preference\PreferenceCategory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */