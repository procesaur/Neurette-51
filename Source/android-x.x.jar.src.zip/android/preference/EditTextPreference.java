/*    */ package android.preference;
/*    */ 
/*    */ import android.content.Context;
/*    */ 
/*  5 */ public class EditTextPreference extends DialogPreference { public EditTextPreference(Context context, android.util.AttributeSet attrs, int defStyle) { super((Context)null, (android.util.AttributeSet)null);throw new RuntimeException("Stub!"); }
/*  6 */   public EditTextPreference(Context context, android.util.AttributeSet attrs) { super((Context)null, (android.util.AttributeSet)null);throw new RuntimeException("Stub!"); }
/*  7 */   public EditTextPreference(Context context) { super((Context)null, (android.util.AttributeSet)null);throw new RuntimeException("Stub!"); }
/*  8 */   public void setText(String text) { throw new RuntimeException("Stub!"); }
/*  9 */   public String getText() { throw new RuntimeException("Stub!"); }
/* 10 */   protected void onBindDialogView(android.view.View view) { throw new RuntimeException("Stub!"); }
/* 11 */   protected void onAddEditTextToDialogView(android.view.View dialogView, android.widget.EditText editText) { throw new RuntimeException("Stub!"); }
/* 12 */   protected void onDialogClosed(boolean positiveResult) { throw new RuntimeException("Stub!"); }
/* 13 */   protected Object onGetDefaultValue(android.content.res.TypedArray a, int index) { throw new RuntimeException("Stub!"); }
/* 14 */   protected void onSetInitialValue(boolean restoreValue, Object defaultValue) { throw new RuntimeException("Stub!"); }
/* 15 */   public boolean shouldDisableDependents() { throw new RuntimeException("Stub!"); }
/* 16 */   public android.widget.EditText getEditText() { throw new RuntimeException("Stub!"); }
/* 17 */   protected android.os.Parcelable onSaveInstanceState() { throw new RuntimeException("Stub!"); }
/* 18 */   protected void onRestoreInstanceState(android.os.Parcelable state) { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\preference\EditTextPreference.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */