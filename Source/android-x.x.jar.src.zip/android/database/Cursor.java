package android.database;

import android.content.ContentResolver;
import android.net.Uri;
import android.os.Bundle;

public abstract interface Cursor
{
  public abstract int getCount();
  
  public abstract int getPosition();
  
  public abstract boolean move(int paramInt);
  
  public abstract boolean moveToPosition(int paramInt);
  
  public abstract boolean moveToFirst();
  
  public abstract boolean moveToLast();
  
  public abstract boolean moveToNext();
  
  public abstract boolean moveToPrevious();
  
  public abstract boolean isFirst();
  
  public abstract boolean isLast();
  
  public abstract boolean isBeforeFirst();
  
  public abstract boolean isAfterLast();
  
  public abstract int getColumnIndex(String paramString);
  
  public abstract int getColumnIndexOrThrow(String paramString)
    throws IllegalArgumentException;
  
  public abstract String getColumnName(int paramInt);
  
  public abstract String[] getColumnNames();
  
  public abstract int getColumnCount();
  
  public abstract byte[] getBlob(int paramInt);
  
  public abstract String getString(int paramInt);
  
  public abstract void copyStringToBuffer(int paramInt, CharArrayBuffer paramCharArrayBuffer);
  
  public abstract short getShort(int paramInt);
  
  public abstract int getInt(int paramInt);
  
  public abstract long getLong(int paramInt);
  
  public abstract float getFloat(int paramInt);
  
  public abstract double getDouble(int paramInt);
  
  public abstract boolean isNull(int paramInt);
  
  public abstract void deactivate();
  
  public abstract boolean requery();
  
  public abstract void close();
  
  public abstract boolean isClosed();
  
  public abstract void registerContentObserver(ContentObserver paramContentObserver);
  
  public abstract void unregisterContentObserver(ContentObserver paramContentObserver);
  
  public abstract void registerDataSetObserver(DataSetObserver paramDataSetObserver);
  
  public abstract void unregisterDataSetObserver(DataSetObserver paramDataSetObserver);
  
  public abstract void setNotificationUri(ContentResolver paramContentResolver, Uri paramUri);
  
  public abstract boolean getWantsAllOnMoveCalls();
  
  public abstract Bundle getExtras();
  
  public abstract Bundle respond(Bundle paramBundle);
}


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\database\Cursor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */