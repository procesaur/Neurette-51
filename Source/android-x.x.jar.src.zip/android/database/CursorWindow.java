/*    */ package android.database;
/*    */ 
/*    */ import android.os.Parcel;
/*    */ 
/*    */ public class CursorWindow extends android.database.sqlite.SQLiteClosable implements android.os.Parcelable {
/*  6 */   public CursorWindow(boolean localWindow) { throw new RuntimeException("Stub!"); }
/*  7 */   public int getStartPosition() { throw new RuntimeException("Stub!"); }
/*  8 */   public void setStartPosition(int pos) { throw new RuntimeException("Stub!"); }
/*  9 */   public int getNumRows() { throw new RuntimeException("Stub!"); }
/* 10 */   public boolean setNumColumns(int columnNum) { throw new RuntimeException("Stub!"); }
/* 11 */   public boolean allocRow() { throw new RuntimeException("Stub!"); }
/* 12 */   public void freeLastRow() { throw new RuntimeException("Stub!"); }
/* 13 */   public boolean putBlob(byte[] value, int row, int col) { throw new RuntimeException("Stub!"); }
/* 14 */   public boolean putString(String value, int row, int col) { throw new RuntimeException("Stub!"); }
/* 15 */   public boolean putLong(long value, int row, int col) { throw new RuntimeException("Stub!"); }
/* 16 */   public boolean putDouble(double value, int row, int col) { throw new RuntimeException("Stub!"); }
/* 17 */   public boolean putNull(int row, int col) { throw new RuntimeException("Stub!"); }
/* 18 */   public boolean isNull(int row, int col) { throw new RuntimeException("Stub!"); }
/* 19 */   public byte[] getBlob(int row, int col) { throw new RuntimeException("Stub!"); }
/* 20 */   public boolean isBlob(int row, int col) { throw new RuntimeException("Stub!"); }
/* 21 */   public boolean isLong(int row, int col) { throw new RuntimeException("Stub!"); }
/* 22 */   public boolean isFloat(int row, int col) { throw new RuntimeException("Stub!"); }
/* 23 */   public boolean isString(int row, int col) { throw new RuntimeException("Stub!"); }
/* 24 */   public String getString(int row, int col) { throw new RuntimeException("Stub!"); }
/* 25 */   public void copyStringToBuffer(int row, int col, CharArrayBuffer buffer) { throw new RuntimeException("Stub!"); }
/* 26 */   public long getLong(int row, int col) { throw new RuntimeException("Stub!"); }
/* 27 */   public double getDouble(int row, int col) { throw new RuntimeException("Stub!"); }
/* 28 */   public short getShort(int row, int col) { throw new RuntimeException("Stub!"); }
/* 29 */   public int getInt(int row, int col) { throw new RuntimeException("Stub!"); }
/* 30 */   public float getFloat(int row, int col) { throw new RuntimeException("Stub!"); }
/* 31 */   public void clear() { throw new RuntimeException("Stub!"); }
/* 32 */   public void close() { throw new RuntimeException("Stub!"); }
/* 33 */   protected void finalize() { throw new RuntimeException("Stub!"); }
/* 34 */   public static CursorWindow newFromParcel(Parcel p) { throw new RuntimeException("Stub!"); }
/* 35 */   public int describeContents() { throw new RuntimeException("Stub!"); }
/* 36 */   public void writeToParcel(Parcel dest, int flags) { throw new RuntimeException("Stub!"); }
/* 37 */   protected void onAllReferencesReleased() { throw new RuntimeException("Stub!"); }
/*    */   
/* 39 */   public static final android.os.Parcelable.Creator<CursorWindow> CREATOR = null;
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\database\CursorWindow.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */