/*   */ package android.database;
/*   */ 
/*   */ public class StaleDataException
/*   */   extends RuntimeException {
/* 5 */   public StaleDataException() { throw new RuntimeException("Stub!"); }
/* 6 */   public StaleDataException(String description) { throw new RuntimeException("Stub!"); }
/*   */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\database\StaleDataException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */