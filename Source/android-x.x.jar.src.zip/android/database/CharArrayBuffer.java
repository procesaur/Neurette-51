/*   */ package android.database;
/*   */ 
/*   */ public final class CharArrayBuffer {
/* 4 */   public CharArrayBuffer(int size) { throw new RuntimeException("Stub!"); }
/* 5 */   public CharArrayBuffer(char[] buf) { throw new RuntimeException("Stub!"); }
/* 6 */   public char[] data = null;
/*   */   public int sizeCopied;
/*   */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\database\CharArrayBuffer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */