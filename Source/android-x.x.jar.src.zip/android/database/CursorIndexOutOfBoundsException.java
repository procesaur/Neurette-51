/*   */ package android.database;
/*   */ 
/*   */ public class CursorIndexOutOfBoundsException
/*   */   extends IndexOutOfBoundsException {
/* 5 */   public CursorIndexOutOfBoundsException(int index, int size) { throw new RuntimeException("Stub!"); }
/* 6 */   public CursorIndexOutOfBoundsException(String message) { throw new RuntimeException("Stub!"); }
/*   */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\database\CursorIndexOutOfBoundsException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */