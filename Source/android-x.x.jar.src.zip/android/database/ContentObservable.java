/*   */ package android.database;
/*   */ 
/*   */ public class ContentObservable
/*   */   extends Observable<ContentObserver> {
/* 5 */   public ContentObservable() { throw new RuntimeException("Stub!"); }
/* 6 */   public void registerObserver(ContentObserver observer) { throw new RuntimeException("Stub!"); }
/* 7 */   public void dispatchChange(boolean selfChange) { throw new RuntimeException("Stub!"); }
/* 8 */   public void notifyChange(boolean selfChange) { throw new RuntimeException("Stub!"); }
/*   */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\database\ContentObservable.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */