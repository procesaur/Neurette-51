/*   */ package android.database.sqlite;
/*   */ 
/*   */ public class SQLiteStatement
/*   */   extends SQLiteProgram {
/* 5 */   SQLiteStatement() { throw new RuntimeException("Stub!"); }
/* 6 */   public void execute() { throw new RuntimeException("Stub!"); }
/* 7 */   public long executeInsert() { throw new RuntimeException("Stub!"); }
/* 8 */   public long simpleQueryForLong() { throw new RuntimeException("Stub!"); }
/* 9 */   public String simpleQueryForString() { throw new RuntimeException("Stub!"); }
/*   */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\database\sqlite\SQLiteStatement.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */