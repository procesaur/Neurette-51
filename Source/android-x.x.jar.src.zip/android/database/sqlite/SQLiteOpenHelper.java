/*    */ package android.database.sqlite;
/*    */ import android.content.Context;
/*    */ 
/*  4 */ public abstract class SQLiteOpenHelper { public SQLiteOpenHelper(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) { throw new RuntimeException("Stub!"); }
/*  5 */   public synchronized SQLiteDatabase getWritableDatabase() { throw new RuntimeException("Stub!"); }
/*  6 */   public synchronized SQLiteDatabase getReadableDatabase() { throw new RuntimeException("Stub!"); }
/*  7 */   public synchronized void close() { throw new RuntimeException("Stub!"); }
/*    */   public abstract void onCreate(SQLiteDatabase paramSQLiteDatabase);
/*    */   public abstract void onUpgrade(SQLiteDatabase paramSQLiteDatabase, int paramInt1, int paramInt2);
/* 10 */   public void onOpen(SQLiteDatabase db) { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\database\sqlite\SQLiteOpenHelper.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */