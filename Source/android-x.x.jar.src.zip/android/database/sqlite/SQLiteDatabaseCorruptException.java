/*   */ package android.database.sqlite;
/*   */ 
/*   */ public class SQLiteDatabaseCorruptException
/*   */   extends SQLiteException {
/* 5 */   public SQLiteDatabaseCorruptException() { throw new RuntimeException("Stub!"); }
/* 6 */   public SQLiteDatabaseCorruptException(String error) { throw new RuntimeException("Stub!"); }
/*   */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\database\sqlite\SQLiteDatabaseCorruptException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */