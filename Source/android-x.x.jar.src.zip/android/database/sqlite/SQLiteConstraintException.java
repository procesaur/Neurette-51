/*   */ package android.database.sqlite;
/*   */ 
/*   */ public class SQLiteConstraintException
/*   */   extends SQLiteException {
/* 5 */   public SQLiteConstraintException() { throw new RuntimeException("Stub!"); }
/* 6 */   public SQLiteConstraintException(String error) { throw new RuntimeException("Stub!"); }
/*   */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\database\sqlite\SQLiteConstraintException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */