/*    */ package android.database.sqlite;
/*    */ 
/*    */ public abstract class SQLiteProgram extends SQLiteClosable { protected SQLiteDatabase mDatabase;
/*    */   
/*  5 */   SQLiteProgram() { throw new RuntimeException("Stub!"); }
/*  6 */   protected void onAllReferencesReleased() { throw new RuntimeException("Stub!"); }
/*  7 */   protected void onAllReferencesReleasedFromContainer() { throw new RuntimeException("Stub!"); }
/*  8 */   public final int getUniqueId() { throw new RuntimeException("Stub!"); }
/*  9 */   protected void compile(String sql, boolean forceCompilation) { throw new RuntimeException("Stub!"); }
/* 10 */   public void bindNull(int index) { throw new RuntimeException("Stub!"); }
/* 11 */   public void bindLong(int index, long value) { throw new RuntimeException("Stub!"); }
/* 12 */   public void bindDouble(int index, double value) { throw new RuntimeException("Stub!"); }
/* 13 */   public void bindString(int index, String value) { throw new RuntimeException("Stub!"); }
/* 14 */   public void bindBlob(int index, byte[] value) { throw new RuntimeException("Stub!"); }
/* 15 */   public void clearBindings() { throw new RuntimeException("Stub!"); }
/* 16 */   public void close() { throw new RuntimeException("Stub!"); }
/* 17 */   protected void finalize() { throw new RuntimeException("Stub!"); }
/*    */   
/*    */   protected int nHandle;
/*    */   protected int nStatement;
/*    */   protected final native void native_compile(String paramString);
/*    */   
/*    */   protected final native void native_finalize();
/*    */   
/*    */   protected final native void native_bind_null(int paramInt);
/*    */   
/*    */   protected final native void native_bind_long(int paramInt, long paramLong);
/*    */   
/*    */   protected final native void native_bind_double(int paramInt, double paramDouble);
/*    */   
/*    */   protected final native void native_bind_string(int paramInt, String paramString);
/*    */   
/*    */   protected final native void native_bind_blob(int paramInt, byte[] paramArrayOfByte);
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\database\sqlite\SQLiteProgram.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */