/*    */ package android.database.sqlite;
/*    */ 
/*    */ import android.database.DataSetObserver;
/*    */ 
/*  5 */ public class SQLiteCursor extends android.database.AbstractWindowedCursor { public SQLiteCursor(SQLiteDatabase db, SQLiteCursorDriver driver, String editTable, SQLiteQuery query) { throw new RuntimeException("Stub!"); }
/*  6 */   public void registerDataSetObserver(DataSetObserver observer) { throw new RuntimeException("Stub!"); }
/*  7 */   public SQLiteDatabase getDatabase() { throw new RuntimeException("Stub!"); }
/*  8 */   public boolean onMove(int oldPosition, int newPosition) { throw new RuntimeException("Stub!"); }
/*  9 */   public int getCount() { throw new RuntimeException("Stub!"); }
/* 10 */   public int getColumnIndex(String columnName) { throw new RuntimeException("Stub!"); }
/* 11 */   public String[] getColumnNames() { throw new RuntimeException("Stub!"); }
/* 12 */   public void deactivate() { throw new RuntimeException("Stub!"); }
/* 13 */   public void close() { throw new RuntimeException("Stub!"); }
/* 14 */   public boolean requery() { throw new RuntimeException("Stub!"); }
/* 15 */   public void setWindow(android.database.CursorWindow window) { throw new RuntimeException("Stub!"); }
/* 16 */   public void setSelectionArguments(String[] selectionArgs) { throw new RuntimeException("Stub!"); }
/* 17 */   protected void finalize() { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\database\sqlite\SQLiteCursor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */