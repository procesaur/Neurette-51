/*   */ package android.database.sqlite;
/*   */ 
/*   */ public abstract class SQLiteClosable {
/* 4 */   public SQLiteClosable() { throw new RuntimeException("Stub!"); }
/*   */   protected abstract void onAllReferencesReleased();
/* 6 */   protected void onAllReferencesReleasedFromContainer() { throw new RuntimeException("Stub!"); }
/* 7 */   public void acquireReference() { throw new RuntimeException("Stub!"); }
/* 8 */   public void releaseReference() { throw new RuntimeException("Stub!"); }
/* 9 */   public void releaseReferenceFromContainer() { throw new RuntimeException("Stub!"); }
/*   */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\database\sqlite\SQLiteClosable.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */