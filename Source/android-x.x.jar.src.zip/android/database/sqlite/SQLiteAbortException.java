/*   */ package android.database.sqlite;
/*   */ 
/*   */ public class SQLiteAbortException
/*   */   extends SQLiteException {
/* 5 */   public SQLiteAbortException() { throw new RuntimeException("Stub!"); }
/* 6 */   public SQLiteAbortException(String error) { throw new RuntimeException("Stub!"); }
/*   */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\database\sqlite\SQLiteAbortException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */