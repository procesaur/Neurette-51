/*    */ package android.database.sqlite;
/*    */ 
/*    */ public class SQLiteQuery
/*    */   extends SQLiteProgram {
/*  5 */   SQLiteQuery() { throw new RuntimeException("Stub!"); }
/*  6 */   public String toString() { throw new RuntimeException("Stub!"); }
/*  7 */   public void close() { throw new RuntimeException("Stub!"); }
/*  8 */   public void bindNull(int index) { throw new RuntimeException("Stub!"); }
/*  9 */   public void bindLong(int index, long value) { throw new RuntimeException("Stub!"); }
/* 10 */   public void bindDouble(int index, double value) { throw new RuntimeException("Stub!"); }
/* 11 */   public void bindString(int index, String value) { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\database\sqlite\SQLiteQuery.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */