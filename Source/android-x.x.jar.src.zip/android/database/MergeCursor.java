/*    */ package android.database;
/*    */ 
/*    */ public class MergeCursor
/*    */   extends AbstractCursor {
/*  5 */   public MergeCursor(Cursor[] cursors) { throw new RuntimeException("Stub!"); }
/*  6 */   public int getCount() { throw new RuntimeException("Stub!"); }
/*  7 */   public boolean onMove(int oldPosition, int newPosition) { throw new RuntimeException("Stub!"); }
/*  8 */   public String getString(int column) { throw new RuntimeException("Stub!"); }
/*  9 */   public short getShort(int column) { throw new RuntimeException("Stub!"); }
/* 10 */   public int getInt(int column) { throw new RuntimeException("Stub!"); }
/* 11 */   public long getLong(int column) { throw new RuntimeException("Stub!"); }
/* 12 */   public float getFloat(int column) { throw new RuntimeException("Stub!"); }
/* 13 */   public double getDouble(int column) { throw new RuntimeException("Stub!"); }
/* 14 */   public boolean isNull(int column) { throw new RuntimeException("Stub!"); }
/* 15 */   public byte[] getBlob(int column) { throw new RuntimeException("Stub!"); }
/* 16 */   public String[] getColumnNames() { throw new RuntimeException("Stub!"); }
/* 17 */   public void deactivate() { throw new RuntimeException("Stub!"); }
/* 18 */   public void close() { throw new RuntimeException("Stub!"); }
/* 19 */   public void registerContentObserver(ContentObserver observer) { throw new RuntimeException("Stub!"); }
/* 20 */   public void unregisterContentObserver(ContentObserver observer) { throw new RuntimeException("Stub!"); }
/* 21 */   public void registerDataSetObserver(DataSetObserver observer) { throw new RuntimeException("Stub!"); }
/* 22 */   public void unregisterDataSetObserver(DataSetObserver observer) { throw new RuntimeException("Stub!"); }
/* 23 */   public boolean requery() { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\database\MergeCursor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */