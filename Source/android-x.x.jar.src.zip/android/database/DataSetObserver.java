/*   */ package android.database;
/*   */ 
/*   */ public abstract class DataSetObserver {
/* 4 */   public DataSetObserver() { throw new RuntimeException("Stub!"); }
/* 5 */   public void onChanged() { throw new RuntimeException("Stub!"); }
/* 6 */   public void onInvalidated() { throw new RuntimeException("Stub!"); }
/*   */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\database\DataSetObserver.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */