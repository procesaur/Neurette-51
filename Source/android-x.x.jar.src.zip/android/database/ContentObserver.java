/*   */ package android.database;
/*   */ import android.os.Handler;
/*   */ 
/* 4 */ public abstract class ContentObserver { public ContentObserver(Handler handler) { throw new RuntimeException("Stub!"); }
/* 5 */   public boolean deliverSelfNotifications() { throw new RuntimeException("Stub!"); }
/* 6 */   public void onChange(boolean selfChange) { throw new RuntimeException("Stub!"); }
/* 7 */   public final void dispatchChange(boolean selfChange) { throw new RuntimeException("Stub!"); }
/*   */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\database\ContentObserver.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */