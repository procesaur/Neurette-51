package android.provider;

public abstract interface BaseColumns
{
  public static final String _ID = "_id";
  public static final String _COUNT = "_count";
}


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\provider\BaseColumns.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */