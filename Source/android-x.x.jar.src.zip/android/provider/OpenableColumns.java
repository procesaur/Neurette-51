package android.provider;

public abstract interface OpenableColumns
{
  public static final String DISPLAY_NAME = "_display_name";
  public static final String SIZE = "_size";
}


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\provider\OpenableColumns.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */