/*    */ package android.test.suitebuilder;
/*    */ import junit.framework.TestCase;
/*    */ 
/*  4 */ public class TestMethod { public TestMethod(java.lang.reflect.Method method, Class<? extends TestCase> enclosingClass) { throw new RuntimeException("Stub!"); }
/*  5 */   public TestMethod(String methodName, Class<? extends TestCase> enclosingClass) { throw new RuntimeException("Stub!"); }
/*  6 */   public TestMethod(TestCase testCase) { throw new RuntimeException("Stub!"); }
/*  7 */   public String getName() { throw new RuntimeException("Stub!"); }
/*  8 */   public String getEnclosingClassname() { throw new RuntimeException("Stub!"); }
/*  9 */   public <T extends java.lang.annotation.Annotation> T getAnnotation(Class<T> annotationClass) { throw new RuntimeException("Stub!"); }
/* 10 */   public Class<? extends TestCase> getEnclosingClass() { throw new RuntimeException("Stub!"); }
/* 11 */   public TestCase createTest() throws java.lang.reflect.InvocationTargetException, IllegalAccessException, InstantiationException { throw new RuntimeException("Stub!"); }
/* 12 */   public boolean equals(Object o) { throw new RuntimeException("Stub!"); }
/* 13 */   public int hashCode() { throw new RuntimeException("Stub!"); }
/* 14 */   public String toString() { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\test\suitebuilder\TestMethod.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */