/*    */ package android.test.suitebuilder;
/*    */ 
/*    */ import com.android.internal.util.Predicate;
/*    */ 
/*    */ public class TestSuiteBuilder {
/*    */   public static class FailedToCreateTests extends junit.framework.TestCase {
/*  7 */     public FailedToCreateTests(Exception exception) { throw new RuntimeException("Stub!"); }
/*  8 */     public void testSuiteConstructionFailed() { throw new RuntimeException("Stub!"); } }
/*    */   
/* 10 */   public TestSuiteBuilder(Class clazz) { throw new RuntimeException("Stub!"); }
/* 11 */   public TestSuiteBuilder(String name, ClassLoader classLoader) { throw new RuntimeException("Stub!"); }
/* 12 */   public TestSuiteBuilder includePackages(String... packageNames) { throw new RuntimeException("Stub!"); }
/* 13 */   public TestSuiteBuilder excludePackages(String... packageNames) { throw new RuntimeException("Stub!"); }
/* 14 */   public TestSuiteBuilder addRequirements(java.util.List<Predicate<TestMethod>> predicates) { throw new RuntimeException("Stub!"); }
/* 15 */   public final TestSuiteBuilder includeAllPackagesUnderHere() { throw new RuntimeException("Stub!"); }
/* 16 */   public TestSuiteBuilder named(String newSuiteName) { throw new RuntimeException("Stub!"); }
/* 17 */   public final junit.framework.TestSuite build() { throw new RuntimeException("Stub!"); }
/* 18 */   protected String getSuiteName() { throw new RuntimeException("Stub!"); }
/* 19 */   public final TestSuiteBuilder addRequirements(Predicate<TestMethod>... predicates) { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\test\suitebuilder\TestSuiteBuilder.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */