/*    */ package android.test;
/*    */ 
/*    */ import android.content.Context;
/*    */ 
/*    */ @Deprecated
/*  6 */ public abstract class ProviderTestCase<T extends android.content.ContentProvider> extends InstrumentationTestCase { public ProviderTestCase(Class<T> providerClass, String providerAuthority) { throw new RuntimeException("Stub!"); }
/*  7 */   public T getProvider() { throw new RuntimeException("Stub!"); }
/*  8 */   protected void setUp() throws Exception { throw new RuntimeException("Stub!"); }
/*  9 */   public android.test.mock.MockContentResolver getMockContentResolver() { throw new RuntimeException("Stub!"); }
/* 10 */   public IsolatedContext getMockContext() { throw new RuntimeException("Stub!"); }
/* 11 */   public static <T extends android.content.ContentProvider> android.content.ContentResolver newResolverWithContentProviderFromSql(Context targetContext, Class<T> providerClass, String authority, String databaseName, int databaseVersion, String sql) throws IllegalAccessException, InstantiationException { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\test\ProviderTestCase.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */