/*    */ package android.test;
/*    */ 
/*    */ import android.content.Intent;
/*    */ 
/*  5 */ public abstract class ActivityInstrumentationTestCase2<T extends android.app.Activity> extends ActivityTestCase { public ActivityInstrumentationTestCase2(String pkg, Class<T> activityClass) { throw new RuntimeException("Stub!"); }
/*  6 */   public T getActivity() { throw new RuntimeException("Stub!"); }
/*  7 */   public void setActivityIntent(Intent i) { throw new RuntimeException("Stub!"); }
/*  8 */   public void setActivityInitialTouchMode(boolean initialTouchMode) { throw new RuntimeException("Stub!"); }
/*  9 */   protected void setUp() throws Exception { throw new RuntimeException("Stub!"); }
/* 10 */   protected void tearDown() throws Exception { throw new RuntimeException("Stub!"); }
/* 11 */   protected void runTest() throws Throwable { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\test\ActivityInstrumentationTestCase2.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */