/*    */ package android.test;
/*    */ 
/*    */ import android.content.Context;
/*    */ 
/*  5 */ public class AndroidTestCase extends junit.framework.TestCase { public AndroidTestCase() { throw new RuntimeException("Stub!"); }
/*  6 */   protected void setUp() throws Exception { throw new RuntimeException("Stub!"); }
/*  7 */   protected void tearDown() throws Exception { throw new RuntimeException("Stub!"); }
/*  8 */   public void testAndroidTestCaseSetupProperly() { throw new RuntimeException("Stub!"); }
/*  9 */   public void setContext(Context context) { throw new RuntimeException("Stub!"); }
/* 10 */   public Context getContext() { throw new RuntimeException("Stub!"); }
/* 11 */   public void assertActivityRequiresPermission(String packageName, String className, String permission) { throw new RuntimeException("Stub!"); }
/* 12 */   public void assertReadingContentUriRequiresPermission(android.net.Uri uri, String permission) { throw new RuntimeException("Stub!"); }
/* 13 */   public void assertWritingContentUriRequiresPermission(android.net.Uri uri, String permission) { throw new RuntimeException("Stub!"); }
/* 14 */   protected void scrubClass(Class<?> testCaseClass) throws IllegalAccessException { throw new RuntimeException("Stub!"); }
/*    */   
/*    */   protected Context mContext;
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\test\AndroidTestCase.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */