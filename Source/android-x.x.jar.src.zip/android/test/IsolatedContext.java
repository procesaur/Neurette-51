/*    */ package android.test;
/*    */ 
/*    */ import android.content.Intent;
/*    */ 
/*  5 */ public class IsolatedContext extends android.content.ContextWrapper { public IsolatedContext(android.content.ContentResolver resolver, android.content.Context targetContext) { super((android.content.Context)null);throw new RuntimeException("Stub!"); }
/*  6 */   public java.util.List<Intent> getAndClearBroadcastIntents() { throw new RuntimeException("Stub!"); }
/*  7 */   public android.content.ContentResolver getContentResolver() { throw new RuntimeException("Stub!"); }
/*  8 */   public boolean bindService(Intent service, android.content.ServiceConnection conn, int flags) { throw new RuntimeException("Stub!"); }
/*  9 */   public Intent registerReceiver(android.content.BroadcastReceiver receiver, android.content.IntentFilter filter) { throw new RuntimeException("Stub!"); }
/* 10 */   public void sendBroadcast(Intent intent) { throw new RuntimeException("Stub!"); }
/* 11 */   public void sendOrderedBroadcast(Intent intent, String receiverPermission) { throw new RuntimeException("Stub!"); }
/* 12 */   public int checkUriPermission(android.net.Uri uri, String readPermission, String writePermission, int pid, int uid, int modeFlags) { throw new RuntimeException("Stub!"); }
/* 13 */   public int checkUriPermission(android.net.Uri uri, int pid, int uid, int modeFlags) { throw new RuntimeException("Stub!"); }
/* 14 */   public Object getSystemService(String name) { throw new RuntimeException("Stub!"); }
/* 15 */   public java.io.File getFilesDir() { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\test\IsolatedContext.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */