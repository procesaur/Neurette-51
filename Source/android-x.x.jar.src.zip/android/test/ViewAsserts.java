/*    */ package android.test;
/*    */ import android.view.View;
/*    */ 
/*  4 */ public class ViewAsserts { ViewAsserts() { throw new RuntimeException("Stub!"); }
/*  5 */   public static void assertOnScreen(View origin, View view) { throw new RuntimeException("Stub!"); }
/*  6 */   public static void assertOffScreenBelow(View origin, View view) { throw new RuntimeException("Stub!"); }
/*  7 */   public static void assertOffScreenAbove(View origin, View view) { throw new RuntimeException("Stub!"); }
/*  8 */   public static void assertHasScreenCoordinates(View origin, View view, int x, int y) { throw new RuntimeException("Stub!"); }
/*  9 */   public static void assertBaselineAligned(View first, View second) { throw new RuntimeException("Stub!"); }
/* 10 */   public static void assertRightAligned(View first, View second) { throw new RuntimeException("Stub!"); }
/* 11 */   public static void assertRightAligned(View first, View second, int margin) { throw new RuntimeException("Stub!"); }
/* 12 */   public static void assertLeftAligned(View first, View second) { throw new RuntimeException("Stub!"); }
/* 13 */   public static void assertLeftAligned(View first, View second, int margin) { throw new RuntimeException("Stub!"); }
/* 14 */   public static void assertBottomAligned(View first, View second) { throw new RuntimeException("Stub!"); }
/* 15 */   public static void assertBottomAligned(View first, View second, int margin) { throw new RuntimeException("Stub!"); }
/* 16 */   public static void assertTopAligned(View first, View second) { throw new RuntimeException("Stub!"); }
/* 17 */   public static void assertTopAligned(View first, View second, int margin) { throw new RuntimeException("Stub!"); }
/* 18 */   public static void assertHorizontalCenterAligned(View reference, View test) { throw new RuntimeException("Stub!"); }
/* 19 */   public static void assertVerticalCenterAligned(View reference, View test) { throw new RuntimeException("Stub!"); }
/* 20 */   public static void assertGroupIntegrity(android.view.ViewGroup parent) { throw new RuntimeException("Stub!"); }
/* 21 */   public static void assertGroupContains(android.view.ViewGroup parent, View child) { throw new RuntimeException("Stub!"); }
/* 22 */   public static void assertGroupNotContains(android.view.ViewGroup parent, View child) { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\test\ViewAsserts.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */