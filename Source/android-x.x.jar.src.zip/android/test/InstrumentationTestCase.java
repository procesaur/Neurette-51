/*    */ package android.test;
/*    */ 
/*    */ import android.app.Instrumentation;
/*    */ 
/*  5 */ public class InstrumentationTestCase extends junit.framework.TestCase { public InstrumentationTestCase() { throw new RuntimeException("Stub!"); }
/*  6 */   public void injectInstrumentation(Instrumentation instrumentation) { throw new RuntimeException("Stub!"); }
/*  7 */   public void injectInsrumentation(Instrumentation instrumentation) { throw new RuntimeException("Stub!"); }
/*  8 */   public Instrumentation getInstrumentation() { throw new RuntimeException("Stub!"); }
/*  9 */   public final <T extends android.app.Activity> T launchActivity(String pkg, Class<T> activityCls, android.os.Bundle extras) { throw new RuntimeException("Stub!"); }
/* 10 */   public final <T extends android.app.Activity> T launchActivityWithIntent(String pkg, Class<T> activityCls, android.content.Intent intent) { throw new RuntimeException("Stub!"); }
/* 11 */   public void runTestOnUiThread(Runnable r) throws Throwable { throw new RuntimeException("Stub!"); }
/* 12 */   protected void runTest() throws Throwable { throw new RuntimeException("Stub!"); }
/* 13 */   public void sendKeys(String keysSequence) { throw new RuntimeException("Stub!"); }
/* 14 */   public void sendKeys(int... keys) { throw new RuntimeException("Stub!"); }
/* 15 */   public void sendRepeatedKeys(int... keys) { throw new RuntimeException("Stub!"); }
/* 16 */   protected void tearDown() throws Exception { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\test\InstrumentationTestCase.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */