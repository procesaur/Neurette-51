/*   */ package android.test;
/*   */ 
/*   */ public class ComparisonFailure
/*   */   extends AssertionFailedError {
/* 5 */   public ComparisonFailure(String message, String expected, String actual) { throw new RuntimeException("Stub!"); }
/* 6 */   public String getMessage() { throw new RuntimeException("Stub!"); }
/*   */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\test\ComparisonFailure.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */