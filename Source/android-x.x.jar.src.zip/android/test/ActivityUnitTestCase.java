/*    */ package android.test;
/*    */ 
/*    */ import android.content.Intent;
/*    */ 
/*  5 */ public abstract class ActivityUnitTestCase<T extends android.app.Activity> extends ActivityTestCase { public ActivityUnitTestCase(Class<T> activityClass) { throw new RuntimeException("Stub!"); }
/*  6 */   public T getActivity() { throw new RuntimeException("Stub!"); }
/*  7 */   protected void setUp() throws Exception { throw new RuntimeException("Stub!"); }
/*  8 */   protected T startActivity(Intent intent, android.os.Bundle savedInstanceState, Object lastNonConfigurationInstance) { throw new RuntimeException("Stub!"); }
/*  9 */   protected void tearDown() throws Exception { throw new RuntimeException("Stub!"); }
/* 10 */   public void setApplication(android.app.Application application) { throw new RuntimeException("Stub!"); }
/* 11 */   public void setActivityContext(android.content.Context activityContext) { throw new RuntimeException("Stub!"); }
/* 12 */   public int getRequestedOrientation() { throw new RuntimeException("Stub!"); }
/* 13 */   public Intent getStartedActivityIntent() { throw new RuntimeException("Stub!"); }
/* 14 */   public int getStartedActivityRequest() { throw new RuntimeException("Stub!"); }
/* 15 */   public boolean isFinishCalled() { throw new RuntimeException("Stub!"); }
/* 16 */   public int getFinishedActivityRequest() { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\test\ActivityUnitTestCase.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */