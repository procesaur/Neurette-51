/*   */ package android.test;
/*   */ 
/*   */ import android.app.Instrumentation;
/*   */ 
/* 5 */ public class InstrumentationTestSuite extends junit.framework.TestSuite { public InstrumentationTestSuite(Instrumentation instr) { throw new RuntimeException("Stub!"); }
/* 6 */   public InstrumentationTestSuite(String name, Instrumentation instr) { throw new RuntimeException("Stub!"); }
/* 7 */   public InstrumentationTestSuite(Class theClass, Instrumentation instr) { throw new RuntimeException("Stub!"); }
/* 8 */   public void addTestSuite(Class testClass) { throw new RuntimeException("Stub!"); }
/* 9 */   public void runTest(junit.framework.Test test, junit.framework.TestResult result) { throw new RuntimeException("Stub!"); }
/*   */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\test\InstrumentationTestSuite.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */