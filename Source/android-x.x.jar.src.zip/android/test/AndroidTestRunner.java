/*    */ package android.test;
/*    */ 
/*    */ import junit.framework.TestResult;
/*    */ 
/*  5 */ public class AndroidTestRunner extends junit.runner.BaseTestRunner { public AndroidTestRunner() { throw new RuntimeException("Stub!"); }
/*  6 */   public void setTestClassName(String testClassName, String testMethodName) { throw new RuntimeException("Stub!"); }
/*  7 */   public void setTest(junit.framework.Test test) { throw new RuntimeException("Stub!"); }
/*  8 */   public void clearTestListeners() { throw new RuntimeException("Stub!"); }
/*  9 */   public void addTestListener(junit.framework.TestListener testListener) { throw new RuntimeException("Stub!"); }
/* 10 */   protected TestResult createTestResult() { throw new RuntimeException("Stub!"); }
/* 11 */   public java.util.List<junit.framework.TestCase> getTestCases() { throw new RuntimeException("Stub!"); }
/* 12 */   public String getTestClassName() { throw new RuntimeException("Stub!"); }
/* 13 */   public TestResult getTestResult() { throw new RuntimeException("Stub!"); }
/* 14 */   public void runTest() { throw new RuntimeException("Stub!"); }
/* 15 */   public void runTest(TestResult testResult) { throw new RuntimeException("Stub!"); }
/* 16 */   public void setContext(android.content.Context context) { throw new RuntimeException("Stub!"); }
/* 17 */   public void setInstrumentation(android.app.Instrumentation instrumentation) { throw new RuntimeException("Stub!"); }
/* 18 */   public void setInstrumentaiton(android.app.Instrumentation instrumentation) { throw new RuntimeException("Stub!"); }
/* 19 */   protected Class loadSuiteClass(String suiteClassName) throws ClassNotFoundException { throw new RuntimeException("Stub!"); }
/* 20 */   public void testStarted(String testName) { throw new RuntimeException("Stub!"); }
/* 21 */   public void testEnded(String testName) { throw new RuntimeException("Stub!"); }
/* 22 */   public void testFailed(int status, junit.framework.Test test, Throwable t) { throw new RuntimeException("Stub!"); }
/* 23 */   protected void runFailed(String message) { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\test\AndroidTestRunner.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */