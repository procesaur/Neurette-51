/*    */ package android.test;
/*    */ 
/*    */ import android.content.Intent;
/*    */ 
/*  5 */ public abstract class ServiceTestCase<T extends android.app.Service> extends AndroidTestCase { public ServiceTestCase(Class<T> serviceClass) { throw new RuntimeException("Stub!"); }
/*  6 */   public T getService() { throw new RuntimeException("Stub!"); }
/*  7 */   protected void setUp() throws Exception { throw new RuntimeException("Stub!"); }
/*  8 */   protected void setupService() { throw new RuntimeException("Stub!"); }
/*  9 */   protected void startService(Intent intent) { throw new RuntimeException("Stub!"); }
/* 10 */   protected android.os.IBinder bindService(Intent intent) { throw new RuntimeException("Stub!"); }
/* 11 */   protected void shutdownService() { throw new RuntimeException("Stub!"); }
/* 12 */   protected void tearDown() throws Exception { throw new RuntimeException("Stub!"); }
/* 13 */   public void setApplication(android.app.Application application) { throw new RuntimeException("Stub!"); }
/* 14 */   public android.app.Application getApplication() { throw new RuntimeException("Stub!"); }
/* 15 */   public android.content.Context getSystemContext() { throw new RuntimeException("Stub!"); }
/* 16 */   public void testServiceTestCaseSetUpProperly() throws Exception { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\test\ServiceTestCase.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */