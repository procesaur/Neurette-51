/*    */ package android.test;
/*    */ 
/*    */ import android.content.Context;
/*    */ 
/*  5 */ public class RenamingDelegatingContext extends android.content.ContextWrapper { public RenamingDelegatingContext(Context context, String filePrefix) { super((Context)null);throw new RuntimeException("Stub!"); }
/*  6 */   public RenamingDelegatingContext(Context context, Context fileContext, String filePrefix) { super((Context)null);throw new RuntimeException("Stub!"); }
/*  7 */   public static <T extends android.content.ContentProvider> T providerWithRenamedContext(Class<T> contentProvider, Context c, String filePrefix) throws IllegalAccessException, InstantiationException { throw new RuntimeException("Stub!"); }
/*  8 */   public static <T extends android.content.ContentProvider> T providerWithRenamedContext(Class<T> contentProvider, Context c, String filePrefix, boolean allowAccessToExistingFilesAndDbs) throws IllegalAccessException, InstantiationException { throw new RuntimeException("Stub!"); }
/*  9 */   public void makeExistingFilesAndDbsAccessible() { throw new RuntimeException("Stub!"); }
/* 10 */   public String getDatabasePrefix() { throw new RuntimeException("Stub!"); }
/* 11 */   public android.database.sqlite.SQLiteDatabase openOrCreateDatabase(String name, int mode, android.database.sqlite.SQLiteDatabase.CursorFactory factory) { throw new RuntimeException("Stub!"); }
/* 12 */   public boolean deleteDatabase(String name) { throw new RuntimeException("Stub!"); }
/* 13 */   public java.io.File getDatabasePath(String name) { throw new RuntimeException("Stub!"); }
/* 14 */   public String[] databaseList() { throw new RuntimeException("Stub!"); }
/* 15 */   public java.io.FileInputStream openFileInput(String name) throws java.io.FileNotFoundException { throw new RuntimeException("Stub!"); }
/* 16 */   public java.io.FileOutputStream openFileOutput(String name, int mode) throws java.io.FileNotFoundException { throw new RuntimeException("Stub!"); }
/* 17 */   public java.io.File getFileStreamPath(String name) { throw new RuntimeException("Stub!"); }
/* 18 */   public boolean deleteFile(String name) { throw new RuntimeException("Stub!"); }
/* 19 */   public String[] fileList() { throw new RuntimeException("Stub!"); }
/* 20 */   public java.io.File getCacheDir() { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\test\RenamingDelegatingContext.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */