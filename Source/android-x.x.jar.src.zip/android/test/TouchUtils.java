/*    */ package android.test;
/*    */ import android.view.View;
/*    */ 
/*  4 */ public class TouchUtils { public TouchUtils() { throw new RuntimeException("Stub!"); }
/*  5 */   public static void dragQuarterScreenDown(ActivityInstrumentationTestCase test) { throw new RuntimeException("Stub!"); }
/*  6 */   public static void dragQuarterScreenDown(InstrumentationTestCase test, android.app.Activity activity) { throw new RuntimeException("Stub!"); }
/*  7 */   public static void dragQuarterScreenUp(ActivityInstrumentationTestCase test) { throw new RuntimeException("Stub!"); }
/*  8 */   public static void dragQuarterScreenUp(InstrumentationTestCase test, android.app.Activity activity) { throw new RuntimeException("Stub!"); }
/*  9 */   public static void scrollToBottom(ActivityInstrumentationTestCase test, android.view.ViewGroup v) { throw new RuntimeException("Stub!"); }
/* 10 */   public static void scrollToBottom(InstrumentationTestCase test, android.app.Activity activity, android.view.ViewGroup v) { throw new RuntimeException("Stub!"); }
/* 11 */   public static void scrollToTop(ActivityInstrumentationTestCase test, android.view.ViewGroup v) { throw new RuntimeException("Stub!"); }
/* 12 */   public static void scrollToTop(InstrumentationTestCase test, android.app.Activity activity, android.view.ViewGroup v) { throw new RuntimeException("Stub!"); }
/* 13 */   public static void dragViewToBottom(ActivityInstrumentationTestCase test, View v) { throw new RuntimeException("Stub!"); }
/* 14 */   public static void dragViewToBottom(InstrumentationTestCase test, android.app.Activity activity, View v) { throw new RuntimeException("Stub!"); }
/* 15 */   public static void dragViewToBottom(ActivityInstrumentationTestCase test, View v, int stepCount) { throw new RuntimeException("Stub!"); }
/* 16 */   public static void dragViewToBottom(InstrumentationTestCase test, android.app.Activity activity, View v, int stepCount) { throw new RuntimeException("Stub!"); }
/* 17 */   public static void tapView(InstrumentationTestCase test, View v) { throw new RuntimeException("Stub!"); }
/* 18 */   public static void touchAndCancelView(InstrumentationTestCase test, View v) { throw new RuntimeException("Stub!"); }
/* 19 */   public static void clickView(InstrumentationTestCase test, View v) { throw new RuntimeException("Stub!"); }
/* 20 */   public static void longClickView(ActivityInstrumentationTestCase test, View v) { throw new RuntimeException("Stub!"); }
/* 21 */   public static void longClickView(InstrumentationTestCase test, View v) { throw new RuntimeException("Stub!"); }
/* 22 */   public static void dragViewToTop(ActivityInstrumentationTestCase test, View v) { throw new RuntimeException("Stub!"); }
/* 23 */   public static void dragViewToTop(ActivityInstrumentationTestCase test, View v, int stepCount) { throw new RuntimeException("Stub!"); }
/* 24 */   public static void dragViewToTop(InstrumentationTestCase test, View v) { throw new RuntimeException("Stub!"); }
/* 25 */   public static void dragViewToTop(InstrumentationTestCase test, View v, int stepCount) { throw new RuntimeException("Stub!"); }
/* 26 */   public static int dragViewBy(ActivityInstrumentationTestCase test, View v, int gravity, int deltaX, int deltaY) { throw new RuntimeException("Stub!"); }
/* 27 */   public static int dragViewBy(InstrumentationTestCase test, View v, int gravity, int deltaX, int deltaY) { throw new RuntimeException("Stub!"); }
/* 28 */   public static int dragViewTo(ActivityInstrumentationTestCase test, View v, int gravity, int toX, int toY) { throw new RuntimeException("Stub!"); }
/* 29 */   public static int dragViewTo(InstrumentationTestCase test, View v, int gravity, int toX, int toY) { throw new RuntimeException("Stub!"); }
/* 30 */   public static int dragViewToX(ActivityInstrumentationTestCase test, View v, int gravity, int toX) { throw new RuntimeException("Stub!"); }
/* 31 */   public static int dragViewToX(InstrumentationTestCase test, View v, int gravity, int toX) { throw new RuntimeException("Stub!"); }
/* 32 */   public static int dragViewToY(ActivityInstrumentationTestCase test, View v, int gravity, int toY) { throw new RuntimeException("Stub!"); }
/* 33 */   public static int dragViewToY(InstrumentationTestCase test, View v, int gravity, int toY) { throw new RuntimeException("Stub!"); }
/* 34 */   public static void drag(ActivityInstrumentationTestCase test, float fromX, float toX, float fromY, float toY, int stepCount) { throw new RuntimeException("Stub!"); }
/* 35 */   public static void drag(InstrumentationTestCase test, float fromX, float toX, float fromY, float toY, int stepCount) { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\test\TouchUtils.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */