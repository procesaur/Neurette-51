package android.test;

import junit.framework.TestSuite;

public abstract interface TestSuiteProvider
{
  public abstract TestSuite getTestSuite();
}


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\test\TestSuiteProvider.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */