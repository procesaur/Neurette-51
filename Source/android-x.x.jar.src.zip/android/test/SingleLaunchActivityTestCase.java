/*   */ package android.test;
/*   */ 
/*   */ import android.app.Activity;
/*   */ 
/* 5 */ public abstract class SingleLaunchActivityTestCase<T extends Activity> extends InstrumentationTestCase { public SingleLaunchActivityTestCase(String pkg, Class<T> activityClass) { throw new RuntimeException("Stub!"); }
/* 6 */   public T getActivity() { throw new RuntimeException("Stub!"); }
/* 7 */   protected void setUp() throws Exception { throw new RuntimeException("Stub!"); }
/* 8 */   protected void tearDown() throws Exception { throw new RuntimeException("Stub!"); }
/* 9 */   public void testActivityTestCaseSetUpProperly() throws Exception { throw new RuntimeException("Stub!"); }
/*   */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\test\SingleLaunchActivityTestCase.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */