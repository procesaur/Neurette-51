/*   */ package android.test;
/*   */ 
/*   */ import android.net.Uri;
/*   */ 
/* 5 */ public class SyncBaseInstrumentation extends InstrumentationTestCase { public SyncBaseInstrumentation() { throw new RuntimeException("Stub!"); }
/* 6 */   protected void setUp() throws Exception { throw new RuntimeException("Stub!"); }
/* 7 */   protected void syncProvider(Uri uri, String accountName, String authority) throws Exception { throw new RuntimeException("Stub!"); }
/* 8 */   protected void cancelSyncsandDisableAutoSync() { throw new RuntimeException("Stub!"); }
/*   */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\test\SyncBaseInstrumentation.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */