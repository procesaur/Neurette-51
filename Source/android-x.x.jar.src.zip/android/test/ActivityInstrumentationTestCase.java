/*    */ package android.test;
/*    */ 
/*    */ import android.app.Activity;
/*    */ 
/*    */ @Deprecated
/*  6 */ public abstract class ActivityInstrumentationTestCase<T extends Activity> extends ActivityTestCase { public ActivityInstrumentationTestCase(String pkg, Class<T> activityClass) { throw new RuntimeException("Stub!"); }
/*  7 */   public ActivityInstrumentationTestCase(String pkg, Class<T> activityClass, boolean initialTouchMode) { throw new RuntimeException("Stub!"); }
/*  8 */   public T getActivity() { throw new RuntimeException("Stub!"); }
/*  9 */   protected void setUp() throws Exception { throw new RuntimeException("Stub!"); }
/* 10 */   protected void tearDown() throws Exception { throw new RuntimeException("Stub!"); }
/* 11 */   public void testActivityTestCaseSetUpProperly() throws Exception { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\test\ActivityInstrumentationTestCase.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */