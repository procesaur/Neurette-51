/*   */ package android.test;
/*   */ 
/*   */ public class AssertionFailedError
/*   */   extends Error {
/* 5 */   public AssertionFailedError() { throw new RuntimeException("Stub!"); }
/* 6 */   public AssertionFailedError(String errorMessage) { throw new RuntimeException("Stub!"); }
/*   */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\test\AssertionFailedError.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */