/*    */ package android.test;
/*    */ 
/*    */ import android.content.Context;
/*    */ 
/*  5 */ public abstract class ApplicationTestCase<T extends android.app.Application> extends AndroidTestCase { public ApplicationTestCase(Class<T> applicationClass) { throw new RuntimeException("Stub!"); }
/*  6 */   public T getApplication() { throw new RuntimeException("Stub!"); }
/*  7 */   protected void setUp() throws Exception { throw new RuntimeException("Stub!"); }
/*  8 */   protected final void createApplication() { throw new RuntimeException("Stub!"); }
/*  9 */   protected final void terminateApplication() { throw new RuntimeException("Stub!"); }
/* 10 */   protected void tearDown() throws Exception { throw new RuntimeException("Stub!"); }
/* 11 */   public Context getSystemContext() { throw new RuntimeException("Stub!"); }
/* 12 */   public final void testApplicationTestCaseSetUpProperly() throws Exception { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\test\ApplicationTestCase.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */