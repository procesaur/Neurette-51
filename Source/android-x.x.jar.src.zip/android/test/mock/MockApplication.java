/*   */ package android.test.mock;
/*   */ 
/*   */ import android.content.res.Configuration;
/*   */ 
/* 5 */ public class MockApplication extends android.app.Application { public MockApplication() { throw new RuntimeException("Stub!"); }
/* 6 */   public void onCreate() { throw new RuntimeException("Stub!"); }
/* 7 */   public void onTerminate() { throw new RuntimeException("Stub!"); }
/* 8 */   public void onConfigurationChanged(Configuration newConfig) { throw new RuntimeException("Stub!"); }
/*   */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\test\mock\MockApplication.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */