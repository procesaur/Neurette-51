/*   */ package android.test.mock;
/*   */ 
/*   */ import android.content.ContentProvider;
/*   */ 
/* 5 */ public class MockContentResolver extends android.content.ContentResolver { public MockContentResolver() { super((android.content.Context)null);throw new RuntimeException("Stub!"); }
/* 6 */   public void addProvider(String name, ContentProvider provider) { throw new RuntimeException("Stub!"); }
/* 7 */   public void notifyChange(android.net.Uri uri, android.database.ContentObserver observer, boolean syncToNetwork) { throw new RuntimeException("Stub!"); }
/*   */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\test\mock\MockContentResolver.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */