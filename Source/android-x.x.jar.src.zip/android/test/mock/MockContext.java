/*    */ package android.test.mock;
/*    */ 
/*    */ import android.content.Intent;
/*    */ 
/*  5 */ public class MockContext extends android.content.Context { public MockContext() { throw new RuntimeException("Stub!"); }
/*  6 */   public android.content.res.AssetManager getAssets() { throw new RuntimeException("Stub!"); }
/*  7 */   public android.content.res.Resources getResources() { throw new RuntimeException("Stub!"); }
/*  8 */   public android.content.pm.PackageManager getPackageManager() { throw new RuntimeException("Stub!"); }
/*  9 */   public android.content.ContentResolver getContentResolver() { throw new RuntimeException("Stub!"); }
/* 10 */   public android.os.Looper getMainLooper() { throw new RuntimeException("Stub!"); }
/* 11 */   public android.content.Context getApplicationContext() { throw new RuntimeException("Stub!"); }
/* 12 */   public void setTheme(int resid) { throw new RuntimeException("Stub!"); }
/* 13 */   public android.content.res.Resources.Theme getTheme() { throw new RuntimeException("Stub!"); }
/* 14 */   public ClassLoader getClassLoader() { throw new RuntimeException("Stub!"); }
/* 15 */   public String getPackageName() { throw new RuntimeException("Stub!"); }
/* 16 */   public android.content.pm.ApplicationInfo getApplicationInfo() { throw new RuntimeException("Stub!"); }
/* 17 */   public String getPackageResourcePath() { throw new RuntimeException("Stub!"); }
/* 18 */   public String getPackageCodePath() { throw new RuntimeException("Stub!"); }
/* 19 */   public android.content.SharedPreferences getSharedPreferences(String name, int mode) { throw new RuntimeException("Stub!"); }
/* 20 */   public java.io.FileInputStream openFileInput(String name) throws java.io.FileNotFoundException { throw new RuntimeException("Stub!"); }
/* 21 */   public java.io.FileOutputStream openFileOutput(String name, int mode) throws java.io.FileNotFoundException { throw new RuntimeException("Stub!"); }
/* 22 */   public boolean deleteFile(String name) { throw new RuntimeException("Stub!"); }
/* 23 */   public java.io.File getFileStreamPath(String name) { throw new RuntimeException("Stub!"); }
/* 24 */   public String[] fileList() { throw new RuntimeException("Stub!"); }
/* 25 */   public java.io.File getFilesDir() { throw new RuntimeException("Stub!"); }
/* 26 */   public java.io.File getCacheDir() { throw new RuntimeException("Stub!"); }
/* 27 */   public java.io.File getDir(String name, int mode) { throw new RuntimeException("Stub!"); }
/* 28 */   public android.database.sqlite.SQLiteDatabase openOrCreateDatabase(String file, int mode, android.database.sqlite.SQLiteDatabase.CursorFactory factory) { throw new RuntimeException("Stub!"); }
/* 29 */   public java.io.File getDatabasePath(String name) { throw new RuntimeException("Stub!"); }
/* 30 */   public String[] databaseList() { throw new RuntimeException("Stub!"); }
/* 31 */   public boolean deleteDatabase(String name) { throw new RuntimeException("Stub!"); }
/* 32 */   public android.graphics.drawable.Drawable getWallpaper() { throw new RuntimeException("Stub!"); }
/* 33 */   public android.graphics.drawable.Drawable peekWallpaper() { throw new RuntimeException("Stub!"); }
/* 34 */   public int getWallpaperDesiredMinimumWidth() { throw new RuntimeException("Stub!"); }
/* 35 */   public int getWallpaperDesiredMinimumHeight() { throw new RuntimeException("Stub!"); }
/* 36 */   public void setWallpaper(android.graphics.Bitmap bitmap) throws java.io.IOException { throw new RuntimeException("Stub!"); }
/* 37 */   public void setWallpaper(java.io.InputStream data) throws java.io.IOException { throw new RuntimeException("Stub!"); }
/* 38 */   public void clearWallpaper() { throw new RuntimeException("Stub!"); }
/* 39 */   public void startActivity(Intent intent) { throw new RuntimeException("Stub!"); }
/* 40 */   public void startIntentSender(android.content.IntentSender intent, Intent fillInIntent, int flagsMask, int flagsValues, int extraFlags) throws android.content.IntentSender.SendIntentException { throw new RuntimeException("Stub!"); }
/* 41 */   public void sendBroadcast(Intent intent) { throw new RuntimeException("Stub!"); }
/* 42 */   public void sendBroadcast(Intent intent, String receiverPermission) { throw new RuntimeException("Stub!"); }
/* 43 */   public void sendOrderedBroadcast(Intent intent, String receiverPermission) { throw new RuntimeException("Stub!"); }
/* 44 */   public void sendOrderedBroadcast(Intent intent, String receiverPermission, android.content.BroadcastReceiver resultReceiver, android.os.Handler scheduler, int initialCode, String initialData, android.os.Bundle initialExtras) { throw new RuntimeException("Stub!"); }
/* 45 */   public void sendStickyBroadcast(Intent intent) { throw new RuntimeException("Stub!"); }
/* 46 */   public void sendStickyOrderedBroadcast(Intent intent, android.content.BroadcastReceiver resultReceiver, android.os.Handler scheduler, int initialCode, String initialData, android.os.Bundle initialExtras) { throw new RuntimeException("Stub!"); }
/* 47 */   public void removeStickyBroadcast(Intent intent) { throw new RuntimeException("Stub!"); }
/* 48 */   public Intent registerReceiver(android.content.BroadcastReceiver receiver, android.content.IntentFilter filter) { throw new RuntimeException("Stub!"); }
/* 49 */   public Intent registerReceiver(android.content.BroadcastReceiver receiver, android.content.IntentFilter filter, String broadcastPermission, android.os.Handler scheduler) { throw new RuntimeException("Stub!"); }
/* 50 */   public void unregisterReceiver(android.content.BroadcastReceiver receiver) { throw new RuntimeException("Stub!"); }
/* 51 */   public android.content.ComponentName startService(Intent service) { throw new RuntimeException("Stub!"); }
/* 52 */   public boolean stopService(Intent service) { throw new RuntimeException("Stub!"); }
/* 53 */   public boolean bindService(Intent service, android.content.ServiceConnection conn, int flags) { throw new RuntimeException("Stub!"); }
/* 54 */   public void unbindService(android.content.ServiceConnection conn) { throw new RuntimeException("Stub!"); }
/* 55 */   public boolean startInstrumentation(android.content.ComponentName className, String profileFile, android.os.Bundle arguments) { throw new RuntimeException("Stub!"); }
/* 56 */   public Object getSystemService(String name) { throw new RuntimeException("Stub!"); }
/* 57 */   public int checkPermission(String permission, int pid, int uid) { throw new RuntimeException("Stub!"); }
/* 58 */   public int checkCallingPermission(String permission) { throw new RuntimeException("Stub!"); }
/* 59 */   public int checkCallingOrSelfPermission(String permission) { throw new RuntimeException("Stub!"); }
/* 60 */   public void enforcePermission(String permission, int pid, int uid, String message) { throw new RuntimeException("Stub!"); }
/* 61 */   public void enforceCallingPermission(String permission, String message) { throw new RuntimeException("Stub!"); }
/* 62 */   public void enforceCallingOrSelfPermission(String permission, String message) { throw new RuntimeException("Stub!"); }
/* 63 */   public void grantUriPermission(String toPackage, android.net.Uri uri, int modeFlags) { throw new RuntimeException("Stub!"); }
/* 64 */   public void revokeUriPermission(android.net.Uri uri, int modeFlags) { throw new RuntimeException("Stub!"); }
/* 65 */   public int checkUriPermission(android.net.Uri uri, int pid, int uid, int modeFlags) { throw new RuntimeException("Stub!"); }
/* 66 */   public int checkCallingUriPermission(android.net.Uri uri, int modeFlags) { throw new RuntimeException("Stub!"); }
/* 67 */   public int checkCallingOrSelfUriPermission(android.net.Uri uri, int modeFlags) { throw new RuntimeException("Stub!"); }
/* 68 */   public int checkUriPermission(android.net.Uri uri, String readPermission, String writePermission, int pid, int uid, int modeFlags) { throw new RuntimeException("Stub!"); }
/* 69 */   public void enforceUriPermission(android.net.Uri uri, int pid, int uid, int modeFlags, String message) { throw new RuntimeException("Stub!"); }
/* 70 */   public void enforceCallingUriPermission(android.net.Uri uri, int modeFlags, String message) { throw new RuntimeException("Stub!"); }
/* 71 */   public void enforceCallingOrSelfUriPermission(android.net.Uri uri, int modeFlags, String message) { throw new RuntimeException("Stub!"); }
/* 72 */   public void enforceUriPermission(android.net.Uri uri, String readPermission, String writePermission, int pid, int uid, int modeFlags, String message) { throw new RuntimeException("Stub!"); }
/* 73 */   public android.content.Context createPackageContext(String packageName, int flags) throws android.content.pm.PackageManager.NameNotFoundException { throw new RuntimeException("Stub!"); }
/* 74 */   public boolean isRestricted() { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\test\mock\MockContext.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */