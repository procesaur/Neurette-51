/*   */ package android.test.mock;
/*   */ 
/*   */ import android.content.DialogInterface;
/*   */ 
/* 5 */ public class MockDialogInterface implements DialogInterface { public MockDialogInterface() { throw new RuntimeException("Stub!"); }
/* 6 */   public void cancel() { throw new RuntimeException("Stub!"); }
/* 7 */   public void dismiss() { throw new RuntimeException("Stub!"); }
/*   */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\test\mock\MockDialogInterface.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */