/*    */ package android.test.mock;
/*    */ 
/*    */ import android.content.ComponentName;
/*    */ 
/*  5 */ public class MockPackageManager extends android.content.pm.PackageManager { public MockPackageManager() { throw new RuntimeException("Stub!"); }
/*  6 */   public android.content.pm.PackageInfo getPackageInfo(String packageName, int flags) throws android.content.pm.PackageManager.NameNotFoundException { throw new RuntimeException("Stub!"); }
/*  7 */   public android.content.Intent getLaunchIntentForPackage(String packageName) { throw new RuntimeException("Stub!"); }
/*  8 */   public int[] getPackageGids(String packageName) throws android.content.pm.PackageManager.NameNotFoundException { throw new RuntimeException("Stub!"); }
/*  9 */   public android.content.pm.PermissionInfo getPermissionInfo(String name, int flags) throws android.content.pm.PackageManager.NameNotFoundException { throw new RuntimeException("Stub!"); }
/* 10 */   public java.util.List<android.content.pm.PermissionInfo> queryPermissionsByGroup(String group, int flags) throws android.content.pm.PackageManager.NameNotFoundException { throw new RuntimeException("Stub!"); }
/* 11 */   public android.content.pm.PermissionGroupInfo getPermissionGroupInfo(String name, int flags) throws android.content.pm.PackageManager.NameNotFoundException { throw new RuntimeException("Stub!"); }
/* 12 */   public java.util.List<android.content.pm.PermissionGroupInfo> getAllPermissionGroups(int flags) { throw new RuntimeException("Stub!"); }
/* 13 */   public android.content.pm.ApplicationInfo getApplicationInfo(String packageName, int flags) throws android.content.pm.PackageManager.NameNotFoundException { throw new RuntimeException("Stub!"); }
/* 14 */   public android.content.pm.ActivityInfo getActivityInfo(ComponentName className, int flags) throws android.content.pm.PackageManager.NameNotFoundException { throw new RuntimeException("Stub!"); }
/* 15 */   public android.content.pm.ActivityInfo getReceiverInfo(ComponentName className, int flags) throws android.content.pm.PackageManager.NameNotFoundException { throw new RuntimeException("Stub!"); }
/* 16 */   public android.content.pm.ServiceInfo getServiceInfo(ComponentName className, int flags) throws android.content.pm.PackageManager.NameNotFoundException { throw new RuntimeException("Stub!"); }
/* 17 */   public java.util.List<android.content.pm.PackageInfo> getInstalledPackages(int flags) { throw new RuntimeException("Stub!"); }
/* 18 */   public int checkPermission(String permName, String pkgName) { throw new RuntimeException("Stub!"); }
/* 19 */   public boolean addPermission(android.content.pm.PermissionInfo info) { throw new RuntimeException("Stub!"); }
/* 20 */   public void removePermission(String name) { throw new RuntimeException("Stub!"); }
/* 21 */   public int checkSignatures(String pkg1, String pkg2) { throw new RuntimeException("Stub!"); }
/* 22 */   public int checkSignatures(int uid1, int uid2) { throw new RuntimeException("Stub!"); }
/* 23 */   public String[] getPackagesForUid(int uid) { throw new RuntimeException("Stub!"); }
/* 24 */   public String getNameForUid(int uid) { throw new RuntimeException("Stub!"); }
/* 25 */   public java.util.List<android.content.pm.ApplicationInfo> getInstalledApplications(int flags) { throw new RuntimeException("Stub!"); }
/* 26 */   public android.content.pm.ResolveInfo resolveActivity(android.content.Intent intent, int flags) { throw new RuntimeException("Stub!"); }
/* 27 */   public java.util.List<android.content.pm.ResolveInfo> queryIntentActivities(android.content.Intent intent, int flags) { throw new RuntimeException("Stub!"); }
/* 28 */   public java.util.List<android.content.pm.ResolveInfo> queryIntentActivityOptions(ComponentName caller, android.content.Intent[] specifics, android.content.Intent intent, int flags) { throw new RuntimeException("Stub!"); }
/* 29 */   public java.util.List<android.content.pm.ResolveInfo> queryBroadcastReceivers(android.content.Intent intent, int flags) { throw new RuntimeException("Stub!"); }
/* 30 */   public android.content.pm.ResolveInfo resolveService(android.content.Intent intent, int flags) { throw new RuntimeException("Stub!"); }
/* 31 */   public java.util.List<android.content.pm.ResolveInfo> queryIntentServices(android.content.Intent intent, int flags) { throw new RuntimeException("Stub!"); }
/* 32 */   public android.content.pm.ProviderInfo resolveContentProvider(String name, int flags) { throw new RuntimeException("Stub!"); }
/* 33 */   public java.util.List<android.content.pm.ProviderInfo> queryContentProviders(String processName, int uid, int flags) { throw new RuntimeException("Stub!"); }
/* 34 */   public android.content.pm.InstrumentationInfo getInstrumentationInfo(ComponentName className, int flags) throws android.content.pm.PackageManager.NameNotFoundException { throw new RuntimeException("Stub!"); }
/* 35 */   public java.util.List<android.content.pm.InstrumentationInfo> queryInstrumentation(String targetPackage, int flags) { throw new RuntimeException("Stub!"); }
/* 36 */   public android.graphics.drawable.Drawable getDrawable(String packageName, int resid, android.content.pm.ApplicationInfo appInfo) { throw new RuntimeException("Stub!"); }
/* 37 */   public android.graphics.drawable.Drawable getActivityIcon(ComponentName activityName) throws android.content.pm.PackageManager.NameNotFoundException { throw new RuntimeException("Stub!"); }
/* 38 */   public android.graphics.drawable.Drawable getActivityIcon(android.content.Intent intent) throws android.content.pm.PackageManager.NameNotFoundException { throw new RuntimeException("Stub!"); }
/* 39 */   public android.graphics.drawable.Drawable getDefaultActivityIcon() { throw new RuntimeException("Stub!"); }
/* 40 */   public android.graphics.drawable.Drawable getApplicationIcon(android.content.pm.ApplicationInfo info) { throw new RuntimeException("Stub!"); }
/* 41 */   public android.graphics.drawable.Drawable getApplicationIcon(String packageName) throws android.content.pm.PackageManager.NameNotFoundException { throw new RuntimeException("Stub!"); }
/* 42 */   public CharSequence getText(String packageName, int resid, android.content.pm.ApplicationInfo appInfo) { throw new RuntimeException("Stub!"); }
/* 43 */   public android.content.res.XmlResourceParser getXml(String packageName, int resid, android.content.pm.ApplicationInfo appInfo) { throw new RuntimeException("Stub!"); }
/* 44 */   public CharSequence getApplicationLabel(android.content.pm.ApplicationInfo info) { throw new RuntimeException("Stub!"); }
/* 45 */   public android.content.res.Resources getResourcesForActivity(ComponentName activityName) throws android.content.pm.PackageManager.NameNotFoundException { throw new RuntimeException("Stub!"); }
/* 46 */   public android.content.res.Resources getResourcesForApplication(android.content.pm.ApplicationInfo app) { throw new RuntimeException("Stub!"); }
/* 47 */   public android.content.res.Resources getResourcesForApplication(String appPackageName) throws android.content.pm.PackageManager.NameNotFoundException { throw new RuntimeException("Stub!"); }
/* 48 */   public android.content.pm.PackageInfo getPackageArchiveInfo(String archiveFilePath, int flags) { throw new RuntimeException("Stub!"); }
/* 49 */   public String getInstallerPackageName(String packageName) { throw new RuntimeException("Stub!"); }
/* 50 */   public void addPackageToPreferred(String packageName) { throw new RuntimeException("Stub!"); }
/* 51 */   public void removePackageFromPreferred(String packageName) { throw new RuntimeException("Stub!"); }
/* 52 */   public java.util.List<android.content.pm.PackageInfo> getPreferredPackages(int flags) { throw new RuntimeException("Stub!"); }
/* 53 */   public void setComponentEnabledSetting(ComponentName componentName, int newState, int flags) { throw new RuntimeException("Stub!"); }
/* 54 */   public int getComponentEnabledSetting(ComponentName componentName) { throw new RuntimeException("Stub!"); }
/* 55 */   public void setApplicationEnabledSetting(String packageName, int newState, int flags) { throw new RuntimeException("Stub!"); }
/* 56 */   public int getApplicationEnabledSetting(String packageName) { throw new RuntimeException("Stub!"); }
/* 57 */   public void addPreferredActivity(android.content.IntentFilter filter, int match, ComponentName[] set, ComponentName activity) { throw new RuntimeException("Stub!"); }
/* 58 */   public void clearPackagePreferredActivities(String packageName) { throw new RuntimeException("Stub!"); }
/* 59 */   public int getPreferredActivities(java.util.List<android.content.IntentFilter> outFilters, java.util.List<ComponentName> outActivities, String packageName) { throw new RuntimeException("Stub!"); }
/* 60 */   public String[] getSystemSharedLibraryNames() { throw new RuntimeException("Stub!"); }
/* 61 */   public android.content.pm.FeatureInfo[] getSystemAvailableFeatures() { throw new RuntimeException("Stub!"); }
/* 62 */   public boolean hasSystemFeature(String name) { throw new RuntimeException("Stub!"); }
/* 63 */   public boolean isSafeMode() { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\test\mock\MockPackageManager.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */