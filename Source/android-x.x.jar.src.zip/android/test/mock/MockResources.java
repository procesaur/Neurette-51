/*    */ package android.test.mock;
/*    */ 
/*    */ import android.content.res.Resources.NotFoundException;
/*    */ 
/*  5 */ public class MockResources extends android.content.res.Resources { public MockResources() { super((android.content.res.AssetManager)null, (android.util.DisplayMetrics)null, (android.content.res.Configuration)null);throw new RuntimeException("Stub!"); }
/*  6 */   public void updateConfiguration(android.content.res.Configuration config, android.util.DisplayMetrics metrics) { throw new RuntimeException("Stub!"); }
/*  7 */   public CharSequence getText(int id) throws Resources.NotFoundException { throw new RuntimeException("Stub!"); }
/*  8 */   public CharSequence getQuantityText(int id, int quantity) throws Resources.NotFoundException { throw new RuntimeException("Stub!"); }
/*  9 */   public String getString(int id) throws Resources.NotFoundException { throw new RuntimeException("Stub!"); }
/* 10 */   public String getString(int id, Object... formatArgs) throws Resources.NotFoundException { throw new RuntimeException("Stub!"); }
/* 11 */   public String getQuantityString(int id, int quantity, Object... formatArgs) throws Resources.NotFoundException { throw new RuntimeException("Stub!"); }
/* 12 */   public String getQuantityString(int id, int quantity) throws Resources.NotFoundException { throw new RuntimeException("Stub!"); }
/* 13 */   public CharSequence getText(int id, CharSequence def) { throw new RuntimeException("Stub!"); }
/* 14 */   public CharSequence[] getTextArray(int id) throws Resources.NotFoundException { throw new RuntimeException("Stub!"); }
/* 15 */   public String[] getStringArray(int id) throws Resources.NotFoundException { throw new RuntimeException("Stub!"); }
/* 16 */   public int[] getIntArray(int id) throws Resources.NotFoundException { throw new RuntimeException("Stub!"); }
/* 17 */   public android.content.res.TypedArray obtainTypedArray(int id) throws Resources.NotFoundException { throw new RuntimeException("Stub!"); }
/* 18 */   public float getDimension(int id) throws Resources.NotFoundException { throw new RuntimeException("Stub!"); }
/* 19 */   public int getDimensionPixelOffset(int id) throws Resources.NotFoundException { throw new RuntimeException("Stub!"); }
/* 20 */   public int getDimensionPixelSize(int id) throws Resources.NotFoundException { throw new RuntimeException("Stub!"); }
/* 21 */   public android.graphics.drawable.Drawable getDrawable(int id) throws Resources.NotFoundException { throw new RuntimeException("Stub!"); }
/* 22 */   public android.graphics.Movie getMovie(int id) throws Resources.NotFoundException { throw new RuntimeException("Stub!"); }
/* 23 */   public int getColor(int id) throws Resources.NotFoundException { throw new RuntimeException("Stub!"); }
/* 24 */   public android.content.res.ColorStateList getColorStateList(int id) throws Resources.NotFoundException { throw new RuntimeException("Stub!"); }
/* 25 */   public int getInteger(int id) throws Resources.NotFoundException { throw new RuntimeException("Stub!"); }
/* 26 */   public android.content.res.XmlResourceParser getLayout(int id) throws Resources.NotFoundException { throw new RuntimeException("Stub!"); }
/* 27 */   public android.content.res.XmlResourceParser getAnimation(int id) throws Resources.NotFoundException { throw new RuntimeException("Stub!"); }
/* 28 */   public android.content.res.XmlResourceParser getXml(int id) throws Resources.NotFoundException { throw new RuntimeException("Stub!"); }
/* 29 */   public java.io.InputStream openRawResource(int id) throws Resources.NotFoundException { throw new RuntimeException("Stub!"); }
/* 30 */   public android.content.res.AssetFileDescriptor openRawResourceFd(int id) throws Resources.NotFoundException { throw new RuntimeException("Stub!"); }
/* 31 */   public void getValue(int id, android.util.TypedValue outValue, boolean resolveRefs) throws Resources.NotFoundException { throw new RuntimeException("Stub!"); }
/* 32 */   public void getValue(String name, android.util.TypedValue outValue, boolean resolveRefs) throws Resources.NotFoundException { throw new RuntimeException("Stub!"); }
/* 33 */   public android.content.res.TypedArray obtainAttributes(android.util.AttributeSet set, int[] attrs) { throw new RuntimeException("Stub!"); }
/* 34 */   public android.util.DisplayMetrics getDisplayMetrics() { throw new RuntimeException("Stub!"); }
/* 35 */   public android.content.res.Configuration getConfiguration() { throw new RuntimeException("Stub!"); }
/* 36 */   public int getIdentifier(String name, String defType, String defPackage) { throw new RuntimeException("Stub!"); }
/* 37 */   public String getResourceName(int resid) throws Resources.NotFoundException { throw new RuntimeException("Stub!"); }
/* 38 */   public String getResourcePackageName(int resid) throws Resources.NotFoundException { throw new RuntimeException("Stub!"); }
/* 39 */   public String getResourceTypeName(int resid) throws Resources.NotFoundException { throw new RuntimeException("Stub!"); }
/* 40 */   public String getResourceEntryName(int resid) throws Resources.NotFoundException { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\test\mock\MockResources.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */