/*    */ package android.os;
/*    */ 
/*    */ import java.util.concurrent.ExecutionException;
/*    */ 
/*    */ public abstract class AsyncTask<Params, Progress, Result> {
/*  6 */   public static enum Status { FINISHED, 
/*  7 */     PENDING, 
/*  8 */     RUNNING;
/*    */     private Status() {} }
/* 10 */   public AsyncTask() { throw new RuntimeException("Stub!"); }
/* 11 */   public final Status getStatus() { throw new RuntimeException("Stub!"); }
/*    */   protected abstract Result doInBackground(Params... paramVarArgs);
/* 13 */   protected void onPreExecute() { throw new RuntimeException("Stub!"); }
/* 14 */   protected void onPostExecute(Result result) { throw new RuntimeException("Stub!"); }
/* 15 */   protected void onProgressUpdate(Progress... values) { throw new RuntimeException("Stub!"); }
/* 16 */   protected void onCancelled() { throw new RuntimeException("Stub!"); }
/* 17 */   public final boolean isCancelled() { throw new RuntimeException("Stub!"); }
/* 18 */   public final boolean cancel(boolean mayInterruptIfRunning) { throw new RuntimeException("Stub!"); }
/* 19 */   public final Result get() throws InterruptedException, ExecutionException { throw new RuntimeException("Stub!"); }
/* 20 */   public final Result get(long timeout, java.util.concurrent.TimeUnit unit) throws InterruptedException, ExecutionException, java.util.concurrent.TimeoutException { throw new RuntimeException("Stub!"); }
/* 21 */   public final AsyncTask<Params, Progress, Result> execute(Params... params) { throw new RuntimeException("Stub!"); }
/* 22 */   protected final void publishProgress(Progress... values) { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\os\AsyncTask.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */