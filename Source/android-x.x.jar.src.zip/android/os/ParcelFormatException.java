/*   */ package android.os;
/*   */ 
/*   */ public class ParcelFormatException
/*   */   extends RuntimeException {
/* 5 */   public ParcelFormatException() { throw new RuntimeException("Stub!"); }
/* 6 */   public ParcelFormatException(String reason) { throw new RuntimeException("Stub!"); }
/*   */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\os\ParcelFormatException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */