/*    */ package android.os;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ public class ParcelFileDescriptor implements Parcelable { public static final int MODE_WORLD_READABLE = 1;
/*    */   public static final int MODE_WORLD_WRITEABLE = 2;
/*    */   
/*  8 */   public static class AutoCloseInputStream extends java.io.FileInputStream { public AutoCloseInputStream(ParcelFileDescriptor fd) { super();throw new RuntimeException("Stub!"); }
/*  9 */     public void close() throws IOException { throw new RuntimeException("Stub!"); }
/*    */   }
/*    */   
/*    */   public static class AutoCloseOutputStream extends java.io.FileOutputStream {
/*    */     public AutoCloseOutputStream(ParcelFileDescriptor fd) {
/* 14 */       super();throw new RuntimeException("Stub!"); }
/* 15 */     public void close() throws IOException { throw new RuntimeException("Stub!"); } }
/*    */   
/* 17 */   public ParcelFileDescriptor(ParcelFileDescriptor descriptor) { throw new RuntimeException("Stub!"); }
/* 18 */   public static ParcelFileDescriptor open(java.io.File file, int mode) throws java.io.FileNotFoundException { throw new RuntimeException("Stub!"); }
/* 19 */   public static ParcelFileDescriptor fromSocket(java.net.Socket socket) { throw new RuntimeException("Stub!"); }
/* 20 */   public java.io.FileDescriptor getFileDescriptor() { throw new RuntimeException("Stub!"); }
/*    */   public native long getStatSize();
/* 22 */   public void close() throws IOException { throw new RuntimeException("Stub!"); }
/* 23 */   public String toString() { throw new RuntimeException("Stub!"); }
/* 24 */   protected void finalize() throws Throwable { throw new RuntimeException("Stub!"); }
/* 25 */   public int describeContents() { throw new RuntimeException("Stub!"); }
/* 26 */   public void writeToParcel(Parcel out, int flags) { throw new RuntimeException("Stub!"); }
/*    */   
/*    */ 
/*    */   public static final int MODE_READ_ONLY = 268435456;
/*    */   
/*    */   public static final int MODE_WRITE_ONLY = 536870912;
/*    */   public static final int MODE_READ_WRITE = 805306368;
/*    */   public static final int MODE_CREATE = 134217728;
/*    */   public static final int MODE_TRUNCATE = 67108864;
/*    */   public static final int MODE_APPEND = 33554432;
/* 36 */   public static final Parcelable.Creator<ParcelFileDescriptor> CREATOR = null;
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\os\ParcelFileDescriptor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */