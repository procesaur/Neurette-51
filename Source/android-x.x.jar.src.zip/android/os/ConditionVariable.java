/*   */ package android.os;
/*   */ 
/*   */ public class ConditionVariable {
/* 4 */   public ConditionVariable() { throw new RuntimeException("Stub!"); }
/* 5 */   public ConditionVariable(boolean state) { throw new RuntimeException("Stub!"); }
/* 6 */   public void open() { throw new RuntimeException("Stub!"); }
/* 7 */   public void close() { throw new RuntimeException("Stub!"); }
/* 8 */   public void block() { throw new RuntimeException("Stub!"); }
/* 9 */   public boolean block(long timeout) { throw new RuntimeException("Stub!"); }
/*   */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\os\ConditionVariable.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */