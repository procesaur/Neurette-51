/*    */ package android.os;
/*    */ import android.util.Printer;
/*    */ 
/*  4 */ public class Looper { Looper() { throw new RuntimeException("Stub!"); }
/*  5 */   public static final void prepare() { throw new RuntimeException("Stub!"); }
/*  6 */   public static final void prepareMainLooper() { throw new RuntimeException("Stub!"); }
/*  7 */   public static final synchronized Looper getMainLooper() { throw new RuntimeException("Stub!"); }
/*  8 */   public static final void loop() { throw new RuntimeException("Stub!"); }
/*  9 */   public static final Looper myLooper() { throw new RuntimeException("Stub!"); }
/* 10 */   public void setMessageLogging(Printer printer) { throw new RuntimeException("Stub!"); }
/* 11 */   public static final MessageQueue myQueue() { throw new RuntimeException("Stub!"); }
/* 12 */   public void quit() { throw new RuntimeException("Stub!"); }
/* 13 */   public Thread getThread() { throw new RuntimeException("Stub!"); }
/* 14 */   public void dump(Printer pw, String prefix) { throw new RuntimeException("Stub!"); }
/* 15 */   public String toString() { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\os\Looper.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */