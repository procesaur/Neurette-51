/*    */ package android.os;
/*    */ 
/*    */ public class HandlerThread
/*    */   extends Thread {
/*  5 */   public HandlerThread(String name) { throw new RuntimeException("Stub!"); }
/*  6 */   public HandlerThread(String name, int priority) { throw new RuntimeException("Stub!"); }
/*  7 */   protected void onLooperPrepared() { throw new RuntimeException("Stub!"); }
/*  8 */   public void run() { throw new RuntimeException("Stub!"); }
/*  9 */   public Looper getLooper() { throw new RuntimeException("Stub!"); }
/* 10 */   public boolean quit() { throw new RuntimeException("Stub!"); }
/* 11 */   public int getThreadId() { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\os\HandlerThread.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */