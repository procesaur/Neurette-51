/*   */ package android.accounts;
/*   */ 
/*   */ public class NetworkErrorException
/*   */   extends AccountsException {
/* 5 */   public NetworkErrorException() { throw new RuntimeException("Stub!"); }
/* 6 */   public NetworkErrorException(String message) { throw new RuntimeException("Stub!"); }
/* 7 */   public NetworkErrorException(String message, Throwable cause) { throw new RuntimeException("Stub!"); }
/* 8 */   public NetworkErrorException(Throwable cause) { throw new RuntimeException("Stub!"); }
/*   */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\accounts\NetworkErrorException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */