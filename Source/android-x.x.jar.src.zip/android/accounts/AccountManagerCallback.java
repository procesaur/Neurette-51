package android.accounts;

public abstract interface AccountManagerCallback<V>
{
  public abstract void run(AccountManagerFuture<V> paramAccountManagerFuture);
}


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\accounts\AccountManagerCallback.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */