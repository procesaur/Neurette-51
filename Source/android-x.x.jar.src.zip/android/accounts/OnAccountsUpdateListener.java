package android.accounts;

public abstract interface OnAccountsUpdateListener
{
  public abstract void onAccountsUpdated(Account[] paramArrayOfAccount);
}


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\accounts\OnAccountsUpdateListener.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */