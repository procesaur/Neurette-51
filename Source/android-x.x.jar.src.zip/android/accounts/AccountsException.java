/*   */ package android.accounts;
/*   */ 
/*   */ public class AccountsException
/*   */   extends Exception {
/* 5 */   public AccountsException() { throw new RuntimeException("Stub!"); }
/* 6 */   public AccountsException(String message) { throw new RuntimeException("Stub!"); }
/* 7 */   public AccountsException(String message, Throwable cause) { throw new RuntimeException("Stub!"); }
/* 8 */   public AccountsException(Throwable cause) { throw new RuntimeException("Stub!"); }
/*   */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\accounts\AccountsException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */