/*   */ package android.accounts;
/*   */ 
/*   */ public class OperationCanceledException
/*   */   extends AccountsException {
/* 5 */   public OperationCanceledException() { throw new RuntimeException("Stub!"); }
/* 6 */   public OperationCanceledException(String message) { throw new RuntimeException("Stub!"); }
/* 7 */   public OperationCanceledException(String message, Throwable cause) { throw new RuntimeException("Stub!"); }
/* 8 */   public OperationCanceledException(Throwable cause) { throw new RuntimeException("Stub!"); }
/*   */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\accounts\OperationCanceledException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */