/*   */ package android.accounts;
/*   */ 
/*   */ public class AuthenticatorException
/*   */   extends AccountsException {
/* 5 */   public AuthenticatorException() { throw new RuntimeException("Stub!"); }
/* 6 */   public AuthenticatorException(String message) { throw new RuntimeException("Stub!"); }
/* 7 */   public AuthenticatorException(String message, Throwable cause) { throw new RuntimeException("Stub!"); }
/* 8 */   public AuthenticatorException(Throwable cause) { throw new RuntimeException("Stub!"); }
/*   */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\accounts\AuthenticatorException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */