/*   */ package android.accounts;
/*   */ 
/*   */ import android.os.Bundle;
/*   */ 
/* 5 */ public class AccountAuthenticatorActivity extends android.app.Activity { public AccountAuthenticatorActivity() { throw new RuntimeException("Stub!"); }
/* 6 */   public final void setAccountAuthenticatorResult(Bundle result) { throw new RuntimeException("Stub!"); }
/* 7 */   protected void onCreate(Bundle icicle) { throw new RuntimeException("Stub!"); }
/* 8 */   public void finish() { throw new RuntimeException("Stub!"); }
/*   */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\accounts\AccountAuthenticatorActivity.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */