/*    */ package android.media;
/*    */ import java.io.IOException;
/*    */ 
/*  4 */ public class ExifInterface { public ExifInterface(String filename) throws IOException { throw new RuntimeException("Stub!"); }
/*  5 */   public String getAttribute(String tag) { throw new RuntimeException("Stub!"); }
/*  6 */   public int getAttributeInt(String tag, int defaultValue) { throw new RuntimeException("Stub!"); }
/*  7 */   public void setAttribute(String tag, String value) { throw new RuntimeException("Stub!"); }
/*  8 */   public void saveAttributes() throws IOException { throw new RuntimeException("Stub!"); }
/*  9 */   public boolean hasThumbnail() { throw new RuntimeException("Stub!"); }
/* 10 */   public byte[] getThumbnail() { throw new RuntimeException("Stub!"); }
/* 11 */   public boolean getLatLong(float[] output) { throw new RuntimeException("Stub!"); }
/*    */   
/*    */   public static final String TAG_ORIENTATION = "Orientation";
/*    */   public static final String TAG_DATETIME = "DateTime";
/*    */   public static final String TAG_MAKE = "Make";
/*    */   public static final String TAG_MODEL = "Model";
/*    */   public static final String TAG_FLASH = "Flash";
/*    */   public static final String TAG_IMAGE_WIDTH = "ImageWidth";
/*    */   public static final String TAG_IMAGE_LENGTH = "ImageLength";
/*    */   public static final String TAG_GPS_LATITUDE = "GPSLatitude";
/*    */   public static final String TAG_GPS_LONGITUDE = "GPSLongitude";
/*    */   public static final String TAG_GPS_LATITUDE_REF = "GPSLatitudeRef";
/*    */   public static final String TAG_GPS_LONGITUDE_REF = "GPSLongitudeRef";
/*    */   public static final String TAG_WHITE_BALANCE = "WhiteBalance";
/*    */   public static final int ORIENTATION_UNDEFINED = 0;
/*    */   public static final int ORIENTATION_NORMAL = 1;
/*    */   public static final int ORIENTATION_FLIP_HORIZONTAL = 2;
/*    */   public static final int ORIENTATION_ROTATE_180 = 3;
/*    */   public static final int ORIENTATION_FLIP_VERTICAL = 4;
/*    */   public static final int ORIENTATION_TRANSPOSE = 5;
/*    */   public static final int ORIENTATION_ROTATE_90 = 6;
/*    */   public static final int ORIENTATION_TRANSVERSE = 7;
/*    */   public static final int ORIENTATION_ROTATE_270 = 8;
/*    */   public static final int WHITEBALANCE_AUTO = 0;
/*    */   public static final int WHITEBALANCE_MANUAL = 1;
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\media\ExifInterface.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */