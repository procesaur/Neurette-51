/*    */ package android.media;
/*    */ 
/*    */ import android.content.ComponentName;
/*    */ import android.os.IBinder;
/*    */ 
/*    */ 
/*    */ public class MediaScannerConnection
/*    */   implements android.content.ServiceConnection
/*    */ {
/* 10 */   public MediaScannerConnection(android.content.Context context, MediaScannerConnectionClient client) { throw new RuntimeException("Stub!"); }
/* 11 */   public void connect() { throw new RuntimeException("Stub!"); }
/* 12 */   public void disconnect() { throw new RuntimeException("Stub!"); }
/* 13 */   public synchronized boolean isConnected() { throw new RuntimeException("Stub!"); }
/* 14 */   public void scanFile(String path, String mimeType) { throw new RuntimeException("Stub!"); }
/* 15 */   public void onServiceConnected(ComponentName className, IBinder service) { throw new RuntimeException("Stub!"); }
/* 16 */   public void onServiceDisconnected(ComponentName className) { throw new RuntimeException("Stub!"); }
/*    */   
/*    */   public static abstract interface MediaScannerConnectionClient
/*    */   {
/*    */     public abstract void onMediaScannerConnected();
/*    */     
/*    */     public abstract void onScanCompleted(String paramString, android.net.Uri paramUri);
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\media\MediaScannerConnection.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */