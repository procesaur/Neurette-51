/*    */ package android.media;
/*    */ import android.content.Context;
/*    */ 
/*  4 */ public class Ringtone { Ringtone() { throw new RuntimeException("Stub!"); }
/*  5 */   public void setStreamType(int streamType) { throw new RuntimeException("Stub!"); }
/*  6 */   public int getStreamType() { throw new RuntimeException("Stub!"); }
/*  7 */   public String getTitle(Context context) { throw new RuntimeException("Stub!"); }
/*  8 */   public void play() { throw new RuntimeException("Stub!"); }
/*  9 */   public void stop() { throw new RuntimeException("Stub!"); }
/* 10 */   public boolean isPlaying() { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\media\Ringtone.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */