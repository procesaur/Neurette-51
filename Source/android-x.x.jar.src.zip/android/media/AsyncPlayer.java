/*   */ package android.media;
/*   */ import android.content.Context;
/*   */ 
/* 4 */ public class AsyncPlayer { public AsyncPlayer(String tag) { throw new RuntimeException("Stub!"); }
/* 5 */   public void play(Context context, android.net.Uri uri, boolean looping, int stream) { throw new RuntimeException("Stub!"); }
/* 6 */   public void stop() { throw new RuntimeException("Stub!"); }
/*   */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\media\AsyncPlayer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */