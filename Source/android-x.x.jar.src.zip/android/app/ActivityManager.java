/*     */ package android.app;
/*     */ 
/*     */ import android.os.Parcel;
/*     */ 
/*     */ public class ActivityManager { public static final int RECENT_WITH_EXCLUDED = 1;
/*     */   
/*   7 */   public static class RecentTaskInfo implements android.os.Parcelable { public RecentTaskInfo() { throw new RuntimeException("Stub!"); }
/*   8 */     public int describeContents() { throw new RuntimeException("Stub!"); }
/*   9 */     public void writeToParcel(Parcel dest, int flags) { throw new RuntimeException("Stub!"); }
/*  10 */     public void readFromParcel(Parcel source) { throw new RuntimeException("Stub!"); }
/*     */     
/*     */     public int id;
/*     */     public android.content.Intent baseIntent;
/*     */     public android.content.ComponentName origActivity;
/*  15 */     public static final android.os.Parcelable.Creator<RecentTaskInfo> CREATOR = null;
/*     */   }
/*     */   
/*     */   public static class RunningTaskInfo implements android.os.Parcelable { public int id;
/*     */     
/*  20 */     public RunningTaskInfo() { throw new RuntimeException("Stub!"); }
/*  21 */     public int describeContents() { throw new RuntimeException("Stub!"); }
/*  22 */     public void writeToParcel(Parcel dest, int flags) { throw new RuntimeException("Stub!"); }
/*  23 */     public void readFromParcel(Parcel source) { throw new RuntimeException("Stub!"); }
/*     */     
/*     */ 
/*     */     public android.content.ComponentName baseActivity;
/*     */     public android.content.ComponentName topActivity;
/*     */     public android.graphics.Bitmap thumbnail;
/*     */     public CharSequence description;
/*     */     public int numActivities;
/*     */     public int numRunning;
/*  32 */     public static final android.os.Parcelable.Creator<RunningTaskInfo> CREATOR = null; }
/*     */   
/*     */   public static class RunningServiceInfo implements android.os.Parcelable { public android.content.ComponentName service;
/*     */     public int pid;
/*     */     
/*  37 */     public RunningServiceInfo() { throw new RuntimeException("Stub!"); }
/*  38 */     public int describeContents() { throw new RuntimeException("Stub!"); }
/*  39 */     public void writeToParcel(Parcel dest, int flags) { throw new RuntimeException("Stub!"); }
/*  40 */     public void readFromParcel(Parcel source) { throw new RuntimeException("Stub!"); }
/*     */     
/*     */ 
/*     */     public int uid;
/*     */     
/*     */     public String process;
/*     */     public boolean foreground;
/*     */     public long activeSince;
/*     */     public boolean started;
/*     */     public int clientCount;
/*     */     public int crashCount;
/*     */     public long lastActivityTime;
/*     */     public long restarting;
/*     */     public static final int FLAG_STARTED = 1;
/*     */     public static final int FLAG_FOREGROUND = 2;
/*     */     public static final int FLAG_SYSTEM_PROCESS = 4;
/*     */     public static final int FLAG_PERSISTENT_PROCESS = 8;
/*     */     public int flags;
/*     */     public String clientPackage;
/*     */     public int clientLabel;
/*  60 */     public static final android.os.Parcelable.Creator<RunningServiceInfo> CREATOR = null;
/*     */   }
/*     */   
/*     */   public static class MemoryInfo implements android.os.Parcelable { public long availMem;
/*     */     
/*  65 */     public MemoryInfo() { throw new RuntimeException("Stub!"); }
/*  66 */     public int describeContents() { throw new RuntimeException("Stub!"); }
/*  67 */     public void writeToParcel(Parcel dest, int flags) { throw new RuntimeException("Stub!"); }
/*  68 */     public void readFromParcel(Parcel source) { throw new RuntimeException("Stub!"); }
/*     */     
/*     */ 
/*     */     public long threshold;
/*     */     public boolean lowMemory;
/*  73 */     public static final android.os.Parcelable.Creator<MemoryInfo> CREATOR = null; }
/*     */   
/*     */   public static class ProcessErrorStateInfo implements android.os.Parcelable { public static final int NO_ERROR = 0;
/*     */     public static final int CRASHED = 1;
/*     */     
/*  78 */     public ProcessErrorStateInfo() { throw new RuntimeException("Stub!"); }
/*  79 */     public int describeContents() { throw new RuntimeException("Stub!"); }
/*  80 */     public void writeToParcel(Parcel dest, int flags) { throw new RuntimeException("Stub!"); }
/*  81 */     public void readFromParcel(Parcel source) { throw new RuntimeException("Stub!"); }
/*     */     
/*     */ 
/*     */     public static final int NOT_RESPONDING = 2;
/*     */     public int condition;
/*     */     public String processName;
/*     */     public int pid;
/*     */     public int uid;
/*     */     public String tag;
/*     */     public String shortMsg;
/*     */     public String longMsg;
/*  92 */     public byte[] crashData = null;
/*     */     
/*  94 */     public static final android.os.Parcelable.Creator<ProcessErrorStateInfo> CREATOR = null;
/*     */   }
/*     */   
/*     */   public static class RunningAppProcessInfo implements android.os.Parcelable { public String processName;
/*     */     
/*  99 */     public RunningAppProcessInfo() { throw new RuntimeException("Stub!"); }
/* 100 */     public RunningAppProcessInfo(String pProcessName, int pPid, String[] pArr) { throw new RuntimeException("Stub!"); }
/* 101 */     public int describeContents() { throw new RuntimeException("Stub!"); }
/* 102 */     public void writeToParcel(Parcel dest, int flags) { throw new RuntimeException("Stub!"); }
/* 103 */     public void readFromParcel(Parcel source) { throw new RuntimeException("Stub!"); }
/*     */     
/*     */     public int pid;
/*     */     public int uid;
/* 107 */     public String[] pkgList = null;
/*     */     
/*     */     public static final int IMPORTANCE_FOREGROUND = 100;
/*     */     public static final int IMPORTANCE_VISIBLE = 200;
/*     */     public static final int IMPORTANCE_SERVICE = 300;
/*     */     public static final int IMPORTANCE_BACKGROUND = 400;
/*     */     public static final int IMPORTANCE_EMPTY = 500;
/*     */     public int importance;
/*     */     public int lru;
/*     */     public static final int REASON_UNKNOWN = 0;
/*     */     public static final int REASON_PROVIDER_IN_USE = 1;
/*     */     public static final int REASON_SERVICE_IN_USE = 2;
/*     */     public int importanceReasonCode;
/*     */     public int importanceReasonPid;
/*     */     public android.content.ComponentName importanceReasonComponent;
/* 122 */     public static final android.os.Parcelable.Creator<RunningAppProcessInfo> CREATOR = null; }
/*     */   
/* 124 */   ActivityManager() { throw new RuntimeException("Stub!"); }
/* 125 */   public int getMemoryClass() { throw new RuntimeException("Stub!"); }
/* 126 */   public java.util.List<RecentTaskInfo> getRecentTasks(int maxNum, int flags) throws SecurityException { throw new RuntimeException("Stub!"); }
/* 127 */   public java.util.List<RunningTaskInfo> getRunningTasks(int maxNum) throws SecurityException { throw new RuntimeException("Stub!"); }
/* 128 */   public java.util.List<RunningServiceInfo> getRunningServices(int maxNum) throws SecurityException { throw new RuntimeException("Stub!"); }
/* 129 */   public PendingIntent getRunningServiceControlPanel(android.content.ComponentName service) throws SecurityException { throw new RuntimeException("Stub!"); }
/* 130 */   public void getMemoryInfo(MemoryInfo outInfo) { throw new RuntimeException("Stub!"); }
/* 131 */   public java.util.List<ProcessErrorStateInfo> getProcessesInErrorState() { throw new RuntimeException("Stub!"); }
/* 132 */   public java.util.List<RunningAppProcessInfo> getRunningAppProcesses() { throw new RuntimeException("Stub!"); }
/* 133 */   public android.os.Debug.MemoryInfo[] getProcessMemoryInfo(int[] pids) { throw new RuntimeException("Stub!"); }
/* 134 */   public void restartPackage(String packageName) { throw new RuntimeException("Stub!"); }
/* 135 */   public android.content.pm.ConfigurationInfo getDeviceConfigurationInfo() { throw new RuntimeException("Stub!"); }
/*     */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\app\ActivityManager.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */