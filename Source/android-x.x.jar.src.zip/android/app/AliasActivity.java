/*   */ package android.app;
/*   */ 
/*   */ import android.os.Bundle;
/*   */ 
/* 5 */ public class AliasActivity extends Activity { public AliasActivity() { throw new RuntimeException("Stub!"); }
/* 6 */   protected void onCreate(Bundle savedInstanceState) { throw new RuntimeException("Stub!"); }
/*   */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\app\AliasActivity.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */