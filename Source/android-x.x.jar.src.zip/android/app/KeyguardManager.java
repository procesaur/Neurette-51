/*    */ package android.app;
/*    */ 
/*    */ public class KeyguardManager { public static abstract interface OnKeyguardExitResult { public abstract void onKeyguardExitResult(boolean paramBoolean);
/*    */   }
/*    */   
/*  6 */   public class KeyguardLock { KeyguardLock() { throw new RuntimeException("Stub!"); }
/*  7 */     public void disableKeyguard() { throw new RuntimeException("Stub!"); }
/*  8 */     public void reenableKeyguard() { throw new RuntimeException("Stub!"); }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/* 14 */   KeyguardManager() { throw new RuntimeException("Stub!"); }
/* 15 */   public KeyguardLock newKeyguardLock(String tag) { throw new RuntimeException("Stub!"); }
/* 16 */   public boolean inKeyguardRestrictedInputMode() { throw new RuntimeException("Stub!"); }
/* 17 */   public void exitKeyguardSecurely(OnKeyguardExitResult callback) { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\app\KeyguardManager.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */