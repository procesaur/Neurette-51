/*    */ package android.app;
/*    */ 
/*    */ import android.os.Bundle;
/*    */ 
/*  5 */ public class ActivityGroup extends Activity { public ActivityGroup() { throw new RuntimeException("Stub!"); }
/*  6 */   public ActivityGroup(boolean singleActivityMode) { throw new RuntimeException("Stub!"); }
/*  7 */   protected void onCreate(Bundle savedInstanceState) { throw new RuntimeException("Stub!"); }
/*  8 */   protected void onResume() { throw new RuntimeException("Stub!"); }
/*  9 */   protected void onSaveInstanceState(Bundle outState) { throw new RuntimeException("Stub!"); }
/* 10 */   protected void onPause() { throw new RuntimeException("Stub!"); }
/* 11 */   protected void onStop() { throw new RuntimeException("Stub!"); }
/* 12 */   protected void onDestroy() { throw new RuntimeException("Stub!"); }
/* 13 */   public Activity getCurrentActivity() { throw new RuntimeException("Stub!"); }
/* 14 */   public final LocalActivityManager getLocalActivityManager() { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\app\ActivityGroup.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */