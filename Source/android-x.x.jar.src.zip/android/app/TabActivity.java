/*    */ package android.app;
/*    */ 
/*    */ import android.os.Bundle;
/*    */ 
/*  5 */ public class TabActivity extends ActivityGroup { public TabActivity() { throw new RuntimeException("Stub!"); }
/*  6 */   public void setDefaultTab(String tag) { throw new RuntimeException("Stub!"); }
/*  7 */   public void setDefaultTab(int index) { throw new RuntimeException("Stub!"); }
/*  8 */   protected void onRestoreInstanceState(Bundle state) { throw new RuntimeException("Stub!"); }
/*  9 */   protected void onPostCreate(Bundle icicle) { throw new RuntimeException("Stub!"); }
/* 10 */   protected void onSaveInstanceState(Bundle outState) { throw new RuntimeException("Stub!"); }
/* 11 */   public void onContentChanged() { throw new RuntimeException("Stub!"); }
/* 12 */   protected void onChildTitleChanged(Activity childActivity, CharSequence title) { throw new RuntimeException("Stub!"); }
/* 13 */   public android.widget.TabHost getTabHost() { throw new RuntimeException("Stub!"); }
/* 14 */   public android.widget.TabWidget getTabWidget() { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\app\TabActivity.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */