/*   */ package android.app;
/*   */ 
/*   */ public class NotificationManager {
/* 4 */   NotificationManager() { throw new RuntimeException("Stub!"); }
/* 5 */   public void notify(int id, Notification notification) { throw new RuntimeException("Stub!"); }
/* 6 */   public void notify(String tag, int id, Notification notification) { throw new RuntimeException("Stub!"); }
/* 7 */   public void cancel(int id) { throw new RuntimeException("Stub!"); }
/* 8 */   public void cancel(String tag, int id) { throw new RuntimeException("Stub!"); }
/* 9 */   public void cancelAll() { throw new RuntimeException("Stub!"); }
/*   */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\app\NotificationManager.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */