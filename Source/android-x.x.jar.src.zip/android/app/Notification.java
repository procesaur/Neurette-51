/*    */ package android.app;
/*    */ import android.os.Parcel;
/*    */ 
/*    */ public class Notification implements android.os.Parcelable { public static final int DEFAULT_ALL = -1; public static final int DEFAULT_SOUND = 1; public static final int DEFAULT_VIBRATE = 2; public static final int DEFAULT_LIGHTS = 4; public long when; public int icon; public int number; public PendingIntent contentIntent;
/*  5 */   public Notification() { throw new RuntimeException("Stub!"); }
/*  6 */   public Notification(int icon, CharSequence tickerText, long when) { throw new RuntimeException("Stub!"); }
/*  7 */   public Notification(Parcel parcel) { throw new RuntimeException("Stub!"); }
/*  8 */   public int describeContents() { throw new RuntimeException("Stub!"); }
/*  9 */   public void writeToParcel(Parcel parcel, int flags) { throw new RuntimeException("Stub!"); }
/* 10 */   public void setLatestEventInfo(android.content.Context context, CharSequence contentTitle, CharSequence contentText, PendingIntent contentIntent) { throw new RuntimeException("Stub!"); }
/* 11 */   public String toString() { throw new RuntimeException("Stub!"); }
/*    */   
/*    */ 
/*    */   public PendingIntent deleteIntent;
/*    */   
/*    */   public CharSequence tickerText;
/*    */   
/*    */   public android.widget.RemoteViews contentView;
/*    */   
/*    */   public int iconLevel;
/*    */   
/*    */   public android.net.Uri sound;
/*    */   
/*    */   public static final int STREAM_DEFAULT = -1;
/*    */   
/*    */   public int audioStreamType;
/* 27 */   public long[] vibrate = null;
/*    */   
/*    */   public int ledARGB;
/*    */   public int ledOnMS;
/*    */   public int ledOffMS;
/*    */   public int defaults;
/*    */   public static final int FLAG_SHOW_LIGHTS = 1;
/*    */   public static final int FLAG_ONGOING_EVENT = 2;
/*    */   public static final int FLAG_INSISTENT = 4;
/*    */   public static final int FLAG_ONLY_ALERT_ONCE = 8;
/*    */   public static final int FLAG_AUTO_CANCEL = 16;
/*    */   public static final int FLAG_NO_CLEAR = 32;
/*    */   public static final int FLAG_FOREGROUND_SERVICE = 64;
/*    */   public int flags;
/* 41 */   public static final android.os.Parcelable.Creator<Notification> CREATOR = null;
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\app\Notification.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */