/*    */ package android.app;
/*    */ 
/*    */ import android.widget.ListView;
/*    */ 
/*  5 */ public class ListActivity extends Activity { public ListActivity() { throw new RuntimeException("Stub!"); }
/*  6 */   protected void onListItemClick(ListView l, android.view.View v, int position, long id) { throw new RuntimeException("Stub!"); }
/*  7 */   protected void onRestoreInstanceState(android.os.Bundle state) { throw new RuntimeException("Stub!"); }
/*  8 */   public void onContentChanged() { throw new RuntimeException("Stub!"); }
/*  9 */   public void setListAdapter(android.widget.ListAdapter adapter) { throw new RuntimeException("Stub!"); }
/* 10 */   public void setSelection(int position) { throw new RuntimeException("Stub!"); }
/* 11 */   public int getSelectedItemPosition() { throw new RuntimeException("Stub!"); }
/* 12 */   public long getSelectedItemId() { throw new RuntimeException("Stub!"); }
/* 13 */   public ListView getListView() { throw new RuntimeException("Stub!"); }
/* 14 */   public android.widget.ListAdapter getListAdapter() { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\app\ListActivity.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */