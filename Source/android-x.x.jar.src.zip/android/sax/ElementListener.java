package android.sax;

public abstract interface ElementListener
  extends StartElementListener, EndElementListener
{}


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\sax\ElementListener.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */