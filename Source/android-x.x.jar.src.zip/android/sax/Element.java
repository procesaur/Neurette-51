/*    */ package android.sax;
/*    */ 
/*    */ public class Element {
/*  4 */   Element() { throw new RuntimeException("Stub!"); }
/*  5 */   public Element getChild(String localName) { throw new RuntimeException("Stub!"); }
/*  6 */   public Element getChild(String uri, String localName) { throw new RuntimeException("Stub!"); }
/*  7 */   public Element requireChild(String localName) { throw new RuntimeException("Stub!"); }
/*  8 */   public Element requireChild(String uri, String localName) { throw new RuntimeException("Stub!"); }
/*  9 */   public void setElementListener(ElementListener elementListener) { throw new RuntimeException("Stub!"); }
/* 10 */   public void setTextElementListener(TextElementListener elementListener) { throw new RuntimeException("Stub!"); }
/* 11 */   public void setStartElementListener(StartElementListener startElementListener) { throw new RuntimeException("Stub!"); }
/* 12 */   public void setEndElementListener(EndElementListener endElementListener) { throw new RuntimeException("Stub!"); }
/* 13 */   public void setEndTextElementListener(EndTextElementListener endTextElementListener) { throw new RuntimeException("Stub!"); }
/* 14 */   public String toString() { throw new RuntimeException("Stub!"); }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\sax\Element.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */