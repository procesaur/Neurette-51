package android.sax;

public abstract interface EndTextElementListener
{
  public abstract void end(String paramString);
}


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\sax\EndTextElementListener.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */