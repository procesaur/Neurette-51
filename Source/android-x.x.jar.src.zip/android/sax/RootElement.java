/*   */ package android.sax;
/*   */ 
/*   */ import org.xml.sax.ContentHandler;
/*   */ 
/* 5 */ public class RootElement extends Element { public RootElement(String uri, String localName) { throw new RuntimeException("Stub!"); }
/* 6 */   public RootElement(String localName) { throw new RuntimeException("Stub!"); }
/* 7 */   public ContentHandler getContentHandler() { throw new RuntimeException("Stub!"); }
/*   */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\android-x.x.jar!\android\sax\RootElement.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */