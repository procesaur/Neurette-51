/*    */ package org.neuroph.util;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.neuroph.core.Connection;
/*    */ import org.neuroph.core.Layer;
/*    */ import org.neuroph.core.NeuralNetwork;
/*    */ import org.neuroph.core.Neuron;
/*    */ import org.neuroph.core.Weight;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NeuralNetworkCODEC
/*    */ {
/*    */   public static void network2array(NeuralNetwork network, double[] array)
/*    */   {
/* 48 */     int index = 0;
/*    */     
/* 50 */     List<Layer> layers = network.getLayers();
/* 51 */     for (Layer layer : layers) {
/* 52 */       for (Neuron neuron : layer.getNeurons()) {
/* 53 */         for (Connection connection : neuron.getOutConnections()) {
/* 54 */           array[(index++)] = connection.getWeight().getValue();
/*    */         }
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static void array2network(double[] array, NeuralNetwork network)
/*    */   {
/* 66 */     int index = 0;
/*    */     
/* 68 */     List<Layer> layers = network.getLayers();
/* 69 */     for (Layer layer : layers) {
/* 70 */       for (Neuron neuron : layer.getNeurons()) {
/* 71 */         for (Connection connection : neuron.getOutConnections()) {
/* 72 */           connection.getWeight().setValue(array[(index++)]);
/*    */         }
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static int determineArraySize(NeuralNetwork network)
/*    */   {
/* 85 */     int result = 0;
/*    */     
/* 87 */     List<Layer> layers = network.getLayers();
/* 88 */     for (Layer layer : layers) {
/* 89 */       for (Neuron neuron : layer.getNeurons()) {
/* 90 */         result += neuron.getOutConnections().size();
/*    */       }
/*    */     }
/* 93 */     return result;
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\util\NeuralNetworkCODEC.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */