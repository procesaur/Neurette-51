/*     */ package org.neuroph.util;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.neuroph.core.Connection;
/*     */ import org.neuroph.core.Layer;
/*     */ import org.neuroph.core.Neuron;
/*     */ import org.neuroph.core.Weight;
/*     */ import org.neuroph.nnet.comp.DelayedConnection;
/*     */ import org.neuroph.nnet.comp.neuron.BiasNeuron;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConnectionFactory
/*     */ {
/*     */   public static void createConnection(Neuron fromNeuron, Neuron toNeuron)
/*     */   {
/*  40 */     Connection connection = new Connection(fromNeuron, toNeuron);
/*  41 */     toNeuron.addInputConnection(connection);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void createConnection(Neuron fromNeuron, Neuron toNeuron, double weightVal)
/*     */   {
/*  55 */     Connection connection = new Connection(fromNeuron, toNeuron, weightVal);
/*  56 */     toNeuron.addInputConnection(connection);
/*     */   }
/*     */   
/*     */   public static void createConnection(Neuron fromNeuron, Neuron toNeuron, double weightVal, int delay) {
/*  60 */     DelayedConnection connection = new DelayedConnection(fromNeuron, toNeuron, weightVal, delay);
/*  61 */     toNeuron.addInputConnection(connection);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void createConnection(Neuron fromNeuron, Neuron toNeuron, Weight weight)
/*     */   {
/*  75 */     Connection connection = new Connection(fromNeuron, toNeuron, weight);
/*  76 */     toNeuron.addInputConnection(connection);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void createConnection(Neuron fromNeuron, Layer toLayer)
/*     */   {
/*  89 */     for (Neuron toNeuron : toLayer.getNeurons()) {
/*  90 */       createConnection(fromNeuron, toNeuron);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void fullConnect(Layer fromLayer, Layer toLayer)
/*     */   {
/* 104 */     for (Iterator localIterator1 = fromLayer.getNeurons().iterator(); localIterator1.hasNext();) { fromNeuron = (Neuron)localIterator1.next();
/* 105 */       for (Neuron toNeuron : toLayer.getNeurons()) {
/* 106 */         createConnection(fromNeuron, toNeuron);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     Neuron fromNeuron;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void fullConnect(Layer fromLayer, Layer toLayer, boolean connectBiasNeuron)
/*     */   {
/* 120 */     for (Iterator localIterator1 = fromLayer.getNeurons().iterator(); localIterator1.hasNext();) { fromNeuron = (Neuron)localIterator1.next();
/* 121 */       if (!(fromNeuron instanceof BiasNeuron))
/*     */       {
/*     */ 
/* 124 */         for (Neuron toNeuron : toLayer.getNeurons()) {
/* 125 */           createConnection(fromNeuron, toNeuron);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     Neuron fromNeuron;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void fullConnect(Layer fromLayer, Layer toLayer, double weightVal)
/*     */   {
/* 144 */     for (Iterator localIterator1 = fromLayer.getNeurons().iterator(); localIterator1.hasNext();) { fromNeuron = (Neuron)localIterator1.next();
/* 145 */       for (Neuron toNeuron : toLayer.getNeurons()) {
/* 146 */         createConnection(fromNeuron, toNeuron, weightVal);
/*     */       }
/*     */     }
/*     */     
/*     */     Neuron fromNeuron;
/*     */   }
/*     */   
/*     */ 
/*     */   public static void fullConnect(Layer layer)
/*     */   {
/* 156 */     int neuronNum = layer.getNeuronsCount();
/* 157 */     for (int i = 0; i < neuronNum; i++) {
/* 158 */       for (int j = 0; j < neuronNum; j++) {
/* 159 */         if (j != i)
/*     */         {
/* 161 */           Neuron from = layer.getNeuronAt(i);
/* 162 */           Neuron to = layer.getNeuronAt(j);
/* 163 */           createConnection(from, to);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void fullConnect(Layer layer, double weightVal)
/*     */   {
/* 174 */     int neuronNum = layer.getNeuronsCount();
/* 175 */     for (int i = 0; i < neuronNum; i++) {
/* 176 */       for (int j = 0; j < neuronNum; j++) {
/* 177 */         if (j != i)
/*     */         {
/* 179 */           Neuron from = layer.getNeuronAt(i);
/* 180 */           Neuron to = layer.getNeuronAt(j);
/* 181 */           createConnection(from, to, weightVal);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void fullConnect(Layer layer, double weightVal, int delay)
/*     */   {
/* 192 */     int neuronNum = layer.getNeuronsCount();
/* 193 */     for (int i = 0; i < neuronNum; i++) {
/* 194 */       for (int j = 0; j < neuronNum; j++) {
/* 195 */         if (j != i)
/*     */         {
/* 197 */           Neuron from = layer.getNeuronAt(i);
/* 198 */           Neuron to = layer.getNeuronAt(j);
/* 199 */           createConnection(from, to, weightVal, delay);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void forwardConnect(Layer fromLayer, Layer toLayer, double weightVal)
/*     */   {
/* 213 */     for (int i = 0; i < fromLayer.getNeuronsCount(); i++) {
/* 214 */       Neuron fromNeuron = fromLayer.getNeuronAt(i);
/* 215 */       Neuron toNeuron = toLayer.getNeuronAt(i);
/* 216 */       createConnection(fromNeuron, toNeuron, weightVal);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void forwardConnect(Layer fromLayer, Layer toLayer)
/*     */   {
/* 229 */     for (int i = 0; i < fromLayer.getNeuronsCount(); i++) {
/* 230 */       Neuron fromNeuron = fromLayer.getNeuronAt(i);
/* 231 */       Neuron toNeuron = toLayer.getNeuronAt(i);
/* 232 */       createConnection(fromNeuron, toNeuron, 1.0D);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\util\ConnectionFactory.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */