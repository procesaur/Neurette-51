/*    */ package org.neuroph.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum NeuralNetworkType
/*    */ {
/* 23 */   ADALINE("Adaline"), 
/* 24 */   PERCEPTRON("Perceptron"), 
/* 25 */   MULTI_LAYER_PERCEPTRON("Multi Layer Perceptron"), 
/* 26 */   HOPFIELD("Hopfield"), 
/* 27 */   KOHONEN("Kohonen"), 
/* 28 */   NEURO_FUZZY_REASONER("Neuro Fuzzy Reasoner"), 
/* 29 */   SUPERVISED_HEBBIAN_NET("Supervised Hebbian network"), 
/* 30 */   UNSUPERVISED_HEBBIAN_NET("Unsupervised Hebbian network"), 
/* 31 */   COMPETITIVE("Competitive"), 
/* 32 */   MAXNET("Maxnet"), 
/* 33 */   INSTAR("Instar"), 
/* 34 */   OUTSTAR("Outstar"), 
/* 35 */   RBF_NETWORK("RBF Network"), 
/* 36 */   BAM("BAM"), 
/* 37 */   BOLTZMAN("Boltzman"), 
/* 38 */   COUNTERPROPAGATION("CounterPropagation"), 
/* 39 */   INSTAR_OUTSTAR("InstarOutstar"), 
/* 40 */   PCA_NETWORK("PCANetwork"), 
/* 41 */   RECOMMENDER("Recommender");
/*    */   
/*    */   private String typeLabel;
/*    */   
/*    */   private NeuralNetworkType(String typeLabel) {
/* 46 */     this.typeLabel = typeLabel;
/*    */   }
/*    */   
/*    */   public String getTypeLabel() {
/* 50 */     return this.typeLabel;
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\util\NeuralNetworkType.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */