/*    */ package org.neuroph.util.plugins;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.neuroph.core.NeuralNetwork;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PluginBase
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private String name;
/*    */   private NeuralNetwork<?> parentNetwork;
/*    */   
/*    */   public PluginBase() {}
/*    */   
/*    */   public PluginBase(String name)
/*    */   {
/* 55 */     this.name = name;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getName()
/*    */   {
/* 63 */     return this.name;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public NeuralNetwork<?> getParentNetwork()
/*    */   {
/* 71 */     return this.parentNetwork;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setParentNetwork(NeuralNetwork parentNetwork)
/*    */   {
/* 79 */     this.parentNetwork = parentNetwork;
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\util\plugins\PluginBase.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */