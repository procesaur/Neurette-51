/*    */ package org.neuroph.util;
/*    */ 
/*    */ import java.io.BufferedReader;
/*    */ import java.io.File;
/*    */ import java.io.FileNotFoundException;
/*    */ import java.io.FileReader;
/*    */ import java.io.IOException;
/*    */ import org.neuroph.core.data.DataSet;
/*    */ import org.neuroph.core.data.DataSetRow;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TrainingSetImport
/*    */ {
/*    */   public static DataSet importFromFile(String filePath, int inputsCount, int outputsCount, String separator)
/*    */     throws IOException, FileNotFoundException, NumberFormatException
/*    */   {
/* 46 */     FileReader fileReader = null;
/*    */     try
/*    */     {
/* 49 */       DataSet trainingSet = new DataSet(inputsCount, outputsCount);
/* 50 */       fileReader = new FileReader(new File(filePath));
/* 51 */       BufferedReader reader = new BufferedReader(fileReader);
/*    */       
/* 53 */       String line = "";
/*    */       
/* 55 */       while ((line = reader.readLine()) != null) {
/* 56 */         double[] inputs = new double[inputsCount];
/* 57 */         double[] outputs = new double[outputsCount];
/* 58 */         String[] values = line.split(separator);
/*    */         
/* 60 */         if (!values[0].equals(""))
/*    */         {
/* 62 */           for (int i = 0; i < inputsCount; i++) {
/* 63 */             inputs[i] = Double.parseDouble(values[i]);
/*    */           }
/* 65 */           for (int i = 0; i < outputsCount; i++) {
/* 66 */             outputs[i] = Double.parseDouble(values[(inputsCount + i)]);
/*    */           }
/* 68 */           if (outputsCount > 0) {
/* 69 */             trainingSet.addRow(new DataSetRow(inputs, outputs));
/*    */           } else {
/* 71 */             trainingSet.addRow(new DataSetRow(inputs));
/*    */           }
/*    */         }
/*    */       }
/* 75 */       return trainingSet;
/*    */     }
/*    */     catch (FileNotFoundException ex) {
/* 78 */       ex.printStackTrace();
/* 79 */       throw ex;
/*    */     } catch (IOException ex) {
/* 81 */       if (fileReader != null) {
/* 82 */         fileReader.close();
/*    */       }
/* 84 */       ex.printStackTrace();
/* 85 */       throw ex;
/*    */     } catch (NumberFormatException ex) {
/* 87 */       fileReader.close();
/* 88 */       ex.printStackTrace();
/* 89 */       throw ex;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\util\TrainingSetImport.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */