/*    */ package org.neuroph.util.io;
/*    */ 
/*    */ import java.io.BufferedReader;
/*    */ import java.io.File;
/*    */ import java.io.FileNotFoundException;
/*    */ import java.io.FileReader;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FileInputAdapter
/*    */   extends InputStreamAdapter
/*    */ {
/*    */   public FileInputAdapter(File file)
/*    */     throws FileNotFoundException
/*    */   {
/* 38 */     super(new BufferedReader(new FileReader(file)));
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public FileInputAdapter(String fileName)
/*    */     throws FileNotFoundException
/*    */   {
/* 48 */     this(new File(fileName));
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\util\io\FileInputAdapter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */