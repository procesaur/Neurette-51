/*    */ package org.neuroph.util.io;
/*    */ 
/*    */ import org.neuroph.core.NeuralNetwork;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IOHelper
/*    */ {
/*    */   public static void process(NeuralNetwork neuralNet, InputAdapter in, OutputAdapter out)
/*    */   {
/*    */     double[] input;
/* 42 */     while ((input = in.readInput()) != null) {
/* 43 */       neuralNet.setInput(input);
/* 44 */       neuralNet.calculate();
/* 45 */       double[] output = neuralNet.getOutput();
/* 46 */       out.writeOutput(output);
/*    */     }
/*    */     
/* 49 */     in.close();
/* 50 */     out.close();
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\util\io\IOHelper.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */