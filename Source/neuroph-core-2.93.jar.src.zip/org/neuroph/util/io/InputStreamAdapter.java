/*    */ package org.neuroph.util.io;
/*    */ 
/*    */ import java.io.BufferedReader;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.InputStreamReader;
/*    */ import org.neuroph.util.VectorParser;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InputStreamAdapter
/*    */   implements InputAdapter
/*    */ {
/*    */   protected BufferedReader bufferedReader;
/*    */   
/*    */   public InputStreamAdapter(InputStream inputStream)
/*    */   {
/* 35 */     this.bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
/*    */   }
/*    */   
/*    */   public InputStreamAdapter(BufferedReader bufferedReader) {
/* 39 */     this.bufferedReader = bufferedReader;
/*    */   }
/*    */   
/*    */   public double[] readInput()
/*    */   {
/*    */     try {
/* 45 */       String inputLine = this.bufferedReader.readLine();
/* 46 */       if (inputLine != null) {
/* 47 */         return VectorParser.parseDoubleArray(inputLine);
/*    */       }
/*    */       
/* 50 */       return null;
/*    */     } catch (IOException ex) {
/* 52 */       throw new NeurophInputException("Error reading input from stream!", ex);
/*    */     }
/*    */   }
/*    */   
/*    */   public void close()
/*    */   {
/*    */     try {
/* 59 */       if (this.bufferedReader != null)
/* 60 */         this.bufferedReader.close();
/*    */     } catch (IOException ex) {
/* 62 */       throw new NeurophInputException("Error closing stream!", ex);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\util\io\InputStreamAdapter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */