package org.neuroph.util.io;

public abstract interface OutputAdapter
{
  public abstract void writeOutput(double[] paramArrayOfDouble);
  
  public abstract void close();
}


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\util\io\OutputAdapter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */