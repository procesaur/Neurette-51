/*    */ package org.neuroph.util.io;
/*    */ 
/*    */ import org.neuroph.core.exceptions.NeurophException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NeurophInputException
/*    */   extends NeurophException
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public NeurophInputException() {}
/*    */   
/*    */   public NeurophInputException(String message)
/*    */   {
/* 42 */     super(message);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public NeurophInputException(String message, Throwable cause)
/*    */   {
/* 51 */     super(message, cause);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public NeurophInputException(Throwable cause)
/*    */   {
/* 59 */     super(cause);
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\util\io\NeurophInputException.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */