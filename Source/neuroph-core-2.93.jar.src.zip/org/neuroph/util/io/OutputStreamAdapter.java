/*    */ package org.neuroph.util.io;
/*    */ 
/*    */ import java.io.BufferedWriter;
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStream;
/*    */ import java.io.OutputStreamWriter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OutputStreamAdapter
/*    */   implements OutputAdapter
/*    */ {
/*    */   protected BufferedWriter bufferedWriter;
/*    */   
/*    */   public OutputStreamAdapter(OutputStream outputStream)
/*    */   {
/* 37 */     this.bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream));
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public OutputStreamAdapter(BufferedWriter bufferedWriter)
/*    */   {
/* 44 */     this.bufferedWriter = bufferedWriter;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void writeOutput(double[] output)
/*    */   {
/*    */     try
/*    */     {
/* 54 */       StringBuilder outputLine = new StringBuilder();
/* 55 */       for (int i = 0; i < output.length; i++) {
/* 56 */         outputLine.append(output[i]).append(' ').append(outputLine);
/*    */       }
/* 58 */       outputLine.append(System.lineSeparator());
/*    */       
/* 60 */       this.bufferedWriter.write(outputLine.toString());
/*    */     } catch (IOException ex) {
/* 62 */       throw new NeurophOutputException("Error writing output to stream!", ex);
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void close()
/*    */   {
/*    */     try
/*    */     {
/* 72 */       this.bufferedWriter.close();
/*    */     } catch (IOException ex) {
/* 74 */       throw new NeurophOutputException("Error closing output stream!", ex);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\util\io\OutputStreamAdapter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */