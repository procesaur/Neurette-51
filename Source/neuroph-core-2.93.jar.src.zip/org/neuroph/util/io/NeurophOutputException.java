/*    */ package org.neuroph.util.io;
/*    */ 
/*    */ import org.neuroph.core.exceptions.NeurophException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NeurophOutputException
/*    */   extends NeurophException
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public NeurophOutputException() {}
/*    */   
/*    */   public NeurophOutputException(String message)
/*    */   {
/* 43 */     super(message);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public NeurophOutputException(String message, Throwable cause)
/*    */   {
/* 52 */     super(message, cause);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public NeurophOutputException(Throwable cause)
/*    */   {
/* 60 */     super(cause);
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\util\io\NeurophOutputException.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */