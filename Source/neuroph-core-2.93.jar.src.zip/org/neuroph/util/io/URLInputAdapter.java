/*    */ package org.neuroph.util.io;
/*    */ 
/*    */ import java.io.BufferedReader;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStreamReader;
/*    */ import java.net.MalformedURLException;
/*    */ import java.net.URL;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class URLInputAdapter
/*    */   extends InputStreamAdapter
/*    */ {
/*    */   public URLInputAdapter(URL url)
/*    */     throws IOException
/*    */   {
/* 38 */     super(new BufferedReader(new InputStreamReader(url.openStream())));
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public URLInputAdapter(String url)
/*    */     throws MalformedURLException, IOException
/*    */   {
/* 47 */     this(new URL(url));
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\util\io\URLInputAdapter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */