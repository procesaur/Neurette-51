/*    */ package org.neuroph.util.io;
/*    */ 
/*    */ import java.sql.Connection;
/*    */ import java.sql.ResultSet;
/*    */ import java.sql.ResultSetMetaData;
/*    */ import java.sql.SQLException;
/*    */ import java.sql.Statement;
/*    */ import java.util.logging.Level;
/*    */ import java.util.logging.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JDBCInputAdapter
/*    */   implements InputAdapter
/*    */ {
/*    */   ResultSet resultSet;
/*    */   int inputSize;
/*    */   
/*    */   public JDBCInputAdapter(Connection connection, String sql)
/*    */   {
/*    */     try
/*    */     {
/* 38 */       Statement stmt = connection.createStatement();
/* 39 */       this.resultSet = stmt.executeQuery(sql);
/* 40 */       ResultSetMetaData rsmd = this.resultSet.getMetaData();
/* 41 */       this.inputSize = rsmd.getColumnCount();
/*    */     } catch (SQLException ex) {
/* 43 */       Logger.getLogger(JDBCInputAdapter.class.getName()).log(Level.SEVERE, null, ex);
/* 44 */       throw new NeurophInputException("Error executing query at JdbcInputAdapter", ex);
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public double[] readInput()
/*    */   {
/*    */     try
/*    */     {
/* 55 */       if (this.resultSet.next()) {
/* 56 */         double[] inputBuffer = new double[this.inputSize];
/* 57 */         for (int i = 1; i <= this.inputSize; i++) {
/* 58 */           inputBuffer[(i - 1)] = this.resultSet.getDouble(i);
/*    */         }
/* 60 */         return inputBuffer;
/*    */       }
/*    */     } catch (SQLException ex) {
/* 63 */       throw new NeurophInputException("Error reading input value from the result set!", ex);
/*    */     }
/*    */     
/* 66 */     return null;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void close()
/*    */   {
/*    */     try
/*    */     {
/* 75 */       if (this.resultSet != null)
/* 76 */         this.resultSet.close();
/*    */     } catch (SQLException ex) {
/* 78 */       throw new NeurophInputException("Error closing database connection!", ex);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\util\io\JDBCInputAdapter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */