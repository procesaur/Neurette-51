package org.neuroph.util.io;

public abstract interface InputAdapter
{
  public abstract double[] readInput();
  
  public abstract void close();
}


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\util\io\InputAdapter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */