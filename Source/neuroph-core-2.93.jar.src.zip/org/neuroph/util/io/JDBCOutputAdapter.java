/*    */ package org.neuroph.util.io;
/*    */ 
/*    */ import java.sql.Connection;
/*    */ import java.sql.PreparedStatement;
/*    */ import java.sql.SQLException;
/*    */ import java.util.logging.Level;
/*    */ import java.util.logging.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JDBCOutputAdapter
/*    */   implements OutputAdapter
/*    */ {
/*    */   Connection connection;
/*    */   String tableName;
/*    */   
/*    */   public JDBCOutputAdapter(Connection connection, String tableName)
/*    */   {
/* 41 */     this.connection = connection;
/* 42 */     this.tableName = tableName;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void writeOutput(double[] output)
/*    */   {
/*    */     try
/*    */     {
/* 52 */       String sql = "INSERT " + this.tableName + " VALUES(";
/* 53 */       for (int i = 0; i < output.length; i++) {
/* 54 */         sql = sql + "?";
/* 55 */         if (i < output.length - 1) {
/* 56 */           sql = ", ";
/*    */         }
/*    */       }
/* 59 */       sql = sql + ")";
/*    */       
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 71 */       PreparedStatement stmt = this.connection.prepareStatement(sql);
/* 72 */       for (int i = 0; i < output.length; i++) {
/* 73 */         stmt.setDouble(i, output[i]);
/*    */       }
/*    */       
/* 76 */       stmt.executeUpdate(sql);
/* 77 */       stmt.close();
/*    */     }
/*    */     catch (SQLException ex) {
/* 80 */       Logger.getLogger(JDBCOutputAdapter.class.getName()).log(Level.SEVERE, null, ex);
/* 81 */       throw new NeurophInputException("Error executing query at JDBCOutputAdapter", ex);
/*    */     }
/*    */   }
/*    */   
/*    */   public void close() {}
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\util\io\JDBCOutputAdapter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */