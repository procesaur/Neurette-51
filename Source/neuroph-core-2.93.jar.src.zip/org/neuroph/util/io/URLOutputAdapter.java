/*    */ package org.neuroph.util.io;
/*    */ 
/*    */ import java.io.BufferedWriter;
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStreamWriter;
/*    */ import java.net.MalformedURLException;
/*    */ import java.net.URL;
/*    */ import java.net.URLConnection;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class URLOutputAdapter
/*    */   extends OutputStreamAdapter
/*    */ {
/*    */   public URLOutputAdapter(URL url)
/*    */     throws IOException
/*    */   {
/* 38 */     super(new BufferedWriter(new OutputStreamWriter(url.openConnection().getOutputStream())));
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public URLOutputAdapter(String url)
/*    */     throws MalformedURLException, IOException
/*    */   {
/* 47 */     this(new URL(url));
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\util\io\URLOutputAdapter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */