/*     */ package org.neuroph.util;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ import org.neuroph.core.Neuron;
/*     */ import org.neuroph.core.input.InputFunction;
/*     */ import org.neuroph.core.input.WeightedSum;
/*     */ import org.neuroph.core.transfer.Linear;
/*     */ import org.neuroph.core.transfer.TransferFunction;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NeuronProperties
/*     */   extends Properties
/*     */ {
/*     */   private static final long serialVersionUID = 2L;
/*     */   
/*     */   public NeuronProperties()
/*     */   {
/*  38 */     initKeys();
/*  39 */     setProperty("inputFunction", WeightedSum.class);
/*  40 */     setProperty("transferFunction", Linear.class);
/*  41 */     setProperty("neuronType", Neuron.class);
/*     */   }
/*     */   
/*     */   public NeuronProperties(Class<? extends Neuron> neuronClass) {
/*  45 */     initKeys();
/*  46 */     setProperty("inputFunction", WeightedSum.class);
/*  47 */     setProperty("transferFunction", Linear.class);
/*  48 */     setProperty("neuronType", neuronClass);
/*     */   }
/*     */   
/*     */   public NeuronProperties(Class<? extends Neuron> neuronClass, Class<? extends TransferFunction> transferFunctionClass) {
/*  52 */     initKeys();
/*  53 */     setProperty("inputFunction", WeightedSum.class);
/*  54 */     setProperty("transferFunction", transferFunctionClass);
/*  55 */     setProperty("neuronType", neuronClass);
/*     */   }
/*     */   
/*     */ 
/*     */   public NeuronProperties(Class<? extends Neuron> neuronClass, Class<? extends InputFunction> inputFunctionClass, Class<? extends TransferFunction> transferFunctionClass)
/*     */   {
/*  61 */     initKeys();
/*  62 */     setProperty("inputFunction", inputFunctionClass);
/*  63 */     setProperty("transferFunction", transferFunctionClass);
/*  64 */     setProperty("neuronType", neuronClass);
/*     */   }
/*     */   
/*     */   public NeuronProperties(Class<? extends Neuron> neuronClass, TransferFunctionType transferFunctionType) {
/*  68 */     initKeys();
/*  69 */     setProperty("inputFunction", WeightedSum.class);
/*  70 */     setProperty("transferFunction", transferFunctionType.getTypeClass());
/*  71 */     setProperty("neuronType", neuronClass);
/*     */   }
/*     */   
/*     */   public NeuronProperties(TransferFunctionType transferFunctionType, boolean useBias) {
/*  75 */     initKeys();
/*     */     
/*     */ 
/*  78 */     setProperty("inputFunction", WeightedSum.class);
/*  79 */     setProperty("transferFunction", transferFunctionType.getTypeClass());
/*  80 */     setProperty("useBias", Boolean.valueOf(useBias));
/*  81 */     setProperty("neuronType", Neuron.class);
/*     */   }
/*     */   
/*     */   private void initKeys()
/*     */   {
/*  86 */     createKeys(new String[] { "inputFunction", "transferFunction", "neuronType", "useBias" });
/*     */   }
/*     */   
/*     */   public Class getInputFunction() {
/*  90 */     Object val = get("inputFunction");
/*  91 */     if (!val.equals("")) {
/*  92 */       return (Class)val;
/*     */     }
/*  94 */     return null;
/*     */   }
/*     */   
/*     */   public Class getTransferFunction() {
/*  98 */     return (Class)get("transferFunction");
/*     */   }
/*     */   
/*     */   public Class getNeuronType() {
/* 102 */     return (Class)get("neuronType");
/*     */   }
/*     */   
/*     */   public Properties getTransferFunctionProperties() {
/* 106 */     Properties tfProperties = new Properties();
/*     */     
/* 108 */     Iterator iterator = keySet().iterator();
/* 109 */     while (iterator.hasNext()) {
/* 110 */       String name = iterator.next().toString();
/* 111 */       if (name.contains("transferFunction")) {
/* 112 */         tfProperties.setProperty(name, get(name));
/*     */       }
/*     */     }
/* 115 */     return tfProperties;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void setProperty(String key, Object value)
/*     */   {
/* 123 */     if ((value instanceof TransferFunctionType)) {
/* 124 */       value = ((TransferFunctionType)value).getTypeClass();
/*     */     }
/*     */     
/*     */ 
/* 128 */     put(key, value);
/*     */   }
/*     */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\util\NeuronProperties.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */