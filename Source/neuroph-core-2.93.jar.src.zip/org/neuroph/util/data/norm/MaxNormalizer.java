/*    */ package org.neuroph.util.data.norm;
/*    */ 
/*    */ import org.neuroph.core.data.DataSet;
/*    */ import org.neuroph.core.data.DataSetRow;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MaxNormalizer
/*    */   implements Normalizer
/*    */ {
/*    */   double[] maxIn;
/*    */   double[] maxOut;
/*    */   
/*    */   public void normalize(DataSet dataSet)
/*    */   {
/* 35 */     findMaxVectors(dataSet);
/*    */     
/* 37 */     for (DataSetRow row : dataSet.getRows()) {
/* 38 */       double[] normalizedInput = normalizeMax(row.getInput(), this.maxIn);
/* 39 */       row.setInput(normalizedInput);
/*    */       
/* 41 */       if (dataSet.isSupervised()) {
/* 42 */         double[] normalizedOutput = normalizeMax(row.getDesiredOutput(), this.maxOut);
/* 43 */         row.setDesiredOutput(normalizedOutput);
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private void findMaxVectors(DataSet dataSet)
/*    */   {
/* 55 */     int inputSize = dataSet.getInputSize();
/* 56 */     int outputSize = dataSet.getOutputSize();
/*    */     
/* 58 */     this.maxIn = new double[inputSize];
/* 59 */     for (int i = 0; i < inputSize; i++) {
/* 60 */       this.maxIn[i] = Double.MIN_VALUE;
/*    */     }
/*    */     
/* 63 */     this.maxOut = new double[outputSize];
/* 64 */     for (int i = 0; i < outputSize; i++) {
/* 65 */       this.maxOut[i] = Double.MIN_VALUE;
/*    */     }
/* 67 */     for (DataSetRow dataSetRow : dataSet.getRows()) {
/* 68 */       double[] input = dataSetRow.getInput();
/* 69 */       for (int i = 0; i < inputSize; i++) {
/* 70 */         if (input[i] > this.maxIn[i]) {
/* 71 */           this.maxIn[i] = input[i];
/*    */         }
/*    */       }
/*    */       
/* 75 */       double[] output = dataSetRow.getDesiredOutput();
/* 76 */       for (int i = 0; i < outputSize; i++) {
/* 77 */         if (output[i] > this.maxOut[i]) {
/* 78 */           this.maxOut[i] = output[i];
/*    */         }
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */   public double[] normalizeMax(double[] vector, double[] max)
/*    */   {
/* 87 */     double[] normalizedVector = new double[vector.length];
/*    */     
/* 89 */     for (int i = 0; i < vector.length; i++) {
/* 90 */       vector[i] /= max[i];
/*    */     }
/*    */     
/* 93 */     return normalizedVector;
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\util\data\norm\MaxNormalizer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */