/*    */ package org.neuroph.util.data.norm;
/*    */ 
/*    */ import org.neuroph.core.data.DataSet;
/*    */ 
/*    */ public class RangeNormalizer implements Normalizer
/*    */ {
/*    */   double[] minOut;
/*    */   double[] minIn;
/*    */   double[] maxOut;
/*    */   double[] maxIn;
/* 11 */   private double highLimit = 1.0D; private double lowLimit = 0.0D;
/*    */   
/*    */ 
/*    */   public RangeNormalizer(double lowLimit, double highLimit)
/*    */   {
/* 16 */     this.lowLimit = lowLimit;
/* 17 */     this.highLimit = highLimit;
/*    */   }
/*    */   
/*    */   public void normalize(DataSet dataSet)
/*    */   {
/* 22 */     findMaxAndMinVectors(dataSet);
/*    */     
/* 24 */     for (org.neuroph.core.data.DataSetRow row : dataSet.getRows()) {
/* 25 */       double[] normalizedInput = normalizeToRange(row.getInput(), this.minIn, this.maxIn);
/* 26 */       row.setInput(normalizedInput);
/*    */       
/* 28 */       if (dataSet.isSupervised()) {
/* 29 */         double[] normalizedOutput = normalizeToRange(row.getDesiredOutput(), this.minOut, this.maxOut);
/* 30 */         row.setDesiredOutput(normalizedOutput);
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */   private double[] normalizeToRange(double[] vector, double[] min, double[] max)
/*    */   {
/* 38 */     double[] normalizedVector = new double[vector.length];
/*    */     
/* 40 */     for (int i = 0; i < vector.length; i++) {
/* 41 */       normalizedVector[i] = ((vector[i] - min[i]) / (max[i] - min[i]) * (this.highLimit - this.lowLimit) + this.lowLimit);
/*    */     }
/*    */     
/* 44 */     return normalizedVector;
/*    */   }
/*    */   
/*    */ 
/*    */   private void findMaxAndMinVectors(DataSet dataSet)
/*    */   {
/* 50 */     int inputSize = dataSet.getInputSize();
/* 51 */     int outputSize = dataSet.getOutputSize();
/*    */     
/* 53 */     this.maxIn = new double[inputSize];
/* 54 */     this.minIn = new double[inputSize];
/*    */     
/* 56 */     for (int i = 0; i < inputSize; i++) {
/* 57 */       this.maxIn[i] = Double.MIN_VALUE;
/* 58 */       this.minIn[i] = Double.MAX_VALUE;
/*    */     }
/*    */     
/* 61 */     this.maxOut = new double[outputSize];
/* 62 */     this.minOut = new double[outputSize];
/*    */     
/* 64 */     for (int i = 0; i < outputSize; i++) {
/* 65 */       this.maxOut[i] = Double.MIN_VALUE;
/* 66 */       this.minOut[i] = Double.MAX_VALUE;
/*    */     }
/*    */     
/* 69 */     for (org.neuroph.core.data.DataSetRow dataSetRow : dataSet.getRows()) {
/* 70 */       double[] input = dataSetRow.getInput();
/* 71 */       for (int i = 0; i < inputSize; i++) {
/* 72 */         if (input[i] > this.maxIn[i]) {
/* 73 */           this.maxIn[i] = input[i];
/*    */         }
/* 75 */         if (input[i] < this.minIn[i]) {
/* 76 */           this.minIn[i] = input[i];
/*    */         }
/*    */       }
/*    */       
/* 80 */       double[] output = dataSetRow.getDesiredOutput();
/* 81 */       for (int i = 0; i < outputSize; i++) {
/* 82 */         if (output[i] > this.maxOut[i]) {
/* 83 */           this.maxOut[i] = output[i];
/*    */         }
/* 85 */         if (output[i] < this.minOut[i]) {
/* 86 */           this.minOut[i] = output[i];
/*    */         }
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\util\data\norm\RangeNormalizer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */