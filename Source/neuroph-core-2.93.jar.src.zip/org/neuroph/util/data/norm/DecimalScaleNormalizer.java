/*     */ package org.neuroph.util.data.norm;
/*     */ 
/*     */ import org.neuroph.core.data.DataSet;
/*     */ import org.neuroph.core.data.DataSetRow;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DecimalScaleNormalizer
/*     */   implements Normalizer
/*     */ {
/*     */   private double[] maxIn;
/*     */   private double[] maxOut;
/*     */   private double[] scaleFactorIn;
/*     */   private double[] scaleFactorOut;
/*     */   
/*     */   public void normalize(DataSet dataSet)
/*     */   {
/*  35 */     findMaxVectors(dataSet);
/*  36 */     findScaleVectors();
/*     */     
/*  38 */     for (DataSetRow dataSetRow : dataSet.getRows()) {
/*  39 */       double[] normalizedInput = normalizeScale(dataSetRow.getInput(), this.scaleFactorIn);
/*  40 */       dataSetRow.setInput(normalizedInput);
/*     */       
/*  42 */       if (dataSet.isSupervised()) {
/*  43 */         double[] normalizedOutput = normalizeScale(dataSetRow.getDesiredOutput(), this.scaleFactorOut);
/*  44 */         dataSetRow.setDesiredOutput(normalizedOutput);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void findMaxVectors(DataSet dataSet)
/*     */   {
/*  55 */     int inputSize = dataSet.getInputSize();
/*  56 */     int outputSize = dataSet.getOutputSize();
/*     */     
/*  58 */     this.maxIn = new double[inputSize];
/*  59 */     for (int i = 0; i < inputSize; i++) {
/*  60 */       this.maxIn[i] = Double.MIN_VALUE;
/*     */     }
/*     */     
/*  63 */     this.maxOut = new double[outputSize];
/*  64 */     for (int i = 0; i < outputSize; i++) {
/*  65 */       this.maxOut[i] = Double.MIN_VALUE;
/*     */     }
/*     */     
/*  68 */     for (DataSetRow dataSetRow : dataSet.getRows()) {
/*  69 */       double[] input = dataSetRow.getInput();
/*  70 */       for (int i = 0; i < inputSize; i++) {
/*  71 */         if (input[i] > this.maxIn[i]) {
/*  72 */           this.maxIn[i] = input[i];
/*     */         }
/*     */       }
/*     */       
/*  76 */       double[] output = dataSetRow.getDesiredOutput();
/*  77 */       for (int i = 0; i < outputSize; i++) {
/*  78 */         if (output[i] > this.maxOut[i]) {
/*  79 */           this.maxOut[i] = output[i];
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void findScaleVectors()
/*     */   {
/*  87 */     this.scaleFactorIn = new double[this.maxIn.length];
/*  88 */     for (int i = 0; i < this.scaleFactorIn.length; i++) {
/*  89 */       this.scaleFactorIn[i] = 1.0D;
/*     */     }
/*     */     
/*  92 */     for (int i = 0; i < this.maxIn.length; i++) {
/*  93 */       while (this.maxIn[i] > 1.0D) {
/*  94 */         this.maxIn[i] /= 10.0D;
/*  95 */         this.scaleFactorIn[i] *= 10.0D;
/*     */       }
/*     */     }
/*     */     
/*  99 */     this.scaleFactorOut = new double[this.maxOut.length];
/* 100 */     for (int i = 0; i < this.scaleFactorOut.length; i++) {
/* 101 */       this.scaleFactorOut[i] = 1.0D;
/*     */     }
/*     */     
/* 104 */     for (int i = 0; i < this.maxOut.length; i++) {
/* 105 */       while (this.maxOut[i] > 1.0D) {
/* 106 */         this.maxOut[i] /= 10.0D;
/* 107 */         this.scaleFactorOut[i] *= 10.0D;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private double[] normalizeScale(double[] vector, double[] scaleFactor)
/*     */   {
/* 115 */     double[] normalizedVector = new double[vector.length];
/* 116 */     for (int i = 0; i < vector.length; i++) {
/* 117 */       vector[i] /= scaleFactor[i];
/*     */     }
/* 119 */     return normalizedVector;
/*     */   }
/*     */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\util\data\norm\DecimalScaleNormalizer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */