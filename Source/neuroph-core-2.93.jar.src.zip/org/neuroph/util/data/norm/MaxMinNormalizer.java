/*     */ package org.neuroph.util.data.norm;
/*     */ 
/*     */ import org.neuroph.core.data.DataSet;
/*     */ import org.neuroph.core.data.DataSetRow;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MaxMinNormalizer
/*     */   implements Normalizer
/*     */ {
/*     */   double[] maxIn;
/*     */   double[] maxOut;
/*     */   double[] minIn;
/*     */   double[] minOut;
/*     */   
/*     */   public void normalize(DataSet dataSet)
/*     */   {
/*  39 */     findMaxAndMinVectors(dataSet);
/*     */     
/*  41 */     for (DataSetRow row : dataSet.getRows()) {
/*  42 */       double[] normalizedInput = normalizeMaxMin(row.getInput(), this.minIn, this.maxIn);
/*  43 */       row.setInput(normalizedInput);
/*     */       
/*  45 */       if (dataSet.isSupervised()) {
/*  46 */         double[] normalizedOutput = normalizeMaxMin(row.getDesiredOutput(), this.minOut, this.maxOut);
/*  47 */         row.setDesiredOutput(normalizedOutput);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void findMaxAndMinVectors(DataSet dataSet)
/*     */   {
/*  54 */     int inputSize = dataSet.getInputSize();
/*  55 */     int outputSize = dataSet.getOutputSize();
/*     */     
/*  57 */     this.maxIn = new double[inputSize];
/*  58 */     this.minIn = new double[inputSize];
/*     */     
/*  60 */     for (int i = 0; i < inputSize; i++) {
/*  61 */       this.maxIn[i] = Double.MIN_VALUE;
/*  62 */       this.minIn[i] = Double.MAX_VALUE;
/*     */     }
/*     */     
/*  65 */     this.maxOut = new double[outputSize];
/*  66 */     this.minOut = new double[outputSize];
/*     */     
/*  68 */     for (int i = 0; i < outputSize; i++) {
/*  69 */       this.maxOut[i] = Double.MIN_VALUE;
/*  70 */       this.minOut[i] = Double.MAX_VALUE;
/*     */     }
/*     */     
/*  73 */     for (DataSetRow dataSetRow : dataSet.getRows()) {
/*  74 */       double[] input = dataSetRow.getInput();
/*  75 */       for (int i = 0; i < inputSize; i++) {
/*  76 */         if (input[i] > this.maxIn[i]) {
/*  77 */           this.maxIn[i] = input[i];
/*     */         }
/*  79 */         if (input[i] < this.minIn[i]) {
/*  80 */           this.minIn[i] = input[i];
/*     */         }
/*     */       }
/*     */       
/*  84 */       double[] output = dataSetRow.getDesiredOutput();
/*  85 */       for (int i = 0; i < outputSize; i++) {
/*  86 */         if (output[i] > this.maxOut[i]) {
/*  87 */           this.maxOut[i] = output[i];
/*     */         }
/*  89 */         if (output[i] < this.minOut[i]) {
/*  90 */           this.minOut[i] = output[i];
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private double[] normalizeMaxMin(double[] vector, double[] min, double[] max)
/*     */   {
/*  99 */     double[] normalizedVector = new double[vector.length];
/*     */     
/* 101 */     for (int i = 0; i < vector.length; i++) {
/* 102 */       normalizedVector[i] = ((vector[i] - min[i]) / (max[i] - min[i]));
/*     */     }
/*     */     
/* 105 */     return normalizedVector;
/*     */   }
/*     */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\util\data\norm\MaxMinNormalizer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */