/*     */ package org.neuroph.util.data.sample;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import org.neuroph.core.data.DataSet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SubSampling
/*     */   implements Sampling
/*     */ {
/*     */   private int subSetCount;
/*     */   private int[] subSetSizes;
/*  47 */   private boolean allowRepetition = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SubSampling(int subSetCount)
/*     */   {
/*  57 */     this.subSetCount = subSetCount;
/*  58 */     this.subSetSizes = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SubSampling(int... subSetSizes)
/*     */   {
/*  69 */     this.subSetSizes = subSetSizes;
/*  70 */     this.subSetCount = subSetSizes.length;
/*     */   }
/*     */   
/*     */ 
/*     */   public List<DataSet> sample(DataSet dataSet)
/*     */   {
/*  76 */     if (this.subSetSizes == null) {
/*  77 */       int singleSubSetSize = dataSet.size() / this.subSetCount;
/*  78 */       this.subSetSizes = new int[this.subSetCount];
/*  79 */       for (int i = 0; i < this.subSetCount; i++) {
/*  80 */         this.subSetSizes[i] = singleSubSetSize;
/*     */       }
/*     */     }
/*  83 */     List<DataSet> subSets = new ArrayList();
/*     */     
/*     */ 
/*  86 */     dataSet.shuffle();
/*     */     
/*  88 */     int inputSize = dataSet.getInputSize();
/*  89 */     int outputSize = dataSet.getOutputSize();
/*     */     
/*  91 */     int idxCounter = 0;
/*  92 */     for (int s = 0; s < this.subSetSizes.length; s++)
/*     */     {
/*  94 */       DataSet newSubSet = new DataSet(inputSize, outputSize);
/*     */       
/*     */ 
/*  97 */       if (!this.allowRepetition) {
/*  98 */         int itemCount = (int)(this.subSetSizes[s] / 100.0D * dataSet.size());
/*  99 */         for (int i = 0; i < itemCount; i++) {
/* 100 */           newSubSet.addRow(dataSet.getRowAt(idxCounter));
/* 101 */           idxCounter++;
/*     */         }
/*     */       }
/*     */       else {
/* 105 */         Random rand = new Random();
/* 106 */         for (int i = 0; i < this.subSetSizes[s] / 100 * dataSet.size(); i++) {
/* 107 */           int randomIdx = rand.nextInt(dataSet.size());
/* 108 */           newSubSet.addRow(dataSet.getRowAt(randomIdx));
/* 109 */           idxCounter++;
/*     */         }
/*     */       }
/*     */       
/* 113 */       subSets.add(newSubSet);
/*     */     }
/*     */     
/* 116 */     return subSets;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getAllowRepetition()
/*     */   {
/* 124 */     return this.allowRepetition;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAllowRepetition(boolean allowRepetition)
/*     */   {
/* 132 */     this.allowRepetition = allowRepetition;
/*     */   }
/*     */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\util\data\sample\SubSampling.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */