/*    */ package org.neuroph.util;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.neuroph.core.Layer;
/*    */ import org.neuroph.core.Neuron;
/*    */ import org.neuroph.core.transfer.TransferFunction;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LayerFactory
/*    */ {
/*    */   public static Layer createLayer(int neuronsCount, NeuronProperties neuronProperties)
/*    */   {
/* 43 */     Layer layer = new Layer(neuronsCount, neuronProperties);
/* 44 */     return layer;
/*    */   }
/*    */   
/*    */   public static Layer createLayer(int neuronsCount, TransferFunctionType transferFunctionType) {
/* 48 */     NeuronProperties neuronProperties = new NeuronProperties();
/* 49 */     neuronProperties.setProperty("transferFunction", transferFunctionType);
/* 50 */     Layer layer = new Layer(neuronsCount, neuronProperties);
/* 51 */     return layer;
/*    */   }
/*    */   
/*    */   public static Layer createLayer(int neuronsCount, Class<? extends TransferFunction> transferFunctionClass) {
/* 55 */     NeuronProperties neuronProperties = new NeuronProperties();
/* 56 */     neuronProperties.setProperty("transferFunction", transferFunctionClass);
/* 57 */     Layer layer = new Layer(neuronsCount, neuronProperties);
/* 58 */     return layer;
/*    */   }
/*    */   
/*    */   public static Layer createLayer(List<NeuronProperties> neuronPropertiesVector) {
/* 62 */     Layer layer = new Layer();
/*    */     
/* 64 */     for (NeuronProperties neuronProperties : neuronPropertiesVector) {
/* 65 */       Neuron neuron = NeuronFactory.createNeuron(neuronProperties);
/* 66 */       layer.addNeuron(neuron);
/*    */     }
/*    */     
/* 69 */     return layer;
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\util\LayerFactory.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */