/*     */ package org.neuroph.util.random;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import org.neuroph.core.Connection;
/*     */ import org.neuroph.core.Layer;
/*     */ import org.neuroph.core.NeuralNetwork;
/*     */ import org.neuroph.core.Neuron;
/*     */ import org.neuroph.core.Weight;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WeightsRandomizer
/*     */ {
/*     */   protected Random randomGenerator;
/*     */   
/*     */   public WeightsRandomizer()
/*     */   {
/*  46 */     this.randomGenerator = new Random();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public WeightsRandomizer(Random randomGenerator)
/*     */   {
/*  56 */     this.randomGenerator = randomGenerator;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Random getRandomGenerator()
/*     */   {
/*  65 */     return this.randomGenerator;
/*     */   }
/*     */   
/*     */   public void setRandomGenerator(Random randomGenerator) {
/*  69 */     this.randomGenerator = randomGenerator;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void randomize(NeuralNetwork<?> neuralNetwork)
/*     */   {
/*  80 */     for (Layer layer : neuralNetwork.getLayers()) {
/*  81 */       randomize(layer);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void randomize(Layer layer)
/*     */   {
/*  91 */     for (Neuron neuron : layer.getNeurons()) {
/*  92 */       randomize(neuron);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void randomize(Neuron neuron)
/*     */   {
/* 102 */     int numberOfInputConnections = neuron.getInputConnections().size();
/* 103 */     double coefficient = 1.0D / Math.sqrt(numberOfInputConnections);
/* 104 */     coefficient = coefficient == 0.0D ? 1.0D : coefficient;
/* 105 */     for (Connection connection : neuron.getInputConnections())
/*     */     {
/* 107 */       connection.getWeight().setValue(nextRandomWeight());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected double nextRandomWeight()
/*     */   {
/* 118 */     return this.randomGenerator.nextDouble();
/*     */   }
/*     */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\util\random\WeightsRandomizer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */