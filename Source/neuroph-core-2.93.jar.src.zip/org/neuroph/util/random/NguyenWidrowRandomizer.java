/*    */ package org.neuroph.util.random;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.neuroph.core.Connection;
/*    */ import org.neuroph.core.Layer;
/*    */ import org.neuroph.core.NeuralNetwork;
/*    */ import org.neuroph.core.Neuron;
/*    */ import org.neuroph.core.Weight;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NguyenWidrowRandomizer
/*    */   extends RangeRandomizer
/*    */ {
/*    */   public NguyenWidrowRandomizer(double min, double max)
/*    */   {
/* 34 */     super(min, max);
/*    */   }
/*    */   
/*    */   public void randomize(NeuralNetwork neuralNetwork)
/*    */   {
/* 39 */     super.randomize(neuralNetwork);
/*    */     
/* 41 */     int inputNeuronsCount = neuralNetwork.getInputNeurons().size();
/* 42 */     int hiddenNeuronsCount = 0;
/*    */     
/* 44 */     for (int i = 1; i < neuralNetwork.getLayersCount() - 1; i++) {
/* 45 */       hiddenNeuronsCount += neuralNetwork.getLayerAt(i).getNeuronsCount();
/*    */     }
/*    */     
/* 48 */     double beta = 0.7D * Math.pow(hiddenNeuronsCount, 1.0D / inputNeuronsCount);
/*    */     
/* 50 */     List<Layer> layers = neuralNetwork.getLayers();
/* 51 */     for (Layer layer : layers)
/*    */     {
/* 53 */       norm = 0.0D;
/* 54 */       for (Neuron neuron : layer.getNeurons()) {
/* 55 */         for (Connection connection : neuron.getInputConnections()) {
/* 56 */           double weight = connection.getWeight().getValue();
/* 57 */           norm += weight * weight;
/*    */         }
/*    */       }
/* 60 */       norm = Math.sqrt(norm);
/*    */       
/*    */ 
/* 63 */       for (Neuron neuron : layer.getNeurons()) {
/* 64 */         for (Connection connection : neuron.getInputConnections()) {
/* 65 */           double weight = connection.getWeight().getValue();
/* 66 */           weight = beta * weight / norm;
/* 67 */           connection.getWeight().setValue(weight);
/*    */         }
/*    */       }
/*    */     }
/*    */     double norm;
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\util\random\NguyenWidrowRandomizer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */