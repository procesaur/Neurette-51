/*    */ package org.neuroph.util.random;
/*    */ 
/*    */ import java.util.Random;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RangeRandomizer
/*    */   extends WeightsRandomizer
/*    */ {
/*    */   protected double min;
/*    */   protected double max;
/*    */   
/*    */   public RangeRandomizer(double min, double max)
/*    */   {
/* 42 */     this.max = max;
/* 43 */     this.min = min;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected double nextRandomWeight()
/*    */   {
/* 52 */     return this.min + this.randomGenerator.nextDouble() * (this.max - this.min);
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\util\random\RangeRandomizer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */