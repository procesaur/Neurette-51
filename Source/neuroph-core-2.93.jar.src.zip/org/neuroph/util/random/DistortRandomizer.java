/*    */ package org.neuroph.util.random;
/*    */ 
/*    */ import java.util.Random;
/*    */ import org.neuroph.core.Connection;
/*    */ import org.neuroph.core.Neuron;
/*    */ import org.neuroph.core.Weight;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DistortRandomizer
/*    */   extends WeightsRandomizer
/*    */ {
/*    */   double distortionFactor;
/*    */   
/*    */   public DistortRandomizer(double distortionFactor)
/*    */   {
/* 42 */     this.distortionFactor = distortionFactor;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void randomize(Neuron neuron)
/*    */   {
/* 68 */     for (Connection connection : neuron.getInputConnections()) {
/* 69 */       double weight = connection.getWeight().getValue();
/* 70 */       connection.getWeight().setValue(distort(weight));
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private double distort(double weight)
/*    */   {
/* 81 */     return weight + (this.distortionFactor - this.randomGenerator.nextDouble() * this.distortionFactor * 2.0D);
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\util\random\DistortRandomizer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */