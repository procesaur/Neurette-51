/*    */ package org.neuroph.util.random;
/*    */ 
/*    */ import java.util.Random;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GaussianRandomizer
/*    */   extends WeightsRandomizer
/*    */ {
/*    */   double mean;
/*    */   double standardDeviation;
/*    */   private double y2;
/* 37 */   private boolean useLast = false;
/*    */   
/*    */   public GaussianRandomizer(double mean, double standardDeviation) {
/* 40 */     this.mean = mean;
/* 41 */     this.standardDeviation = standardDeviation;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private double boxMuller(double mean, double std)
/*    */   {
/*    */     double y1;
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 57 */     if (this.useLast) {
/* 58 */       double y1 = this.y2;
/* 59 */       this.useLast = false;
/*    */     } else { double x1;
/*    */       double x2;
/* 62 */       do { x1 = 2.0D * this.randomGenerator.nextDouble() - 1.0D;
/* 63 */         x2 = 2.0D * this.randomGenerator.nextDouble() - 1.0D;
/* 64 */         w = x1 * x1 + x2 * x2;
/* 65 */       } while (w >= 1.0D);
/*    */       
/* 67 */       double w = Math.sqrt(-2.0D * Math.log(w) / w);
/* 68 */       y1 = x1 * w;
/* 69 */       this.y2 = (x2 * w);
/* 70 */       this.useLast = true;
/*    */     }
/*    */     
/* 73 */     return mean + y1 * std;
/*    */   }
/*    */   
/*    */   protected double nextRandomWeight()
/*    */   {
/* 78 */     return boxMuller(this.mean, this.standardDeviation);
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\util\random\GaussianRandomizer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */