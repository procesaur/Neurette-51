/*    */ package org.neuroph.util;
/*    */ 
/*    */ import org.neuroph.core.transfer.Gaussian;
/*    */ import org.neuroph.core.transfer.Linear;
/*    */ import org.neuroph.core.transfer.Log;
/*    */ import org.neuroph.core.transfer.Ramp;
/*    */ import org.neuroph.core.transfer.Sgn;
/*    */ import org.neuroph.core.transfer.Sigmoid;
/*    */ import org.neuroph.core.transfer.Sin;
/*    */ import org.neuroph.core.transfer.Step;
/*    */ import org.neuroph.core.transfer.Tanh;
/*    */ import org.neuroph.core.transfer.Trapezoid;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum TransferFunctionType
/*    */ {
/* 34 */   LINEAR("Linear"), 
/* 35 */   RAMP("Ramp"), 
/* 36 */   STEP("Step"), 
/* 37 */   SIGMOID("Sigmoid"), 
/* 38 */   TANH("Tanh"), 
/* 39 */   GAUSSIAN("Gaussian"), 
/* 40 */   TRAPEZOID("Trapezoid"), 
/* 41 */   SGN("Sgn"), 
/* 42 */   SIN("Sin"), 
/* 43 */   LOG("Log");
/*    */   
/*    */   private String typeLabel;
/*    */   
/*    */   private TransferFunctionType(String typeLabel) {
/* 48 */     this.typeLabel = typeLabel;
/*    */   }
/*    */   
/*    */   public String getTypeLabel() {
/* 52 */     return this.typeLabel;
/*    */   }
/*    */   
/*    */   public Class getTypeClass() {
/* 56 */     switch (this) {
/*    */     case LINEAR: 
/* 58 */       return Linear.class;
/*    */     case STEP: 
/* 60 */       return Step.class;
/*    */     case RAMP: 
/* 62 */       return Ramp.class;
/*    */     case SIGMOID: 
/* 64 */       return Sigmoid.class;
/*    */     case TANH: 
/* 66 */       return Tanh.class;
/*    */     case TRAPEZOID: 
/* 68 */       return Trapezoid.class;
/*    */     case GAUSSIAN: 
/* 70 */       return Gaussian.class;
/*    */     case SGN: 
/* 72 */       return Sgn.class;
/*    */     case SIN: 
/* 74 */       return Sin.class;
/*    */     case LOG: 
/* 76 */       return Log.class;
/*    */     }
/*    */     
/* 79 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\util\TransferFunctionType.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */