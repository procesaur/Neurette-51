/*    */ package org.neuroph.util;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Properties
/*    */   extends HashMap
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   protected void createKeys(String... keys)
/*    */   {
/* 30 */     for (int i = 0; i < keys.length; i++) {
/* 31 */       put(keys[i], "");
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */   public void setProperty(String key, Object value)
/*    */   {
/* 38 */     put(key, value);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public Object getProperty(String key)
/*    */   {
/* 45 */     return get(key);
/*    */   }
/*    */   
/*    */   public boolean hasProperty(String key) {
/* 49 */     return containsKey(key);
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\util\Properties.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */