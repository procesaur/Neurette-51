/*    */ package org.neuroph.util.benchmark;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BenchmarkSample
/*    */ {
/*    */   public static void main(String[] args)
/*    */   {
/* 27 */     BenchmarkTask task1 = new MyBenchmarkTask("MyFirstBenchmark");
/*    */     
/* 29 */     task1.setWarmupIterations(1);
/*    */     
/* 31 */     task1.setTestIterations(1);
/*    */     
/*    */ 
/* 34 */     Benchmark benchmark = new Benchmark();
/*    */     
/* 36 */     benchmark.addTask(task1);
/*    */     
/* 38 */     benchmark.run();
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\util\benchmark\BenchmarkSample.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */