/*    */ package org.neuroph.util.benchmark;
/*    */ 
/*    */ import org.neuroph.core.data.DataSet;
/*    */ import org.neuroph.core.data.DataSetRow;
/*    */ import org.neuroph.nnet.MultiLayerPerceptron;
/*    */ import org.neuroph.nnet.learning.MomentumBackpropagation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MyBenchmarkTask
/*    */   extends BenchmarkTask
/*    */ {
/*    */   private MultiLayerPerceptron network;
/*    */   private DataSet trainingSet;
/*    */   
/*    */   public MyBenchmarkTask(String name)
/*    */   {
/* 35 */     super(name);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void prepareTest()
/*    */   {
/* 45 */     int trainingSetSize = 100;
/* 46 */     int inputSize = 10;
/* 47 */     int outputSize = 5;
/*    */     
/* 49 */     this.trainingSet = new DataSet(inputSize, outputSize);
/*    */     
/* 51 */     for (int i = 0; i < trainingSetSize; i++) {
/* 52 */       double[] input = new double[inputSize];
/* 53 */       for (int j = 0; j < inputSize; j++) {
/* 54 */         input[j] = Math.random();
/*    */       }
/* 56 */       double[] output = new double[outputSize];
/* 57 */       for (int j = 0; j < outputSize; j++) {
/* 58 */         output[j] = Math.random();
/*    */       }
/* 60 */       DataSetRow trainingSetRow = new DataSetRow(input, output);
/* 61 */       this.trainingSet.addRow(trainingSetRow);
/*    */     }
/*    */     
/*    */ 
/* 65 */     this.network = new MultiLayerPerceptron(new int[] { inputSize, 8, 7, outputSize });
/* 66 */     ((MomentumBackpropagation)this.network.getLearningRule()).setMaxIterations(2000);
/*    */   }
/*    */   
/*    */ 
/*    */   public void runTest()
/*    */   {
/* 72 */     this.network.learn(this.trainingSet);
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\util\benchmark\MyBenchmarkTask.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */