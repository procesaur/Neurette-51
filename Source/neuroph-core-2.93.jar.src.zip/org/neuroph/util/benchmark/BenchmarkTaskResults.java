/*     */ package org.neuroph.util.benchmark;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BenchmarkTaskResults
/*     */ {
/*     */   int testIterations;
/*     */   
/*     */ 
/*     */ 
/*     */   long[] elapsedTimes;
/*     */   
/*     */ 
/*     */ 
/*     */   int timesCounter;
/*     */   
/*     */ 
/*     */ 
/*     */   double averageTestTime;
/*     */   
/*     */ 
/*     */   double standardDeviation;
/*     */   
/*     */ 
/*     */   double minTestTime;
/*     */   
/*     */ 
/*     */   double maxTestTime;
/*     */   
/*     */ 
/*     */ 
/*     */   public BenchmarkTaskResults(int testIterations)
/*     */   {
/*  35 */     this.testIterations = testIterations;
/*  36 */     this.elapsedTimes = new long[testIterations];
/*  37 */     this.timesCounter = 0;
/*     */   }
/*     */   
/*     */   public double getAverageTestTime() {
/*  41 */     return this.averageTestTime;
/*     */   }
/*     */   
/*     */   public long[] getElapsedTimes() {
/*  45 */     return this.elapsedTimes;
/*     */   }
/*     */   
/*     */   public double getMaxTestTime() {
/*  49 */     return this.maxTestTime;
/*     */   }
/*     */   
/*     */   public double getMinTestTime() {
/*  53 */     return this.minTestTime;
/*     */   }
/*     */   
/*     */   public double getStandardDeviation() {
/*  57 */     return this.standardDeviation;
/*     */   }
/*     */   
/*     */   public int getTestIterations() {
/*  61 */     return this.testIterations;
/*     */   }
/*     */   
/*     */   public void addElapsedTime(long time) {
/*  65 */     this.elapsedTimes[(this.timesCounter++)] = time;
/*     */   }
/*     */   
/*     */   public void calculateStatistics()
/*     */   {
/*  70 */     this.minTestTime = this.elapsedTimes[0];
/*  71 */     this.maxTestTime = this.elapsedTimes[0];
/*  72 */     long sum = 0L;
/*     */     
/*  74 */     for (int i = 0; i < this.timesCounter; i++) {
/*  75 */       sum += this.elapsedTimes[i];
/*  76 */       if (this.elapsedTimes[i] < this.minTestTime) {
/*  77 */         this.minTestTime = this.elapsedTimes[i];
/*     */       }
/*  79 */       if (this.elapsedTimes[i] > this.maxTestTime) {
/*  80 */         this.maxTestTime = this.elapsedTimes[i];
/*     */       }
/*     */     }
/*     */     
/*  84 */     this.averageTestTime = (sum / this.timesCounter);
/*     */     
/*     */ 
/*  87 */     long sqrSum = 0L;
/*     */     
/*  89 */     for (int i = 0; i < this.timesCounter; i++) {
/*  90 */       sqrSum = (sqrSum + (this.elapsedTimes[i] - this.averageTestTime) * (this.elapsedTimes[i] - this.averageTestTime));
/*     */     }
/*     */     
/*  93 */     this.standardDeviation = Math.sqrt(sqrSum / this.timesCounter);
/*     */   }
/*     */   
/*     */   public String toString() {
/*  97 */     String results = "Test iterations: " + this.testIterations + "\n" + "Min time: " + this.minTestTime + " ms\n" + "Max time: " + this.maxTestTime + " ms\n" + "Average time: " + this.averageTestTime + " ms\n" + "Std. deviation: " + this.standardDeviation + "\n";
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 103 */     results = results + "Test times:\n";
/*     */     
/* 105 */     for (int i = 0; i < this.timesCounter; i++) {
/* 106 */       results = results + (i + 1) + ". iteration: " + this.elapsedTimes[i] + "ms\n";
/*     */     }
/* 108 */     return results;
/*     */   }
/*     */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\util\benchmark\BenchmarkTaskResults.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */