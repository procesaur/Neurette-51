/*    */ package org.neuroph.util.benchmark;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Stopwatch
/*    */ {
/* 25 */   private long startTime = -1L;
/* 26 */   private long stopTime = -1L;
/* 27 */   private boolean running = false;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void start()
/*    */   {
/* 38 */     this.startTime = System.currentTimeMillis();
/* 39 */     this.running = true;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void stop()
/*    */   {
/* 46 */     this.stopTime = System.currentTimeMillis();
/* 47 */     this.running = false;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public long getElapsedTime()
/*    */   {
/* 55 */     if (this.startTime == -1L) {
/* 56 */       return 0L;
/*    */     }
/* 58 */     if (this.running) {
/* 59 */       return System.currentTimeMillis() - this.startTime;
/*    */     }
/* 61 */     return this.stopTime - this.startTime;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void reset()
/*    */   {
/* 69 */     this.startTime = -1L;
/* 70 */     this.stopTime = -1L;
/* 71 */     this.running = false;
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\util\benchmark\Stopwatch.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */