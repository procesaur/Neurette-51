/*    */ package org.neuroph.util.benchmark;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ import java.util.ArrayList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Benchmark
/*    */ {
/*    */   ArrayList<BenchmarkTask> tasks;
/*    */   
/*    */   public Benchmark()
/*    */   {
/* 32 */     this.tasks = new ArrayList();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void addTask(BenchmarkTask task)
/*    */   {
/* 40 */     this.tasks.add(task);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static void runTask(BenchmarkTask task)
/*    */   {
/* 50 */     System.out.println("Preparing task " + task.getName());
/* 51 */     task.prepareTest();
/*    */     
/* 53 */     System.out.println("Warming up " + task.getName());
/* 54 */     for (int i = 0; i < task.getWarmupIterations(); i++) {
/* 55 */       task.runTest();
/*    */     }
/*    */     
/* 58 */     System.out.println("Runing " + task.getName());
/*    */     
/*    */ 
/* 61 */     Stopwatch timer = new Stopwatch();
/* 62 */     BenchmarkTaskResults results = new BenchmarkTaskResults(task.getTestIterations());
/*    */     
/* 64 */     for (int i = 0; i < task.getTestIterations(); i++) {
/* 65 */       timer.reset();
/*    */       
/* 67 */       timer.start();
/* 68 */       task.runTest();
/* 69 */       timer.stop();
/*    */       
/* 71 */       results.addElapsedTime(timer.getElapsedTime());
/*    */     }
/*    */     
/* 74 */     results.calculateStatistics();
/* 75 */     System.out.println(task.getName() + " results");
/* 76 */     System.out.println(results);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void run()
/*    */   {
/* 83 */     for (int i = 0; i < this.tasks.size(); i++) {
/* 84 */       runTask((BenchmarkTask)this.tasks.get(i));
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\util\benchmark\Benchmark.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */