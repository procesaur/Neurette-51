/*    */ package org.neuroph.util.benchmark;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class BenchmarkTask
/*    */ {
/*    */   private String name;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 26 */   private int warmupIterations = 1;
/* 27 */   private int testIterations = 1;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public BenchmarkTask(String name)
/*    */   {
/* 34 */     this.name = name;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getName()
/*    */   {
/* 42 */     return this.name;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setName(String name)
/*    */   {
/* 50 */     this.name = name;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public int getTestIterations()
/*    */   {
/* 58 */     return this.testIterations;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setTestIterations(int testIterations)
/*    */   {
/* 66 */     this.testIterations = testIterations;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public int getWarmupIterations()
/*    */   {
/* 75 */     return this.warmupIterations;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setWarmupIterations(int warmupIterations)
/*    */   {
/* 84 */     this.warmupIterations = warmupIterations;
/*    */   }
/*    */   
/*    */   public abstract void prepareTest();
/*    */   
/*    */   public abstract void runTest();
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\util\benchmark\BenchmarkTask.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */