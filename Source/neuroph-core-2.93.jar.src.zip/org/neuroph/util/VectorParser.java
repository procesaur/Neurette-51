/*    */ package org.neuroph.util;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import java.util.StringTokenizer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class VectorParser
/*    */ {
/*    */   public static ArrayList<Integer> parseInteger(String str)
/*    */   {
/* 39 */     StringTokenizer tok = new StringTokenizer(str);
/* 40 */     ArrayList<Integer> ret = new ArrayList();
/* 41 */     while (tok.hasMoreTokens()) {
/* 42 */       Integer d = Integer.valueOf(tok.nextToken());
/* 43 */       ret.add(d);
/*    */     }
/* 45 */     return ret;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static double[] parseDoubleArray(String inputStr)
/*    */   {
/* 56 */     String[] inputsArrStr = inputStr.split(" ");
/*    */     
/* 58 */     double[] ret = new double[inputsArrStr.length];
/* 59 */     for (int i = 0; i < inputsArrStr.length; i++) {
/* 60 */       ret[i] = Double.parseDouble(inputsArrStr[i]);
/*    */     }
/*    */     
/* 63 */     return ret;
/*    */   }
/*    */   
/*    */   public static double[] toDoubleArray(List<Double> list) {
/* 67 */     double[] ret = new double[list.size()];
/* 68 */     for (int i = 0; i < list.size(); i++) {
/* 69 */       ret[i] = ((Double)list.get(i)).doubleValue();
/*    */     }
/* 71 */     return ret;
/*    */   }
/*    */   
/*    */   public static ArrayList<Double> convertToVector(double[] array) {
/* 75 */     ArrayList<Double> vector = new ArrayList(array.length);
/*    */     
/* 77 */     for (double val : array) {
/* 78 */       vector.add(Double.valueOf(val));
/*    */     }
/*    */     
/* 81 */     return vector;
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\util\VectorParser.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */