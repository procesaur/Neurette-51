/*     */ package org.neuroph.util;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.neuroph.core.Layer;
/*     */ import org.neuroph.core.NeuralNetwork;
/*     */ import org.neuroph.core.Neuron;
/*     */ import org.neuroph.nnet.Adaline;
/*     */ import org.neuroph.nnet.BAM;
/*     */ import org.neuroph.nnet.CompetitiveNetwork;
/*     */ import org.neuroph.nnet.Hopfield;
/*     */ import org.neuroph.nnet.Instar;
/*     */ import org.neuroph.nnet.Kohonen;
/*     */ import org.neuroph.nnet.MaxNet;
/*     */ import org.neuroph.nnet.MultiLayerPerceptron;
/*     */ import org.neuroph.nnet.Outstar;
/*     */ import org.neuroph.nnet.Perceptron;
/*     */ import org.neuroph.nnet.RBFNetwork;
/*     */ import org.neuroph.nnet.SupervisedHebbianNetwork;
/*     */ import org.neuroph.nnet.UnsupervisedHebbianNetwork;
/*     */ import org.neuroph.nnet.comp.neuron.BiasNeuron;
/*     */ import org.neuroph.nnet.learning.BackPropagation;
/*     */ import org.neuroph.nnet.learning.BinaryDeltaRule;
/*     */ import org.neuroph.nnet.learning.DynamicBackPropagation;
/*     */ import org.neuroph.nnet.learning.MomentumBackpropagation;
/*     */ import org.neuroph.nnet.learning.PerceptronLearning;
/*     */ import org.neuroph.nnet.learning.ResilientPropagation;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NeuralNetworkFactory
/*     */ {
/*     */   public static Adaline createAdaline(int inputsCount)
/*     */   {
/*  57 */     Adaline nnet = new Adaline(inputsCount);
/*  58 */     return nnet;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Perceptron createPerceptron(int inputNeuronsCount, int outputNeuronsCount, TransferFunctionType transferFunctionType)
/*     */   {
/*  70 */     Perceptron nnet = new Perceptron(inputNeuronsCount, outputNeuronsCount, transferFunctionType);
/*  71 */     return nnet;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Perceptron createPerceptron(int inputNeuronsCount, int outputNeuronsCount, TransferFunctionType transferFunctionType, Class learningRule)
/*     */   {
/*  83 */     Perceptron nnet = new Perceptron(inputNeuronsCount, outputNeuronsCount, transferFunctionType);
/*     */     
/*  85 */     if (learningRule.getName().equals(PerceptronLearning.class.getName())) {
/*  86 */       nnet.setLearningRule(new PerceptronLearning());
/*  87 */     } else if (learningRule.getName().equals(BinaryDeltaRule.class.getName())) {
/*  88 */       nnet.setLearningRule(new BinaryDeltaRule());
/*     */     }
/*     */     
/*  91 */     return nnet;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static MultiLayerPerceptron createMLPerceptron(String layersStr, TransferFunctionType transferFunctionType)
/*     */   {
/* 101 */     ArrayList<Integer> layerSizes = VectorParser.parseInteger(layersStr);
/* 102 */     MultiLayerPerceptron nnet = new MultiLayerPerceptron(layerSizes, transferFunctionType);
/*     */     
/* 104 */     return nnet;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static MultiLayerPerceptron createMLPerceptron(String layersStr, TransferFunctionType transferFunctionType, Class learningRule, boolean useBias, boolean connectIO)
/*     */   {
/* 114 */     ArrayList<Integer> layerSizes = VectorParser.parseInteger(layersStr);
/* 115 */     NeuronProperties neuronProperties = new NeuronProperties(transferFunctionType, useBias);
/* 116 */     MultiLayerPerceptron nnet = new MultiLayerPerceptron(layerSizes, neuronProperties);
/*     */     
/*     */ 
/* 119 */     if (learningRule.getName().equals(BackPropagation.class.getName())) {
/* 120 */       nnet.setLearningRule(new BackPropagation());
/* 121 */     } else if (learningRule.getName().equals(MomentumBackpropagation.class.getName())) {
/* 122 */       nnet.setLearningRule(new MomentumBackpropagation());
/* 123 */     } else if (learningRule.getName().equals(DynamicBackPropagation.class.getName())) {
/* 124 */       nnet.setLearningRule(new DynamicBackPropagation());
/* 125 */     } else if (learningRule.getName().equals(ResilientPropagation.class.getName())) {
/* 126 */       nnet.setLearningRule(new ResilientPropagation());
/*     */     }
/*     */     
/*     */ 
/* 130 */     if (connectIO) {
/* 131 */       nnet.connectInputsToOutputs();
/*     */     }
/*     */     
/* 134 */     return nnet;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Hopfield createHopfield(int neuronsCount)
/*     */   {
/* 143 */     Hopfield nnet = new Hopfield(neuronsCount);
/* 144 */     return nnet;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static BAM createBam(int inputNeuronsCount, int outputNeuronsCount)
/*     */   {
/* 154 */     BAM nnet = new BAM(inputNeuronsCount, outputNeuronsCount);
/* 155 */     return nnet;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Kohonen createKohonen(int inputNeuronsCount, int outputNeuronsCount)
/*     */   {
/* 165 */     Kohonen nnet = new Kohonen(inputNeuronsCount, outputNeuronsCount);
/* 166 */     return nnet;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static SupervisedHebbianNetwork createSupervisedHebbian(int inputNeuronsCount, int outputNeuronsCount, TransferFunctionType transferFunctionType)
/*     */   {
/* 178 */     SupervisedHebbianNetwork nnet = new SupervisedHebbianNetwork(inputNeuronsCount, outputNeuronsCount, transferFunctionType);
/*     */     
/* 180 */     return nnet;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static UnsupervisedHebbianNetwork createUnsupervisedHebbian(int inputNeuronsCount, int outputNeuronsCount, TransferFunctionType transferFunctionType)
/*     */   {
/* 192 */     UnsupervisedHebbianNetwork nnet = new UnsupervisedHebbianNetwork(inputNeuronsCount, outputNeuronsCount, transferFunctionType);
/*     */     
/* 194 */     return nnet;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static MaxNet createMaxNet(int neuronsCount)
/*     */   {
/* 203 */     MaxNet nnet = new MaxNet(neuronsCount);
/* 204 */     return nnet;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Instar createInstar(int inputNeuronsCount)
/*     */   {
/* 213 */     Instar nnet = new Instar(inputNeuronsCount);
/* 214 */     return nnet;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Outstar createOutstar(int outputNeuronsCount)
/*     */   {
/* 223 */     Outstar nnet = new Outstar(outputNeuronsCount);
/* 224 */     return nnet;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static CompetitiveNetwork createCompetitiveNetwork(int inputNeuronsCount, int outputNeuronsCount)
/*     */   {
/* 235 */     CompetitiveNetwork nnet = new CompetitiveNetwork(inputNeuronsCount, outputNeuronsCount);
/* 236 */     return nnet;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static RBFNetwork createRbfNetwork(int inputNeuronsCount, int rbfNeuronsCount, int outputNeuronsCount)
/*     */   {
/* 248 */     RBFNetwork nnet = new RBFNetwork(inputNeuronsCount, rbfNeuronsCount, outputNeuronsCount);
/*     */     
/* 250 */     return nnet;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void setDefaultIO(NeuralNetwork nnet)
/*     */   {
/* 258 */     ArrayList<Neuron> inputNeuronsList = new ArrayList();
/* 259 */     Layer firstLayer = nnet.getLayerAt(0);
/* 260 */     for (Neuron neuron : firstLayer.getNeurons()) {
/* 261 */       if (!(neuron instanceof BiasNeuron)) {
/* 262 */         inputNeuronsList.add(neuron);
/*     */       }
/*     */     }
/*     */     
/* 266 */     Object outputNeurons = nnet.getLayerAt(nnet.getLayersCount() - 1).getNeurons();
/*     */     
/* 268 */     nnet.setInputNeurons(inputNeuronsList);
/* 269 */     nnet.setOutputNeurons((List)outputNeurons);
/*     */   }
/*     */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\util\NeuralNetworkFactory.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */