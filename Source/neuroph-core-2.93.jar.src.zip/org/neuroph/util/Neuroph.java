/*     */ package org.neuroph.util;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.net.URL;
/*     */ import java.net.URLDecoder;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Enumeration;
/*     */ import java.util.jar.JarEntry;
/*     */ import java.util.jar.JarFile;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Neuroph
/*     */ {
/*     */   private static Neuroph instance;
/*  28 */   private boolean flattenNetworks = false;
/*     */   
/*     */   public static Neuroph getInstance() {
/*  31 */     if (instance == null)
/*  32 */       instance = new Neuroph();
/*  33 */     return instance;
/*     */   }
/*     */   
/*     */   public static String getVersion() {
/*  37 */     return "2.8";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean shouldFlattenNetworks()
/*     */   {
/*  44 */     return this.flattenNetworks;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFlattenNetworks(boolean flattenNetworks)
/*     */   {
/*  52 */     this.flattenNetworks = flattenNetworks;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void shutdown() {}
/*     */   
/*     */ 
/*     */   public ArrayList<String> getInputFunctions()
/*     */   {
/*     */     try
/*     */     {
/*  64 */       ArrayList classes = getClassNamesFromPackage("org.neuroph.core.input");
/*  65 */       classes.remove("InputFunction");
/*  66 */       return classes;
/*     */     } catch (IOException ex) {
/*  68 */       Logger.getLogger(Neuroph.class.getName()).log(Level.SEVERE, null, ex); }
/*  69 */     return null;
/*     */   }
/*     */   
/*     */   public ArrayList<String> getTransferFunctions()
/*     */   {
/*     */     try {
/*  75 */       ArrayList classes = getClassNamesFromPackage("org.neuroph.core.transfer");
/*  76 */       classes.remove("TransferFunction");
/*  77 */       return classes;
/*     */     } catch (IOException ex) {
/*  79 */       Logger.getLogger(Neuroph.class.getName()).log(Level.SEVERE, null, ex); }
/*  80 */     return null;
/*     */   }
/*     */   
/*     */   public ArrayList<String> getNeurons()
/*     */   {
/*     */     try {
/*  86 */       ArrayList classes = getClassNamesFromPackage("org.neuroph.nnet.comp.neuron");
/*  87 */       classes.add(0, "Neuron");
/*  88 */       return classes;
/*     */     } catch (IOException ex) {
/*  90 */       Logger.getLogger(Neuroph.class.getName()).log(Level.SEVERE, null, ex); }
/*  91 */     return null;
/*     */   }
/*     */   
/*     */   public ArrayList<String> getLayers()
/*     */   {
/*     */     try {
/*  97 */       ArrayList classes = getClassNamesFromPackage("org.neuroph.nnet.comp.layer");
/*  98 */       classes.add(0, "Layer");
/*  99 */       return classes;
/*     */     } catch (IOException ex) {
/* 101 */       Logger.getLogger(Neuroph.class.getName()).log(Level.SEVERE, null, ex); }
/* 102 */     return null;
/*     */   }
/*     */   
/*     */   public ArrayList<String> getLearningRules()
/*     */   {
/*     */     try {
/* 108 */       return getClassNamesFromPackage("org.neuroph.nnet.learning");
/*     */     }
/*     */     catch (IOException ex) {
/* 111 */       Logger.getLogger(Neuroph.class.getName()).log(Level.SEVERE, null, ex); }
/* 112 */     return null;
/*     */   }
/*     */   
/*     */   private static ArrayList<String> getClassNamesFromPackage(String packageName) throws IOException
/*     */   {
/* 117 */     ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
/*     */     
/* 119 */     ArrayList<String> names = new ArrayList();
/*     */     
/* 121 */     packageName = packageName.replace(".", "/");
/* 122 */     URL packageURL = classLoader.getResource(packageName);
/*     */     String entryName;
/* 124 */     if (packageURL.getProtocol().equals("jar"))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 131 */       String jarFileName = URLDecoder.decode(packageURL.getFile(), "UTF-8");
/* 132 */       jarFileName = jarFileName.substring(5, jarFileName.indexOf("!"));
/*     */       
/* 134 */       JarFile jf = new JarFile(jarFileName);
/* 135 */       Enumeration<JarEntry> jarEntries = jf.entries();
/* 136 */       while (jarEntries.hasMoreElements()) {
/* 137 */         entryName = ((JarEntry)jarEntries.nextElement()).getName();
/* 138 */         if ((entryName.startsWith(packageName)) && (entryName.length() > packageName.length() + 5)) {
/* 139 */           entryName = entryName.substring(packageName.length(), entryName.lastIndexOf('.'));
/* 140 */           names.add(entryName.substring(1));
/*     */         }
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 146 */       File folder = new File(packageURL.getFile());
/* 147 */       File[] contenuti = folder.listFiles();
/*     */       
/* 149 */       for (File actual : contenuti) {
/* 150 */         String entryName = actual.getName();
/* 151 */         entryName = entryName.substring(0, entryName.lastIndexOf('.'));
/* 152 */         names.add(entryName);
/*     */       }
/*     */     }
/* 155 */     return names;
/*     */   }
/*     */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\util\Neuroph.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */