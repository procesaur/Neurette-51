/*     */ package org.neuroph.util;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import org.neuroph.core.Neuron;
/*     */ import org.neuroph.core.exceptions.NeurophException;
/*     */ import org.neuroph.core.input.InputFunction;
/*     */ import org.neuroph.core.transfer.TransferFunction;
/*     */ import org.neuroph.nnet.comp.neuron.InputOutputNeuron;
/*     */ import org.neuroph.nnet.comp.neuron.ThresholdNeuron;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NeuronFactory
/*     */ {
/*     */   public static Neuron createNeuron(NeuronProperties neuronProperties)
/*     */   {
/*  48 */     InputFunction inputFunction = null;
/*  49 */     Class inputFunctionClass = neuronProperties.getInputFunction();
/*     */     
/*  51 */     if (inputFunctionClass != null) {
/*  52 */       inputFunction = createInputFunction(inputFunctionClass);
/*     */     }
/*     */     
/*  55 */     TransferFunction transferFunction = createTransferFunction(neuronProperties.getTransferFunctionProperties());
/*     */     
/*  57 */     Neuron neuron = null;
/*  58 */     Class neuronClass = neuronProperties.getNeuronType();
/*     */     
/*     */     try
/*     */     {
/*  62 */       Class[] paramTypes = { InputFunction.class, TransferFunction.class };
/*  63 */       Constructor con = neuronClass.getConstructor(paramTypes);
/*     */       
/*  65 */       Object[] paramList = new Object[2];
/*  66 */       paramList[0] = inputFunction;
/*  67 */       paramList[1] = transferFunction;
/*     */       
/*  69 */       neuron = (Neuron)con.newInstance(paramList);
/*     */ 
/*     */     }
/*     */     catch (NoSuchMethodException e) {}catch (InstantiationException e)
/*     */     {
/*  74 */       throw new NeurophException("InstantiationException while creating Neuron!", e);
/*     */     } catch (IllegalAccessException e) {
/*  76 */       throw new NeurophException("IllegalAccessException while creating Neuron!", e);
/*     */     } catch (InvocationTargetException e) {
/*  78 */       throw new NeurophException("InvocationTargetException while creating Neuron!", e);
/*     */     }
/*     */     
/*  81 */     if (neuron == null) {
/*     */       try
/*     */       {
/*  84 */         neuron = (Neuron)neuronClass.newInstance();
/*     */       } catch (IllegalAccessException e) {
/*  86 */         System.err.println("InstantiationException while creating Neuron!");
/*  87 */         e.printStackTrace();
/*     */       } catch (InstantiationException e) {
/*  89 */         System.err.println("InstantiationException while creating Neuron!");
/*  90 */         e.printStackTrace();
/*     */       }
/*     */     }
/*     */     
/*  94 */     if (neuronProperties.hasProperty("thresh")) {
/*  95 */       ((ThresholdNeuron)neuron).setThresh(((Double)neuronProperties.getProperty("thresh")).doubleValue());
/*  96 */     } else if (neuronProperties.hasProperty("bias")) {
/*  97 */       ((InputOutputNeuron)neuron).setBias(((Double)neuronProperties.getProperty("bias")).doubleValue());
/*     */     }
/*     */     
/* 100 */     return neuron;
/*     */   }
/*     */   
/*     */ 
/*     */   private static InputFunction createInputFunction(Class inputFunctionClass)
/*     */   {
/* 106 */     InputFunction inputFunction = null;
/*     */     try
/*     */     {
/* 109 */       inputFunction = (InputFunction)inputFunctionClass.newInstance();
/*     */     } catch (InstantiationException e) {
/* 111 */       throw new NeurophException("InstantiationException while creating InputFunction!", e);
/*     */     } catch (IllegalAccessException e) {
/* 113 */       throw new NeurophException("IllegalAccessException while creating InputFunction!", e);
/*     */     }
/*     */     
/* 116 */     return inputFunction;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static TransferFunction createTransferFunction(Properties tfProperties)
/*     */   {
/* 128 */     TransferFunction transferFunction = null;
/*     */     
/* 130 */     Class tfClass = (Class)tfProperties.getProperty("transferFunction");
/*     */     try
/*     */     {
/* 133 */       Class[] paramTypes = null;
/*     */       
/* 135 */       Constructor[] cons = tfClass.getConstructors();
/* 136 */       for (int i = 0; i < cons.length; i++) {
/* 137 */         paramTypes = cons[i].getParameterTypes();
/*     */         
/*     */ 
/* 140 */         if ((paramTypes.length == 1) && (paramTypes[0] == Properties.class)) {
/* 141 */           Class[] argTypes = new Class[1];
/* 142 */           argTypes[0] = Properties.class;
/* 143 */           Constructor ct = tfClass.getConstructor(argTypes);
/*     */           
/* 145 */           Object[] argList = new Object[1];
/* 146 */           argList[0] = tfProperties;
/* 147 */           transferFunction = (TransferFunction)ct.newInstance(argList);
/* 148 */           break; }
/* 149 */         if (paramTypes.length == 0) {
/* 150 */           transferFunction = (TransferFunction)tfClass.newInstance();
/* 151 */           break;
/*     */         }
/*     */       }
/*     */       
/* 155 */       return transferFunction;
/*     */     }
/*     */     catch (NoSuchMethodException e) {
/* 158 */       System.err.println("getConstructor() couldn't find the constructor while creating TransferFunction!");
/* 159 */       e.printStackTrace();
/*     */     } catch (InstantiationException e) {
/* 161 */       System.err.println("InstantiationException while creating TransferFunction!");
/* 162 */       e.printStackTrace();
/*     */     } catch (IllegalAccessException e) {
/* 164 */       System.err.println("No permission to invoke method while creating TransferFunction!");
/* 165 */       e.printStackTrace();
/*     */     } catch (InvocationTargetException e) {
/* 167 */       System.err.println("Method threw an: " + e.getTargetException() + " while creating TransferFunction!");
/* 168 */       e.printStackTrace();
/*     */     }
/*     */     
/* 171 */     return transferFunction;
/*     */   }
/*     */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\util\NeuronFactory.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */