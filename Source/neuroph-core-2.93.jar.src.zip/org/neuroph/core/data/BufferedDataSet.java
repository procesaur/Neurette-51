/*     */ package org.neuroph.core.data;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileReader;
/*     */ import java.io.IOException;
/*     */ import java.io.LineNumberReader;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BufferedDataSet
/*     */   extends DataSet
/*     */   implements Iterator<DataSetRow>
/*     */ {
/*  43 */   private int bufferSize = 1000;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private File file;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private long fileLinesNumber;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private long currentFileLineNumber;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int rowsLoaded;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String delimiter;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  73 */   FileReader fileReader = null;
/*     */   
/*     */ 
/*     */ 
/*     */   BufferedReader bufferedReader;
/*     */   
/*     */ 
/*     */ 
/*     */   List<DataSetRow> bufferedRows;
/*     */   
/*     */ 
/*     */ 
/*     */   Iterator<DataSetRow> bufferIterator;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public BufferedDataSet(File file, int inputSize, String delimiter)
/*     */   {
/*  92 */     super(inputSize);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public BufferedDataSet(File file, int inputSize, int outputSize, String delimiter)
/*     */     throws FileNotFoundException
/*     */   {
/* 107 */     super(inputSize, outputSize);
/*     */     
/* 109 */     this.delimiter = delimiter;
/* 110 */     this.file = file;
/* 111 */     this.fileReader = new FileReader(file);
/* 112 */     this.bufferedReader = new BufferedReader(this.fileReader);
/* 113 */     this.fileLinesNumber = countFileLines();
/*     */     
/*     */ 
/* 116 */     loadNextBuffer();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private long countFileLines()
/*     */     throws FileNotFoundException
/*     */   {
/* 125 */     LineNumberReader lnr = new LineNumberReader(new FileReader(this.file));
/*     */     try
/*     */     {
/* 128 */       while (lnr.skip(Long.MAX_VALUE) > 0L) {}
/*     */     } catch (IOException ex) {
/* 130 */       Logger.getLogger(BufferedDataSet.class.getName()).log(Level.SEVERE, null, ex);
/*     */     }
/* 132 */     return lnr.getLineNumber() + 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Iterator<DataSetRow> iterator()
/*     */   {
/* 141 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean hasNext()
/*     */   {
/* 150 */     if (this.currentFileLineNumber < this.fileLinesNumber) {
/* 151 */       return true;
/*     */     }
/*     */     
/* 154 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DataSetRow next()
/*     */   {
/* 165 */     if (!this.bufferIterator.hasNext()) {
/* 166 */       loadNextBuffer();
/*     */     }
/*     */     
/* 169 */     this.currentFileLineNumber += 1L;
/* 170 */     return (DataSetRow)this.bufferIterator.next();
/*     */   }
/*     */   
/*     */   public void remove()
/*     */   {
/* 175 */     throw new UnsupportedOperationException("Not supported yet.");
/*     */   }
/*     */   
/*     */ 
/*     */   private void loadNextBuffer()
/*     */   {
/*     */     try
/*     */     {
/* 183 */       String line = "";
/* 184 */       clear();
/*     */       
/* 186 */       this.rowsLoaded = 0;
/* 187 */       while (this.rowsLoaded < this.bufferSize)
/*     */       {
/* 189 */         line = this.bufferedReader.readLine();
/* 190 */         if (line == null) {
/*     */           break;
/*     */         }
/*     */         
/* 194 */         this.rowsLoaded += 1;
/* 195 */         double[] inputs = new double[getInputSize()];
/* 196 */         double[] outputs = new double[getOutputSize()];
/* 197 */         String[] values = line.split(this.delimiter);
/*     */         
/* 199 */         if (!values[0].equals(""))
/*     */         {
/*     */ 
/* 202 */           for (int i = 0; i < getInputSize(); i++) {
/* 203 */             inputs[i] = Double.parseDouble(values[i]);
/*     */           }
/*     */           
/* 206 */           for (int i = 0; i < getOutputSize(); i++) {
/* 207 */             outputs[i] = Double.parseDouble(values[(getInputSize() + i)]);
/*     */           }
/*     */           
/* 210 */           if (getOutputSize() > 0) {
/* 211 */             addRow(new DataSetRow(inputs, outputs));
/*     */           } else {
/* 213 */             addRow(new DataSetRow(inputs));
/*     */           }
/*     */         }
/*     */       }
/* 217 */       this.bufferedRows = getRows();
/* 218 */       this.bufferIterator = this.bufferedRows.iterator();
/*     */     }
/*     */     catch (FileNotFoundException ex) {
/* 221 */       ex.printStackTrace();
/*     */     } catch (IOException ex) {
/* 223 */       if (this.fileReader != null) {
/*     */         try {
/* 225 */           this.fileReader.close();
/*     */         }
/*     */         catch (IOException ex1) {}
/*     */       }
/* 229 */       ex.printStackTrace();
/*     */     } catch (NumberFormatException ex) {
/* 231 */       if (this.fileReader != null) {
/*     */         try {
/* 233 */           this.fileReader.close();
/*     */         }
/*     */         catch (IOException ex1) {}
/*     */       }
/* 237 */       ex.printStackTrace();
/* 238 */       throw ex;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\core\data\BufferedDataSet.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */