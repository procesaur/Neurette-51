/*     */ package org.neuroph.core.data;
/*     */ 
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.FileWriter;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.ListIterator;
/*     */ import org.neuroph.core.exceptions.NeurophException;
/*     */ import org.neuroph.core.exceptions.VectorSizeMismatchException;
/*     */ import org.neuroph.util.data.sample.Sampling;
/*     */ import org.neuroph.util.data.sample.SubSampling;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DataSet
/*     */   implements List<DataSetRow>, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 2L;
/*     */   private List<DataSetRow> rows;
/*  55 */   private int inputSize = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  60 */   private int outputSize = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String[] columnNames;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  70 */   private boolean isSupervised = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String label;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private transient String filePath;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DataSet(int inputSize)
/*     */   {
/*  89 */     this.rows = new ArrayList();
/*  90 */     this.inputSize = inputSize;
/*  91 */     this.isSupervised = false;
/*     */     
/*  93 */     setDefaultColumnNames();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DataSet(int inputSize, int outputSize)
/*     */   {
/* 103 */     this.rows = new ArrayList();
/* 104 */     this.inputSize = inputSize;
/* 105 */     this.outputSize = outputSize;
/* 106 */     this.isSupervised = true;
/*     */     
/* 108 */     setDefaultColumnNames();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean addRow(DataSetRow row)
/*     */     throws VectorSizeMismatchException
/*     */   {
/* 119 */     if (row == null) {
/* 120 */       throw new IllegalArgumentException("Data set row cannot be null!");
/*     */     }
/*     */     
/*     */ 
/* 124 */     if ((this.inputSize != 0) && 
/* 125 */       (row.getInput().length != this.inputSize)) {
/* 126 */       throw new VectorSizeMismatchException("Input vector size does not match data set input size!");
/*     */     }
/*     */     
/* 129 */     if ((this.outputSize != 0) && 
/* 130 */       (row.getDesiredOutput().length != this.outputSize)) {
/* 131 */       throw new VectorSizeMismatchException("Output vector size does not match data set output size!");
/*     */     }
/*     */     
/*     */ 
/* 135 */     return this.rows.add(row);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addRow(double[] input)
/*     */   {
/* 144 */     if (input == null) {
/* 145 */       throw new IllegalArgumentException("Input for dataset row cannot be null!");
/*     */     }
/* 147 */     if (input.length != this.inputSize) {
/* 148 */       throw new NeurophException("Input size for given row is different from the data set size!");
/*     */     }
/* 150 */     if (this.isSupervised) {
/* 151 */       throw new NeurophException("Cannot add unsupervised row to supervised data set!");
/*     */     }
/* 153 */     addRow(new DataSetRow(input));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addRow(double[] input, double[] output)
/*     */   {
/* 163 */     addRow(new DataSetRow(input, output));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeRowAt(int idx)
/*     */   {
/* 172 */     this.rows.remove(idx);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Iterator<DataSetRow> iterator()
/*     */   {
/* 181 */     return this.rows.iterator();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<DataSetRow> getRows()
/*     */   {
/* 190 */     return this.rows;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DataSetRow getRowAt(int idx)
/*     */   {
/* 200 */     return (DataSetRow)this.rows.get(idx);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void clear()
/*     */   {
/* 207 */     this.rows.clear();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isEmpty()
/*     */   {
/* 216 */     return this.rows.isEmpty();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isSupervised()
/*     */   {
/* 225 */     return this.isSupervised;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int size()
/*     */   {
/* 235 */     return this.rows.size();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getLabel()
/*     */   {
/* 244 */     return this.label;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLabel(String label)
/*     */   {
/* 253 */     this.label = label;
/*     */   }
/*     */   
/*     */   public String[] getColumnNames() {
/* 257 */     return this.columnNames;
/*     */   }
/*     */   
/*     */   public void setColumnNames(String[] columnNames) {
/* 261 */     this.columnNames = columnNames;
/*     */   }
/*     */   
/*     */   public String getColumnName(int idx) {
/* 265 */     return this.columnNames[idx];
/*     */   }
/*     */   
/*     */   public void setColumnName(int idx, String columnName) {
/* 269 */     this.columnNames[idx] = columnName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFilePath(String filePath)
/*     */   {
/* 279 */     this.filePath = filePath;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getFilePath()
/*     */   {
/* 288 */     return this.filePath;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 298 */     StringBuilder sb = new StringBuilder();
/* 299 */     sb.append("Dataset Label: ").append(this.label).append(System.lineSeparator());
/*     */     
/* 301 */     if (this.columnNames != null) {
/* 302 */       sb.append("Columns: ");
/* 303 */       for (String columnName : this.columnNames) {
/* 304 */         sb.append(columnName).append(", ");
/*     */       }
/* 306 */       sb.delete(sb.length() - 2, sb.length() - 1);
/* 307 */       sb.append(System.lineSeparator());
/*     */     }
/*     */     
/* 310 */     for (??? = this.rows.iterator(); ((Iterator)???).hasNext();) { DataSetRow row = (DataSetRow)((Iterator)???).next();
/* 311 */       sb.append(row).append(System.lineSeparator());
/*     */     }
/*     */     
/* 314 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toCSV()
/*     */   {
/* 323 */     StringBuilder sb = new StringBuilder();
/*     */     
/* 325 */     if ((this.columnNames != null) && (this.columnNames.length > 0)) {
/* 326 */       for (String columnName : this.columnNames) {
/* 327 */         sb.append(columnName).append(", ");
/*     */       }
/* 329 */       sb.delete(sb.length() - 2, sb.length() - 1);
/* 330 */       sb.append(System.lineSeparator());
/*     */     }
/*     */     
/*     */ 
/* 334 */     for (??? = this.rows.iterator(); ((Iterator)???).hasNext();) { DataSetRow row = (DataSetRow)((Iterator)???).next();
/* 335 */       sb.append(row.toCSV());
/* 336 */       sb.append(System.lineSeparator());
/*     */     }
/*     */     
/* 339 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void save(String filePath)
/*     */   {
/* 348 */     this.filePath = filePath;
/* 349 */     save();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void save()
/*     */   {
/* 357 */     if (this.filePath == null) throw new NeurophException("filePath is null! It must be specified in order to save file!");
/*     */     try {
/* 359 */       ObjectOutputStream out = new ObjectOutputStream(new BufferedOutputStream(new FileOutputStream(this.filePath)));Throwable localThrowable3 = null;
/* 360 */       try { out.writeObject(this);
/* 361 */         out.flush();
/* 362 */         out.close();
/*     */       }
/*     */       catch (Throwable localThrowable1)
/*     */       {
/* 359 */         localThrowable3 = localThrowable1;throw localThrowable1;
/*     */       }
/*     */       finally
/*     */       {
/* 363 */         if (out != null) if (localThrowable3 != null) try { out.close(); } catch (Throwable localThrowable2) { localThrowable3.addSuppressed(localThrowable2); } else out.close();
/* 364 */       } } catch (IOException ioe) { throw new NeurophException(ioe);
/*     */     }
/*     */   }
/*     */   
/*     */   public void saveAsTxt(String filePath, String delimiter)
/*     */   {
/* 370 */     if (filePath == null) { throw new IllegalArgumentException("File path is null!");
/*     */     }
/*     */     
/* 373 */     if ((delimiter == null) || (delimiter.equals(""))) {
/* 374 */       delimiter = " ";
/*     */     }
/*     */     try
/*     */     {
/* 378 */       PrintWriter out = new PrintWriter(new FileWriter(new File(filePath)));Throwable localThrowable3 = null;
/*     */       try {
/* 380 */         int columnCount = this.inputSize + this.outputSize;
/* 381 */         int i; if ((this.columnNames != null) && (this.columnNames.length > 0)) {
/* 382 */           for (i = 0; i < this.columnNames.length; i++) {
/* 383 */             out.print(this.columnNames[i]);
/* 384 */             if (i < columnCount - 1) out.print(delimiter);
/*     */           }
/* 386 */           out.println();
/*     */         }
/*     */         
/* 389 */         for (DataSetRow row : this.rows) {
/* 390 */           double[] input = row.getInput();
/* 391 */           for (int i = 0; i < input.length; i++) {
/* 392 */             out.print(input[i]);
/* 393 */             if (i < columnCount - 1) { out.print(delimiter);
/*     */             }
/*     */           }
/* 396 */           if (row.isSupervised()) {
/* 397 */             double[] output = row.getDesiredOutput();
/* 398 */             for (int j = 0; j < output.length; j++) {
/* 399 */               out.print(output[j]);
/* 400 */               if (this.inputSize + j < columnCount - 1) out.print(delimiter);
/*     */             }
/*     */           }
/* 403 */           out.println();
/*     */         }
/*     */         
/* 406 */         out.flush();
/*     */       }
/*     */       catch (Throwable localThrowable1)
/*     */       {
/* 378 */         localThrowable3 = localThrowable1;throw localThrowable1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       }
/*     */       finally
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 408 */         if (out != null) if (localThrowable3 != null) try { out.close(); } catch (Throwable localThrowable2) { localThrowable3.addSuppressed(localThrowable2); } else out.close();
/* 409 */       } } catch (IOException ex) { throw new NeurophException("Error saving data set file!", ex);
/*     */     }
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public static DataSet load(String filePath)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: new 84	java/io/ObjectInputStream
/*     */     //   3: dup
/*     */     //   4: new 85	java/io/BufferedInputStream
/*     */     //   7: dup
/*     */     //   8: new 86	java/io/FileInputStream
/*     */     //   11: dup
/*     */     //   12: aload_0
/*     */     //   13: invokespecial 87	java/io/FileInputStream:<init>	(Ljava/lang/String;)V
/*     */     //   16: invokespecial 88	java/io/BufferedInputStream:<init>	(Ljava/io/InputStream;)V
/*     */     //   19: invokespecial 89	java/io/ObjectInputStream:<init>	(Ljava/io/InputStream;)V
/*     */     //   22: astore_1
/*     */     //   23: aconst_null
/*     */     //   24: astore_2
/*     */     //   25: aload_1
/*     */     //   26: invokevirtual 90	java/io/ObjectInputStream:readObject	()Ljava/lang/Object;
/*     */     //   29: checkcast 91	org/neuroph/core/data/DataSet
/*     */     //   32: astore_3
/*     */     //   33: aload_3
/*     */     //   34: aload_0
/*     */     //   35: invokevirtual 92	org/neuroph/core/data/DataSet:setFilePath	(Ljava/lang/String;)V
/*     */     //   38: aload_3
/*     */     //   39: astore 4
/*     */     //   41: aload_1
/*     */     //   42: ifnull +29 -> 71
/*     */     //   45: aload_2
/*     */     //   46: ifnull +21 -> 67
/*     */     //   49: aload_1
/*     */     //   50: invokevirtual 93	java/io/ObjectInputStream:close	()V
/*     */     //   53: goto +18 -> 71
/*     */     //   56: astore 5
/*     */     //   58: aload_2
/*     */     //   59: aload 5
/*     */     //   61: invokevirtual 63	java/lang/Throwable:addSuppressed	(Ljava/lang/Throwable;)V
/*     */     //   64: goto +7 -> 71
/*     */     //   67: aload_1
/*     */     //   68: invokevirtual 93	java/io/ObjectInputStream:close	()V
/*     */     //   71: aload 4
/*     */     //   73: areturn
/*     */     //   74: astore_3
/*     */     //   75: aload_3
/*     */     //   76: astore_2
/*     */     //   77: aload_3
/*     */     //   78: athrow
/*     */     //   79: astore 6
/*     */     //   81: aload_1
/*     */     //   82: ifnull +29 -> 111
/*     */     //   85: aload_2
/*     */     //   86: ifnull +21 -> 107
/*     */     //   89: aload_1
/*     */     //   90: invokevirtual 93	java/io/ObjectInputStream:close	()V
/*     */     //   93: goto +18 -> 111
/*     */     //   96: astore 7
/*     */     //   98: aload_2
/*     */     //   99: aload 7
/*     */     //   101: invokevirtual 63	java/lang/Throwable:addSuppressed	(Ljava/lang/Throwable;)V
/*     */     //   104: goto +7 -> 111
/*     */     //   107: aload_1
/*     */     //   108: invokevirtual 93	java/io/ObjectInputStream:close	()V
/*     */     //   111: aload 6
/*     */     //   113: athrow
/*     */     //   114: astore_1
/*     */     //   115: new 20	org/neuroph/core/exceptions/NeurophException
/*     */     //   118: dup
/*     */     //   119: new 37	java/lang/StringBuilder
/*     */     //   122: dup
/*     */     //   123: invokespecial 38	java/lang/StringBuilder:<init>	()V
/*     */     //   126: ldc 95
/*     */     //   128: invokevirtual 40	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   131: aload_0
/*     */     //   132: invokevirtual 40	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   135: ldc 96
/*     */     //   137: invokevirtual 40	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   140: invokevirtual 49	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*     */     //   143: aload_1
/*     */     //   144: invokespecial 83	org/neuroph/core/exceptions/NeurophException:<init>	(Ljava/lang/String;Ljava/lang/Throwable;)V
/*     */     //   147: athrow
/*     */     //   148: astore_1
/*     */     //   149: new 20	org/neuroph/core/exceptions/NeurophException
/*     */     //   152: dup
/*     */     //   153: new 37	java/lang/StringBuilder
/*     */     //   156: dup
/*     */     //   157: invokespecial 38	java/lang/StringBuilder:<init>	()V
/*     */     //   160: ldc 97
/*     */     //   162: invokevirtual 40	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   165: aload_0
/*     */     //   166: invokevirtual 40	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   169: ldc 96
/*     */     //   171: invokevirtual 40	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   174: invokevirtual 49	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*     */     //   177: aload_1
/*     */     //   178: invokespecial 83	org/neuroph/core/exceptions/NeurophException:<init>	(Ljava/lang/String;Ljava/lang/Throwable;)V
/*     */     //   181: athrow
/*     */     //   182: astore_1
/*     */     //   183: new 20	org/neuroph/core/exceptions/NeurophException
/*     */     //   186: dup
/*     */     //   187: ldc 99
/*     */     //   189: aload_1
/*     */     //   190: invokespecial 83	org/neuroph/core/exceptions/NeurophException:<init>	(Ljava/lang/String;Ljava/lang/Throwable;)V
/*     */     //   193: athrow
/*     */     // Line number table:
/*     */     //   Java source line #422	-> byte code offset #0
/*     */     //   Java source line #424	-> byte code offset #25
/*     */     //   Java source line #425	-> byte code offset #33
/*     */     //   Java source line #427	-> byte code offset #38
/*     */     //   Java source line #429	-> byte code offset #41
/*     */     //   Java source line #422	-> byte code offset #74
/*     */     //   Java source line #429	-> byte code offset #79
/*     */     //   Java source line #430	-> byte code offset #115
/*     */     //   Java source line #431	-> byte code offset #148
/*     */     //   Java source line #432	-> byte code offset #149
/*     */     //   Java source line #433	-> byte code offset #182
/*     */     //   Java source line #434	-> byte code offset #183
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	194	0	filePath	String
/*     */     //   22	86	1	oistream	java.io.ObjectInputStream
/*     */     //   114	30	1	fnfe	java.io.FileNotFoundException
/*     */     //   148	30	1	ioe	IOException
/*     */     //   182	8	1	ex	ClassNotFoundException
/*     */     //   24	75	2	localThrowable3	Throwable
/*     */     //   32	7	3	dataSet	DataSet
/*     */     //   74	4	3	localThrowable1	Throwable
/*     */     //   56	4	5	localThrowable	Throwable
/*     */     //   79	33	6	localObject	Object
/*     */     //   96	4	7	localThrowable2	Throwable
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   49	53	56	java/lang/Throwable
/*     */     //   25	41	74	java/lang/Throwable
/*     */     //   25	41	79	finally
/*     */     //   74	81	79	finally
/*     */     //   89	93	96	java/lang/Throwable
/*     */     //   0	71	114	java/io/FileNotFoundException
/*     */     //   74	114	114	java/io/FileNotFoundException
/*     */     //   0	71	148	java/io/IOException
/*     */     //   74	114	148	java/io/IOException
/*     */     //   0	71	182	java/lang/ClassNotFoundException
/*     */     //   74	114	182	java/lang/ClassNotFoundException
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public static DataSet createFromFile(String filePath, int inputsCount, int outputsCount, String delimiter, boolean loadColumnNames)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: ifnonnull +13 -> 14
/*     */     //   4: new 9	java/lang/IllegalArgumentException
/*     */     //   7: dup
/*     */     //   8: ldc 100
/*     */     //   10: invokespecial 11	java/lang/IllegalArgumentException:<init>	(Ljava/lang/String;)V
/*     */     //   13: athrow
/*     */     //   14: iload_1
/*     */     //   15: ifgt +30 -> 45
/*     */     //   18: new 9	java/lang/IllegalArgumentException
/*     */     //   21: dup
/*     */     //   22: new 37	java/lang/StringBuilder
/*     */     //   25: dup
/*     */     //   26: invokespecial 38	java/lang/StringBuilder:<init>	()V
/*     */     //   29: ldc 101
/*     */     //   31: invokevirtual 40	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   34: iload_1
/*     */     //   35: invokevirtual 102	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
/*     */     //   38: invokevirtual 49	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*     */     //   41: invokespecial 11	java/lang/IllegalArgumentException:<init>	(Ljava/lang/String;)V
/*     */     //   44: athrow
/*     */     //   45: iload_2
/*     */     //   46: ifge +30 -> 76
/*     */     //   49: new 9	java/lang/IllegalArgumentException
/*     */     //   52: dup
/*     */     //   53: new 37	java/lang/StringBuilder
/*     */     //   56: dup
/*     */     //   57: invokespecial 38	java/lang/StringBuilder:<init>	()V
/*     */     //   60: ldc 103
/*     */     //   62: invokevirtual 40	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   65: iload_2
/*     */     //   66: invokevirtual 102	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
/*     */     //   69: invokevirtual 49	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*     */     //   72: invokespecial 11	java/lang/IllegalArgumentException:<init>	(Ljava/lang/String;)V
/*     */     //   75: athrow
/*     */     //   76: aload_3
/*     */     //   77: ifnull +10 -> 87
/*     */     //   80: aload_3
/*     */     //   81: invokevirtual 104	java/lang/String:isEmpty	()Z
/*     */     //   84: ifeq +13 -> 97
/*     */     //   87: new 9	java/lang/IllegalArgumentException
/*     */     //   90: dup
/*     */     //   91: ldc 105
/*     */     //   93: invokespecial 11	java/lang/IllegalArgumentException:<init>	(Ljava/lang/String;)V
/*     */     //   96: athrow
/*     */     //   97: new 106	java/io/BufferedReader
/*     */     //   100: dup
/*     */     //   101: new 107	java/io/FileReader
/*     */     //   104: dup
/*     */     //   105: aload_0
/*     */     //   106: invokespecial 108	java/io/FileReader:<init>	(Ljava/lang/String;)V
/*     */     //   109: invokespecial 109	java/io/BufferedReader:<init>	(Ljava/io/Reader;)V
/*     */     //   112: astore 5
/*     */     //   114: aconst_null
/*     */     //   115: astore 6
/*     */     //   117: new 91	org/neuroph/core/data/DataSet
/*     */     //   120: dup
/*     */     //   121: iload_1
/*     */     //   122: iload_2
/*     */     //   123: invokespecial 110	org/neuroph/core/data/DataSet:<init>	(II)V
/*     */     //   126: astore 7
/*     */     //   128: aload 7
/*     */     //   130: aload_0
/*     */     //   131: invokevirtual 92	org/neuroph/core/data/DataSet:setFilePath	(Ljava/lang/String;)V
/*     */     //   134: aconst_null
/*     */     //   135: astore 8
/*     */     //   137: iload 4
/*     */     //   139: ifeq +28 -> 167
/*     */     //   142: aload 5
/*     */     //   144: invokevirtual 111	java/io/BufferedReader:readLine	()Ljava/lang/String;
/*     */     //   147: astore 8
/*     */     //   149: aload 8
/*     */     //   151: aload_3
/*     */     //   152: invokevirtual 112	java/lang/String:split	(Ljava/lang/String;)[Ljava/lang/String;
/*     */     //   155: astore 9
/*     */     //   157: aload 7
/*     */     //   159: aload 9
/*     */     //   161: invokevirtual 113	org/neuroph/core/data/DataSet:setColumnNames	([Ljava/lang/String;)V
/*     */     //   164: goto +8 -> 172
/*     */     //   167: aload 7
/*     */     //   169: invokespecial 8	org/neuroph/core/data/DataSet:setDefaultColumnNames	()V
/*     */     //   172: aload 5
/*     */     //   174: invokevirtual 111	java/io/BufferedReader:readLine	()Ljava/lang/String;
/*     */     //   177: dup
/*     */     //   178: astore 8
/*     */     //   180: ifnull +136 -> 316
/*     */     //   183: aload 8
/*     */     //   185: aload_3
/*     */     //   186: invokevirtual 112	java/lang/String:split	(Ljava/lang/String;)[Ljava/lang/String;
/*     */     //   189: astore 9
/*     */     //   191: iload_1
/*     */     //   192: newarray <illegal type>
/*     */     //   194: astore 10
/*     */     //   196: iload_2
/*     */     //   197: newarray <illegal type>
/*     */     //   199: astore 11
/*     */     //   201: aload 9
/*     */     //   203: iconst_0
/*     */     //   204: aaload
/*     */     //   205: ldc 67
/*     */     //   207: invokevirtual 68	java/lang/String:equals	(Ljava/lang/Object;)Z
/*     */     //   210: ifeq +6 -> 216
/*     */     //   213: goto -41 -> 172
/*     */     //   216: iconst_0
/*     */     //   217: istore 12
/*     */     //   219: iload 12
/*     */     //   221: iload_1
/*     */     //   222: if_icmpge +22 -> 244
/*     */     //   225: aload 10
/*     */     //   227: iload 12
/*     */     //   229: aload 9
/*     */     //   231: iload 12
/*     */     //   233: aaload
/*     */     //   234: invokestatic 114	java/lang/Double:parseDouble	(Ljava/lang/String;)D
/*     */     //   237: dastore
/*     */     //   238: iinc 12 1
/*     */     //   241: goto -22 -> 219
/*     */     //   244: iconst_0
/*     */     //   245: istore 12
/*     */     //   247: iload 12
/*     */     //   249: iload_2
/*     */     //   250: if_icmpge +24 -> 274
/*     */     //   253: aload 11
/*     */     //   255: iload 12
/*     */     //   257: aload 9
/*     */     //   259: iload_1
/*     */     //   260: iload 12
/*     */     //   262: iadd
/*     */     //   263: aaload
/*     */     //   264: invokestatic 114	java/lang/Double:parseDouble	(Ljava/lang/String;)D
/*     */     //   267: dastore
/*     */     //   268: iinc 12 1
/*     */     //   271: goto -24 -> 247
/*     */     //   274: iload_2
/*     */     //   275: ifle +23 -> 298
/*     */     //   278: aload 7
/*     */     //   280: new 24	org/neuroph/core/data/DataSetRow
/*     */     //   283: dup
/*     */     //   284: aload 10
/*     */     //   286: aload 11
/*     */     //   288: invokespecial 27	org/neuroph/core/data/DataSetRow:<init>	([D[D)V
/*     */     //   291: invokevirtual 26	org/neuroph/core/data/DataSet:addRow	(Lorg/neuroph/core/data/DataSetRow;)Z
/*     */     //   294: pop
/*     */     //   295: goto +18 -> 313
/*     */     //   298: aload 7
/*     */     //   300: new 24	org/neuroph/core/data/DataSetRow
/*     */     //   303: dup
/*     */     //   304: aload 10
/*     */     //   306: invokespecial 25	org/neuroph/core/data/DataSetRow:<init>	([D)V
/*     */     //   309: invokevirtual 26	org/neuroph/core/data/DataSet:addRow	(Lorg/neuroph/core/data/DataSetRow;)Z
/*     */     //   312: pop
/*     */     //   313: goto -141 -> 172
/*     */     //   316: aload 5
/*     */     //   318: invokevirtual 115	java/io/BufferedReader:close	()V
/*     */     //   321: aload 7
/*     */     //   323: astore 9
/*     */     //   325: aload 5
/*     */     //   327: ifnull +33 -> 360
/*     */     //   330: aload 6
/*     */     //   332: ifnull +23 -> 355
/*     */     //   335: aload 5
/*     */     //   337: invokevirtual 115	java/io/BufferedReader:close	()V
/*     */     //   340: goto +20 -> 360
/*     */     //   343: astore 10
/*     */     //   345: aload 6
/*     */     //   347: aload 10
/*     */     //   349: invokevirtual 63	java/lang/Throwable:addSuppressed	(Ljava/lang/Throwable;)V
/*     */     //   352: goto +8 -> 360
/*     */     //   355: aload 5
/*     */     //   357: invokevirtual 115	java/io/BufferedReader:close	()V
/*     */     //   360: aload 9
/*     */     //   362: areturn
/*     */     //   363: astore 7
/*     */     //   365: aload 7
/*     */     //   367: astore 6
/*     */     //   369: aload 7
/*     */     //   371: athrow
/*     */     //   372: astore 13
/*     */     //   374: aload 5
/*     */     //   376: ifnull +33 -> 409
/*     */     //   379: aload 6
/*     */     //   381: ifnull +23 -> 404
/*     */     //   384: aload 5
/*     */     //   386: invokevirtual 115	java/io/BufferedReader:close	()V
/*     */     //   389: goto +20 -> 409
/*     */     //   392: astore 14
/*     */     //   394: aload 6
/*     */     //   396: aload 14
/*     */     //   398: invokevirtual 63	java/lang/Throwable:addSuppressed	(Ljava/lang/Throwable;)V
/*     */     //   401: goto +8 -> 409
/*     */     //   404: aload 5
/*     */     //   406: invokevirtual 115	java/io/BufferedReader:close	()V
/*     */     //   409: aload 13
/*     */     //   411: athrow
/*     */     //   412: astore 5
/*     */     //   414: new 20	org/neuroph/core/exceptions/NeurophException
/*     */     //   417: dup
/*     */     //   418: ldc 116
/*     */     //   420: aload 5
/*     */     //   422: invokespecial 83	org/neuroph/core/exceptions/NeurophException:<init>	(Ljava/lang/String;Ljava/lang/Throwable;)V
/*     */     //   425: athrow
/*     */     //   426: astore 5
/*     */     //   428: new 20	org/neuroph/core/exceptions/NeurophException
/*     */     //   431: dup
/*     */     //   432: ldc 117
/*     */     //   434: aload 5
/*     */     //   436: invokespecial 83	org/neuroph/core/exceptions/NeurophException:<init>	(Ljava/lang/String;Ljava/lang/Throwable;)V
/*     */     //   439: athrow
/*     */     //   440: astore 5
/*     */     //   442: aload 5
/*     */     //   444: invokevirtual 119	java/lang/NumberFormatException:printStackTrace	()V
/*     */     //   447: new 20	org/neuroph/core/exceptions/NeurophException
/*     */     //   450: dup
/*     */     //   451: ldc 120
/*     */     //   453: aload 5
/*     */     //   455: invokespecial 83	org/neuroph/core/exceptions/NeurophException:<init>	(Ljava/lang/String;Ljava/lang/Throwable;)V
/*     */     //   458: athrow
/*     */     // Line number table:
/*     */     //   Java source line #452	-> byte code offset #0
/*     */     //   Java source line #453	-> byte code offset #14
/*     */     //   Java source line #454	-> byte code offset #45
/*     */     //   Java source line #455	-> byte code offset #76
/*     */     //   Java source line #456	-> byte code offset #87
/*     */     //   Java source line #458	-> byte code offset #97
/*     */     //   Java source line #459	-> byte code offset #117
/*     */     //   Java source line #460	-> byte code offset #128
/*     */     //   Java source line #462	-> byte code offset #134
/*     */     //   Java source line #464	-> byte code offset #137
/*     */     //   Java source line #466	-> byte code offset #142
/*     */     //   Java source line #467	-> byte code offset #149
/*     */     //   Java source line #468	-> byte code offset #157
/*     */     //   Java source line #469	-> byte code offset #164
/*     */     //   Java source line #470	-> byte code offset #167
/*     */     //   Java source line #473	-> byte code offset #172
/*     */     //   Java source line #474	-> byte code offset #183
/*     */     //   Java source line #476	-> byte code offset #191
/*     */     //   Java source line #477	-> byte code offset #196
/*     */     //   Java source line #479	-> byte code offset #201
/*     */     //   Java source line #480	-> byte code offset #213
/*     */     //   Java source line #482	-> byte code offset #216
/*     */     //   Java source line #483	-> byte code offset #225
/*     */     //   Java source line #482	-> byte code offset #238
/*     */     //   Java source line #486	-> byte code offset #244
/*     */     //   Java source line #487	-> byte code offset #253
/*     */     //   Java source line #486	-> byte code offset #268
/*     */     //   Java source line #490	-> byte code offset #274
/*     */     //   Java source line #491	-> byte code offset #278
/*     */     //   Java source line #493	-> byte code offset #298
/*     */     //   Java source line #495	-> byte code offset #313
/*     */     //   Java source line #497	-> byte code offset #316
/*     */     //   Java source line #499	-> byte code offset #321
/*     */     //   Java source line #501	-> byte code offset #325
/*     */     //   Java source line #458	-> byte code offset #363
/*     */     //   Java source line #501	-> byte code offset #372
/*     */     //   Java source line #502	-> byte code offset #414
/*     */     //   Java source line #503	-> byte code offset #426
/*     */     //   Java source line #504	-> byte code offset #428
/*     */     //   Java source line #505	-> byte code offset #440
/*     */     //   Java source line #506	-> byte code offset #442
/*     */     //   Java source line #507	-> byte code offset #447
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	459	0	filePath	String
/*     */     //   0	459	1	inputsCount	int
/*     */     //   0	459	2	outputsCount	int
/*     */     //   0	459	3	delimiter	String
/*     */     //   0	459	4	loadColumnNames	boolean
/*     */     //   112	293	5	reader	java.io.BufferedReader
/*     */     //   412	9	5	ex	java.io.FileNotFoundException
/*     */     //   426	9	5	ex	IOException
/*     */     //   440	14	5	ex	NumberFormatException
/*     */     //   115	280	6	localThrowable3	Throwable
/*     */     //   126	196	7	dataSet	DataSet
/*     */     //   363	7	7	localThrowable1	Throwable
/*     */     //   135	49	8	line	String
/*     */     //   155	5	9	colNames	String[]
/*     */     //   189	172	9	values	String[]
/*     */     //   194	111	10	inputs	double[]
/*     */     //   343	5	10	localThrowable	Throwable
/*     */     //   199	88	11	outputs	double[]
/*     */     //   217	22	12	i	int
/*     */     //   245	24	12	i	int
/*     */     //   372	38	13	localObject	Object
/*     */     //   392	5	14	localThrowable2	Throwable
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   335	340	343	java/lang/Throwable
/*     */     //   117	325	363	java/lang/Throwable
/*     */     //   117	325	372	finally
/*     */     //   363	374	372	finally
/*     */     //   384	389	392	java/lang/Throwable
/*     */     //   97	360	412	java/io/FileNotFoundException
/*     */     //   363	412	412	java/io/FileNotFoundException
/*     */     //   97	360	426	java/io/IOException
/*     */     //   363	412	426	java/io/IOException
/*     */     //   97	360	440	java/lang/NumberFormatException
/*     */     //   363	412	440	java/lang/NumberFormatException
/*     */   }
/*     */   
/*     */   public static DataSet createFromFile(String filePath, int inputsCount, int outputsCount, String delimiter)
/*     */   {
/* 522 */     return createFromFile(filePath, inputsCount, outputsCount, delimiter, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DataSet[] createTrainingAndTestSubsets(int trainSetPercent, int testSetPercent)
/*     */   {
/* 536 */     SubSampling sampling = new SubSampling(new int[] { trainSetPercent, testSetPercent });
/* 537 */     DataSet[] trainAndTestSet = new DataSet[2];
/* 538 */     sampling.sample(this).toArray(trainAndTestSet);
/* 539 */     return trainAndTestSet;
/*     */   }
/*     */   
/*     */   public List<DataSet> split(int... sizePercents) {
/* 543 */     SubSampling sampling = new SubSampling(sizePercents);
/* 544 */     return sampling.sample(this);
/*     */   }
/*     */   
/*     */   public List<DataSet> sample(Sampling sampling)
/*     */   {
/* 549 */     return sampling.sample(this);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getOutputSize()
/*     */   {
/* 557 */     return this.outputSize;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getInputSize()
/*     */   {
/* 566 */     return this.inputSize;
/*     */   }
/*     */   
/*     */   public void shuffle() {
/* 570 */     Collections.shuffle(this.rows);
/*     */   }
/*     */   
/*     */   public boolean contains(Object o)
/*     */   {
/* 575 */     return this.rows.contains(o);
/*     */   }
/*     */   
/*     */   public Object[] toArray()
/*     */   {
/* 580 */     return this.rows.toArray();
/*     */   }
/*     */   
/*     */   public <T> T[] toArray(T[] a)
/*     */   {
/* 585 */     return this.rows.toArray(a);
/*     */   }
/*     */   
/*     */   public boolean add(DataSetRow row)
/*     */   {
/* 590 */     return this.rows.add(row);
/*     */   }
/*     */   
/*     */   public boolean remove(Object row)
/*     */   {
/* 595 */     return this.rows.remove(row);
/*     */   }
/*     */   
/*     */   public boolean containsAll(Collection<?> c)
/*     */   {
/* 600 */     return this.rows.containsAll(c);
/*     */   }
/*     */   
/*     */   public boolean addAll(Collection<? extends DataSetRow> c)
/*     */   {
/* 605 */     return this.rows.addAll(c);
/*     */   }
/*     */   
/*     */   public boolean addAll(int index, Collection<? extends DataSetRow> c)
/*     */   {
/* 610 */     return this.rows.addAll(index, c);
/*     */   }
/*     */   
/*     */   public boolean removeAll(Collection<?> c)
/*     */   {
/* 615 */     return this.rows.removeAll(c);
/*     */   }
/*     */   
/*     */   public boolean retainAll(Collection<?> c)
/*     */   {
/* 620 */     return this.rows.retainAll(c);
/*     */   }
/*     */   
/*     */   public DataSetRow get(int index)
/*     */   {
/* 625 */     return (DataSetRow)this.rows.get(index);
/*     */   }
/*     */   
/*     */   public DataSetRow set(int index, DataSetRow row)
/*     */   {
/* 630 */     return (DataSetRow)this.rows.set(index, row);
/*     */   }
/*     */   
/*     */   public void add(int index, DataSetRow row)
/*     */   {
/* 635 */     this.rows.add(index, row);
/*     */   }
/*     */   
/*     */   public DataSetRow remove(int index)
/*     */   {
/* 640 */     return (DataSetRow)this.rows.remove(index);
/*     */   }
/*     */   
/*     */   public int indexOf(Object row)
/*     */   {
/* 645 */     return this.rows.indexOf(row);
/*     */   }
/*     */   
/*     */   public int lastIndexOf(Object row)
/*     */   {
/* 650 */     return this.rows.lastIndexOf(row);
/*     */   }
/*     */   
/*     */   public ListIterator<DataSetRow> listIterator()
/*     */   {
/* 655 */     return this.rows.listIterator();
/*     */   }
/*     */   
/*     */   public ListIterator<DataSetRow> listIterator(int index)
/*     */   {
/* 660 */     return this.rows.listIterator(index);
/*     */   }
/*     */   
/*     */   public List<DataSetRow> subList(int fromIndex, int toIndex)
/*     */   {
/* 665 */     return this.rows.subList(fromIndex, toIndex);
/*     */   }
/*     */   
/*     */   private void setDefaultColumnNames() {
/* 669 */     this.columnNames = new String[this.inputSize + this.outputSize];
/*     */     
/* 671 */     for (int i = 0; i < this.inputSize; i++) {
/* 672 */       this.columnNames[i] = ("Input" + (i + 1));
/*     */     }
/* 674 */     for (int i = 0; i < this.outputSize; i++) {
/* 675 */       this.columnNames[(this.inputSize + i)] = ("Output" + (i + 1));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\core\data\DataSet.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */