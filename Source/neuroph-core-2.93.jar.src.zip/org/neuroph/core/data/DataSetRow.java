/*     */ package org.neuroph.core.data;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Objects;
/*     */ import org.neuroph.util.VectorParser;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DataSetRow
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   protected double[] input;
/*     */   private double[] desiredOutput;
/*     */   protected String label;
/*     */   
/*     */   public DataSetRow(String input, String desiredOutput)
/*     */   {
/*  60 */     this.input = VectorParser.parseDoubleArray(input);
/*  61 */     this.desiredOutput = VectorParser.parseDoubleArray(desiredOutput);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DataSetRow(double[] input, double[] desiredOutput)
/*     */   {
/*  72 */     this.input = input;
/*  73 */     this.desiredOutput = desiredOutput;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DataSetRow(double... input)
/*     */   {
/*  82 */     this.input = input;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DataSetRow(ArrayList<Double> input, ArrayList<Double> desiredOutput)
/*     */   {
/*  96 */     this.input = VectorParser.toDoubleArray(input);
/*  97 */     this.desiredOutput = VectorParser.toDoubleArray(desiredOutput);
/*     */   }
/*     */   
/*     */   public DataSetRow(ArrayList<Double> input)
/*     */   {
/* 102 */     this.input = VectorParser.toDoubleArray(input);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public double[] getInput()
/*     */   {
/* 111 */     return this.input;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setInput(double[] input)
/*     */   {
/* 120 */     this.input = input;
/*     */   }
/*     */   
/*     */   public double[] getDesiredOutput() {
/* 124 */     return this.desiredOutput;
/*     */   }
/*     */   
/*     */   public void setDesiredOutput(double[] desiredOutput) {
/* 128 */     this.desiredOutput = desiredOutput;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getLabel()
/*     */   {
/* 137 */     return this.label;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLabel(String label)
/*     */   {
/* 146 */     this.label = label;
/*     */   }
/*     */   
/*     */   public boolean isSupervised() {
/* 150 */     return this.desiredOutput != null;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 155 */     StringBuilder sb = new StringBuilder();
/*     */     
/* 157 */     sb.append("Input: ");
/* 158 */     for (double in : this.input) {
/* 159 */       sb.append(in).append(", ");
/*     */     }
/* 161 */     sb.delete(sb.length() - 2, sb.length() - 1);
/*     */     
/* 163 */     if (isSupervised()) {
/* 164 */       sb.append(" Desired output: ");
/* 165 */       for (double out : this.desiredOutput) {
/* 166 */         sb.append(out).append(", ");
/*     */       }
/* 168 */       sb.delete(sb.length() - 2, sb.length() - 1);
/*     */     }
/*     */     
/* 171 */     return sb.toString();
/*     */   }
/*     */   
/*     */   public String toCSV()
/*     */   {
/* 176 */     StringBuilder sb = new StringBuilder();
/*     */     
/* 178 */     for (double in : this.input) {
/* 179 */       sb.append(in).append(", ");
/*     */     }
/*     */     
/* 182 */     if (isSupervised()) {
/* 183 */       for (double out : this.desiredOutput) {
/* 184 */         sb.append(out).append(", ");
/*     */       }
/*     */     }
/*     */     
/* 188 */     sb.delete(sb.length() - 2, sb.length() - 1);
/*     */     
/* 190 */     return sb.toString();
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/* 195 */     int hash = 5;
/* 196 */     return hash;
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj)
/*     */   {
/* 201 */     if (this == obj) {
/* 202 */       return true;
/*     */     }
/* 204 */     if (obj == null) {
/* 205 */       return false;
/*     */     }
/* 207 */     if (getClass() != obj.getClass()) {
/* 208 */       return false;
/*     */     }
/* 210 */     DataSetRow other = (DataSetRow)obj;
/* 211 */     if (!Objects.equals(this.label, other.label)) {
/* 212 */       return false;
/*     */     }
/* 214 */     if (!Arrays.equals(this.input, other.input)) {
/* 215 */       return false;
/*     */     }
/* 217 */     if (!Arrays.equals(this.desiredOutput, other.desiredOutput)) {
/* 218 */       return false;
/*     */     }
/* 220 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\core\data\DataSetRow.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */