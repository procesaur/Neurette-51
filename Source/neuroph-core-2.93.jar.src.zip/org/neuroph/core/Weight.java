/*     */ package org.neuroph.core;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Objects;
/*     */ import java.util.Random;
/*     */ import org.apache.commons.lang3.builder.HashCodeBuilder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Weight
/*     */   implements Serializable, Cloneable
/*     */ {
/*     */   private static final long serialVersionUID = 2L;
/*     */   public double value;
/*     */   public transient double weightChange;
/*     */   private transient Object trainingData;
/*     */   
/*     */   public Weight()
/*     */   {
/*  58 */     this.value = (Math.random() - 0.5D);
/*  59 */     this.weightChange = 0.0D;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Weight(double value)
/*     */   {
/*  68 */     this.value = value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void inc(double amount)
/*     */   {
/*  77 */     this.value += amount;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void dec(double amount)
/*     */   {
/*  86 */     this.value -= amount;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setValue(double value)
/*     */   {
/*  95 */     this.value = value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public double getValue()
/*     */   {
/* 104 */     return this.value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 112 */     return String.valueOf(this.value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void randomize()
/*     */   {
/* 119 */     this.value = (Math.random() - 0.5D);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void randomize(double min, double max)
/*     */   {
/* 126 */     this.value = (min + Math.random() * (max - min));
/*     */   }
/*     */   
/*     */   public void randomize(Random generator) {
/* 130 */     this.value = generator.nextDouble();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getTrainingData()
/*     */   {
/* 139 */     return this.trainingData;
/*     */   }
/*     */   
/*     */   public void setTrainingData(Object trainingData) {
/* 143 */     this.trainingData = trainingData;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object clone()
/*     */     throws CloneNotSupportedException
/*     */   {
/* 154 */     Weight cloned = (Weight)super.clone();
/* 155 */     cloned.setTrainingData(new Object());
/* 156 */     return cloned;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 164 */     return new HashCodeBuilder(7, 17).append(this.value).append(this.weightChange).append(this.trainingData).toHashCode();
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj)
/*     */   {
/* 169 */     if (this == obj) {
/* 170 */       return true;
/*     */     }
/* 172 */     if (obj == null) {
/* 173 */       return false;
/*     */     }
/* 175 */     if (getClass() != obj.getClass()) {
/* 176 */       return false;
/*     */     }
/* 178 */     Weight other = (Weight)obj;
/* 179 */     if (Double.doubleToLongBits(this.value) != Double.doubleToLongBits(other.value)) {
/* 180 */       return false;
/*     */     }
/* 182 */     if (Double.doubleToLongBits(this.weightChange) != Double.doubleToLongBits(other.weightChange)) {
/* 183 */       return false;
/*     */     }
/* 185 */     if (!Objects.equals(this.trainingData, other.trainingData)) {
/* 186 */       return false;
/*     */     }
/* 188 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\core\Weight.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */