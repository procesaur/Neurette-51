/*    */ package org.neuroph.core.learning.stop;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.neuroph.core.learning.SupervisedLearning;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MaxErrorStop
/*    */   implements StopCondition, Serializable
/*    */ {
/*    */   private final SupervisedLearning learningRule;
/*    */   
/*    */   public MaxErrorStop(SupervisedLearning learningRule)
/*    */   {
/* 31 */     this.learningRule = learningRule;
/*    */   }
/*    */   
/*    */   public boolean isReached()
/*    */   {
/* 36 */     if (this.learningRule.getTotalNetworkError() < this.learningRule.getMaxError()) {
/* 37 */       return true;
/*    */     }
/*    */     
/* 40 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\core\learning\stop\MaxErrorStop.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */