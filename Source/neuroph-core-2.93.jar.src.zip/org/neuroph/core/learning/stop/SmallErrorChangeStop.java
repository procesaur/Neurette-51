/*    */ package org.neuroph.core.learning.stop;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.neuroph.core.learning.SupervisedLearning;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SmallErrorChangeStop
/*    */   implements StopCondition, Serializable
/*    */ {
/*    */   private SupervisedLearning learningRule;
/*    */   
/*    */   public SmallErrorChangeStop(SupervisedLearning learningRule)
/*    */   {
/* 32 */     this.learningRule = learningRule;
/*    */   }
/*    */   
/*    */   public boolean isReached()
/*    */   {
/* 37 */     if (this.learningRule.getMinErrorChangeIterationsCount() >= this.learningRule.getMinErrorChangeIterationsLimit()) {
/* 38 */       return true;
/*    */     }
/*    */     
/* 41 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\core\learning\stop\SmallErrorChangeStop.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */