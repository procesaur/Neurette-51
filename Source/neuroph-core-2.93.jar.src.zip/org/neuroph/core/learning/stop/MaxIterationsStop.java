/*    */ package org.neuroph.core.learning.stop;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.neuroph.core.learning.IterativeLearning;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MaxIterationsStop
/*    */   implements StopCondition, Serializable
/*    */ {
/*    */   private IterativeLearning learningRule;
/*    */   
/*    */   public MaxIterationsStop(IterativeLearning learningRule)
/*    */   {
/* 31 */     this.learningRule = learningRule;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public boolean isReached()
/*    */   {
/* 38 */     if (this.learningRule.getCurrentIteration() >= this.learningRule.getMaxIterations()) {
/* 39 */       return true;
/*    */     }
/*    */     
/* 42 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\core\learning\stop\MaxIterationsStop.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */