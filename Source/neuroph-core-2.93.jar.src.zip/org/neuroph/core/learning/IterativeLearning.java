/*     */ package org.neuroph.core.learning;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.neuroph.core.data.DataSet;
/*     */ import org.neuroph.core.events.LearningEvent;
/*     */ import org.neuroph.core.events.LearningEvent.Type;
/*     */ import org.neuroph.core.learning.stop.MaxIterationsStop;
/*     */ import org.neuroph.core.learning.stop.StopCondition;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class IterativeLearning
/*     */   extends LearningRule
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  43 */   protected double learningRate = 0.1D;
/*     */   
/*     */ 
/*     */ 
/*  47 */   protected int currentIteration = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  54 */   private int maxIterations = Integer.MAX_VALUE;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  59 */   private boolean iterationsLimited = false;
/*     */   
/*     */ 
/*     */ 
/*     */   protected List<StopCondition> stopConditions;
/*     */   
/*     */ 
/*  66 */   private volatile transient boolean pausedLearning = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public IterativeLearning()
/*     */   {
/*  73 */     this.stopConditions = new ArrayList();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public double getLearningRate()
/*     */   {
/*  82 */     return this.learningRate;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLearningRate(double learningRate)
/*     */   {
/*  91 */     this.learningRate = learningRate;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMaxIterations(int maxIterations)
/*     */   {
/* 100 */     if (maxIterations > 0) {
/* 101 */       this.maxIterations = maxIterations;
/* 102 */       this.iterationsLimited = true;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getMaxIterations()
/*     */   {
/* 112 */     return this.maxIterations;
/*     */   }
/*     */   
/*     */   public boolean isIterationsLimited() {
/* 116 */     return this.iterationsLimited;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getCurrentIteration()
/*     */   {
/* 125 */     return this.currentIteration;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isPausedLearning()
/*     */   {
/* 134 */     return this.pausedLearning;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void pause()
/*     */   {
/* 141 */     this.pausedLearning = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void resume()
/*     */   {
/* 148 */     this.pausedLearning = false;
/* 149 */     synchronized (this) {
/* 150 */       notify();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void onStart()
/*     */   {
/* 160 */     super.onStart();
/*     */     
/* 162 */     if (this.iterationsLimited) {
/* 163 */       this.stopConditions.add(new MaxIterationsStop(this));
/*     */     }
/*     */     
/* 166 */     this.currentIteration = 0;
/*     */   }
/*     */   
/*     */ 
/*     */   protected void beforeEpoch() {}
/*     */   
/*     */ 
/*     */   protected void afterEpoch() {}
/*     */   
/*     */   public final void learn(DataSet trainingSet)
/*     */   {
/* 177 */     setTrainingSet(trainingSet);
/* 178 */     onStart();
/*     */     
/* 180 */     while (!isStopped()) {
/* 181 */       beforeEpoch();
/* 182 */       doLearningEpoch(trainingSet);
/* 183 */       this.currentIteration += 1;
/* 184 */       afterEpoch();
/*     */       
/*     */ 
/* 187 */       if (hasReachedStopCondition()) {
/* 188 */         stopLearning();
/* 189 */       } else if ((!this.iterationsLimited) && (this.currentIteration == Integer.MAX_VALUE))
/*     */       {
/* 191 */         this.currentIteration = 1;
/*     */       }
/*     */       
/*     */ 
/* 195 */       fireLearningEvent(new LearningEvent(this, LearningEvent.Type.EPOCH_ENDED));
/*     */       
/*     */ 
/* 198 */       if (this.pausedLearning) {
/* 199 */         synchronized (this) {
/* 200 */           while (this.pausedLearning) {
/*     */             try {
/* 202 */               wait();
/*     */             }
/*     */             catch (Exception e) {}
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 210 */     onStop();
/* 211 */     fireLearningEvent(new LearningEvent(this, LearningEvent.Type.LEARNING_STOPPED));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean hasReachedStopCondition()
/*     */   {
/* 220 */     for (StopCondition stop : this.stopConditions) {
/* 221 */       if (stop.isReached()) {
/* 222 */         return true;
/*     */       }
/*     */     }
/*     */     
/* 226 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void learn(DataSet trainingSet, int maxIterations)
/*     */   {
/* 237 */     setMaxIterations(maxIterations);
/* 238 */     learn(trainingSet);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void doOneLearningIteration(DataSet trainingSet)
/*     */   {
/* 249 */     beforeEpoch();
/* 250 */     doLearningEpoch(trainingSet);
/* 251 */     afterEpoch();
/*     */     
/* 253 */     fireLearningEvent(new LearningEvent(this, LearningEvent.Type.LEARNING_STOPPED));
/*     */   }
/*     */   
/*     */   public abstract void doLearningEpoch(DataSet paramDataSet);
/*     */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\core\learning\IterativeLearning.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */