/*    */ package org.neuroph.core.learning.error;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MeanSquaredError
/*    */   implements ErrorFunction, Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private transient double totalError;
/*    */   private transient double patternCount;
/*    */   
/*    */   public MeanSquaredError()
/*    */   {
/* 38 */     reset();
/*    */   }
/*    */   
/*    */ 
/*    */   public void reset()
/*    */   {
/* 44 */     this.totalError = 0.0D;
/* 45 */     this.patternCount = 0.0D;
/*    */   }
/*    */   
/*    */ 
/*    */   public double getTotalError()
/*    */   {
/* 51 */     return this.totalError / (2.0D * this.patternCount);
/*    */   }
/*    */   
/*    */   public double[] calculatePatternError(double[] predictedOutput, double[] targetOutput)
/*    */   {
/* 56 */     double[] patternError = new double[targetOutput.length];
/*    */     
/* 58 */     for (int i = 0; i < predictedOutput.length; i++) {
/* 59 */       targetOutput[i] -= predictedOutput[i];
/* 60 */       this.totalError += patternError[i] * patternError[i];
/*    */     }
/* 62 */     this.patternCount += 1.0D;
/* 63 */     return patternError;
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\core\learning\error\MeanSquaredError.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */