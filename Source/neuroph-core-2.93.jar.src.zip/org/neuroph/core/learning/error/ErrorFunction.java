package org.neuroph.core.learning.error;

public abstract interface ErrorFunction
{
  public abstract double getTotalError();
  
  public abstract void reset();
  
  public abstract double[] calculatePatternError(double[] paramArrayOfDouble1, double[] paramArrayOfDouble2);
}


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\core\learning\error\ErrorFunction.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */