/*    */ package org.neuroph.core.learning;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.Iterator;
/*    */ import org.neuroph.core.NeuralNetwork;
/*    */ import org.neuroph.core.data.DataSet;
/*    */ import org.neuroph.core.data.DataSetRow;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class UnsupervisedLearning
/*    */   extends IterativeLearning
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public void doLearningEpoch(DataSet trainingSet)
/*    */   {
/* 57 */     Iterator<DataSetRow> iterator = trainingSet.iterator();
/* 58 */     while ((iterator.hasNext()) && (!isStopped())) {
/* 59 */       DataSetRow trainingSetRow = (DataSetRow)iterator.next();
/* 60 */       learnPattern(trainingSetRow);
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected void learnPattern(DataSetRow trainingElement)
/*    */   {
/* 71 */     double[] input = trainingElement.getInput();
/* 72 */     this.neuralNetwork.setInput(input);
/* 73 */     this.neuralNetwork.calculate();
/* 74 */     updateNetworkWeights();
/*    */   }
/*    */   
/*    */   protected abstract void updateNetworkWeights();
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\core\learning\UnsupervisedLearning.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */