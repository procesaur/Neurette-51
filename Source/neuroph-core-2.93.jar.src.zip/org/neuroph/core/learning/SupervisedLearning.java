/*     */ package org.neuroph.core.learning;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.neuroph.core.Connection;
/*     */ import org.neuroph.core.Layer;
/*     */ import org.neuroph.core.NeuralNetwork;
/*     */ import org.neuroph.core.Neuron;
/*     */ import org.neuroph.core.Weight;
/*     */ import org.neuroph.core.data.DataSet;
/*     */ import org.neuroph.core.data.DataSetRow;
/*     */ import org.neuroph.core.learning.error.ErrorFunction;
/*     */ import org.neuroph.core.learning.error.MeanSquaredError;
/*     */ import org.neuroph.core.learning.stop.MaxErrorStop;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class SupervisedLearning
/*     */   extends IterativeLearning
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 3L;
/*     */   protected transient double previousEpochError;
/*  56 */   protected double maxError = 0.01D;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  61 */   private double minErrorChange = Double.POSITIVE_INFINITY;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  66 */   private int minErrorChangeIterationsLimit = Integer.MAX_VALUE;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private transient int minErrorChangeIterationsCount;
/*     */   
/*     */ 
/*     */ 
/*  75 */   private boolean batchMode = false;
/*     */   
/*     */ 
/*     */   private ErrorFunction errorFunction;
/*     */   
/*     */ 
/*     */ 
/*     */   public SupervisedLearning()
/*     */   {
/*  84 */     this.errorFunction = new MeanSquaredError();
/*     */     
/*  86 */     this.stopConditions.add(new MaxErrorStop(this));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void learn(DataSet trainingSet, double maxError)
/*     */   {
/*  96 */     this.maxError = maxError;
/*  97 */     learn(trainingSet);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void learn(DataSet trainingSet, double maxError, int maxIterations)
/*     */   {
/* 108 */     this.maxError = maxError;
/* 109 */     setMaxIterations(maxIterations);
/* 110 */     learn(trainingSet);
/*     */   }
/*     */   
/*     */   protected void onStart()
/*     */   {
/* 115 */     super.onStart();
/* 116 */     this.minErrorChangeIterationsCount = 0;
/* 117 */     this.previousEpochError = 0.0D;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void beforeEpoch()
/*     */   {
/* 127 */     this.previousEpochError = this.errorFunction.getTotalError();
/* 128 */     this.errorFunction.reset();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void afterEpoch()
/*     */   {
/* 135 */     double absErrorChange = Math.abs(this.previousEpochError - this.errorFunction.getTotalError());
/* 136 */     if (absErrorChange <= this.minErrorChange) {
/* 137 */       this.minErrorChangeIterationsCount += 1;
/*     */     } else {
/* 139 */       this.minErrorChangeIterationsCount = 0;
/*     */     }
/*     */     
/*     */ 
/* 143 */     if (this.batchMode == true) {
/* 144 */       doBatchWeightsUpdate();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void doLearningEpoch(DataSet trainingSet)
/*     */   {
/* 162 */     Iterator<DataSetRow> iterator = trainingSet.iterator();
/* 163 */     while ((iterator.hasNext()) && (!isStopped())) {
/* 164 */       DataSetRow dataSetRow = (DataSetRow)iterator.next();
/*     */       
/* 166 */       learnPattern(dataSetRow);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void learnPattern(DataSetRow trainingElement)
/*     */   {
/* 185 */     double[] input = trainingElement.getInput();
/* 186 */     this.neuralNetwork.setInput(input);
/* 187 */     this.neuralNetwork.calculate();
/* 188 */     double[] output = this.neuralNetwork.getOutput();
/* 189 */     double[] desiredOutput = trainingElement.getDesiredOutput();
/* 190 */     double[] patternError = this.errorFunction.calculatePatternError(output, desiredOutput);
/* 191 */     calculateWeightChanges(patternError);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void doBatchWeightsUpdate()
/*     */   {
/* 206 */     List<Layer> layers = this.neuralNetwork.getLayers();
/* 207 */     for (int i = this.neuralNetwork.getLayersCount() - 1; i > 0; i--)
/*     */     {
/* 209 */       for (Neuron neuron : ((Layer)layers.get(i)).getNeurons())
/*     */       {
/* 211 */         for (Connection connection : neuron.getInputConnections())
/*     */         {
/* 213 */           Weight weight = connection.getWeight();
/* 214 */           weight.value += weight.weightChange;
/* 215 */           weight.weightChange = 0.0D;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isInBatchMode()
/*     */   {
/* 265 */     return this.batchMode;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBatchMode(boolean batchMode)
/*     */   {
/* 274 */     this.batchMode = batchMode;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMaxError(double maxError)
/*     */   {
/* 283 */     this.maxError = maxError;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public double getMaxError()
/*     */   {
/* 292 */     return this.maxError;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public double getPreviousEpochError()
/*     */   {
/* 301 */     return this.previousEpochError;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public double getMinErrorChange()
/*     */   {
/* 310 */     return this.minErrorChange;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMinErrorChange(double minErrorChange)
/*     */   {
/* 319 */     this.minErrorChange = minErrorChange;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getMinErrorChangeIterationsLimit()
/*     */   {
/* 328 */     return this.minErrorChangeIterationsLimit;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMinErrorChangeIterationsLimit(int minErrorChangeIterationsLimit)
/*     */   {
/* 337 */     this.minErrorChangeIterationsLimit = minErrorChangeIterationsLimit;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getMinErrorChangeIterationsCount()
/*     */   {
/* 346 */     return this.minErrorChangeIterationsCount;
/*     */   }
/*     */   
/*     */   public ErrorFunction getErrorFunction() {
/* 350 */     return this.errorFunction;
/*     */   }
/*     */   
/*     */   public void setErrorFunction(ErrorFunction errorFunction) {
/* 354 */     this.errorFunction = errorFunction;
/*     */   }
/*     */   
/*     */   public double getTotalNetworkError()
/*     */   {
/* 359 */     return this.errorFunction.getTotalError();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract void calculateWeightChanges(double[] paramArrayOfDouble);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void applyWeightChanges()
/*     */   {
/* 372 */     List<Layer> layers = this.neuralNetwork.getLayers();
/* 373 */     for (int i = this.neuralNetwork.getLayersCount() - 1; i > 0; i--)
/*     */     {
/* 375 */       for (Neuron neuron : ((Layer)layers.get(i)).getNeurons())
/*     */       {
/* 377 */         for (Connection connection : neuron.getInputConnections())
/*     */         {
/* 379 */           Weight weight = connection.getWeight();
/* 380 */           weight.value += weight.weightChange;
/* 381 */           weight.weightChange = 0.0D;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\core\learning\SupervisedLearning.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */