/*     */ package org.neuroph.core.learning;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.neuroph.core.NeuralNetwork;
/*     */ import org.neuroph.core.data.DataSet;
/*     */ import org.neuroph.core.events.LearningEvent;
/*     */ import org.neuroph.core.events.LearningEventListener;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class LearningRule
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   protected NeuralNetwork<?> neuralNetwork;
/*     */   private transient DataSet trainingSet;
/*  57 */   private volatile transient boolean stopLearning = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  62 */   protected transient List<LearningEventListener> listeners = new ArrayList();
/*     */   
/*     */ 
/*  65 */   private final Logger LOGGER = LoggerFactory.getLogger(LearningRule.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTrainingSet(DataSet trainingSet)
/*     */   {
/*  79 */     this.trainingSet = trainingSet;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DataSet getTrainingSet()
/*     */   {
/*  88 */     return this.trainingSet;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NeuralNetwork getNeuralNetwork()
/*     */   {
/*  97 */     return this.neuralNetwork;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setNeuralNetwork(NeuralNetwork neuralNetwork)
/*     */   {
/* 106 */     this.neuralNetwork = neuralNetwork;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void onStart()
/*     */   {
/* 114 */     this.stopLearning = false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void onStop() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void stopLearning()
/*     */   {
/* 130 */     this.stopLearning = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized boolean isStopped()
/*     */   {
/* 140 */     return this.stopLearning;
/*     */   }
/*     */   
/*     */   public synchronized void addListener(LearningEventListener listener)
/*     */   {
/* 145 */     if (listener == null) {
/* 146 */       throw new IllegalArgumentException("listener is null!");
/*     */     }
/* 148 */     if (!this.listeners.contains(listener)) {
/* 149 */       this.listeners.add(listener);
/*     */     }
/*     */   }
/*     */   
/*     */   public synchronized void removeListener(LearningEventListener listener)
/*     */   {
/* 155 */     if (listener == null) {
/* 156 */       throw new IllegalArgumentException("listener is null!");
/*     */     }
/* 158 */     this.listeners.remove(listener);
/*     */   }
/*     */   
/*     */   protected synchronized void fireLearningEvent(LearningEvent evt)
/*     */   {
/* 163 */     for (LearningEventListener listener : this.listeners) {
/* 164 */       listener.handleLearningEvent(evt);
/*     */     }
/*     */   }
/*     */   
/*     */   private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException
/*     */   {
/* 170 */     in.defaultReadObject();
/* 171 */     this.listeners = new ArrayList();
/*     */   }
/*     */   
/*     */   public abstract void learn(DataSet paramDataSet);
/*     */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\core\learning\LearningRule.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */