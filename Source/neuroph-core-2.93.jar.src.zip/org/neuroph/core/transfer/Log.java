/*    */ package org.neuroph.core.transfer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Log
/*    */   extends TransferFunction
/*    */ {
/*    */   public double getOutput(double net)
/*    */   {
/* 30 */     return Math.log(net);
/*    */   }
/*    */   
/*    */   public double getDerivative(double net)
/*    */   {
/* 35 */     return 1.0D / net;
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\core\transfer\Log.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */