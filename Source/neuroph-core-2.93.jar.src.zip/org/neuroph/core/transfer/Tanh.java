/*     */ package org.neuroph.core.transfer;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.io.Serializable;
/*     */ import org.neuroph.util.Properties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Tanh
/*     */   extends TransferFunction
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 2L;
/*  43 */   private double slope = 2.0D;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  48 */   private double amplitude = 1.7159D;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Tanh() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Tanh(double slope)
/*     */   {
/*  64 */     this.slope = slope;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Tanh(Properties properties)
/*     */   {
/*     */     try
/*     */     {
/*  75 */       this.slope = ((Double)properties.getProperty("transferFunction.slope")).doubleValue();
/*     */     }
/*     */     catch (NullPointerException e) {}catch (NumberFormatException e)
/*     */     {
/*  79 */       System.err.println("Invalid transfer function properties! Using default values.");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public final double getOutput(double input)
/*     */   {
/*  86 */     if (input > 100.0D)
/*  87 */       return 1.0D;
/*  88 */     if (input < -100.0D) {
/*  89 */       return -1.0D;
/*     */     }
/*     */     
/*  92 */     double E_x = Math.exp(this.slope * input);
/*  93 */     this.output = (this.amplitude * ((E_x - 1.0D) / (E_x + 1.0D)));
/*     */     
/*     */ 
/*     */ 
/*  97 */     return this.output;
/*     */   }
/*     */   
/*     */   public final double getDerivative(double net)
/*     */   {
/* 102 */     return 1.0D - this.output * this.output;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public double getSlope()
/*     */   {
/* 111 */     return this.slope;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSlope(double slope)
/*     */   {
/* 120 */     this.slope = slope;
/*     */   }
/*     */   
/*     */   public double getAmplitude() {
/* 124 */     return this.amplitude;
/*     */   }
/*     */   
/*     */   public void setAmplitude(double amplitude) {
/* 128 */     this.amplitude = amplitude;
/*     */   }
/*     */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\core\transfer\Tanh.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */