/*     */ package org.neuroph.core.transfer;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.io.Serializable;
/*     */ import org.neuroph.util.Properties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Step
/*     */   extends TransferFunction
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  40 */   private double yHigh = 1.0D;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  45 */   private double yLow = 0.0D;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Step() {}
/*     */   
/*     */ 
/*     */ 
/*     */   public Step(Properties properties)
/*     */   {
/*     */     try
/*     */     {
/*  58 */       this.yHigh = ((Double)properties.getProperty("transferFunction.yHigh")).doubleValue();
/*  59 */       this.yLow = ((Double)properties.getProperty("transferFunction.yLow")).doubleValue();
/*     */     }
/*     */     catch (NullPointerException e) {}catch (NumberFormatException e)
/*     */     {
/*  63 */       System.err.println("Invalid transfer function properties! Using default values.");
/*     */     }
/*     */   }
/*     */   
/*     */   public double getOutput(double net)
/*     */   {
/*  69 */     if (net > 0.0D) {
/*  70 */       return this.yHigh;
/*     */     }
/*  72 */     return this.yLow;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public double getYHigh()
/*     */   {
/*  80 */     return this.yHigh;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setYHigh(double yHigh)
/*     */   {
/*  88 */     this.yHigh = yHigh;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public double getYLow()
/*     */   {
/*  96 */     return this.yLow;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setYLow(double yLow)
/*     */   {
/* 104 */     this.yLow = yLow;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Properties getProperties()
/*     */   {
/* 112 */     Properties properties = new Properties();
/* 113 */     properties.setProperty("transferFunction.yHigh", String.valueOf(this.yHigh));
/* 114 */     properties.setProperty("transferFunction.yLow", String.valueOf(this.yLow));
/* 115 */     return properties;
/*     */   }
/*     */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\core\transfer\Step.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */