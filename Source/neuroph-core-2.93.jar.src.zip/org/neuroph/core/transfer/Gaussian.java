/*    */ package org.neuroph.core.transfer;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ import java.io.Serializable;
/*    */ import org.neuroph.util.Properties;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Gaussian
/*    */   extends TransferFunction
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/* 42 */   private double sigma = 0.5D;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Gaussian() {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public Gaussian(Properties properties)
/*    */   {
/*    */     try
/*    */     {
/* 57 */       this.sigma = ((Double)properties.getProperty("transferFunction.sigma")).doubleValue();
/*    */     }
/*    */     catch (NullPointerException e) {}catch (NumberFormatException e)
/*    */     {
/* 61 */       System.err.println("Invalid transfer function properties! Using default values.");
/*    */     }
/*    */   }
/*    */   
/*    */   public double getOutput(double totalInput)
/*    */   {
/* 67 */     this.output = Math.exp(-Math.pow(totalInput, 2.0D) / (2.0D * Math.pow(this.sigma, 2.0D)));
/*    */     
/* 69 */     return this.output;
/*    */   }
/*    */   
/*    */ 
/*    */   public double getDerivative(double net)
/*    */   {
/* 75 */     double derivative = this.output * (-net / (this.sigma * this.sigma));
/* 76 */     return derivative;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public double getSigma()
/*    */   {
/* 84 */     return this.sigma;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setSigma(double sigma)
/*    */   {
/* 92 */     this.sigma = sigma;
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\core\transfer\Gaussian.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */