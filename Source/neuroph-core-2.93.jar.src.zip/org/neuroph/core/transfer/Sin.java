/*    */ package org.neuroph.core.transfer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Sin
/*    */   extends TransferFunction
/*    */ {
/*    */   public double getOutput(double net)
/*    */   {
/* 31 */     return Math.sin(net);
/*    */   }
/*    */   
/*    */   public double getDerivative(double net)
/*    */   {
/* 36 */     return Math.cos(net);
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\core\transfer\Sin.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */