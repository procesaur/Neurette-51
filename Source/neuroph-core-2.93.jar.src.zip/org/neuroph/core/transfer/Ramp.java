/*     */ package org.neuroph.core.transfer;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.io.Serializable;
/*     */ import org.neuroph.util.Properties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Ramp
/*     */   extends TransferFunction
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  38 */   private double slope = 1.0D;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  43 */   private double xHigh = 1.0D;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  48 */   private double xLow = 0.0D;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  53 */   private double yHigh = 1.0D;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  58 */   private double yLow = 0.0D;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Ramp() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Ramp(double slope, double xLow, double xHigh, double yLow, double yHigh)
/*     */   {
/*  71 */     this.slope = slope;
/*  72 */     this.xLow = xLow;
/*  73 */     this.xHigh = xHigh;
/*  74 */     this.yLow = yLow;
/*  75 */     this.yHigh = yHigh;
/*     */   }
/*     */   
/*     */ 
/*     */   public Ramp(Properties properties)
/*     */   {
/*     */     try
/*     */     {
/*  83 */       this.slope = ((Double)properties.getProperty("transferFunction.slope")).doubleValue();
/*  84 */       this.yHigh = ((Double)properties.getProperty("transferFunction.yHigh")).doubleValue();
/*  85 */       this.yLow = ((Double)properties.getProperty("transferFunction.yLow")).doubleValue();
/*  86 */       this.xHigh = ((Double)properties.getProperty("transferFunction.xHigh")).doubleValue();
/*  87 */       this.xLow = ((Double)properties.getProperty("transferFunction.xLow")).doubleValue();
/*     */     }
/*     */     catch (NullPointerException e) {}catch (NumberFormatException e)
/*     */     {
/*  91 */       System.err.println("Invalid transfer function properties! Using default values.");
/*     */     }
/*     */   }
/*     */   
/*     */   public double getOutput(double net)
/*     */   {
/*  97 */     if (net < this.xLow)
/*  98 */       return this.yLow;
/*  99 */     if (net > this.xHigh) {
/* 100 */       return this.yHigh;
/*     */     }
/* 102 */     return this.slope * net;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public double getXLow()
/*     */   {
/* 110 */     return this.xLow;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setXLow(double x)
/*     */   {
/* 118 */     this.xLow = x;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public double getXHigh()
/*     */   {
/* 126 */     return this.xHigh;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setXHigh(double x)
/*     */   {
/* 134 */     this.xHigh = x;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public double getYLow()
/*     */   {
/* 142 */     return this.yLow;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setYLow(double y)
/*     */   {
/* 150 */     this.yLow = y;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public double getYHigh()
/*     */   {
/* 158 */     return this.yHigh;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setYHigh(double y)
/*     */   {
/* 166 */     this.yHigh = y;
/*     */   }
/*     */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\core\transfer\Ramp.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */