/*     */ package org.neuroph.core.transfer;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.io.Serializable;
/*     */ import org.neuroph.util.Properties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Sigmoid
/*     */   extends TransferFunction
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 2L;
/*  40 */   private double slope = 1.0D;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Sigmoid() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Sigmoid(double slope)
/*     */   {
/*  55 */     this.slope = slope;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Sigmoid(Properties properties)
/*     */   {
/*     */     try
/*     */     {
/*  65 */       this.slope = ((Double)properties.getProperty("transferFunction.slope")).doubleValue();
/*     */     }
/*     */     catch (NullPointerException e) {}catch (NumberFormatException e)
/*     */     {
/*  69 */       System.err.println("Invalid transfer function properties! Using default values.");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public double getSlope()
/*     */   {
/*  78 */     return this.slope;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSlope(double slope)
/*     */   {
/*  86 */     this.slope = slope;
/*     */   }
/*     */   
/*     */ 
/*     */   public double getOutput(double net)
/*     */   {
/*  92 */     if (net > 100.0D)
/*  93 */       return 1.0D;
/*  94 */     if (net < -100.0D) {
/*  95 */       return 0.0D;
/*     */     }
/*     */     
/*  98 */     double den = 1.0D + Math.exp(-this.slope * net);
/*  99 */     this.output = (1.0D / den);
/*     */     
/* 101 */     return this.output;
/*     */   }
/*     */   
/*     */ 
/*     */   public double getDerivative(double net)
/*     */   {
/* 107 */     double derivative = this.slope * this.output * (1.0D - this.output) + 0.1D;
/* 108 */     return derivative;
/*     */   }
/*     */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\core\transfer\Sigmoid.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */