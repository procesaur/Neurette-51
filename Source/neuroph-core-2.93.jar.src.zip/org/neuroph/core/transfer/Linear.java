/*    */ package org.neuroph.core.transfer;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ import java.io.Serializable;
/*    */ import org.neuroph.util.Properties;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Linear
/*    */   extends TransferFunction
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/* 38 */   private double slope = 1.0D;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Linear() {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public Linear(double slope)
/*    */   {
/* 51 */     this.slope = slope;
/*    */   }
/*    */   
/*    */ 
/*    */   public Linear(Properties properties)
/*    */   {
/*    */     try
/*    */     {
/* 59 */       this.slope = ((Double)properties.getProperty("transferFunction.slope")).doubleValue();
/*    */     }
/*    */     catch (NullPointerException e) {}catch (NumberFormatException e)
/*    */     {
/* 63 */       System.err.println("Invalid transfer function properties! Using default values.");
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public double getSlope()
/*    */   {
/* 72 */     return this.slope;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setSlope(double slope)
/*    */   {
/* 80 */     this.slope = slope;
/*    */   }
/*    */   
/*    */   public double getOutput(double net)
/*    */   {
/* 85 */     return this.slope * net;
/*    */   }
/*    */   
/*    */   public double getDerivative(double net)
/*    */   {
/* 90 */     return this.slope;
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\core\transfer\Linear.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */