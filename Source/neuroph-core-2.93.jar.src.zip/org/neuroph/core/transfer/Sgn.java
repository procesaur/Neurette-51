/*    */ package org.neuroph.core.transfer;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.Properties;
/*    */ import org.neuroph.util.TransferFunctionType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Sgn
/*    */   extends TransferFunction
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public double getOutput(double net)
/*    */   {
/* 43 */     if (net > 0.0D) {
/* 44 */       return 1.0D;
/*    */     }
/* 46 */     return -1.0D;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public Properties getProperties()
/*    */   {
/* 54 */     Properties properties = new Properties();
/* 55 */     properties.setProperty("transferFunction", TransferFunctionType.SGN.toString());
/* 56 */     return properties;
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\core\transfer\Sgn.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */