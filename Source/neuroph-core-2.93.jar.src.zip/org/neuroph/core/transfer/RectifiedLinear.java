/*    */ package org.neuroph.core.transfer;
/*    */ 
/*    */ 
/*    */ public class RectifiedLinear
/*    */   extends TransferFunction
/*    */ {
/*    */   public double getOutput(double net)
/*    */   {
/*  9 */     return Math.max(0.0D, net);
/*    */   }
/*    */   
/*    */   public double getDerivative(double net) {
/* 13 */     if (net > Double.MIN_VALUE)
/* 14 */       return 1.0D;
/* 15 */     return 0.0D;
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\core\transfer\RectifiedLinear.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */