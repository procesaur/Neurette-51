/*     */ package org.neuroph.core.transfer;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.io.Serializable;
/*     */ import org.neuroph.util.Properties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Trapezoid
/*     */   extends TransferFunction
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   double leftLow;
/*     */   double leftHigh;
/*     */   double rightLow;
/*     */   double rightHigh;
/*     */   
/*     */   public Trapezoid()
/*     */   {
/*  43 */     this.leftLow = 0.0D;
/*  44 */     this.leftHigh = 1.0D;
/*  45 */     this.rightLow = 3.0D;
/*  46 */     this.rightHigh = 2.0D;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Trapezoid(double leftLow, double leftHigh, double rightLow, double rightHigh)
/*     */   {
/*  54 */     this.leftLow = leftLow;
/*  55 */     this.leftHigh = leftHigh;
/*  56 */     this.rightLow = rightLow;
/*  57 */     this.rightHigh = rightHigh;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Trapezoid(Properties properties)
/*     */   {
/*     */     try
/*     */     {
/*  66 */       this.leftLow = ((Double)properties.getProperty("transferFunction.leftLow")).doubleValue();
/*  67 */       this.leftHigh = ((Double)properties.getProperty("transferFunction.leftHigh")).doubleValue();
/*  68 */       this.rightLow = ((Double)properties.getProperty("transferFunction.rightLow")).doubleValue();
/*  69 */       this.rightHigh = ((Double)properties.getProperty("transferFunction.rightHigh")).doubleValue();
/*     */     }
/*     */     catch (NullPointerException e) {}catch (NumberFormatException e)
/*     */     {
/*  73 */       System.err.println("Invalid transfer function properties! Using default values.");
/*     */     }
/*     */   }
/*     */   
/*     */   public double getOutput(double net)
/*     */   {
/*  79 */     if ((net >= this.leftHigh) && (net <= this.rightHigh))
/*  80 */       return 1.0D;
/*  81 */     if ((net > this.leftLow) && (net < this.leftHigh))
/*  82 */       return (net - this.leftLow) / (this.leftHigh - this.leftLow);
/*  83 */     if ((net > this.rightHigh) && (net < this.rightLow)) {
/*  84 */       return (this.rightLow - net) / (this.rightLow - this.rightHigh);
/*     */     }
/*     */     
/*  87 */     return 0.0D;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLeftLow(double leftLow)
/*     */   {
/*  95 */     this.leftLow = leftLow;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLeftHigh(double leftHigh)
/*     */   {
/* 103 */     this.leftHigh = leftHigh;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRightLow(double rightLow)
/*     */   {
/* 111 */     this.rightLow = rightLow;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRightHigh(double rightHigh)
/*     */   {
/* 119 */     this.rightHigh = rightHigh;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public double getLeftLow()
/*     */   {
/* 127 */     return this.leftLow;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public double getLeftHigh()
/*     */   {
/* 135 */     return this.leftHigh;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public double getRightLow()
/*     */   {
/* 143 */     return this.rightLow;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public double getRightHigh()
/*     */   {
/* 151 */     return this.rightHigh;
/*     */   }
/*     */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\core\transfer\Trapezoid.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */