/*    */ package org.neuroph.core.events;
/*    */ 
/*    */ import java.util.EventObject;
/*    */ import org.neuroph.core.learning.LearningRule;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LearningEvent
/*    */   extends EventObject
/*    */ {
/*    */   Type eventType;
/*    */   
/*    */   public LearningEvent(LearningRule source, Type eventType)
/*    */   {
/* 31 */     super(source);
/* 32 */     this.eventType = eventType;
/*    */   }
/*    */   
/*    */   public Type getEventType() {
/* 36 */     return this.eventType;
/*    */   }
/*    */   
/*    */   public static enum Type
/*    */   {
/* 41 */     EPOCH_ENDED,  LEARNING_STOPPED;
/*    */     
/*    */     private Type() {}
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\core\events\LearningEvent.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */