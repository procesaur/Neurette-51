package org.neuroph.core.events;

import java.util.EventListener;

@FunctionalInterface
public abstract interface LearningEventListener
  extends EventListener
{
  public abstract void handleLearningEvent(LearningEvent paramLearningEvent);
}


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\core\events\LearningEventListener.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */