/*    */ package org.neuroph.core.events;
/*    */ 
/*    */ import java.util.EventObject;
/*    */ import org.neuroph.core.Layer;
/*    */ import org.neuroph.core.NeuralNetwork;
/*    */ import org.neuroph.core.Neuron;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NeuralNetworkEvent
/*    */   extends EventObject
/*    */ {
/*    */   Type eventType;
/*    */   
/*    */   public NeuralNetworkEvent(NeuralNetwork source, Type eventType)
/*    */   {
/* 32 */     super(source);
/* 33 */     this.eventType = eventType;
/*    */   }
/*    */   
/*    */   public NeuralNetworkEvent(Layer source, Type eventType) {
/* 37 */     super(source);
/* 38 */     this.eventType = eventType;
/*    */   }
/*    */   
/*    */   public NeuralNetworkEvent(Neuron source, Type eventType) {
/* 42 */     super(source);
/* 43 */     this.eventType = eventType;
/*    */   }
/*    */   
/*    */   public Type getEventType() {
/* 47 */     return this.eventType;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public static enum Type
/*    */   {
/* 54 */     CALCULATED, 
/* 55 */     LAYER_ADDED, 
/* 56 */     LAYER_REMOVED, 
/* 57 */     NEURON_ADDED, 
/* 58 */     NEURON_REMOVED, 
/* 59 */     CONNECTION_ADDED, 
/* 60 */     CONNECTION_REMOVED;
/*    */     
/*    */     private Type() {}
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\core\events\NeuralNetworkEvent.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */