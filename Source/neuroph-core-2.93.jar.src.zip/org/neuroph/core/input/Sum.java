/*    */ package org.neuroph.core.input;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.List;
/*    */ import org.neuroph.core.Connection;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Sum
/*    */   extends InputFunction
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 2L;
/*    */   
/*    */   public double getOutput(List<Connection> inputConnections)
/*    */   {
/* 37 */     double output = 0.0D;
/*    */     
/* 39 */     for (Connection connection : inputConnections) {
/* 40 */       output += connection.getInput();
/*    */     }
/*    */     
/* 43 */     return output;
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\core\input\Sum.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */