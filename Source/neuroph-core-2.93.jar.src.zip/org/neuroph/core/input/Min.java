/*    */ package org.neuroph.core.input;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.List;
/*    */ import org.neuroph.core.Connection;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Min
/*    */   extends InputFunction
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 2L;
/*    */   
/*    */   public double getOutput(List<Connection> inputConnections)
/*    */   {
/* 38 */     if (inputConnections.size() == 0) { return 0.0D;
/*    */     }
/* 40 */     double min = ((Connection)inputConnections.get(0)).getWeightedInput();
/*    */     
/* 42 */     for (Connection connection : inputConnections) {
/* 43 */       min = Math.min(min, connection.getWeightedInput());
/*    */     }
/*    */     
/* 46 */     return min;
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\core\input\Min.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */