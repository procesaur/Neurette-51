/*    */ package org.neuroph.core.input;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.neuroph.core.Connection;
/*    */ import org.neuroph.core.Neuron;
/*    */ import org.neuroph.core.Weight;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EuclideanRBF
/*    */   extends InputFunction
/*    */ {
/*    */   public double getOutput(List<Connection> inputConnections)
/*    */   {
/* 23 */     double sqrSum = 0.0D;
/* 24 */     for (Connection connection : inputConnections) {
/* 25 */       Neuron neuron = connection.getFromNeuron();
/* 26 */       Weight weight = connection.getWeight();
/* 27 */       double diff = neuron.getOutput() - weight.getValue();
/* 28 */       sqrSum += diff * diff;
/*    */     }
/*    */     
/* 31 */     return 0.5D * Math.sqrt(sqrSum) / inputConnections.size();
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\core\input\EuclideanRBF.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */