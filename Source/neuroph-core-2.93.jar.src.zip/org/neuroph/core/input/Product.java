/*    */ package org.neuroph.core.input;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.List;
/*    */ import org.neuroph.core.Connection;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Product
/*    */   extends InputFunction
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 2L;
/*    */   
/*    */   public double getOutput(List<Connection> inputConnections)
/*    */   {
/* 37 */     if (inputConnections.size() == 0) {
/* 38 */       return 0.0D;
/*    */     }
/*    */     
/* 41 */     double output = 1.0D;
/*    */     
/* 43 */     for (Connection connection : inputConnections) {
/* 44 */       output *= connection.getInput();
/*    */     }
/*    */     
/* 47 */     return output;
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\core\input\Product.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */