/*    */ package org.neuroph.core.input;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.List;
/*    */ import org.neuroph.core.Connection;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Or
/*    */   extends InputFunction
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public double getOutput(List<Connection> inputConnections)
/*    */   {
/* 40 */     if (inputConnections.size() == 0) { return 0.0D;
/*    */     }
/* 42 */     boolean output = false;
/*    */     
/* 44 */     for (Connection connection : inputConnections) {
/* 45 */       output = (output) || (connection.getInput() >= 0.5D);
/*    */     }
/*    */     
/* 48 */     return output ? 1.0D : 0.0D;
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\core\input\Or.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */