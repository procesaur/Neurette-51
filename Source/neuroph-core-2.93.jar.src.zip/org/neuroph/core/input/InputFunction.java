package org.neuroph.core.input;

import java.io.Serializable;
import java.util.List;
import org.neuroph.core.Connection;

public abstract class InputFunction
  implements Serializable
{
  private static final long serialVersionUID = 2L;
  
  public abstract double getOutput(List<Connection> paramList);
}


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\core\input\InputFunction.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */