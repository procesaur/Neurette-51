/*    */ package org.neuroph.core.input;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.neuroph.core.Connection;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WeightedSum
/*    */   extends InputFunction
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public double getOutput(List<Connection> inputConnections)
/*    */   {
/* 32 */     double output = 0.0D;
/*    */     
/* 34 */     for (Connection connection : inputConnections) {
/* 35 */       output += connection.getWeightedInput();
/*    */     }
/*    */     
/* 38 */     return output;
/*    */   }
/*    */   
/*    */   public static double[] getOutput(double[] inputs, double[] weights) {
/* 42 */     double[] output = new double[inputs.length];
/*    */     
/* 44 */     for (int i = 0; i < inputs.length; i++) {
/* 45 */       output[i] += inputs[i] * weights[i];
/*    */     }
/*    */     
/* 48 */     return output;
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\core\input\WeightedSum.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */