/*    */ package org.neuroph.core.input;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.List;
/*    */ import org.neuroph.core.Connection;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Max
/*    */   extends InputFunction
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 2L;
/*    */   
/*    */   public double getOutput(List<Connection> inputConnections)
/*    */   {
/* 38 */     if (inputConnections.size() == 0) { return 0.0D;
/*    */     }
/* 40 */     double max = ((Connection)inputConnections.get(0)).getWeightedInput();
/*    */     
/* 42 */     for (Connection connection : inputConnections) {
/* 43 */       max = Math.max(max, connection.getWeightedInput());
/*    */     }
/*    */     
/* 46 */     return max;
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\core\input\Max.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */