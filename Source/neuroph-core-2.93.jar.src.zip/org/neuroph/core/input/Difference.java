/*    */ package org.neuroph.core.input;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.List;
/*    */ import org.neuroph.core.Connection;
/*    */ import org.neuroph.core.Neuron;
/*    */ import org.neuroph.core.Weight;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Difference
/*    */   extends InputFunction
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 21L;
/*    */   
/*    */   public double getOutput(List<Connection> inputConnections)
/*    */   {
/* 42 */     double output = 0.0D;
/*    */     
/* 44 */     double sum = 0.0D;
/* 45 */     for (Connection connection : inputConnections) {
/* 46 */       Neuron neuron = connection.getFromNeuron();
/* 47 */       Weight weight = connection.getWeight();
/* 48 */       double diff = neuron.getOutput() - weight.getValue();
/* 49 */       sum += diff * diff;
/*    */     }
/*    */     
/* 52 */     output = Math.sqrt(sum);
/*    */     
/* 54 */     return output;
/*    */   }
/*    */   
/*    */   public double[] getOutput(double[] inputs, double[] weights) {
/* 58 */     double[] output = new double[inputs.length];
/*    */     
/* 60 */     for (int i = 0; i < inputs.length; i++) {
/* 61 */       inputs[i] -= weights[i];
/*    */     }
/*    */     
/* 64 */     return output;
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\core\input\Difference.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */