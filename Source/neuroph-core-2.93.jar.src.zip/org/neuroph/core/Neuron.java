/*     */ package org.neuroph.core;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.neuroph.core.input.InputFunction;
/*     */ import org.neuroph.core.input.WeightedSum;
/*     */ import org.neuroph.core.transfer.Step;
/*     */ import org.neuroph.core.transfer.TransferFunction;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Neuron
/*     */   implements Serializable, Cloneable
/*     */ {
/*     */   private static final long serialVersionUID = 4L;
/*     */   protected Layer parentLayer;
/*     */   protected List<Connection> inputConnections;
/*     */   protected List<Connection> outConnections;
/*  80 */   protected transient double totalInput = 0.0D;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  85 */   protected transient double output = 0.0D;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  90 */   protected transient double error = 0.0D;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected InputFunction inputFunction;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected TransferFunction transferFunction;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String label;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Neuron()
/*     */   {
/* 112 */     this.inputFunction = new WeightedSum();
/* 113 */     this.transferFunction = new Step();
/* 114 */     this.inputConnections = new ArrayList();
/* 115 */     this.outConnections = new ArrayList();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Neuron(InputFunction inputFunction, TransferFunction transferFunction)
/*     */   {
/* 125 */     if (inputFunction == null) {
/* 126 */       throw new IllegalArgumentException("Input function cannot be null!");
/*     */     }
/*     */     
/* 129 */     if (transferFunction == null) {
/* 130 */       throw new IllegalArgumentException("Transfer function cannot be null!");
/*     */     }
/*     */     
/* 133 */     this.inputFunction = inputFunction;
/* 134 */     this.transferFunction = transferFunction;
/* 135 */     this.inputConnections = new ArrayList();
/* 136 */     this.outConnections = new ArrayList();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void calculate()
/*     */   {
/* 143 */     this.totalInput = this.inputFunction.getOutput(this.inputConnections);
/* 144 */     this.output = this.transferFunction.getOutput(this.totalInput);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void reset()
/*     */   {
/* 151 */     setInput(0.0D);
/* 152 */     setOutput(0.0D);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setInput(double input)
/*     */   {
/* 161 */     this.totalInput = input;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public double getNetInput()
/*     */   {
/* 170 */     return this.totalInput;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public double getOutput()
/*     */   {
/* 179 */     return this.output;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean hasInputConnections()
/*     */   {
/* 189 */     return this.inputConnections.size() > 0;
/*     */   }
/*     */   
/*     */   public boolean hasOutputConnectionTo(Neuron neuron) {
/* 193 */     for (Connection connection : this.outConnections) {
/* 194 */       if (connection.getToNeuron() == neuron) {
/* 195 */         return true;
/*     */       }
/*     */     }
/* 198 */     return false;
/*     */   }
/*     */   
/*     */   public boolean hasInputConnectionFrom(Neuron neuron) {
/* 202 */     for (Connection connection : this.inputConnections) {
/* 203 */       if (connection.getFromNeuron() == neuron) {
/* 204 */         return true;
/*     */       }
/*     */     }
/* 207 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addInputConnection(Connection connection)
/*     */   {
/* 217 */     if (connection == null) {
/* 218 */       throw new IllegalArgumentException("Attempt to add null connection to neuron!");
/*     */     }
/*     */     
/*     */ 
/* 222 */     if (connection.getToNeuron() != this) {
/* 223 */       throw new IllegalArgumentException("Cannot add input connection - bad toNeuron specified!");
/*     */     }
/*     */     
/*     */ 
/* 227 */     if (hasInputConnectionFrom(connection.getFromNeuron())) {
/* 228 */       return;
/*     */     }
/*     */     
/* 231 */     this.inputConnections.add(connection);
/*     */     
/* 233 */     Neuron fromNeuron = connection.getFromNeuron();
/* 234 */     fromNeuron.addOutputConnection(connection);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addInputConnection(Neuron fromNeuron)
/*     */   {
/* 243 */     Connection connection = new Connection(fromNeuron, this);
/* 244 */     addInputConnection(connection);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addInputConnection(Neuron fromNeuron, double weightVal)
/*     */   {
/* 254 */     Connection connection = new Connection(fromNeuron, this, weightVal);
/* 255 */     addInputConnection(connection);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void addOutputConnection(Connection connection)
/*     */   {
/* 266 */     if (connection == null) {
/* 267 */       throw new IllegalArgumentException("Attempt to add null connection to neuron!");
/*     */     }
/*     */     
/*     */ 
/* 271 */     if (connection.getFromNeuron() != this) {
/* 272 */       throw new IllegalArgumentException("Cannot add output connection - bad fromNeuron specified!");
/*     */     }
/*     */     
/*     */ 
/* 276 */     if (hasOutputConnectionTo(connection.getToNeuron())) {
/* 277 */       return;
/*     */     }
/*     */     
/*     */ 
/* 281 */     this.outConnections.add(connection);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final List<Connection> getInputConnections()
/*     */   {
/* 290 */     return this.inputConnections;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final List<Connection> getOutConnections()
/*     */   {
/* 299 */     return this.outConnections;
/*     */   }
/*     */   
/*     */   protected void removeInputConnection(Connection conn) {
/* 303 */     this.inputConnections.remove(conn);
/*     */   }
/*     */   
/*     */   protected void removeOutputConnection(Connection conn) {
/* 307 */     this.outConnections.remove(conn);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeInputConnectionFrom(Neuron fromNeuron)
/*     */   {
/* 317 */     for (Connection c : this.inputConnections)
/*     */     {
/* 319 */       if (c.getFromNeuron() == fromNeuron) {
/* 320 */         fromNeuron.removeOutputConnection(c);
/* 321 */         removeInputConnection(c);
/* 322 */         break;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void removeOutputConnectionTo(Neuron toNeuron)
/*     */   {
/* 329 */     for (Connection c : this.outConnections)
/*     */     {
/* 331 */       if (c.getToNeuron() == toNeuron) {
/* 332 */         toNeuron.removeInputConnection(c);
/* 333 */         removeOutputConnection(c);
/* 334 */         break;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void removeAllInputConnections() {
/* 340 */     this.inputConnections.clear();
/*     */   }
/*     */   
/*     */   public void removeAllOutputConnections() {
/* 344 */     this.outConnections.clear();
/*     */   }
/*     */   
/*     */   public void removeAllConnections() {
/* 348 */     removeAllInputConnections();
/* 349 */     removeAllOutputConnections();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Connection getConnectionFrom(Neuron fromNeuron)
/*     */   {
/* 357 */     for (Connection connection : this.inputConnections) {
/* 358 */       if (connection.getFromNeuron() == fromNeuron)
/* 359 */         return connection;
/*     */     }
/* 361 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setInputFunction(InputFunction inputFunction)
/*     */   {
/* 370 */     this.inputFunction = inputFunction;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTransferFunction(TransferFunction transferFunction)
/*     */   {
/* 379 */     this.transferFunction = transferFunction;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public InputFunction getInputFunction()
/*     */   {
/* 388 */     return this.inputFunction;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TransferFunction getTransferFunction()
/*     */   {
/* 397 */     return this.transferFunction;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setParentLayer(Layer parent)
/*     */   {
/* 407 */     this.parentLayer = parent;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Layer getParentLayer()
/*     */   {
/* 416 */     return this.parentLayer;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Weight[] getWeights()
/*     */   {
/* 425 */     Weight[] weights = new Weight[this.inputConnections.size()];
/* 426 */     for (int i = 0; i < this.inputConnections.size(); i++) {
/* 427 */       weights[i] = ((Connection)this.inputConnections.get(i)).getWeight();
/*     */     }
/* 429 */     return weights;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public double getError()
/*     */   {
/* 438 */     return this.error;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setError(double error)
/*     */   {
/* 447 */     this.error = error;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setOutput(double output)
/*     */   {
/* 456 */     this.output = output;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void initializeWeights(double value)
/*     */   {
/* 466 */     for (Connection connection : this.inputConnections) {
/* 467 */       connection.getWeight().setValue(value);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getLabel()
/*     */   {
/* 477 */     return this.label;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLabel(String label)
/*     */   {
/* 486 */     this.label = label;
/*     */   }
/*     */   
/*     */   public Object clone() throws CloneNotSupportedException
/*     */   {
/* 491 */     throw new UnsupportedOperationException("Not yer implemented");
/*     */   }
/*     */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\core\Neuron.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */