/*     */ package org.neuroph.core;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Random;
/*     */ import org.neuroph.core.data.DataSet;
/*     */ import org.neuroph.core.events.NeuralNetworkEvent;
/*     */ import org.neuroph.core.events.NeuralNetworkEvent.Type;
/*     */ import org.neuroph.core.events.NeuralNetworkEventListener;
/*     */ import org.neuroph.core.exceptions.NeurophException;
/*     */ import org.neuroph.core.exceptions.VectorSizeMismatchException;
/*     */ import org.neuroph.core.learning.IterativeLearning;
/*     */ import org.neuroph.core.learning.LearningRule;
/*     */ import org.neuroph.util.NeuralNetworkType;
/*     */ import org.neuroph.util.plugins.PluginBase;
/*     */ import org.neuroph.util.random.RangeRandomizer;
/*     */ import org.neuroph.util.random.WeightsRandomizer;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NeuralNetwork<L extends LearningRule>
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 7L;
/*     */   private NeuralNetworkType type;
/*     */   private List<Layer> layers;
/*     */   private L learningRule;
/*     */   protected double[] outputBuffer;
/*     */   private List<Neuron> inputNeurons;
/*     */   private List<Neuron> outputNeurons;
/*     */   private Map<Class, PluginBase> plugins;
/*  96 */   private String label = "";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 101 */   private transient List<NeuralNetworkEventListener> listeners = new ArrayList();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 106 */   private final Logger LOGGER = LoggerFactory.getLogger(NeuralNetwork.class);
/*     */   
/*     */ 
/*     */ 
/*     */   public NeuralNetwork()
/*     */   {
/* 112 */     this.layers = new ArrayList();
/* 113 */     this.inputNeurons = new ArrayList();
/* 114 */     this.outputNeurons = new ArrayList();
/* 115 */     this.plugins = new HashMap();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addLayer(Layer layer)
/*     */   {
/* 126 */     if (layer == null) {
/* 127 */       throw new IllegalArgumentException("Layer cant be null!");
/*     */     }
/*     */     
/*     */ 
/* 131 */     layer.setParentNetwork(this);
/*     */     
/*     */ 
/* 134 */     this.layers.add(layer);
/*     */     
/*     */ 
/* 137 */     fireNetworkEvent(new NeuralNetworkEvent(layer, NeuralNetworkEvent.Type.LAYER_ADDED));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addLayer(int index, Layer layer)
/*     */   {
/* 149 */     if (layer == null) {
/* 150 */       throw new IllegalArgumentException("Layer cant be null!");
/*     */     }
/*     */     
/*     */ 
/* 154 */     if (index < 0) {
/* 155 */       throw new IllegalArgumentException("Layer index cannot be negative: " + index);
/*     */     }
/*     */     
/*     */ 
/* 159 */     layer.setParentNetwork(this);
/*     */     
/*     */ 
/* 162 */     this.layers.add(index, layer);
/*     */     
/*     */ 
/* 165 */     fireNetworkEvent(new NeuralNetworkEvent(layer, NeuralNetworkEvent.Type.LAYER_ADDED));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeLayer(Layer layer)
/*     */   {
/* 176 */     if (!this.layers.remove(layer)) {
/* 177 */       throw new RuntimeException("Layer not in Neural n/w");
/*     */     }
/*     */     
/*     */ 
/* 181 */     fireNetworkEvent(new NeuralNetworkEvent(layer, NeuralNetworkEvent.Type.LAYER_REMOVED));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeLayerAt(int index)
/*     */   {
/* 191 */     Layer layer = (Layer)this.layers.get(index);
/* 192 */     this.layers.remove(index);
/*     */     
/*     */ 
/* 195 */     fireNetworkEvent(new NeuralNetworkEvent(layer, NeuralNetworkEvent.Type.LAYER_REMOVED));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<Layer> getLayers()
/*     */   {
/* 204 */     return this.layers;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Layer getLayerAt(int index)
/*     */   {
/* 214 */     return (Layer)this.layers.get(index);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int indexOf(Layer layer)
/*     */   {
/* 224 */     return this.layers.indexOf(layer);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getLayersCount()
/*     */   {
/* 233 */     return this.layers.size();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setInput(double... inputVector)
/*     */     throws VectorSizeMismatchException
/*     */   {
/* 242 */     if (inputVector.length != this.inputNeurons.size()) {
/* 243 */       throw new VectorSizeMismatchException("Input vector size does not match network input dimension!");
/*     */     }
/*     */     
/*     */ 
/* 247 */     int i = 0;
/* 248 */     for (Neuron neuron : this.inputNeurons) {
/* 249 */       neuron.setInput(inputVector[i]);
/* 250 */       i++;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public double[] getOutput()
/*     */   {
/* 263 */     int i = 0;
/* 264 */     for (Neuron c : this.outputNeurons) {
/* 265 */       this.outputBuffer[i] = c.getOutput();
/* 266 */       i++;
/*     */     }
/*     */     
/* 269 */     return this.outputBuffer;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void calculate()
/*     */   {
/* 302 */     for (Layer layer : this.layers) {
/* 303 */       layer.calculate();
/*     */     }
/*     */     
/* 306 */     fireNetworkEvent(new NeuralNetworkEvent(this, NeuralNetworkEvent.Type.CALCULATED));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void reset()
/*     */   {
/* 313 */     for (Layer layer : this.layers) {
/* 314 */       layer.reset();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void learn(DataSet trainingSet)
/*     */   {
/* 324 */     if (trainingSet == null) {
/* 325 */       throw new IllegalArgumentException("Training set is null!");
/*     */     }
/*     */     
/* 328 */     this.learningRule.learn(trainingSet);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void learn(DataSet trainingSet, L learningRule)
/*     */   {
/* 338 */     setLearningRule(learningRule);
/* 339 */     learningRule.learn(trainingSet);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void stopLearning()
/*     */   {
/* 347 */     this.learningRule.stopLearning();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void pauseLearning()
/*     */   {
/* 355 */     if ((this.learningRule instanceof IterativeLearning)) {
/* 356 */       ((IterativeLearning)this.learningRule).pause();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void resumeLearning()
/*     */   {
/* 364 */     if ((this.learningRule instanceof IterativeLearning)) {
/* 365 */       ((IterativeLearning)this.learningRule).resume();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void randomizeWeights()
/*     */   {
/* 373 */     randomizeWeights(new WeightsRandomizer());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void randomizeWeights(double minWeight, double maxWeight)
/*     */   {
/* 381 */     randomizeWeights(new RangeRandomizer(minWeight, maxWeight));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void randomizeWeights(Random random)
/*     */   {
/* 389 */     randomizeWeights(new WeightsRandomizer(random));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void randomizeWeights(WeightsRandomizer randomizer)
/*     */   {
/* 399 */     randomizer.randomize(this);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NeuralNetworkType getNetworkType()
/*     */   {
/* 408 */     return this.type;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setNetworkType(NeuralNetworkType type)
/*     */   {
/* 417 */     this.type = type;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<Neuron> getInputNeurons()
/*     */   {
/* 426 */     return this.inputNeurons;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getInputsCount()
/*     */   {
/* 435 */     return this.inputNeurons.size();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setInputNeurons(List<Neuron> inputNeurons)
/*     */   {
/* 444 */     for (Neuron neuron : inputNeurons) {
/* 445 */       this.inputNeurons.add(neuron);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<Neuron> getOutputNeurons()
/*     */   {
/* 455 */     return this.outputNeurons;
/*     */   }
/*     */   
/*     */   public int getOutputsCount() {
/* 459 */     return this.outputNeurons.size();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setOutputNeurons(List<Neuron> outputNeurons)
/*     */   {
/* 468 */     for (Neuron neuron : outputNeurons) {
/* 469 */       this.outputNeurons.add(neuron);
/*     */     }
/* 471 */     this.outputBuffer = new double[outputNeurons.size()];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setOutputLabels(String[] labels)
/*     */   {
/* 480 */     for (int i = 0; i < this.outputNeurons.size(); i++) {
/* 481 */       ((Neuron)this.outputNeurons.get(i)).setLabel(labels[i]);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public L getLearningRule()
/*     */   {
/* 491 */     return this.learningRule;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLearningRule(L learningRule)
/*     */   {
/* 500 */     if (learningRule == null) {
/* 501 */       throw new IllegalArgumentException("Learning rule can't be null!");
/*     */     }
/*     */     
/* 504 */     learningRule.setNeuralNetwork(this);
/* 505 */     this.learningRule = learningRule;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Double[] getWeights()
/*     */   {
/* 515 */     List<Double> weights = new ArrayList();
/* 516 */     for (Layer layer : this.layers) {
/* 517 */       for (Neuron neuron : layer.getNeurons()) {
/* 518 */         for (Connection conn : neuron.getInputConnections()) {
/* 519 */           weights.add(Double.valueOf(conn.getWeight().getValue()));
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 524 */     return (Double[])weights.toArray(new Double[weights.size()]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setWeights(double[] weights)
/*     */   {
/* 533 */     int i = 0;
/* 534 */     for (Layer layer : this.layers) {
/* 535 */       for (Neuron neuron : layer.getNeurons()) {
/* 536 */         for (Connection conn : neuron.getInputConnections()) {
/* 537 */           conn.getWeight().setValue(weights[i]);
/* 538 */           i++;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isEmpty() {
/* 545 */     return this.layers.isEmpty();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void createConnection(Neuron fromNeuron, Neuron toNeuron, double weightVal)
/*     */   {
/* 557 */     toNeuron.addInputConnection(fromNeuron, weightVal);
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 562 */     if (this.label != null) {
/* 563 */       return this.label;
/*     */     }
/*     */     
/* 566 */     return super.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void save(String filePath)
/*     */   {
/* 575 */     ObjectOutputStream out = null;
/*     */     try {
/* 577 */       File file = new File(filePath);
/* 578 */       out = new ObjectOutputStream(new BufferedOutputStream(new FileOutputStream(file)));
/* 579 */       out.writeObject(this);
/* 580 */       out.flush(); return;
/*     */     } catch (IOException ioe) {
/* 582 */       throw new NeurophException("Could not write neural network to file!", ioe);
/*     */     } finally {
/* 584 */       if (out != null) {
/*     */         try {
/* 586 */           out.close();
/*     */         }
/*     */         catch (IOException e) {}
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public static NeuralNetwork load(String filePath)
/*     */   {
/* 601 */     ObjectInputStream oistream = null;
/*     */     try
/*     */     {
/* 604 */       File file = new File(filePath);
/* 605 */       if (!file.exists()) {
/* 606 */         throw new FileNotFoundException("Cannot find file: " + filePath);
/*     */       }
/*     */       
/* 609 */       oistream = new ObjectInputStream(new BufferedInputStream(new FileInputStream(filePath)));
/* 610 */       NeuralNetwork nnet = (NeuralNetwork)oistream.readObject();
/* 611 */       return nnet;
/*     */     }
/*     */     catch (IOException ioe) {
/* 614 */       throw new NeurophException("Could not read neural network file!", ioe);
/*     */     } catch (ClassNotFoundException cnfe) {
/* 616 */       throw new NeurophException("Class not found while trying to read neural network from file!", cnfe);
/*     */     } finally {
/* 618 */       if (oistream != null) {
/*     */         try {
/* 620 */           oistream.close();
/*     */         }
/*     */         catch (IOException ioe) {}
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static NeuralNetwork load(InputStream inputStream)
/*     */   {
/* 634 */     ObjectInputStream oistream = null;
/*     */     try
/*     */     {
/* 637 */       oistream = new ObjectInputStream(new BufferedInputStream(inputStream));
/* 638 */       NeuralNetwork nnet = (NeuralNetwork)oistream.readObject();
/*     */       
/* 640 */       return nnet;
/*     */     }
/*     */     catch (IOException ioe) {
/* 643 */       throw new NeurophException("Could not read neural network file!", ioe);
/*     */     } catch (ClassNotFoundException cnfe) {
/* 645 */       throw new NeurophException("Class not found while trying to read neural network from file!", cnfe);
/*     */     } finally {
/* 647 */       if (oistream != null) {
/*     */         try {
/* 649 */           oistream.close();
/*     */         }
/*     */         catch (IOException ioe) {}
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException
/*     */   {
/* 658 */     in.defaultReadObject();
/* 659 */     this.listeners = new ArrayList();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static NeuralNetwork createFromFile(File file)
/*     */   {
/* 669 */     ObjectInputStream oistream = null;
/*     */     try
/*     */     {
/* 672 */       if (!file.exists()) {
/* 673 */         throw new FileNotFoundException("Cannot find file: " + file);
/*     */       }
/*     */       
/* 676 */       oistream = new ObjectInputStream(new BufferedInputStream(new FileInputStream(file)));
/* 677 */       NeuralNetwork nnet = (NeuralNetwork)oistream.readObject();
/* 678 */       return nnet;
/*     */     }
/*     */     catch (IOException ioe) {
/* 681 */       throw new NeurophException("Could not read neural network file!", ioe);
/*     */     } catch (ClassNotFoundException cnfe) {
/* 683 */       throw new NeurophException("Class not found while trying to read neural network from file!", cnfe);
/*     */     } finally {
/* 685 */       if (oistream != null) {
/*     */         try {
/* 687 */           oistream.close();
/*     */         }
/*     */         catch (IOException ioe) {}
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public static NeuralNetwork createFromFile(String filePath) {
/* 695 */     File file = new File(filePath);
/* 696 */     return createFromFile(file);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addPlugin(PluginBase plugin)
/*     */   {
/* 705 */     plugin.setParentNetwork(this);
/* 706 */     this.plugins.put(plugin.getClass(), plugin);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public <T extends PluginBase> T getPlugin(Class<T> pluginClass)
/*     */   {
/* 716 */     return (PluginBase)pluginClass.cast(this.plugins.get(pluginClass));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removePlugin(Class pluginClass)
/*     */   {
/* 725 */     this.plugins.remove(pluginClass);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getLabel()
/*     */   {
/* 734 */     return this.label;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLabel(String label)
/*     */   {
/* 743 */     this.label = label;
/*     */   }
/*     */   
/*     */   public synchronized void addListener(NeuralNetworkEventListener listener)
/*     */   {
/* 748 */     if (listener == null) {
/* 749 */       throw new IllegalArgumentException("listener is null!");
/*     */     }
/* 751 */     this.listeners.add(listener);
/*     */   }
/*     */   
/*     */   public synchronized void removeListener(NeuralNetworkEventListener listener)
/*     */   {
/* 756 */     if (listener == null) {
/* 757 */       throw new IllegalArgumentException("listener is null!");
/*     */     }
/* 759 */     this.listeners.remove(listener);
/*     */   }
/*     */   
/*     */   public synchronized void fireNetworkEvent(NeuralNetworkEvent evt)
/*     */   {
/* 764 */     for (NeuralNetworkEventListener listener : this.listeners) {
/* 765 */       listener.handleNeuralNetworkEvent(evt);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\core\NeuralNetwork.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */