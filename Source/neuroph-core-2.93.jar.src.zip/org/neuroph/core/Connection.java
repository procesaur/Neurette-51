/*     */ package org.neuroph.core;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Objects;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Connection
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   protected Neuron fromNeuron;
/*     */   protected Neuron toNeuron;
/*     */   protected Weight weight;
/*     */   
/*     */   public Connection(Neuron fromNeuron, Neuron toNeuron)
/*     */   {
/*  61 */     if (fromNeuron == null) {
/*  62 */       throw new IllegalArgumentException("From neuron in connection cant be null !");
/*     */     }
/*  64 */     this.fromNeuron = fromNeuron;
/*     */     
/*     */ 
/*  67 */     if (toNeuron == null) {
/*  68 */       throw new IllegalArgumentException("To neuron in connection cant be null!");
/*     */     }
/*  70 */     this.toNeuron = toNeuron;
/*     */     
/*     */ 
/*  73 */     this.weight = new Weight();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Connection(Neuron fromNeuron, Neuron toNeuron, Weight weight)
/*     */   {
/*  85 */     this(fromNeuron, toNeuron);
/*     */     
/*  87 */     if (weight == null) {
/*  88 */       throw new IllegalArgumentException("Connection Weight cant be null!");
/*     */     }
/*  90 */     this.weight = weight;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Connection(Neuron fromNeuron, Neuron toNeuron, double weightVal)
/*     */   {
/* 104 */     this(fromNeuron, toNeuron, new Weight(weightVal));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Weight getWeight()
/*     */   {
/* 113 */     return this.weight;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setWeight(Weight weight)
/*     */   {
/* 121 */     if (weight == null) {
/* 122 */       throw new IllegalArgumentException("Connection Weight cant be null!");
/*     */     }
/* 124 */     this.weight = weight;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public double getInput()
/*     */   {
/* 135 */     return this.fromNeuron.getOutput();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public double getWeightedInput()
/*     */   {
/* 144 */     return this.fromNeuron.getOutput() * this.weight.value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Neuron getFromNeuron()
/*     */   {
/* 152 */     return this.fromNeuron;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Neuron getToNeuron()
/*     */   {
/* 160 */     return this.toNeuron;
/*     */   }
/*     */   
/*     */   public Object clone() throws CloneNotSupportedException
/*     */   {
/* 165 */     Connection cloned = (Connection)super.clone();
/* 166 */     cloned.setWeight((Weight)this.weight.clone());
/* 167 */     cloned.toNeuron = ((Neuron)this.toNeuron.clone());
/* 168 */     cloned.fromNeuron = ((Neuron)this.fromNeuron.clone());
/*     */     
/* 170 */     return cloned;
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/* 175 */     int hash = 7;
/* 176 */     hash = 67 * hash + Objects.hashCode(this.fromNeuron);
/* 177 */     hash = 67 * hash + Objects.hashCode(this.toNeuron);
/* 178 */     hash = 67 * hash + Objects.hashCode(this.weight);
/* 179 */     return hash;
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj)
/*     */   {
/* 184 */     if (this == obj) {
/* 185 */       return true;
/*     */     }
/* 187 */     if (obj == null) {
/* 188 */       return false;
/*     */     }
/* 190 */     if (getClass() != obj.getClass()) {
/* 191 */       return false;
/*     */     }
/* 193 */     Connection other = (Connection)obj;
/* 194 */     if (!Objects.equals(this.fromNeuron, other.fromNeuron)) {
/* 195 */       return false;
/*     */     }
/* 197 */     if (!Objects.equals(this.toNeuron, other.toNeuron)) {
/* 198 */       return false;
/*     */     }
/* 200 */     if (!Objects.equals(this.weight, other.weight)) {
/* 201 */       return false;
/*     */     }
/* 203 */     return true;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 208 */     return "Connection{fromNeuron=" + this.fromNeuron + ", toNeuron=" + this.toNeuron + ", weight=" + this.weight + '}';
/*     */   }
/*     */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\core\Connection.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */