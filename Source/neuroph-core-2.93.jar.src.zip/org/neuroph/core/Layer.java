/*     */ package org.neuroph.core;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.neuroph.core.events.NeuralNetworkEvent;
/*     */ import org.neuroph.core.events.NeuralNetworkEvent.Type;
/*     */ import org.neuroph.util.NeuronFactory;
/*     */ import org.neuroph.util.NeuronProperties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Layer
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 4L;
/*     */   private NeuralNetwork parentNetwork;
/*     */   protected List<Neuron> neurons;
/*     */   private String label;
/*     */   
/*     */   public Layer()
/*     */   {
/*  63 */     this.neurons = new ArrayList();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Layer(int neuronsCount)
/*     */   {
/*  71 */     this.neurons = new ArrayList(neuronsCount);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Layer(int neuronsCount, NeuronProperties neuronProperties)
/*     */   {
/*  82 */     this(neuronsCount);
/*     */     
/*  84 */     for (int i = 0; i < neuronsCount; i++) {
/*  85 */       Neuron neuron = NeuronFactory.createNeuron(neuronProperties);
/*  86 */       addNeuron(neuron);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void setParentNetwork(NeuralNetwork parent)
/*     */   {
/*  96 */     this.parentNetwork = parent;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final NeuralNetwork getParentNetwork()
/*     */   {
/* 105 */     return this.parentNetwork;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final List<Neuron> getNeurons()
/*     */   {
/* 115 */     return this.neurons;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void addNeuron(Neuron neuron)
/*     */   {
/* 125 */     if (neuron == null) {
/* 126 */       throw new IllegalArgumentException("Neuron cant be null!");
/*     */     }
/*     */     
/*     */ 
/* 130 */     neuron.setParentLayer(this);
/*     */     
/*     */ 
/* 133 */     this.neurons.add(neuron);
/*     */     
/*     */ 
/* 136 */     if (this.parentNetwork != null) {
/* 137 */       this.parentNetwork.fireNetworkEvent(new NeuralNetworkEvent(neuron, NeuralNetworkEvent.Type.NEURON_ADDED));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void addNeuron(int index, Neuron neuron)
/*     */   {
/* 151 */     if (neuron == null) {
/* 152 */       throw new IllegalArgumentException("Neuron cant be null!");
/*     */     }
/*     */     
/*     */ 
/* 156 */     this.neurons.add(index, neuron);
/*     */     
/*     */ 
/* 159 */     neuron.setParentLayer(this);
/*     */     
/*     */ 
/* 162 */     if (this.parentNetwork != null) {
/* 163 */       this.parentNetwork.fireNetworkEvent(new NeuralNetworkEvent(neuron, NeuralNetworkEvent.Type.NEURON_ADDED));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void setNeuron(int index, Neuron neuron)
/*     */   {
/* 174 */     if (neuron == null) {
/* 175 */       throw new IllegalArgumentException("Neuron cant be null!");
/*     */     }
/*     */     
/*     */ 
/* 179 */     this.neurons.set(index, neuron);
/*     */     
/*     */ 
/* 182 */     neuron.setParentLayer(this);
/*     */     
/*     */ 
/* 185 */     if (this.parentNetwork != null) {
/* 186 */       this.parentNetwork.fireNetworkEvent(new NeuralNetworkEvent(neuron, NeuralNetworkEvent.Type.NEURON_ADDED));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void removeNeuron(Neuron neuron)
/*     */   {
/* 196 */     int index = indexOf(neuron);
/* 197 */     removeNeuronAt(index);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void removeNeuronAt(int index)
/*     */   {
/* 206 */     Neuron neuron = (Neuron)this.neurons.get(index);
/* 207 */     neuron.setParentLayer(null);
/* 208 */     neuron.removeAllConnections();
/* 209 */     this.neurons.remove(index);
/*     */     
/*     */ 
/* 212 */     if (this.parentNetwork != null)
/* 213 */       this.parentNetwork.fireNetworkEvent(new NeuralNetworkEvent(this, NeuralNetworkEvent.Type.NEURON_REMOVED));
/*     */   }
/*     */   
/*     */   public final void removeAllNeurons() {
/* 217 */     this.neurons.clear();
/*     */     
/*     */ 
/* 220 */     if (this.parentNetwork != null) {
/* 221 */       this.parentNetwork.fireNetworkEvent(new NeuralNetworkEvent(this, NeuralNetworkEvent.Type.NEURON_REMOVED));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Neuron getNeuronAt(int index)
/*     */   {
/* 231 */     return (Neuron)this.neurons.get(index);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int indexOf(Neuron neuron)
/*     */   {
/* 241 */     return this.neurons.indexOf(neuron);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getNeuronsCount()
/*     */   {
/* 250 */     return this.neurons.size();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void calculate()
/*     */   {
/* 260 */     for (Neuron neuron : this.neurons) {
/* 261 */       neuron.calculate();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void reset()
/*     */   {
/* 272 */     for (Neuron neuron : this.neurons) {
/* 273 */       neuron.reset();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void initializeWeights(double value)
/*     */   {
/* 283 */     for (Neuron neuron : this.neurons) {
/* 284 */       neuron.initializeWeights(value);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getLabel()
/*     */   {
/* 294 */     return this.label;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLabel(String label)
/*     */   {
/* 303 */     this.label = label;
/*     */   }
/*     */   
/*     */   public boolean isEmpty() {
/* 307 */     return this.neurons.isEmpty();
/*     */   }
/*     */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\core\Layer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */