/*    */ package org.neuroph.core.exceptions;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class VectorSizeMismatchException
/*    */   extends NeurophException
/*    */ {
/*    */   private static final long serialVersionUID = 2L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public VectorSizeMismatchException() {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public VectorSizeMismatchException(String message)
/*    */   {
/* 41 */     super(message);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public VectorSizeMismatchException(String message, Throwable cause)
/*    */   {
/* 50 */     super(message, cause);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public VectorSizeMismatchException(Throwable cause)
/*    */   {
/* 58 */     super(cause);
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\core\exceptions\VectorSizeMismatchException.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */