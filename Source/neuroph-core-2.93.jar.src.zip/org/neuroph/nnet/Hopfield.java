/*     */ package org.neuroph.nnet;
/*     */ 
/*     */ import org.neuroph.core.Layer;
/*     */ import org.neuroph.core.NeuralNetwork;
/*     */ import org.neuroph.nnet.comp.neuron.InputOutputNeuron;
/*     */ import org.neuroph.nnet.learning.BinaryHebbianLearning;
/*     */ import org.neuroph.util.ConnectionFactory;
/*     */ import org.neuroph.util.LayerFactory;
/*     */ import org.neuroph.util.NeuralNetworkFactory;
/*     */ import org.neuroph.util.NeuralNetworkType;
/*     */ import org.neuroph.util.NeuronProperties;
/*     */ import org.neuroph.util.TransferFunctionType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Hopfield
/*     */   extends NeuralNetwork
/*     */ {
/*     */   private static final long serialVersionUID = 2L;
/*     */   
/*     */   public Hopfield(int neuronsCount)
/*     */   {
/*  53 */     NeuronProperties neuronProperties = new NeuronProperties();
/*  54 */     neuronProperties.setProperty("neuronType", InputOutputNeuron.class);
/*  55 */     neuronProperties.setProperty("bias", new Double(0.0D));
/*  56 */     neuronProperties.setProperty("transferFunction", TransferFunctionType.STEP);
/*  57 */     neuronProperties.setProperty("transferFunction.yHigh", new Double(1.0D));
/*  58 */     neuronProperties.setProperty("transferFunction.yLow", new Double(0.0D));
/*     */     
/*  60 */     createNetwork(neuronsCount, neuronProperties);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Hopfield(int neuronsCount, NeuronProperties neuronProperties)
/*     */   {
/*  73 */     createNetwork(neuronsCount, neuronProperties);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void createNetwork(int neuronsCount, NeuronProperties neuronProperties)
/*     */   {
/*  87 */     setNetworkType(NeuralNetworkType.HOPFIELD);
/*     */     
/*     */ 
/*  90 */     Layer layer = LayerFactory.createLayer(neuronsCount, neuronProperties);
/*     */     
/*     */ 
/*  93 */     ConnectionFactory.fullConnect(layer, 0.1D);
/*     */     
/*     */ 
/*  96 */     addLayer(layer);
/*     */     
/*     */ 
/*  99 */     NeuralNetworkFactory.setDefaultIO(this);
/*     */     
/*     */ 
/*     */ 
/* 103 */     setLearningRule(new BinaryHebbianLearning());
/*     */   }
/*     */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\nnet\Hopfield.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */