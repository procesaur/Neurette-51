/*    */ package org.neuroph.nnet;
/*    */ 
/*    */ import org.neuroph.core.Layer;
/*    */ import org.neuroph.core.NeuralNetwork;
/*    */ import org.neuroph.nnet.comp.neuron.BiasNeuron;
/*    */ import org.neuroph.nnet.learning.LMS;
/*    */ import org.neuroph.util.ConnectionFactory;
/*    */ import org.neuroph.util.LayerFactory;
/*    */ import org.neuroph.util.NeuralNetworkFactory;
/*    */ import org.neuroph.util.NeuralNetworkType;
/*    */ import org.neuroph.util.NeuronProperties;
/*    */ import org.neuroph.util.TransferFunctionType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Adaline
/*    */   extends NeuralNetwork
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public Adaline(int inputNeuronsCount)
/*    */   {
/* 53 */     createNetwork(inputNeuronsCount);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private void createNetwork(int inputNeuronsCount)
/*    */   {
/* 64 */     setNetworkType(NeuralNetworkType.ADALINE);
/*    */     
/*    */ 
/* 67 */     NeuronProperties inNeuronProperties = new NeuronProperties();
/* 68 */     inNeuronProperties.setProperty("transferFunction", TransferFunctionType.LINEAR);
/*    */     
/*    */ 
/* 71 */     Layer inputLayer = LayerFactory.createLayer(inputNeuronsCount, inNeuronProperties);
/* 72 */     inputLayer.addNeuron(new BiasNeuron());
/* 73 */     addLayer(inputLayer);
/*    */     
/*    */ 
/* 76 */     NeuronProperties outNeuronProperties = new NeuronProperties();
/* 77 */     outNeuronProperties.setProperty("transferFunction", TransferFunctionType.RAMP);
/* 78 */     outNeuronProperties.setProperty("transferFunction.slope", new Double(1.0D));
/* 79 */     outNeuronProperties.setProperty("transferFunction.yHigh", new Double(1.0D));
/* 80 */     outNeuronProperties.setProperty("transferFunction.xHigh", new Double(1.0D));
/* 81 */     outNeuronProperties.setProperty("transferFunction.yLow", new Double(-1.0D));
/* 82 */     outNeuronProperties.setProperty("transferFunction.xLow", new Double(-1.0D));
/*    */     
/*    */ 
/* 85 */     Layer outputLayer = LayerFactory.createLayer(1, outNeuronProperties);
/* 86 */     addLayer(outputLayer);
/*    */     
/*    */ 
/* 89 */     ConnectionFactory.fullConnect(inputLayer, outputLayer);
/*    */     
/*    */ 
/* 92 */     NeuralNetworkFactory.setDefaultIO(this);
/*    */     
/*    */ 
/* 95 */     setLearningRule(new LMS());
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\nnet\Adaline.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */