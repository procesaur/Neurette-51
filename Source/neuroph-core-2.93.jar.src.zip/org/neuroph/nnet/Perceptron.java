/*     */ package org.neuroph.nnet;
/*     */ 
/*     */ import org.neuroph.core.Layer;
/*     */ import org.neuroph.core.NeuralNetwork;
/*     */ import org.neuroph.nnet.comp.layer.InputLayer;
/*     */ import org.neuroph.nnet.comp.neuron.ThresholdNeuron;
/*     */ import org.neuroph.nnet.learning.BinaryDeltaRule;
/*     */ import org.neuroph.util.ConnectionFactory;
/*     */ import org.neuroph.util.LayerFactory;
/*     */ import org.neuroph.util.NeuralNetworkFactory;
/*     */ import org.neuroph.util.NeuralNetworkType;
/*     */ import org.neuroph.util.NeuronProperties;
/*     */ import org.neuroph.util.TransferFunctionType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Perceptron
/*     */   extends NeuralNetwork
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   
/*     */   public Perceptron(int inputNeuronsCount, int outputNeuronsCount)
/*     */   {
/*  57 */     createNetwork(inputNeuronsCount, outputNeuronsCount, TransferFunctionType.STEP);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Perceptron(int inputNeuronsCount, int outputNeuronsCount, TransferFunctionType transferFunctionType)
/*     */   {
/*  72 */     createNetwork(inputNeuronsCount, outputNeuronsCount, transferFunctionType);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void createNetwork(int inputNeuronsCount, int outputNeuronsCount, TransferFunctionType transferFunctionType)
/*     */   {
/*  88 */     setNetworkType(NeuralNetworkType.PERCEPTRON);
/*     */     
/*  90 */     Layer inputLayer = new InputLayer(inputNeuronsCount);
/*  91 */     addLayer(inputLayer);
/*     */     
/*  93 */     NeuronProperties outputNeuronProperties = new NeuronProperties();
/*  94 */     outputNeuronProperties.setProperty("neuronType", ThresholdNeuron.class);
/*  95 */     outputNeuronProperties.setProperty("thresh", new Double(Math.abs(Math.random())));
/*  96 */     outputNeuronProperties.setProperty("transferFunction", transferFunctionType);
/*     */     
/*  98 */     outputNeuronProperties.setProperty("transferFunction.slope", new Double(1.0D));
/*     */     
/*     */ 
/* 101 */     Layer outputLayer = LayerFactory.createLayer(outputNeuronsCount, outputNeuronProperties);
/* 102 */     addLayer(outputLayer);
/*     */     
/*     */ 
/* 105 */     ConnectionFactory.fullConnect(inputLayer, outputLayer);
/*     */     
/*     */ 
/* 108 */     NeuralNetworkFactory.setDefaultIO(this);
/*     */     
/* 110 */     setLearningRule(new BinaryDeltaRule());
/*     */   }
/*     */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\nnet\Perceptron.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */