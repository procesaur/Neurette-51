/*     */ package org.neuroph.nnet.comp;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import org.neuroph.core.Weight;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Kernel
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = -3948374914759253222L;
/*     */   private int width;
/*     */   private int height;
/*     */   private Weight[][] weights;
/*     */   
/*     */   public Kernel(Dimension2D dimension)
/*     */   {
/*  53 */     this.width = dimension.getWidth();
/*  54 */     this.height = dimension.getHeight();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Kernel(int width, int height)
/*     */   {
/*  64 */     this.width = width;
/*  65 */     this.height = height;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getWidth()
/*     */   {
/*  74 */     return this.width;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setWidth(int width)
/*     */   {
/*  83 */     this.width = width;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getHeight()
/*     */   {
/*  92 */     return this.height;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setHeight(int height)
/*     */   {
/* 101 */     this.height = height;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getArea()
/*     */   {
/* 110 */     return this.width * this.height;
/*     */   }
/*     */   
/*     */   public Weight[][] getWeights() {
/* 114 */     return this.weights;
/*     */   }
/*     */   
/*     */   public void setWeights(Weight[][] weights) {
/* 118 */     this.weights = weights;
/*     */   }
/*     */   
/*     */   public void initWeights(double min, double max) {
/* 122 */     this.weights = new Weight[this.height][this.width];
/*     */     
/* 124 */     for (int i = 0; i < this.height; i++) {
/* 125 */       for (int j = 0; j < this.width; j++) {
/* 126 */         Weight weight = new Weight();
/* 127 */         weight.randomize(min, max);
/* 128 */         this.weights[i][j] = weight;
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\nnet\comp\Kernel.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */