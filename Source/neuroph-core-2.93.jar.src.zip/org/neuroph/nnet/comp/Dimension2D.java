/*    */ package org.neuroph.nnet.comp;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Dimension2D
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = -4491706467345191108L;
/*    */   private int width;
/*    */   private int height;
/*    */   
/*    */   public Dimension2D(int width, int height)
/*    */   {
/* 27 */     this.width = width;
/* 28 */     this.height = height;
/*    */   }
/*    */   
/*    */   public int getWidth() {
/* 32 */     return this.width;
/*    */   }
/*    */   
/*    */   public void setWidth(int width) {
/* 36 */     this.width = width;
/*    */   }
/*    */   
/*    */   public int getHeight() {
/* 40 */     return this.height;
/*    */   }
/*    */   
/*    */   public void setHeight(int height) {
/* 44 */     this.height = height;
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 49 */     String dimensions = "Width = " + this.width + "; Height = " + this.height;
/* 50 */     return dimensions;
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\nnet\comp\Dimension2D.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */