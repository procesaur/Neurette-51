/*    */ package org.neuroph.nnet.comp;
/*    */ 
/*    */ import org.neuroph.core.Connection;
/*    */ import org.neuroph.core.Neuron;
/*    */ import org.neuroph.nnet.comp.neuron.DelayedNeuron;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DelayedConnection
/*    */   extends Connection
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/* 39 */   private int delay = 0;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public DelayedConnection(Neuron fromNeuron, Neuron toNeuron, double weightVal, int delay)
/*    */   {
/* 50 */     super(fromNeuron, toNeuron, weightVal);
/* 51 */     this.delay = delay;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public int getDelay()
/*    */   {
/* 59 */     return this.delay;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setDelay(int delay)
/*    */   {
/* 67 */     this.delay = delay;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public double getInput()
/*    */   {
/* 76 */     if ((this.fromNeuron instanceof DelayedNeuron)) {
/* 77 */       return ((DelayedNeuron)this.fromNeuron).getOutput(this.delay);
/*    */     }
/* 79 */     return this.fromNeuron.getOutput();
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\nnet\comp\DelayedConnection.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */