/*    */ package org.neuroph.nnet.comp.neuron;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.ObjectInputStream;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.neuroph.core.Neuron;
/*    */ import org.neuroph.core.input.InputFunction;
/*    */ import org.neuroph.core.transfer.TransferFunction;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DelayedNeuron
/*    */   extends Neuron
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   protected transient List<Double> outputHistory;
/*    */   
/*    */   public DelayedNeuron(InputFunction inputFunction, TransferFunction transferFunction)
/*    */   {
/* 51 */     super(inputFunction, transferFunction);
/* 52 */     this.outputHistory = new ArrayList(5);
/* 53 */     this.outputHistory.add(new Double(0.0D));
/*    */   }
/*    */   
/*    */   public void calculate()
/*    */   {
/* 58 */     super.calculate();
/* 59 */     this.outputHistory.add(0, new Double(this.output));
/* 60 */     if (this.outputHistory.size() > 5) {
/* 61 */       this.outputHistory.remove(5);
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public double getOutput(int delay)
/*    */   {
/* 70 */     return ((Double)this.outputHistory.get(delay)).doubleValue();
/*    */   }
/*    */   
/*    */   private void readObject(ObjectInputStream in)
/*    */     throws IOException, ClassNotFoundException
/*    */   {
/* 76 */     in.defaultReadObject();
/* 77 */     this.outputHistory = new ArrayList(5);
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\nnet\comp\neuron\DelayedNeuron.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */