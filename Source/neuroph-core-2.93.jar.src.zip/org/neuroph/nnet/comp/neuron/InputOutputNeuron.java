/*     */ package org.neuroph.nnet.comp.neuron;
/*     */ 
/*     */ import org.neuroph.core.Neuron;
/*     */ import org.neuroph.core.input.InputFunction;
/*     */ import org.neuroph.core.transfer.TransferFunction;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InputOutputNeuron
/*     */   extends Neuron
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private boolean externalInputSet;
/*  45 */   private double bias = 0.0D;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public InputOutputNeuron() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public InputOutputNeuron(InputFunction inFunc, TransferFunction transFunc)
/*     */   {
/*  61 */     super(inFunc, transFunc);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setInput(double input)
/*     */   {
/*  72 */     this.totalInput = input;
/*  73 */     this.externalInputSet = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public double getBias()
/*     */   {
/*  81 */     return this.bias;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBias(double bias)
/*     */   {
/*  89 */     this.bias = bias;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void calculate()
/*     */   {
/*  98 */     if ((!this.externalInputSet) && 
/*  99 */       (hasInputConnections()))
/*     */     {
/* 101 */       this.totalInput = this.inputFunction.getOutput(this.inputConnections);
/*     */     }
/*     */     
/*     */ 
/* 105 */     this.output = this.transferFunction.getOutput(this.totalInput + this.bias);
/*     */     
/*     */ 
/* 108 */     if (this.externalInputSet) {
/* 109 */       this.externalInputSet = false;
/* 110 */       this.totalInput = 0.0D;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\nnet\comp\neuron\InputOutputNeuron.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */