/*    */ package org.neuroph.nnet.comp.neuron;
/*    */ 
/*    */ import org.neuroph.core.Neuron;
/*    */ import org.neuroph.core.input.InputFunction;
/*    */ import org.neuroph.core.transfer.TransferFunction;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ThresholdNeuron
/*    */   extends Neuron
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/* 38 */   protected double thresh = 0.0D;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public ThresholdNeuron(InputFunction inputFunction, TransferFunction transferFunction)
/*    */   {
/* 50 */     this.inputFunction = inputFunction;
/* 51 */     this.transferFunction = transferFunction;
/* 52 */     this.thresh = Math.random();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void calculate()
/*    */   {
/* 60 */     this.totalInput = this.inputFunction.getOutput(this.inputConnections);
/* 61 */     this.output = this.transferFunction.getOutput(this.totalInput - this.thresh);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public double getThresh()
/*    */   {
/* 69 */     return this.thresh;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setThresh(double thresh)
/*    */   {
/* 77 */     this.thresh = thresh;
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\nnet\comp\neuron\ThresholdNeuron.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */