/*    */ package org.neuroph.nnet.comp.neuron;
/*    */ 
/*    */ import org.neuroph.core.Neuron;
/*    */ import org.neuroph.core.input.WeightedSum;
/*    */ import org.neuroph.core.transfer.Linear;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InputNeuron
/*    */   extends Neuron
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public InputNeuron()
/*    */   {
/* 37 */     super(new WeightedSum(), new Linear());
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void calculate()
/*    */   {
/* 46 */     this.output = this.totalInput;
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\nnet\comp\neuron\InputNeuron.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */