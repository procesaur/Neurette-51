/*     */ package org.neuroph.nnet.comp.neuron;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.neuroph.core.Connection;
/*     */ import org.neuroph.core.Neuron;
/*     */ import org.neuroph.core.input.InputFunction;
/*     */ import org.neuroph.core.transfer.TransferFunction;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CompetitiveNeuron
/*     */   extends DelayedNeuron
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  44 */   private boolean isCompeting = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private List<Connection> connectionsFromOtherLayers;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private List<Connection> connectionsFromThisLayer;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CompetitiveNeuron(InputFunction inputFunction, TransferFunction transferFunction)
/*     */   {
/*  63 */     super(inputFunction, transferFunction);
/*  64 */     this.connectionsFromOtherLayers = new ArrayList();
/*  65 */     this.connectionsFromThisLayer = new ArrayList();
/*  66 */     addInputConnection(this, 1.0D);
/*     */   }
/*     */   
/*     */   public void calculate()
/*     */   {
/*  71 */     if (this.isCompeting)
/*     */     {
/*     */ 
/*  74 */       this.totalInput = this.inputFunction.getOutput(this.connectionsFromThisLayer);
/*     */     }
/*     */     else
/*     */     {
/*  78 */       this.totalInput = this.inputFunction.getOutput(this.connectionsFromOtherLayers);
/*  79 */       this.isCompeting = true;
/*     */     }
/*     */     
/*  82 */     this.output = this.transferFunction.getOutput(this.totalInput);
/*  83 */     this.outputHistory.add(0, new Double(this.output));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addInputConnection(Connection connection)
/*     */   {
/*  92 */     super.addInputConnection(connection);
/*     */     
/*  94 */     if (connection.getFromNeuron().getParentLayer() == getParentLayer())
/*     */     {
/*     */ 
/*  97 */       this.connectionsFromThisLayer.add(connection);
/*     */     }
/*     */     else
/*     */     {
/* 101 */       this.connectionsFromOtherLayers.add(connection);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<Connection> getConnectionsFromOtherLayers()
/*     */   {
/* 110 */     return this.connectionsFromOtherLayers;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void reset()
/*     */   {
/* 118 */     super.reset();
/* 119 */     this.isCompeting = false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isCompeting()
/*     */   {
/* 127 */     return this.isCompeting;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setIsCompeting(boolean isCompeting)
/*     */   {
/* 135 */     this.isCompeting = isCompeting;
/*     */   }
/*     */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\nnet\comp\neuron\CompetitiveNeuron.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */