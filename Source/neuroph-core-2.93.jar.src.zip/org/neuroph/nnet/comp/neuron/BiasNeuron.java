/*    */ package org.neuroph.nnet.comp.neuron;
/*    */ 
/*    */ import org.neuroph.core.Connection;
/*    */ import org.neuroph.core.Neuron;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BiasNeuron
/*    */   extends Neuron
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public double getOutput()
/*    */   {
/* 45 */     return 1.0D;
/*    */   }
/*    */   
/*    */   public void addInputConnection(Connection connection) {}
/*    */   
/*    */   public void addInputConnection(Neuron fromNeuron, double weightVal) {}
/*    */   
/*    */   public void addInputConnection(Neuron fromNeuron) {}
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\nnet\comp\neuron\BiasNeuron.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */