/*     */ package org.neuroph.nnet.comp.layer;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.neuroph.core.Layer;
/*     */ import org.neuroph.core.Neuron;
/*     */ import org.neuroph.nnet.comp.Dimension2D;
/*     */ import org.neuroph.util.NeuronProperties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class FeatureMapsLayer
/*     */   extends Layer
/*     */ {
/*     */   private static final long serialVersionUID = -6706741997689639209L;
/*     */   protected Dimension2D mapDimensions;
/*     */   private List<FeatureMapLayer> featureMaps;
/*     */   
/*     */   public List<FeatureMapLayer> getFeatureMaps()
/*     */   {
/*  61 */     return this.featureMaps;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FeatureMapsLayer()
/*     */   {
/*  76 */     this.featureMaps = new ArrayList();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FeatureMapsLayer(Dimension2D mapDimensions)
/*     */   {
/*  88 */     this.mapDimensions = mapDimensions;
/*  89 */     this.featureMaps = new ArrayList();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FeatureMapsLayer(Dimension2D kernelDimension, Dimension2D mapDimensions, int mapCount, NeuronProperties neuronProp)
/*     */   {
/* 103 */     this.mapDimensions = mapDimensions;
/* 104 */     this.featureMaps = new ArrayList();
/* 105 */     createFeatureMaps(mapCount, mapDimensions, kernelDimension, neuronProp);
/*     */   }
/*     */   
/*     */ 
/*     */   public FeatureMapsLayer(Dimension2D mapDimensions, int mapCount, NeuronProperties neuronProp)
/*     */   {
/* 111 */     this.mapDimensions = mapDimensions;
/* 112 */     this.featureMaps = new ArrayList();
/* 113 */     createFeatureMaps(mapCount, mapDimensions, neuronProp);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addFeatureMap(FeatureMapLayer featureMap)
/*     */   {
/* 122 */     if (featureMap == null) {
/* 123 */       throw new IllegalArgumentException("FeatureMap cant be null!");
/*     */     }
/*     */     
/* 126 */     this.featureMaps.add(featureMap);
/* 127 */     this.neurons.addAll(featureMap.getNeurons());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final void createFeatureMaps(int mapCount, Dimension2D mapDimensions, Dimension2D kernelDimension, NeuronProperties neuronProperties)
/*     */   {
/* 139 */     for (int i = 0; i < mapCount; i++) {
/* 140 */       addFeatureMap(new FeatureMapLayer(mapDimensions, neuronProperties, kernelDimension));
/*     */     }
/*     */   }
/*     */   
/*     */   private final void createFeatureMaps(int mapCount, Dimension2D mapDimensions, NeuronProperties neuronProperties)
/*     */   {
/* 146 */     for (int i = 0; i < mapCount; i++) {
/* 147 */       addFeatureMap(new FeatureMapLayer(mapDimensions, neuronProperties));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FeatureMapLayer getFeatureMap(int index)
/*     */   {
/* 159 */     return (FeatureMapLayer)this.featureMaps.get(index);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getNumberOfMaps()
/*     */   {
/* 168 */     return this.featureMaps.size();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Neuron getNeuronAt(int x, int y, int mapIndex)
/*     */   {
/* 180 */     FeatureMapLayer map = (FeatureMapLayer)this.featureMaps.get(mapIndex);
/* 181 */     return map.getNeuronAt(x, y);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getNeuronsCount()
/*     */   {
/* 191 */     int neuronCount = 0;
/* 192 */     for (FeatureMapLayer map : this.featureMaps)
/* 193 */       neuronCount += map.getNeuronsCount();
/* 194 */     return neuronCount;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Dimension2D getMapDimensions()
/*     */   {
/* 220 */     return this.mapDimensions;
/*     */   }
/*     */   
/*     */   public abstract void connectMaps(FeatureMapLayer paramFeatureMapLayer1, FeatureMapLayer paramFeatureMapLayer2);
/*     */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\nnet\comp\layer\FeatureMapsLayer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */