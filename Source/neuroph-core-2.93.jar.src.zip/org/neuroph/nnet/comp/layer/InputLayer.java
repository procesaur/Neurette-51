/*    */ package org.neuroph.nnet.comp.layer;
/*    */ 
/*    */ import org.neuroph.core.Layer;
/*    */ import org.neuroph.core.Neuron;
/*    */ import org.neuroph.core.transfer.Linear;
/*    */ import org.neuroph.nnet.comp.neuron.InputNeuron;
/*    */ import org.neuroph.util.NeuronFactory;
/*    */ import org.neuroph.util.NeuronProperties;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InputLayer
/*    */   extends Layer
/*    */ {
/*    */   public InputLayer(int neuronsCount)
/*    */   {
/* 38 */     NeuronProperties inputNeuronProperties = new NeuronProperties(InputNeuron.class, Linear.class);
/*    */     
/* 40 */     for (int i = 0; i < neuronsCount; i++) {
/* 41 */       Neuron neuron = NeuronFactory.createNeuron(inputNeuronProperties);
/* 42 */       addNeuron(neuron);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\nnet\comp\layer\InputLayer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */