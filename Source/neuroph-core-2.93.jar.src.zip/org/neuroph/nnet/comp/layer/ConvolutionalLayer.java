/*     */ package org.neuroph.nnet.comp.layer;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.neuroph.core.Neuron;
/*     */ import org.neuroph.core.Weight;
/*     */ import org.neuroph.core.input.WeightedSum;
/*     */ import org.neuroph.core.transfer.Tanh;
/*     */ import org.neuroph.core.transfer.TransferFunction;
/*     */ import org.neuroph.nnet.comp.Dimension2D;
/*     */ import org.neuroph.nnet.comp.Kernel;
/*     */ import org.neuroph.nnet.comp.neuron.BiasNeuron;
/*     */ import org.neuroph.util.ConnectionFactory;
/*     */ import org.neuroph.util.NeuronProperties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConvolutionalLayer
/*     */   extends FeatureMapsLayer
/*     */ {
/*     */   private static final long serialVersionUID = -4619196904153707871L;
/*  47 */   public static final NeuronProperties DEFAULT_NEURON_PROP = new NeuronProperties();
/*     */   
/*     */   static
/*     */   {
/*  51 */     DEFAULT_NEURON_PROP.setProperty("inputFunction", WeightedSum.class);
/*  52 */     DEFAULT_NEURON_PROP.setProperty("transferFunction", Tanh.class);
/*  53 */     DEFAULT_NEURON_PROP.setProperty("useBias", Boolean.valueOf(true));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ConvolutionalLayer(FeatureMapsLayer fromLayer, Dimension2D kernelDimension, int numberOfMaps)
/*     */   {
/*  83 */     Dimension2D fromDimension = fromLayer.getMapDimensions();
/*     */     
/*  85 */     int mapWidth = fromDimension.getWidth() - kernelDimension.getWidth() + 1;
/*  86 */     int mapHeight = fromDimension.getHeight() - kernelDimension.getHeight() + 1;
/*  87 */     this.mapDimensions = new Dimension2D(mapWidth, mapHeight);
/*     */     
/*  89 */     createFeatureMaps(numberOfMaps, this.mapDimensions, kernelDimension, DEFAULT_NEURON_PROP);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ConvolutionalLayer(FeatureMapsLayer fromLayer, Dimension2D kernelDimension, int numberOfMaps, Class<? extends TransferFunction> transferFunction)
/*     */   {
/* 104 */     Dimension2D fromDimension = fromLayer.getMapDimensions();
/*     */     
/* 106 */     int mapWidth = fromDimension.getWidth() - kernelDimension.getWidth() + 1;
/* 107 */     int mapHeight = fromDimension.getHeight() - kernelDimension.getHeight() + 1;
/* 108 */     this.mapDimensions = new Dimension2D(mapWidth, mapHeight);
/*     */     
/* 110 */     NeuronProperties neuronProp = new NeuronProperties(Neuron.class, transferFunction);
/*     */     
/* 112 */     createFeatureMaps(numberOfMaps, this.mapDimensions, kernelDimension, neuronProp);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ConvolutionalLayer(FeatureMapsLayer fromLayer, Dimension2D kernelDimension, int numberOfMaps, NeuronProperties neuronProp)
/*     */   {
/* 126 */     Dimension2D fromDimension = fromLayer.getMapDimensions();
/*     */     
/* 128 */     int mapWidth = fromDimension.getWidth() - kernelDimension.getWidth() + 1;
/* 129 */     int mapHeight = fromDimension.getHeight() - kernelDimension.getHeight() + 1;
/* 130 */     this.mapDimensions = new Dimension2D(mapWidth, mapHeight);
/*     */     
/* 132 */     createFeatureMaps(numberOfMaps, this.mapDimensions, kernelDimension, neuronProp);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void connectMaps(FeatureMapLayer fromMap, FeatureMapLayer toMap)
/*     */   {
/* 149 */     Kernel kernel = toMap.getKernel();
/* 150 */     kernel.initWeights(-0.15D, 0.15D);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 166 */     BiasNeuron biasNeuron = new BiasNeuron();
/* 167 */     fromMap.addNeuron(biasNeuron);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 173 */     for (int y = 0; y < toMap.getHeight(); y++) {
/* 174 */       for (int x = 0; x < toMap.getWidth(); x++) {
/* 175 */         Neuron toNeuron = toMap.getNeuronAt(x, y);
/* 176 */         for (int ky = 0; ky < kernel.getHeight(); ky++) {
/* 177 */           for (int kx = 0; kx < kernel.getWidth(); kx++) {
/* 178 */             int fromX = x + kx;
/* 179 */             int fromY = y + ky;
/*     */             
/* 181 */             Weight[][] concreteKernel = kernel.getWeights();
/* 182 */             Neuron fromNeuron = fromMap.getNeuronAt(fromX, fromY);
/* 183 */             ConnectionFactory.createConnection(fromNeuron, toNeuron, concreteKernel[kx][ky]);
/*     */             
/* 185 */             ConnectionFactory.createConnection(biasNeuron, toNeuron);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private double getWeightCoeficient(FeatureMapLayer toMap)
/*     */   {
/* 195 */     int numberOfInputConnections = toMap.getNeuronAt(0, 0).getInputConnections().size();
/* 196 */     double coefficient = 1.0D / Math.sqrt(numberOfInputConnections);
/* 197 */     coefficient = (!Double.isInfinite(coefficient)) || (!Double.isNaN(coefficient)) || (coefficient == 0.0D) ? 1.0D : coefficient;
/* 198 */     return coefficient;
/*     */   }
/*     */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\nnet\comp\layer\ConvolutionalLayer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */