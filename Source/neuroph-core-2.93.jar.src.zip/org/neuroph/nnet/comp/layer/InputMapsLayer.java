/*    */ package org.neuroph.nnet.comp.layer;
/*    */ 
/*    */ import org.neuroph.core.transfer.Linear;
/*    */ import org.neuroph.nnet.comp.Dimension2D;
/*    */ import org.neuroph.nnet.comp.neuron.InputNeuron;
/*    */ import org.neuroph.util.NeuronProperties;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InputMapsLayer
/*    */   extends FeatureMapsLayer
/*    */ {
/*    */   private static final long serialVersionUID = -4982081431101626706L;
/* 36 */   public static final NeuronProperties DEFAULT_NEURON_PROP = new NeuronProperties();
/*    */   
/*    */   static {
/* 39 */     DEFAULT_NEURON_PROP.setProperty("neuronType", InputNeuron.class);
/* 40 */     DEFAULT_NEURON_PROP.setProperty("transferFunction", Linear.class);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void connectMaps(FeatureMapLayer fromMap, FeatureMapLayer toMap) {}
/*    */   
/*    */ 
/*    */   public InputMapsLayer(Dimension2D mapDimensions, int mapCount)
/*    */   {
/* 50 */     super(mapDimensions, mapCount, DEFAULT_NEURON_PROP);
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\nnet\comp\layer\InputMapsLayer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */