/*     */ package org.neuroph.nnet.comp.layer;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.neuroph.core.Layer;
/*     */ import org.neuroph.core.Neuron;
/*     */ import org.neuroph.nnet.comp.neuron.CompetitiveNeuron;
/*     */ import org.neuroph.util.NeuronProperties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CompetitiveLayer
/*     */   extends Layer
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  44 */   private int maxIterations = 100;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private CompetitiveNeuron winner;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CompetitiveLayer(int neuronNum, NeuronProperties neuronProperties)
/*     */   {
/*  58 */     super(neuronNum, neuronProperties);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void calculate()
/*     */   {
/*  66 */     boolean hasWinner = false;
/*     */     
/*  68 */     int iterationsCount = 0;
/*     */     Neuron neuron;
/*  70 */     while (!hasWinner) {
/*  71 */       int fireingNeurons = 0;
/*  72 */       for (Iterator localIterator = getNeurons().iterator(); localIterator.hasNext();) { neuron = (Neuron)localIterator.next();
/*  73 */         neuron.calculate();
/*  74 */         if (neuron.getOutput() > 0.0D) {
/*  75 */           fireingNeurons++;
/*     */         }
/*     */       }
/*  78 */       if (iterationsCount > this.maxIterations)
/*     */         break;
/*  80 */       if (fireingNeurons == 1)
/*  81 */         hasWinner = true;
/*  82 */       iterationsCount++;
/*     */     }
/*     */     
/*     */     double maxOutput;
/*  86 */     if (hasWinner)
/*     */     {
/*  88 */       maxOutput = Double.MIN_VALUE;
/*     */       
/*  90 */       for (Neuron neuron : getNeurons()) {
/*  91 */         CompetitiveNeuron cNeuron = (CompetitiveNeuron)neuron;
/*  92 */         cNeuron.setIsCompeting(false);
/*  93 */         if (cNeuron.getOutput() > maxOutput) {
/*  94 */           maxOutput = cNeuron.getOutput();
/*  95 */           this.winner = cNeuron;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CompetitiveNeuron getWinner()
/*     */   {
/* 107 */     return this.winner;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getMaxIterations()
/*     */   {
/* 115 */     return this.maxIterations;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMaxIterations(int maxIterations)
/*     */   {
/* 123 */     this.maxIterations = maxIterations;
/*     */   }
/*     */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\nnet\comp\layer\CompetitiveLayer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */