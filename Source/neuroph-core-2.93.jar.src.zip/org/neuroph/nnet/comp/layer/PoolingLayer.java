/*     */ package org.neuroph.nnet.comp.layer;
/*     */ 
/*     */ import org.neuroph.core.Neuron;
/*     */ import org.neuroph.core.Weight;
/*     */ import org.neuroph.core.input.Max;
/*     */ import org.neuroph.core.transfer.Tanh;
/*     */ import org.neuroph.nnet.comp.Dimension2D;
/*     */ import org.neuroph.nnet.comp.Kernel;
/*     */ import org.neuroph.util.ConnectionFactory;
/*     */ import org.neuroph.util.NeuronProperties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PoolingLayer
/*     */   extends FeatureMapsLayer
/*     */ {
/*     */   private static final long serialVersionUID = -6771501759374920878L;
/*     */   private Kernel kernel;
/*  48 */   public static final NeuronProperties DEFAULT_NEURON_PROP = new NeuronProperties();
/*     */   
/*     */   static {
/*  51 */     DEFAULT_NEURON_PROP.setProperty("useBias", Boolean.valueOf(true));
/*  52 */     DEFAULT_NEURON_PROP.setProperty("transferFunction", Tanh.class);
/*     */     
/*  54 */     DEFAULT_NEURON_PROP.setProperty("inputFunction", Max.class);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PoolingLayer(FeatureMapsLayer fromLayer, Dimension2D kernelDim)
/*     */   {
/*  68 */     this.kernel = new Kernel(kernelDim);
/*  69 */     int numberOfMaps = fromLayer.getNumberOfMaps();
/*  70 */     Dimension2D fromDimension = fromLayer.getMapDimensions();
/*     */     
/*  72 */     int mapWidth = fromDimension.getWidth() / this.kernel.getWidth();
/*  73 */     int mapHeight = fromDimension.getHeight() / this.kernel.getHeight();
/*  74 */     this.mapDimensions = new Dimension2D(mapWidth, mapHeight);
/*     */     
/*  76 */     createFeatureMaps(numberOfMaps, this.mapDimensions, kernelDim, DEFAULT_NEURON_PROP);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PoolingLayer(FeatureMapsLayer fromLayer, Dimension2D kernelDim, int numberOfMaps, NeuronProperties neuronProp)
/*     */   {
/*  90 */     this.kernel = this.kernel;
/*  91 */     Dimension2D fromDimension = fromLayer.getMapDimensions();
/*     */     
/*  93 */     int mapWidth = fromDimension.getWidth() / this.kernel.getWidth();
/*  94 */     int mapHeight = fromDimension.getHeight() / this.kernel.getHeight();
/*  95 */     this.mapDimensions = new Dimension2D(mapWidth, mapHeight);
/*     */     
/*  97 */     createFeatureMaps(numberOfMaps, this.mapDimensions, kernelDim, neuronProp);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void connectMaps(FeatureMapLayer fromMap, FeatureMapLayer toMap)
/*     */   {
/* 111 */     int kernelWidth = this.kernel.getWidth();
/* 112 */     int kernelHeight = this.kernel.getHeight();
/* 113 */     Weight weight = new Weight(1.0D);
/* 114 */     for (int x = 0; x < fromMap.getWidth() - kernelWidth + 1; x += kernelWidth) {
/* 115 */       for (int y = 0; y < fromMap.getHeight() - kernelHeight + 1; y += kernelHeight)
/*     */       {
/* 117 */         Neuron toNeuron = toMap.getNeuronAt(x / kernelWidth, y / kernelHeight);
/* 118 */         for (int dy = 0; dy < kernelHeight; dy++) {
/* 119 */           for (int dx = 0; dx < kernelWidth; dx++) {
/* 120 */             int fromX = x + dx;
/* 121 */             int fromY = y + dy;
/* 122 */             Neuron fromNeuron = fromMap.getNeuronAt(fromX, fromY);
/* 123 */             ConnectionFactory.createConnection(fromNeuron, toNeuron, weight);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\nnet\comp\layer\PoolingLayer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */