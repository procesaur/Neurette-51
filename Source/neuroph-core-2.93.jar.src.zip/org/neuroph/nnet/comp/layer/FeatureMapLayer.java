/*     */ package org.neuroph.nnet.comp.layer;
/*     */ 
/*     */ import org.neuroph.core.Layer;
/*     */ import org.neuroph.core.Neuron;
/*     */ import org.neuroph.nnet.comp.Dimension2D;
/*     */ import org.neuroph.nnet.comp.Kernel;
/*     */ import org.neuroph.util.NeuronFactory;
/*     */ import org.neuroph.util.NeuronProperties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FeatureMapLayer
/*     */   extends Layer
/*     */ {
/*     */   private static final long serialVersionUID = 2498669699995172395L;
/*     */   private Dimension2D dimensions;
/*     */   private Kernel kernel;
/*     */   
/*     */   public FeatureMapLayer(Dimension2D dimensions, NeuronProperties neuronProperties)
/*     */   {
/*  58 */     this.dimensions = dimensions;
/*     */     
/*  60 */     for (int i = 0; i < dimensions.getHeight() * dimensions.getWidth(); i++) {
/*  61 */       Neuron neuron = NeuronFactory.createNeuron(neuronProperties);
/*  62 */       addNeuron(neuron);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FeatureMapLayer(Dimension2D dimensions, Dimension2D kernelDimension)
/*     */   {
/*  73 */     this.dimensions = dimensions;
/*  74 */     this.kernel = new Kernel(kernelDimension);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FeatureMapLayer(Dimension2D dimensions, NeuronProperties neuronProperties, Dimension2D kernelDimension)
/*     */   {
/*  85 */     this(dimensions, kernelDimension);
/*     */     
/*  87 */     for (int i = 0; i < dimensions.getHeight() * dimensions.getWidth(); i++) {
/*  88 */       Neuron neuron = NeuronFactory.createNeuron(neuronProperties);
/*  89 */       addNeuron(neuron);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getWidth()
/*     */   {
/*  99 */     return this.dimensions.getWidth();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getHeight()
/*     */   {
/* 108 */     return this.dimensions.getHeight();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Dimension2D getDimensions()
/*     */   {
/* 118 */     return this.dimensions;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Neuron getNeuronAt(int x, int y)
/*     */   {
/* 130 */     return getNeuronAt(x + y * this.dimensions.getWidth());
/*     */   }
/*     */   
/*     */   public Kernel getKernel() {
/* 134 */     return this.kernel;
/*     */   }
/*     */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\nnet\comp\layer\FeatureMapLayer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */