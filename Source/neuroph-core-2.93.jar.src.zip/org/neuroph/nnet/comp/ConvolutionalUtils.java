/*    */ package org.neuroph.nnet.comp;
/*    */ 
/*    */ import org.neuroph.nnet.comp.layer.ConvolutionalLayer;
/*    */ import org.neuroph.nnet.comp.layer.FeatureMapLayer;
/*    */ import org.neuroph.nnet.comp.layer.FeatureMapsLayer;
/*    */ import org.neuroph.nnet.comp.layer.PoolingLayer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConvolutionalUtils
/*    */ {
/*    */   public static void fullConnectMapLayers(FeatureMapsLayer fromLayer, FeatureMapsLayer toLayer)
/*    */   {
/* 38 */     if ((toLayer instanceof ConvolutionalLayer)) {
/* 39 */       for (int i = 0; i < fromLayer.getNumberOfMaps(); i++) {
/* 40 */         for (int j = 0; j < toLayer.getNumberOfMaps(); j++) {
/* 41 */           FeatureMapLayer fromMap = fromLayer.getFeatureMap(i);
/* 42 */           FeatureMapLayer toMap = toLayer.getFeatureMap(j);
/* 43 */           toLayer.connectMaps(fromMap, toMap);
/*    */         }
/*    */       }
/* 46 */     } else if ((toLayer instanceof PoolingLayer)) {
/* 47 */       for (int i = 0; i < toLayer.getNumberOfMaps(); i++) {
/* 48 */         FeatureMapLayer fromMap = fromLayer.getFeatureMap(i);
/* 49 */         FeatureMapLayer toMap = toLayer.getFeatureMap(i);
/* 50 */         toLayer.connectMaps(fromMap, toMap);
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static void connectFeatureMaps(FeatureMapsLayer fromLayer, FeatureMapsLayer toLayer, int fromFeatureMapIndex, int toFeatureMapIndex)
/*    */   {
/* 66 */     FeatureMapLayer fromMap = fromLayer.getFeatureMap(fromFeatureMapIndex);
/* 67 */     FeatureMapLayer toMap = toLayer.getFeatureMap(toFeatureMapIndex);
/* 68 */     toLayer.connectMaps(fromMap, toMap);
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\nnet\comp\ConvolutionalUtils.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */