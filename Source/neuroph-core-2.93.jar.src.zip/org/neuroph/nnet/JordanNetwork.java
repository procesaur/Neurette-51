/*    */ package org.neuroph.nnet;
/*    */ 
/*    */ import org.neuroph.core.Layer;
/*    */ import org.neuroph.core.NeuralNetwork;
/*    */ import org.neuroph.nnet.comp.layer.InputLayer;
/*    */ import org.neuroph.nnet.comp.neuron.BiasNeuron;
/*    */ import org.neuroph.nnet.learning.BackPropagation;
/*    */ import org.neuroph.util.ConnectionFactory;
/*    */ import org.neuroph.util.NeuralNetworkFactory;
/*    */ import org.neuroph.util.NeuronProperties;
/*    */ import org.neuroph.util.TransferFunctionType;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JordanNetwork
/*    */   extends NeuralNetwork
/*    */ {
/*    */   public JordanNetwork(int inputNeuronsCount, int hiddenNeuronsCount, int contextNeuronsCount, int outputNeuronsCount)
/*    */   {
/* 20 */     createNetwork(inputNeuronsCount, hiddenNeuronsCount, contextNeuronsCount, outputNeuronsCount);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private void createNetwork(int inputNeuronsCount, int hiddenNeuronsCount, int contextNeuronsCount, int outputNeuronsCount)
/*    */   {
/* 35 */     InputLayer inputLayer = new InputLayer(inputNeuronsCount);
/* 36 */     inputLayer.addNeuron(new BiasNeuron());
/* 37 */     addLayer(inputLayer);
/*    */     
/* 39 */     NeuronProperties neuronProperties = new NeuronProperties();
/*    */     
/* 41 */     neuronProperties.setProperty("transferFunction", TransferFunctionType.SIGMOID);
/*    */     
/* 43 */     Layer hiddenLayer = new Layer(hiddenNeuronsCount, neuronProperties);
/* 44 */     hiddenLayer.addNeuron(new BiasNeuron());
/* 45 */     addLayer(hiddenLayer);
/*    */     
/* 47 */     ConnectionFactory.fullConnect(inputLayer, hiddenLayer);
/*    */     
/* 49 */     Layer contextLayer = new Layer(contextNeuronsCount, neuronProperties);
/* 50 */     addLayer(contextLayer);
/*    */     
/* 52 */     Layer outputLayer = new Layer(outputNeuronsCount, neuronProperties);
/* 53 */     addLayer(outputLayer);
/*    */     
/* 55 */     ConnectionFactory.fullConnect(hiddenLayer, outputLayer);
/*    */     
/* 57 */     ConnectionFactory.fullConnect(outputLayer, contextLayer);
/* 58 */     ConnectionFactory.fullConnect(contextLayer, hiddenLayer);
/*    */     
/*    */ 
/*    */ 
/* 62 */     NeuralNetworkFactory.setDefaultIO(this);
/*    */     
/*    */ 
/* 65 */     setLearningRule(new BackPropagation());
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\nnet\JordanNetwork.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */