/*    */ package org.neuroph.nnet;
/*    */ 
/*    */ import org.neuroph.core.Layer;
/*    */ import org.neuroph.core.NeuralNetwork;
/*    */ import org.neuroph.nnet.comp.neuron.InputOutputNeuron;
/*    */ import org.neuroph.nnet.learning.BinaryHebbianLearning;
/*    */ import org.neuroph.util.ConnectionFactory;
/*    */ import org.neuroph.util.LayerFactory;
/*    */ import org.neuroph.util.NeuralNetworkFactory;
/*    */ import org.neuroph.util.NeuralNetworkType;
/*    */ import org.neuroph.util.NeuronProperties;
/*    */ import org.neuroph.util.TransferFunctionType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BAM
/*    */   extends NeuralNetwork
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public BAM(int inputNeuronsCount, int outputNeuronsCount)
/*    */   {
/* 49 */     NeuronProperties neuronProperties = new NeuronProperties();
/* 50 */     neuronProperties.setProperty("neuronType", InputOutputNeuron.class);
/* 51 */     neuronProperties.setProperty("bias", new Double(0.0D));
/* 52 */     neuronProperties.setProperty("transferFunction", TransferFunctionType.STEP);
/* 53 */     neuronProperties.setProperty("transferFunction.yHigh", new Double(1.0D));
/* 54 */     neuronProperties.setProperty("transferFunction.yLow", new Double(0.0D));
/*    */     
/* 56 */     createNetwork(inputNeuronsCount, outputNeuronsCount, neuronProperties);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private void createNetwork(int inputNeuronsCount, int outputNeuronsCount, NeuronProperties neuronProperties)
/*    */   {
/* 72 */     setNetworkType(NeuralNetworkType.BAM);
/*    */     
/*    */ 
/* 75 */     Layer inputLayer = LayerFactory.createLayer(inputNeuronsCount, neuronProperties);
/*    */     
/* 77 */     addLayer(inputLayer);
/*    */     
/*    */ 
/* 80 */     Layer outputLayer = LayerFactory.createLayer(outputNeuronsCount, neuronProperties);
/*    */     
/* 82 */     addLayer(outputLayer);
/*    */     
/*    */ 
/* 85 */     ConnectionFactory.fullConnect(inputLayer, outputLayer);
/*    */     
/* 87 */     ConnectionFactory.fullConnect(outputLayer, inputLayer);
/*    */     
/*    */ 
/* 90 */     NeuralNetworkFactory.setDefaultIO(this);
/*    */     
/*    */ 
/* 93 */     setLearningRule(new BinaryHebbianLearning());
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\nnet\BAM.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */