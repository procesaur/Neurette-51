/*     */ package org.neuroph.nnet;
/*     */ 
/*     */ import org.neuroph.core.Layer;
/*     */ import org.neuroph.core.NeuralNetwork;
/*     */ import org.neuroph.core.Neuron;
/*     */ import org.neuroph.core.exceptions.NeurophException;
/*     */ import org.neuroph.core.exceptions.VectorSizeMismatchException;
/*     */ import org.neuroph.core.input.WeightedSum;
/*     */ import org.neuroph.core.transfer.TransferFunction;
/*     */ import org.neuroph.nnet.comp.ConvolutionalUtils;
/*     */ import org.neuroph.nnet.comp.Dimension2D;
/*     */ import org.neuroph.nnet.comp.layer.ConvolutionalLayer;
/*     */ import org.neuroph.nnet.comp.layer.FeatureMapLayer;
/*     */ import org.neuroph.nnet.comp.layer.FeatureMapsLayer;
/*     */ import org.neuroph.nnet.comp.layer.InputMapsLayer;
/*     */ import org.neuroph.nnet.comp.layer.PoolingLayer;
/*     */ import org.neuroph.nnet.comp.neuron.BiasNeuron;
/*     */ import org.neuroph.nnet.learning.ConvolutionalBackpropagation;
/*     */ import org.neuroph.util.ConnectionFactory;
/*     */ import org.neuroph.util.NeuronProperties;
/*     */ import org.neuroph.util.TransferFunctionType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConvolutionalNetwork
/*     */   extends NeuralNetwork<ConvolutionalBackpropagation>
/*     */ {
/*     */   private static final long serialVersionUID = -1393907449047650509L;
/*     */   
/*     */   public void setInput(double... inputVector)
/*     */     throws VectorSizeMismatchException
/*     */   {
/*  62 */     FeatureMapsLayer inputLayer = (FeatureMapsLayer)getLayerAt(0);
/*  63 */     int currentNeuron = 0;
/*  64 */     for (int i = 0; i < inputLayer.getNumberOfMaps(); i++) {
/*  65 */       FeatureMapLayer map = inputLayer.getFeatureMap(i);
/*  66 */       for (Neuron neuron : map.getNeurons()) {
/*  67 */         if (!(neuron instanceof BiasNeuron)) {
/*  68 */           neuron.setInput(inputVector[(currentNeuron++)]);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public static class Builder {
/*  75 */     public static final NeuronProperties DEFAULT_FULL_CONNECTED_NEURON_PROPERTIES = new NeuronProperties();
/*     */     private ConvolutionalNetwork network;
/*     */     
/*     */     static {
/*  79 */       DEFAULT_FULL_CONNECTED_NEURON_PROPERTIES.setProperty("useBias", Boolean.valueOf(true));
/*  80 */       DEFAULT_FULL_CONNECTED_NEURON_PROPERTIES.setProperty("transferFunction", TransferFunctionType.SIGMOID);
/*  81 */       DEFAULT_FULL_CONNECTED_NEURON_PROPERTIES.setProperty("inputFunction", WeightedSum.class);
/*     */     }
/*     */     
/*     */     public Builder() {
/*  85 */       this.network = new ConvolutionalNetwork();
/*     */     }
/*     */     
/*     */     public Builder withInputLayer(int width, int height, int numberOfMaps) {
/*  89 */       if (this.network.getLayersCount() > 0) { throw new NeurophException("Input layer must be the first layer in network");
/*     */       }
/*  91 */       InputMapsLayer inputLayer = new InputMapsLayer(new Dimension2D(width, height), numberOfMaps);
/*  92 */       inputLayer.setLabel("Input Layer");
/*  93 */       this.network.addLayer(inputLayer);
/*     */       
/*  95 */       return this;
/*     */     }
/*     */     
/*     */     public Builder withConvolutionLayer(int kernelWidth, int kernelHeight, int numberOfMaps) {
/*  99 */       FeatureMapsLayer prevLayer = getLastFeatureMapLayer();
/* 100 */       ConvolutionalLayer convolutionLayer = new ConvolutionalLayer(prevLayer, new Dimension2D(kernelWidth, kernelHeight), numberOfMaps);
/*     */       
/* 102 */       this.network.addLayer(convolutionLayer);
/* 103 */       ConvolutionalUtils.fullConnectMapLayers(prevLayer, convolutionLayer);
/*     */       
/* 105 */       return this;
/*     */     }
/*     */     
/*     */     public Builder withConvolutionLayer(Dimension2D kernelDimension, int numberOfMaps, Class<? extends TransferFunction> transferFunction) {
/* 109 */       FeatureMapsLayer prevLayer = getLastFeatureMapLayer();
/* 110 */       ConvolutionalLayer convolutionLayer = new ConvolutionalLayer(prevLayer, kernelDimension, numberOfMaps, transferFunction);
/*     */       
/* 112 */       this.network.addLayer(convolutionLayer);
/* 113 */       ConvolutionalUtils.fullConnectMapLayers(prevLayer, convolutionLayer);
/*     */       
/* 115 */       return this;
/*     */     }
/*     */     
/*     */     public Builder withPoolingLayer(int width, int height) {
/* 119 */       FeatureMapsLayer lastLayer = getLastFeatureMapLayer();
/* 120 */       PoolingLayer poolingLayer = new PoolingLayer(lastLayer, new Dimension2D(width, height));
/*     */       
/* 122 */       this.network.addLayer(poolingLayer);
/* 123 */       ConvolutionalUtils.fullConnectMapLayers(lastLayer, poolingLayer);
/*     */       
/* 125 */       return this;
/*     */     }
/*     */     
/*     */     public Builder withFullConnectedLayer(int numberOfNeurons) {
/* 129 */       Layer lastLayer = getLastLayer();
/*     */       
/* 131 */       Layer fullConnectedLayer = new Layer(numberOfNeurons, DEFAULT_FULL_CONNECTED_NEURON_PROPERTIES);
/* 132 */       this.network.addLayer(fullConnectedLayer);
/*     */       
/* 134 */       ConnectionFactory.fullConnect(lastLayer, fullConnectedLayer);
/*     */       
/* 136 */       return this;
/*     */     }
/*     */     
/*     */     public Builder withFullConnectedLayer(Layer layer) {
/* 140 */       Layer lastLayer = getLastLayer();
/* 141 */       this.network.addLayer(layer);
/* 142 */       ConnectionFactory.fullConnect(lastLayer, layer);
/* 143 */       return this;
/*     */     }
/*     */     
/*     */     public ConvolutionalNetwork build() {
/* 147 */       this.network.setInputNeurons(this.network.getLayerAt(0).getNeurons());
/* 148 */       this.network.setOutputNeurons(getLastLayer().getNeurons());
/* 149 */       this.network.setLearningRule(new ConvolutionalBackpropagation());
/* 150 */       return this.network;
/*     */     }
/*     */     
/*     */     private FeatureMapsLayer getLastFeatureMapLayer()
/*     */     {
/* 155 */       Layer layer = getLastLayer();
/* 156 */       if ((layer instanceof FeatureMapsLayer)) {
/* 157 */         return (FeatureMapsLayer)layer;
/*     */       }
/* 159 */       throw new RuntimeException("Unable to add next layer because previous layer is not FeatureMapLayer");
/*     */     }
/*     */     
/*     */     private Layer getLastLayer() {
/* 163 */       return this.network.getLayerAt(this.network.getLayersCount() - 1);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\nnet\ConvolutionalNetwork.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */