/*    */ package org.neuroph.nnet;
/*    */ 
/*    */ import org.neuroph.core.Layer;
/*    */ import org.neuroph.core.NeuralNetwork;
/*    */ import org.neuroph.nnet.comp.layer.InputLayer;
/*    */ import org.neuroph.nnet.comp.neuron.BiasNeuron;
/*    */ import org.neuroph.nnet.learning.BackPropagation;
/*    */ import org.neuroph.util.ConnectionFactory;
/*    */ import org.neuroph.util.NeuralNetworkFactory;
/*    */ import org.neuroph.util.NeuronProperties;
/*    */ import org.neuroph.util.TransferFunctionType;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ElmanNetwork
/*    */   extends NeuralNetwork
/*    */ {
/*    */   public ElmanNetwork(int inputNeuronsCount, int hiddenNeuronsCount, int contextNeuronsCount, int outputNeuronsCount)
/*    */   {
/* 20 */     createNetwork(inputNeuronsCount, hiddenNeuronsCount, contextNeuronsCount, outputNeuronsCount);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private void createNetwork(int inputNeuronsCount, int hiddenNeuronsCount, int contextNeuronsCount, int outputNeuronsCount)
/*    */   {
/* 34 */     InputLayer inputLayer = new InputLayer(inputNeuronsCount);
/* 35 */     inputLayer.addNeuron(new BiasNeuron());
/* 36 */     addLayer(inputLayer);
/*    */     
/* 38 */     NeuronProperties neuronProperties = new NeuronProperties();
/*    */     
/* 40 */     neuronProperties.setProperty("transferFunction", TransferFunctionType.SIGMOID);
/*    */     
/* 42 */     Layer hiddenLayer = new Layer(hiddenNeuronsCount, neuronProperties);
/* 43 */     hiddenLayer.addNeuron(new BiasNeuron());
/* 44 */     addLayer(hiddenLayer);
/*    */     
/* 46 */     ConnectionFactory.fullConnect(inputLayer, hiddenLayer);
/*    */     
/* 48 */     Layer contextLayer = new Layer(contextNeuronsCount, neuronProperties);
/* 49 */     addLayer(contextLayer);
/*    */     
/* 51 */     Layer outputLayer = new Layer(outputNeuronsCount, neuronProperties);
/* 52 */     addLayer(outputLayer);
/*    */     
/* 54 */     ConnectionFactory.fullConnect(hiddenLayer, outputLayer);
/*    */     
/* 56 */     ConnectionFactory.forwardConnect(hiddenLayer, contextLayer);
/* 57 */     ConnectionFactory.fullConnect(contextLayer, hiddenLayer);
/*    */     
/*    */ 
/*    */ 
/* 61 */     NeuralNetworkFactory.setDefaultIO(this);
/*    */     
/*    */ 
/* 64 */     setLearningRule(new BackPropagation());
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\nnet\ElmanNetwork.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */