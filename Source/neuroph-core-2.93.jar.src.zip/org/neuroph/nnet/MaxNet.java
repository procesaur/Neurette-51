/*    */ package org.neuroph.nnet;
/*    */ 
/*    */ import org.neuroph.core.Layer;
/*    */ import org.neuroph.core.NeuralNetwork;
/*    */ import org.neuroph.nnet.comp.layer.CompetitiveLayer;
/*    */ import org.neuroph.nnet.comp.neuron.CompetitiveNeuron;
/*    */ import org.neuroph.util.ConnectionFactory;
/*    */ import org.neuroph.util.LayerFactory;
/*    */ import org.neuroph.util.NeuralNetworkFactory;
/*    */ import org.neuroph.util.NeuralNetworkType;
/*    */ import org.neuroph.util.NeuronProperties;
/*    */ import org.neuroph.util.TransferFunctionType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MaxNet
/*    */   extends NeuralNetwork
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public MaxNet(int neuronsCount)
/*    */   {
/* 50 */     createNetwork(neuronsCount);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private void createNetwork(int neuronsCount)
/*    */   {
/* 64 */     setNetworkType(NeuralNetworkType.MAXNET);
/*    */     
/*    */ 
/* 67 */     Layer inputLayer = LayerFactory.createLayer(neuronsCount, new NeuronProperties());
/*    */     
/* 69 */     addLayer(inputLayer);
/*    */     
/*    */ 
/* 72 */     NeuronProperties neuronProperties = new NeuronProperties();
/* 73 */     neuronProperties.setProperty("neuronType", CompetitiveNeuron.class);
/* 74 */     neuronProperties.setProperty("transferFunction", TransferFunctionType.RAMP);
/*    */     
/*    */ 
/* 77 */     CompetitiveLayer competitiveLayer = new CompetitiveLayer(neuronsCount, neuronProperties);
/*    */     
/*    */ 
/* 80 */     addLayer(competitiveLayer);
/*    */     
/* 82 */     double competitiveWeight = -(1.0D / neuronsCount);
/*    */     
/* 84 */     ConnectionFactory.fullConnect(competitiveLayer, competitiveWeight, 1);
/*    */     
/*    */ 
/* 87 */     ConnectionFactory.forwardConnect(inputLayer, competitiveLayer, 1.0D);
/*    */     
/*    */ 
/* 90 */     NeuralNetworkFactory.setDefaultIO(this);
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\nnet\MaxNet.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */