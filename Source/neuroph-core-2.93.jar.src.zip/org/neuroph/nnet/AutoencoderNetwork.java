/*   */ package org.neuroph.nnet;
/*   */ 
/*   */ 
/*   */ public class AutoencoderNetwork
/*   */   extends MultiLayerPerceptron
/*   */ {
/*   */   public AutoencoderNetwork(int inputsCount, int hiddenCount)
/*   */   {
/* 9 */     super(new int[] { inputsCount, hiddenCount, inputsCount });
/*   */   }
/*   */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\nnet\AutoencoderNetwork.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */