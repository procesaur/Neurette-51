/*    */ package org.neuroph.nnet;
/*    */ 
/*    */ import org.neuroph.core.Layer;
/*    */ import org.neuroph.core.NeuralNetwork;
/*    */ import org.neuroph.nnet.learning.InstarLearning;
/*    */ import org.neuroph.util.ConnectionFactory;
/*    */ import org.neuroph.util.LayerFactory;
/*    */ import org.neuroph.util.NeuralNetworkFactory;
/*    */ import org.neuroph.util.NeuralNetworkType;
/*    */ import org.neuroph.util.NeuronProperties;
/*    */ import org.neuroph.util.TransferFunctionType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Instar
/*    */   extends NeuralNetwork
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public Instar(int inputNeuronsCount)
/*    */   {
/* 48 */     createNetwork(inputNeuronsCount);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private void createNetwork(int inputNeuronsCount)
/*    */   {
/* 60 */     setNetworkType(NeuralNetworkType.INSTAR);
/*    */     
/*    */ 
/* 63 */     NeuronProperties neuronProperties = new NeuronProperties();
/* 64 */     neuronProperties.setProperty("transferFunction", TransferFunctionType.STEP);
/*    */     
/*    */ 
/* 67 */     Layer inputLayer = LayerFactory.createLayer(inputNeuronsCount, neuronProperties);
/* 68 */     addLayer(inputLayer);
/*    */     
/*    */ 
/* 71 */     neuronProperties.setProperty("transferFunction", TransferFunctionType.STEP);
/* 72 */     Layer outputLayer = LayerFactory.createLayer(1, neuronProperties);
/* 73 */     addLayer(outputLayer);
/*    */     
/*    */ 
/* 76 */     ConnectionFactory.fullConnect(inputLayer, outputLayer);
/*    */     
/*    */ 
/* 79 */     NeuralNetworkFactory.setDefaultIO(this);
/*    */     
/*    */ 
/* 82 */     setLearningRule(new InstarLearning());
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\nnet\Instar.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */