/*    */ package org.neuroph.nnet;
/*    */ 
/*    */ import org.neuroph.core.Layer;
/*    */ import org.neuroph.core.NeuralNetwork;
/*    */ import org.neuroph.nnet.learning.OutstarLearning;
/*    */ import org.neuroph.util.ConnectionFactory;
/*    */ import org.neuroph.util.LayerFactory;
/*    */ import org.neuroph.util.NeuralNetworkFactory;
/*    */ import org.neuroph.util.NeuralNetworkType;
/*    */ import org.neuroph.util.NeuronProperties;
/*    */ import org.neuroph.util.TransferFunctionType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Outstar
/*    */   extends NeuralNetwork
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public Outstar(int outputNeuronsCount)
/*    */   {
/* 49 */     createNetwork(outputNeuronsCount);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private void createNetwork(int outputNeuronsCount)
/*    */   {
/* 62 */     setNetworkType(NeuralNetworkType.OUTSTAR);
/*    */     
/*    */ 
/* 65 */     NeuronProperties neuronProperties = new NeuronProperties();
/* 66 */     neuronProperties.setProperty("transferFunction", TransferFunctionType.STEP);
/*    */     
/*    */ 
/* 69 */     Layer inputLayer = LayerFactory.createLayer(1, neuronProperties);
/* 70 */     addLayer(inputLayer);
/*    */     
/*    */ 
/* 73 */     neuronProperties.setProperty("transferFunction", TransferFunctionType.RAMP);
/* 74 */     Layer outputLayer = LayerFactory.createLayer(outputNeuronsCount, neuronProperties);
/* 75 */     addLayer(outputLayer);
/*    */     
/*    */ 
/* 78 */     ConnectionFactory.fullConnect(inputLayer, outputLayer);
/*    */     
/*    */ 
/* 81 */     NeuralNetworkFactory.setDefaultIO(this);
/*    */     
/*    */ 
/* 84 */     setLearningRule(new OutstarLearning());
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\nnet\Outstar.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */