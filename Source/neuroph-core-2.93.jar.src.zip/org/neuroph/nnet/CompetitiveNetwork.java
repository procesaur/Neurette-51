/*    */ package org.neuroph.nnet;
/*    */ 
/*    */ import org.neuroph.core.Layer;
/*    */ import org.neuroph.core.NeuralNetwork;
/*    */ import org.neuroph.core.input.WeightedSum;
/*    */ import org.neuroph.nnet.comp.layer.CompetitiveLayer;
/*    */ import org.neuroph.nnet.comp.neuron.CompetitiveNeuron;
/*    */ import org.neuroph.nnet.learning.CompetitiveLearning;
/*    */ import org.neuroph.util.ConnectionFactory;
/*    */ import org.neuroph.util.LayerFactory;
/*    */ import org.neuroph.util.NeuralNetworkFactory;
/*    */ import org.neuroph.util.NeuralNetworkType;
/*    */ import org.neuroph.util.NeuronProperties;
/*    */ import org.neuroph.util.TransferFunctionType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CompetitiveNetwork
/*    */   extends NeuralNetwork
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public CompetitiveNetwork(int inputNeuronsCount, int outputNeuronsCount)
/*    */   {
/* 54 */     createNetwork(inputNeuronsCount, outputNeuronsCount);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private void createNetwork(int inputNeuronsCount, int outputNeuronsCount)
/*    */   {
/* 69 */     setNetworkType(NeuralNetworkType.COMPETITIVE);
/*    */     
/*    */ 
/* 72 */     Layer inputLayer = LayerFactory.createLayer(inputNeuronsCount, new NeuronProperties());
/* 73 */     addLayer(inputLayer);
/*    */     
/*    */ 
/* 76 */     NeuronProperties neuronProperties = new NeuronProperties();
/* 77 */     neuronProperties.setProperty("neuronType", CompetitiveNeuron.class);
/* 78 */     neuronProperties.setProperty("inputFunction", WeightedSum.class);
/* 79 */     neuronProperties.setProperty("transferFunction", TransferFunctionType.RAMP);
/*    */     
/*    */ 
/* 82 */     CompetitiveLayer competitiveLayer = new CompetitiveLayer(outputNeuronsCount, neuronProperties);
/*    */     
/*    */ 
/* 85 */     addLayer(competitiveLayer);
/*    */     
/* 87 */     double competitiveWeight = -(1.0D / outputNeuronsCount);
/*    */     
/* 89 */     ConnectionFactory.fullConnect(competitiveLayer, competitiveWeight, 1);
/*    */     
/*    */ 
/* 92 */     ConnectionFactory.fullConnect(inputLayer, competitiveLayer);
/*    */     
/*    */ 
/* 95 */     NeuralNetworkFactory.setDefaultIO(this);
/*    */     
/* 97 */     setLearningRule(new CompetitiveLearning());
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\nnet\CompetitiveNetwork.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */