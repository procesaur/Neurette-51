/*     */ package org.neuroph.nnet;
/*     */ 
/*     */ import org.neuroph.core.Layer;
/*     */ import org.neuroph.core.NeuralNetwork;
/*     */ import org.neuroph.nnet.learning.UnsupervisedHebbianLearning;
/*     */ import org.neuroph.util.ConnectionFactory;
/*     */ import org.neuroph.util.LayerFactory;
/*     */ import org.neuroph.util.NeuralNetworkFactory;
/*     */ import org.neuroph.util.NeuralNetworkType;
/*     */ import org.neuroph.util.NeuronProperties;
/*     */ import org.neuroph.util.TransferFunctionType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UnsupervisedHebbianNetwork
/*     */   extends NeuralNetwork
/*     */ {
/*     */   private static final long serialVersionUID = 2L;
/*     */   
/*     */   public UnsupervisedHebbianNetwork(int inputNeuronsNum, int outputNeuronsNum)
/*     */   {
/*  52 */     createNetwork(inputNeuronsNum, outputNeuronsNum, TransferFunctionType.LINEAR);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public UnsupervisedHebbianNetwork(int inputNeuronsNum, int outputNeuronsNum, TransferFunctionType transferFunctionType)
/*     */   {
/*  70 */     createNetwork(inputNeuronsNum, outputNeuronsNum, transferFunctionType);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void createNetwork(int inputNeuronsNum, int outputNeuronsNum, TransferFunctionType transferFunctionType)
/*     */   {
/*  89 */     NeuronProperties neuronProperties = new NeuronProperties();
/*     */     
/*     */ 
/*     */ 
/*  93 */     neuronProperties.setProperty("transferFunction", transferFunctionType);
/*  94 */     neuronProperties.setProperty("transferFunction.slope", new Double(1.0D));
/*     */     
/*     */ 
/*  97 */     setNetworkType(NeuralNetworkType.UNSUPERVISED_HEBBIAN_NET);
/*     */     
/*     */ 
/* 100 */     Layer inputLayer = LayerFactory.createLayer(inputNeuronsNum, neuronProperties);
/*     */     
/* 102 */     addLayer(inputLayer);
/*     */     
/*     */ 
/* 105 */     Layer outputLayer = LayerFactory.createLayer(outputNeuronsNum, neuronProperties);
/*     */     
/* 107 */     addLayer(outputLayer);
/*     */     
/*     */ 
/* 110 */     ConnectionFactory.fullConnect(inputLayer, outputLayer);
/*     */     
/*     */ 
/* 113 */     NeuralNetworkFactory.setDefaultIO(this);
/*     */     
/*     */ 
/* 116 */     setLearningRule(new UnsupervisedHebbianLearning());
/*     */   }
/*     */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\nnet\UnsupervisedHebbianNetwork.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */