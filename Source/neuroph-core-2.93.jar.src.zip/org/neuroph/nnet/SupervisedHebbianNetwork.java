/*     */ package org.neuroph.nnet;
/*     */ 
/*     */ import org.neuroph.core.Layer;
/*     */ import org.neuroph.core.NeuralNetwork;
/*     */ import org.neuroph.nnet.learning.SupervisedHebbianLearning;
/*     */ import org.neuroph.util.ConnectionFactory;
/*     */ import org.neuroph.util.LayerFactory;
/*     */ import org.neuroph.util.NeuralNetworkFactory;
/*     */ import org.neuroph.util.NeuralNetworkType;
/*     */ import org.neuroph.util.NeuronProperties;
/*     */ import org.neuroph.util.TransferFunctionType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SupervisedHebbianNetwork
/*     */   extends NeuralNetwork
/*     */ {
/*     */   private static final long serialVersionUID = 2L;
/*     */   
/*     */   public SupervisedHebbianNetwork(int inputNeuronsNum, int outputNeuronsNum)
/*     */   {
/*  53 */     createNetwork(inputNeuronsNum, outputNeuronsNum, TransferFunctionType.RAMP);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SupervisedHebbianNetwork(int inputNeuronsNum, int outputNeuronsNum, TransferFunctionType transferFunctionType)
/*     */   {
/*  70 */     createNetwork(inputNeuronsNum, outputNeuronsNum, transferFunctionType);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void createNetwork(int inputNeuronsNum, int outputNeuronsNum, TransferFunctionType transferFunctionType)
/*     */   {
/*  89 */     NeuronProperties neuronProperties = new NeuronProperties();
/*  90 */     neuronProperties.setProperty("transferFunction", transferFunctionType);
/*  91 */     neuronProperties.setProperty("transferFunction.slope", new Double(1.0D));
/*  92 */     neuronProperties.setProperty("transferFunction.yHigh", new Double(1.0D));
/*  93 */     neuronProperties.setProperty("transferFunction.xHigh", new Double(1.0D));
/*  94 */     neuronProperties.setProperty("transferFunction.yLow", new Double(-1.0D));
/*  95 */     neuronProperties.setProperty("transferFunction.xLow", new Double(-1.0D));
/*     */     
/*     */ 
/*  98 */     setNetworkType(NeuralNetworkType.SUPERVISED_HEBBIAN_NET);
/*     */     
/*     */ 
/* 101 */     Layer inputLayer = LayerFactory.createLayer(inputNeuronsNum, neuronProperties);
/*     */     
/* 103 */     addLayer(inputLayer);
/*     */     
/*     */ 
/* 106 */     Layer outputLayer = LayerFactory.createLayer(outputNeuronsNum, neuronProperties);
/*     */     
/* 108 */     addLayer(outputLayer);
/*     */     
/*     */ 
/* 111 */     ConnectionFactory.fullConnect(inputLayer, outputLayer);
/*     */     
/*     */ 
/* 114 */     NeuralNetworkFactory.setDefaultIO(this);
/*     */     
/*     */ 
/* 117 */     setLearningRule(new SupervisedHebbianLearning());
/*     */   }
/*     */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\nnet\SupervisedHebbianNetwork.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */