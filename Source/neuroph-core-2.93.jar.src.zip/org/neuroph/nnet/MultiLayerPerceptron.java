/*     */ package org.neuroph.nnet;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.neuroph.core.Layer;
/*     */ import org.neuroph.core.NeuralNetwork;
/*     */ import org.neuroph.core.input.WeightedSum;
/*     */ import org.neuroph.core.transfer.Linear;
/*     */ import org.neuroph.nnet.comp.neuron.BiasNeuron;
/*     */ import org.neuroph.nnet.comp.neuron.InputNeuron;
/*     */ import org.neuroph.nnet.learning.BackPropagation;
/*     */ import org.neuroph.nnet.learning.MomentumBackpropagation;
/*     */ import org.neuroph.util.ConnectionFactory;
/*     */ import org.neuroph.util.LayerFactory;
/*     */ import org.neuroph.util.NeuralNetworkFactory;
/*     */ import org.neuroph.util.NeuralNetworkType;
/*     */ import org.neuroph.util.NeuronProperties;
/*     */ import org.neuroph.util.TransferFunctionType;
/*     */ import org.neuroph.util.random.RangeRandomizer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MultiLayerPerceptron
/*     */   extends NeuralNetwork<BackPropagation>
/*     */ {
/*     */   private static final long serialVersionUID = 2L;
/*     */   
/*     */   public MultiLayerPerceptron(List<Integer> neuronsInLayers)
/*     */   {
/*  61 */     NeuronProperties neuronProperties = new NeuronProperties();
/*  62 */     neuronProperties.setProperty("useBias", Boolean.valueOf(true));
/*  63 */     neuronProperties.setProperty("transferFunction", TransferFunctionType.SIGMOID);
/*     */     
/*  65 */     createNetwork(neuronsInLayers, neuronProperties);
/*     */   }
/*     */   
/*     */   public MultiLayerPerceptron(int... neuronsInLayers)
/*     */   {
/*  70 */     NeuronProperties neuronProperties = new NeuronProperties();
/*  71 */     neuronProperties.setProperty("useBias", Boolean.valueOf(true));
/*  72 */     neuronProperties.setProperty("transferFunction", TransferFunctionType.SIGMOID);
/*  73 */     neuronProperties.setProperty("inputFunction", WeightedSum.class);
/*     */     
/*  75 */     List<Integer> neuronsInLayersVector = new ArrayList();
/*  76 */     for (int i = 0; i < neuronsInLayers.length; i++) {
/*  77 */       neuronsInLayersVector.add(Integer.valueOf(neuronsInLayers[i]));
/*     */     }
/*     */     
/*  80 */     createNetwork(neuronsInLayersVector, neuronProperties);
/*     */   }
/*     */   
/*     */   public MultiLayerPerceptron(TransferFunctionType transferFunctionType, int... neuronsInLayers)
/*     */   {
/*  85 */     NeuronProperties neuronProperties = new NeuronProperties();
/*  86 */     neuronProperties.setProperty("useBias", Boolean.valueOf(true));
/*  87 */     neuronProperties.setProperty("transferFunction", transferFunctionType);
/*  88 */     neuronProperties.setProperty("inputFunction", WeightedSum.class);
/*     */     
/*     */ 
/*  91 */     List<Integer> neuronsInLayersVector = new ArrayList();
/*  92 */     for (int i = 0; i < neuronsInLayers.length; i++) {
/*  93 */       neuronsInLayersVector.add(Integer.valueOf(neuronsInLayers[i]));
/*     */     }
/*     */     
/*  96 */     createNetwork(neuronsInLayersVector, neuronProperties);
/*     */   }
/*     */   
/*     */   public MultiLayerPerceptron(List<Integer> neuronsInLayers, TransferFunctionType transferFunctionType)
/*     */   {
/* 101 */     NeuronProperties neuronProperties = new NeuronProperties();
/* 102 */     neuronProperties.setProperty("useBias", Boolean.valueOf(true));
/* 103 */     neuronProperties.setProperty("transferFunction", transferFunctionType);
/*     */     
/* 105 */     createNetwork(neuronsInLayers, neuronProperties);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MultiLayerPerceptron(List<Integer> neuronsInLayers, NeuronProperties neuronProperties)
/*     */   {
/* 116 */     createNetwork(neuronsInLayers, neuronProperties);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void createNetwork(List<Integer> neuronsInLayers, NeuronProperties neuronProperties)
/*     */   {
/* 129 */     setNetworkType(NeuralNetworkType.MULTI_LAYER_PERCEPTRON);
/*     */     
/*     */ 
/* 132 */     NeuronProperties inputNeuronProperties = new NeuronProperties(InputNeuron.class, Linear.class);
/* 133 */     Layer layer = LayerFactory.createLayer(((Integer)neuronsInLayers.get(0)).intValue(), inputNeuronProperties);
/*     */     
/* 135 */     boolean useBias = true;
/* 136 */     if (neuronProperties.hasProperty("useBias")) {
/* 137 */       useBias = ((Boolean)neuronProperties.getProperty("useBias")).booleanValue();
/*     */     }
/*     */     
/* 140 */     if (useBias) {
/* 141 */       layer.addNeuron(new BiasNeuron());
/*     */     }
/*     */     
/* 144 */     addLayer(layer);
/*     */     
/*     */ 
/* 147 */     Layer prevLayer = layer;
/*     */     
/*     */ 
/* 150 */     for (int layerIdx = 1; layerIdx < neuronsInLayers.size(); layerIdx++) {
/* 151 */       Integer neuronsNum = (Integer)neuronsInLayers.get(layerIdx);
/*     */       
/* 153 */       layer = LayerFactory.createLayer(neuronsNum.intValue(), neuronProperties);
/*     */       
/* 155 */       if ((useBias) && (layerIdx < neuronsInLayers.size() - 1)) {
/* 156 */         layer.addNeuron(new BiasNeuron());
/*     */       }
/*     */       
/*     */ 
/* 160 */       addLayer(layer);
/*     */       
/* 162 */       if (prevLayer != null) {
/* 163 */         ConnectionFactory.fullConnect(prevLayer, layer);
/*     */       }
/*     */       
/* 166 */       prevLayer = layer;
/*     */     }
/*     */     
/*     */ 
/* 170 */     NeuralNetworkFactory.setDefaultIO(this);
/*     */     
/*     */ 
/*     */ 
/* 174 */     setLearningRule(new MomentumBackpropagation());
/*     */     
/*     */ 
/* 177 */     randomizeWeights(new RangeRandomizer(-0.7D, 0.7D));
/*     */   }
/*     */   
/*     */ 
/*     */   public void connectInputsToOutputs()
/*     */   {
/* 183 */     ConnectionFactory.fullConnect(getLayerAt(0), getLayerAt(getLayersCount() - 1), false);
/*     */   }
/*     */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\nnet\MultiLayerPerceptron.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */