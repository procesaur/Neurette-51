/*    */ package org.neuroph.nnet;
/*    */ 
/*    */ import org.neuroph.core.Layer;
/*    */ import org.neuroph.core.NeuralNetwork;
/*    */ import org.neuroph.core.Neuron;
/*    */ import org.neuroph.core.input.Difference;
/*    */ import org.neuroph.core.transfer.Linear;
/*    */ import org.neuroph.nnet.learning.KohonenLearning;
/*    */ import org.neuroph.util.ConnectionFactory;
/*    */ import org.neuroph.util.LayerFactory;
/*    */ import org.neuroph.util.NeuralNetworkFactory;
/*    */ import org.neuroph.util.NeuralNetworkType;
/*    */ import org.neuroph.util.NeuronProperties;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Kohonen
/*    */   extends NeuralNetwork
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public Kohonen(int inputNeuronsCount, int outputNeuronsCount)
/*    */   {
/* 50 */     createNetwork(inputNeuronsCount, outputNeuronsCount);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private void createNetwork(int inputNeuronsCount, int outputNeuronsCount)
/*    */   {
/* 66 */     NeuronProperties inputNeuronProperties = new NeuronProperties();
/*    */     
/*    */ 
/* 69 */     NeuronProperties outputNeuronProperties = new NeuronProperties(Neuron.class, Difference.class, Linear.class);
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 75 */     setNetworkType(NeuralNetworkType.KOHONEN);
/*    */     
/*    */ 
/* 78 */     Layer inLayer = LayerFactory.createLayer(inputNeuronsCount, inputNeuronProperties);
/*    */     
/* 80 */     addLayer(inLayer);
/*    */     
/*    */ 
/* 83 */     Layer mapLayer = LayerFactory.createLayer(outputNeuronsCount, outputNeuronProperties);
/*    */     
/* 85 */     addLayer(mapLayer);
/*    */     
/*    */ 
/* 88 */     ConnectionFactory.fullConnect(inLayer, mapLayer);
/*    */     
/*    */ 
/* 91 */     NeuralNetworkFactory.setDefaultIO(this);
/*    */     
/* 93 */     setLearningRule(new KohonenLearning());
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\nnet\Kohonen.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */