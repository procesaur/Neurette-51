/*    */ package org.neuroph.nnet.learning;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.neuroph.core.Connection;
/*    */ import org.neuroph.core.NeuralNetwork;
/*    */ import org.neuroph.core.Weight;
/*    */ import org.neuroph.core.data.DataSet;
/*    */ import org.neuroph.core.learning.UnsupervisedLearning;
/*    */ import org.neuroph.nnet.comp.layer.CompetitiveLayer;
/*    */ import org.neuroph.nnet.comp.neuron.CompetitiveNeuron;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CompetitiveLearning
/*    */   extends UnsupervisedLearning
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public void doLearningEpoch(DataSet trainingSet)
/*    */   {
/* 59 */     super.doLearningEpoch(trainingSet);
/* 60 */     stopLearning();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected void updateNetworkWeights()
/*    */   {
/* 70 */     CompetitiveNeuron winningNeuron = ((CompetitiveLayer)this.neuralNetwork.getLayerAt(1)).getWinner();
/*    */     
/*    */ 
/* 73 */     List<Connection> inputConnections = winningNeuron.getConnectionsFromOtherLayers();
/*    */     
/* 75 */     for (Connection connection : inputConnections) {
/* 76 */       double weight = connection.getWeight().getValue();
/* 77 */       double input = connection.getInput();
/* 78 */       double deltaWeight = this.learningRate * (input - weight);
/* 79 */       connection.getWeight().inc(deltaWeight);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\nnet\learning\CompetitiveLearning.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */