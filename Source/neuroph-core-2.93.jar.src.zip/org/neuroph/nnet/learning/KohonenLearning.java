/*     */ package org.neuroph.nnet.learning;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import org.neuroph.core.Connection;
/*     */ import org.neuroph.core.Layer;
/*     */ import org.neuroph.core.NeuralNetwork;
/*     */ import org.neuroph.core.Neuron;
/*     */ import org.neuroph.core.Weight;
/*     */ import org.neuroph.core.data.DataSet;
/*     */ import org.neuroph.core.data.DataSetRow;
/*     */ import org.neuroph.core.events.LearningEvent;
/*     */ import org.neuroph.core.events.LearningEvent.Type;
/*     */ import org.neuroph.core.learning.LearningRule;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class KohonenLearning
/*     */   extends LearningRule
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  43 */   double learningRate = 0.9D;
/*  44 */   int[] iterations = { 100, 0 };
/*  45 */   double[] decStep = new double[2];
/*  46 */   int mapSize = 0;
/*  47 */   int[] nR = { 1, 1 };
/*     */   
/*     */ 
/*     */ 
/*     */   int currentIteration;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void learn(DataSet trainingSet)
/*     */   {
/*  58 */     for (int phase = 0; phase < 2; phase++) {
/*  59 */       for (int k = 0; k < this.iterations[phase]; k++) {
/*  60 */         Iterator<DataSetRow> iterator = trainingSet.iterator();
/*  61 */         while ((iterator.hasNext()) && (!isStopped())) {
/*  62 */           DataSetRow trainingSetRow = (DataSetRow)iterator.next();
/*  63 */           learnPattern(trainingSetRow, this.nR[phase]);
/*     */         }
/*  65 */         this.currentIteration = k;
/*  66 */         fireLearningEvent(new LearningEvent(this, LearningEvent.Type.EPOCH_ENDED));
/*  67 */         if (isStopped()) return;
/*     */       }
/*  69 */       this.learningRate *= 0.5D;
/*     */     }
/*     */   }
/*     */   
/*     */   private void learnPattern(DataSetRow dataSetRow, int neighborhood) {
/*  74 */     this.neuralNetwork.setInput(dataSetRow.getInput());
/*  75 */     this.neuralNetwork.calculate();
/*  76 */     Neuron winner = getClosestNeuron();
/*  77 */     if (winner.getOutput() == 0.0D) {
/*  78 */       return;
/*     */     }
/*  80 */     Layer mapLayer = this.neuralNetwork.getLayerAt(1);
/*  81 */     int winnerIdx = mapLayer.indexOf(winner);
/*  82 */     adjustCellWeights(winner, 0);
/*     */     
/*  84 */     int cellNum = mapLayer.getNeuronsCount();
/*  85 */     for (int p = 0; p < cellNum; p++) {
/*  86 */       if (p != winnerIdx)
/*     */       {
/*  88 */         if (isNeighbor(winnerIdx, p, neighborhood)) {
/*  89 */           Neuron cell = mapLayer.getNeuronAt(p);
/*  90 */           adjustCellWeights(cell, 1);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private Neuron getClosestNeuron()
/*     */   {
/*  98 */     Neuron winner = new Neuron();
/*  99 */     double minOutput = 100.0D;
/* 100 */     for (Neuron n : this.neuralNetwork.getLayerAt(1).getNeurons()) {
/* 101 */       double out = n.getOutput();
/* 102 */       if (out < minOutput) {
/* 103 */         minOutput = out;
/* 104 */         winner = n;
/*     */       }
/*     */     }
/* 107 */     return winner;
/*     */   }
/*     */   
/*     */   private void adjustCellWeights(Neuron cell, int r) {
/* 111 */     for (Connection conn : cell.getInputConnections())
/*     */     {
/* 113 */       double dWeight = this.learningRate / (r + 1) * (conn.getInput() - conn.getWeight().getValue());
/* 114 */       conn.getWeight().inc(dWeight);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private boolean isNeighbor(int i, int j, int n)
/*     */   {
/* 122 */     n = 1;
/* 123 */     int d = this.mapSize;
/*     */     
/*     */ 
/*     */ 
/* 127 */     int rt = n;
/* 128 */     while (i - rt * d < 0) {
/* 129 */       rt--;
/*     */     }
/*     */     
/* 132 */     int rb = n;
/* 133 */     while (i + rb * d > d * d - 1) {
/* 134 */       rb--;
/*     */     }
/*     */     
/* 137 */     for (int g = -rt; g <= rb; g++) {
/* 138 */       int rl = n;
/* 139 */       int rlMod = (i - rl) % d;
/* 140 */       int i_mod = i % d;
/* 141 */       while (rlMod > i_mod) {
/* 142 */         rl--;
/* 143 */         rlMod = (i - rl) % d;
/*     */       }
/*     */       
/* 146 */       int rd = n;
/* 147 */       int rdMod = (i + rd) % d;
/* 148 */       while (rdMod < i_mod) {
/* 149 */         rd--;
/* 150 */         rdMod = (i + rd) % d;
/*     */       }
/*     */       
/* 153 */       if ((j >= i + g * d - rl) && (j <= i + g * d + rd)) {
/* 154 */         return true;
/*     */       }
/*     */     }
/* 157 */     return false;
/*     */   }
/*     */   
/*     */   public double getLearningRate() {
/* 161 */     return this.learningRate;
/*     */   }
/*     */   
/*     */   public void setLearningRate(double learningRate) {
/* 165 */     this.learningRate = learningRate;
/*     */   }
/*     */   
/*     */   public void setIterations(int Iphase, int IIphase) {
/* 169 */     this.iterations[0] = Iphase;
/* 170 */     this.iterations[1] = IIphase;
/*     */   }
/*     */   
/*     */   public int getIteration() {
/* 174 */     return this.currentIteration;
/*     */   }
/*     */   
/*     */   public int getMapSize() {
/* 178 */     return this.mapSize;
/*     */   }
/*     */   
/*     */   public void setNeuralNetwork(NeuralNetwork neuralNetwork)
/*     */   {
/* 183 */     super.setNeuralNetwork(neuralNetwork);
/* 184 */     int neuronsNum = neuralNetwork.getLayerAt(1).getNeuronsCount();
/* 185 */     this.mapSize = ((int)Math.sqrt(neuronsNum));
/*     */   }
/*     */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\nnet\learning\KohonenLearning.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */