/*    */ package org.neuroph.nnet.learning;
/*    */ 
/*    */ import org.neuroph.core.Connection;
/*    */ import org.neuroph.core.NeuralNetwork;
/*    */ import org.neuroph.core.Neuron;
/*    */ import org.neuroph.core.Weight;
/*    */ import org.neuroph.core.data.DataSet;
/*    */ import org.neuroph.core.learning.UnsupervisedLearning;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UnsupervisedHebbianLearning
/*    */   extends UnsupervisedLearning
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public UnsupervisedHebbianLearning()
/*    */   {
/* 41 */     setLearningRate(0.1D);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void doLearningEpoch(DataSet trainingSet)
/*    */   {
/* 55 */     super.doLearningEpoch(trainingSet);
/* 56 */     stopLearning();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   protected void updateNetworkWeights()
/*    */   {
/* 64 */     for (Neuron neuron : this.neuralNetwork.getOutputNeurons()) {
/* 65 */       updateNeuronWeights(neuron);
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected void updateNeuronWeights(Neuron neuron)
/*    */   {
/* 76 */     double output = neuron.getOutput();
/*    */     
/* 78 */     for (Connection connection : neuron.getInputConnections()) {
/* 79 */       double input = connection.getInput();
/* 80 */       double deltaWeight = input * output * this.learningRate;
/* 81 */       connection.getWeight().inc(deltaWeight);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\nnet\learning\UnsupervisedHebbianLearning.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */