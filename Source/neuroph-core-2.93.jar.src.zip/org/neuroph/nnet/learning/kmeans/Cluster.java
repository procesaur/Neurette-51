/*     */ package org.neuroph.nnet.learning.kmeans;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Cluster
/*     */ {
/*     */   KVector centroid;
/*     */   List<KVector> vectors;
/*     */   
/*     */   public Cluster()
/*     */   {
/*  25 */     this.vectors = new ArrayList();
/*     */   }
/*     */   
/*     */   public KVector getCentroid() {
/*  29 */     return this.centroid;
/*     */   }
/*     */   
/*     */   public void setCentroid(KVector centroid) {
/*  33 */     this.centroid = centroid;
/*     */   }
/*     */   
/*     */   public void removePoint(KVector point)
/*     */   {
/*  38 */     this.vectors.remove(point);
/*     */   }
/*     */   
/*     */   public List<KVector> getPoints() {
/*  42 */     return this.vectors;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public double[] getAvgSum()
/*     */   {
/*  50 */     double size = this.vectors.size();
/*  51 */     double[] avg = new double[((KVector)this.vectors.get(0)).size()];
/*     */     
/*  53 */     for (KVector item : this.vectors) {
/*  54 */       double[] values = item.getValues();
/*     */       
/*  56 */       for (int i = 0; i < values.length; i++) {
/*  57 */         avg[i] += values[i] / size;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*  62 */     return avg;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/*  73 */     if (obj == null) {
/*  74 */       return false;
/*     */     }
/*  76 */     if (getClass() != obj.getClass()) {
/*  77 */       return false;
/*     */     }
/*     */     
/*  80 */     Cluster other = (Cluster)obj;
/*  81 */     double[] otherValues = other.getCentroid().getValues();
/*  82 */     double[] values = other.getCentroid().getValues();
/*     */     
/*  84 */     for (int i = 0; i < this.centroid.size(); i++) {
/*  85 */       if (otherValues[i] != values[i]) {
/*  86 */         return false;
/*     */       }
/*     */     }
/*  89 */     return true;
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/*  94 */     int hash = 7;
/*  95 */     hash = 97 * hash + Objects.hashCode(this.centroid);
/*  96 */     hash = 97 * hash + Objects.hashCode(this.vectors);
/*  97 */     return hash;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void assignVector(KVector vector)
/*     */   {
/* 109 */     if (vector.getCluster() != this) {
/* 110 */       vector.setCluster(this);
/* 111 */       this.vectors.add(vector);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int size()
/*     */   {
/* 120 */     return this.vectors.size();
/*     */   }
/*     */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\nnet\learning\kmeans\Cluster.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */