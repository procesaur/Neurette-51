/*     */ package org.neuroph.nnet.learning.kmeans;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class KVector
/*     */ {
/*     */   private double[] values;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private Cluster cluster;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private double distance;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public KVector(int size)
/*     */   {
/*  28 */     this.values = new double[size];
/*     */   }
/*     */   
/*     */   public KVector(double[] values) {
/*  32 */     this.values = values;
/*     */   }
/*     */   
/*     */   public void setValueAt(int idx, double value)
/*     */   {
/*  37 */     this.values[idx] = value;
/*     */   }
/*     */   
/*     */   public double getValueAt(int idx) {
/*  41 */     return this.values[idx];
/*     */   }
/*     */   
/*     */   public double[] getValues() {
/*  45 */     return this.values;
/*     */   }
/*     */   
/*     */   public void setValues(double[] values) {
/*  49 */     this.values = values;
/*     */   }
/*     */   
/*     */   public Cluster getCluster()
/*     */   {
/*  54 */     return this.cluster;
/*     */   }
/*     */   
/*     */   public void setCluster(Cluster cluster)
/*     */   {
/*  59 */     if (this.cluster != null) {
/*  60 */       this.cluster.removePoint(this);
/*     */     }
/*  62 */     this.cluster = cluster;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public double getIntensity()
/*     */   {
/*  70 */     double intensity = 0.0D;
/*     */     
/*  72 */     for (double value : this.values) {
/*  73 */       intensity += value * value;
/*     */     }
/*     */     
/*  76 */     intensity = Math.sqrt(intensity);
/*     */     
/*  78 */     return intensity;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public double distanceFrom(KVector otherVector)
/*     */   {
/*  88 */     double[] otherValues = otherVector.getValues();
/*     */     
/*  90 */     double distance = 0.0D;
/*     */     
/*  92 */     for (int i = 0; i < this.values.length; i++) {
/*  93 */       distance += Math.pow(otherValues[i] - this.values[i], 2.0D);
/*     */     }
/*     */     
/*  96 */     distance = Math.sqrt(distance);
/*     */     
/*  98 */     return distance;
/*     */   }
/*     */   
/*     */   public int size() {
/* 102 */     return this.values.length;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 107 */     StringBuilder sb = new StringBuilder();
/* 108 */     sb.append("KMeansVector{");
/* 109 */     for (int i = 0; i < this.values.length; i++) {
/* 110 */       sb.append("[" + i + "]=" + this.values[i] + ",");
/*     */     }
/* 112 */     sb.append('}');
/*     */     
/* 114 */     return sb.toString();
/*     */   }
/*     */   
/*     */   public double getDistance() {
/* 118 */     return this.distance;
/*     */   }
/*     */   
/*     */   public void setDistance(double distance) {
/* 122 */     this.distance = distance;
/*     */   }
/*     */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\nnet\learning\kmeans\KVector.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */