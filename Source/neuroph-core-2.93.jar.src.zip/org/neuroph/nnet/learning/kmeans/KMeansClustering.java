/*     */ package org.neuroph.nnet.learning.kmeans;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import org.neuroph.core.data.DataSet;
/*     */ import org.neuroph.core.data.DataSetRow;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class KMeansClustering
/*     */ {
/*     */   private DataSet dataSet;
/*     */   private KVector[] dataVectors;
/*     */   private int numberOfClusters;
/*     */   private Cluster[] clusters;
/*  37 */   StringBuilder log = new StringBuilder();
/*     */   
/*     */   public KMeansClustering(DataSet dataSet) {
/*  40 */     this.dataSet = dataSet;
/*  41 */     this.dataVectors = new KVector[dataSet.size()];
/*     */     
/*  43 */     this.dataVectors = new KVector[dataSet.size()];
/*     */     
/*  45 */     int i = 0;
/*  46 */     for (DataSetRow row : dataSet.getRows()) {
/*  47 */       KVector vector = new KVector(row.getInput());
/*  48 */       this.dataVectors[i] = vector;
/*  49 */       i++;
/*     */     }
/*     */   }
/*     */   
/*     */   public KMeansClustering(DataSet dataSet, int numberOfClusters)
/*     */   {
/*  55 */     this.dataSet = dataSet;
/*  56 */     this.numberOfClusters = numberOfClusters;
/*  57 */     this.dataVectors = new KVector[dataSet.size()];
/*     */     
/*  59 */     int i = 0;
/*  60 */     for (DataSetRow row : dataSet.getRows()) {
/*  61 */       KVector vector = new KVector(row.getInput());
/*  62 */       this.dataVectors[i] = vector;
/*  63 */       i++;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void initClusters()
/*     */   {
/*  74 */     ArrayList<Integer> idxList = new ArrayList();
/*     */     
/*  76 */     for (int i = 0; i < this.dataSet.size(); i++) {
/*  77 */       idxList.add(Integer.valueOf(i));
/*     */     }
/*  79 */     Collections.shuffle(idxList);
/*     */     
/*     */ 
/*     */ 
/*  83 */     this.clusters = new Cluster[this.numberOfClusters];
/*  84 */     for (int i = 0; i < this.numberOfClusters; i++) {
/*  85 */       this.clusters[i] = new Cluster();
/*  86 */       int randomIdx = ((Integer)idxList.get(i)).intValue();
/*  87 */       KVector randomVector = this.dataVectors[randomIdx];
/*  88 */       this.clusters[i].setCentroid(randomVector);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Cluster getNearestCluster(KVector vector)
/*     */   {
/* 101 */     Cluster nearestCluster = null;
/* 102 */     double minimumDistanceFromCluster = Double.MAX_VALUE;
/* 103 */     double distanceFromCluster = 0.0D;
/*     */     
/* 105 */     for (Cluster cluster : this.clusters) {
/* 106 */       distanceFromCluster = vector.distanceFrom(cluster.getCentroid());
/* 107 */       if (distanceFromCluster < minimumDistanceFromCluster) {
/* 108 */         minimumDistanceFromCluster = distanceFromCluster;
/* 109 */         nearestCluster = cluster;
/*     */       }
/*     */     }
/*     */     
/* 113 */     return nearestCluster;
/*     */   }
/*     */   
/*     */ 
/*     */   public void doClustering()
/*     */   {
/* 119 */     if (this.numberOfClusters <= 0) {
/* 120 */       throw new RuntimeException("Error: Number of clusters must be greater then zero!");
/*     */     }
/*     */     
/*     */ 
/* 124 */     initClusters();
/*     */     
/*     */ 
/* 127 */     KVector[] arrayOfKVector1 = this.dataVectors;int i = arrayOfKVector1.length; KVector vector; for (KVector localKVector1 = 0; localKVector1 < i; localKVector1++) { vector = arrayOfKVector1[localKVector1];
/* 128 */       Cluster nearestCluster = getNearestCluster(vector);
/* 129 */       nearestCluster.assignVector(vector);
/*     */     }
/*     */     
/*     */     boolean clustersChanged;
/*     */     
/*     */     do
/*     */     {
/* 136 */       clustersChanged = false;
/* 137 */       recalculateCentroids();
/*     */       
/* 139 */       KVector[] arrayOfKVector2 = this.dataVectors;localKVector1 = arrayOfKVector2.length; for (vector = 0; vector < localKVector1; vector++) { KVector vector = arrayOfKVector2[vector];
/* 140 */         Cluster nearestCluster = getNearestCluster(vector);
/* 141 */         if (!vector.getCluster().equals(nearestCluster)) {
/* 142 */           nearestCluster.assignVector(vector);
/* 143 */           clustersChanged = true;
/*     */         }
/*     */       }
/* 146 */     } while (clustersChanged);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void recalculateCentroids()
/*     */   {
/* 154 */     for (Cluster cluster : this.clusters) {
/* 155 */       if (cluster.size() > 0) {
/* 156 */         double[] avgSum = cluster.getAvgSum();
/* 157 */         cluster.getCentroid().setValues(avgSum);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public DataSet getDataSet() {
/* 163 */     return this.dataSet;
/*     */   }
/*     */   
/*     */   public void setDataSet(DataSet vectors) {
/* 167 */     this.dataSet = vectors;
/*     */   }
/*     */   
/*     */   public void setNumberOfClusters(int numberOfClusters) {
/* 171 */     this.numberOfClusters = numberOfClusters;
/*     */   }
/*     */   
/*     */   public Cluster[] getClusters() {
/* 175 */     return this.clusters;
/*     */   }
/*     */   
/*     */   public String getLog() {
/* 179 */     return this.log.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\nnet\learning\kmeans\KMeansClustering.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */