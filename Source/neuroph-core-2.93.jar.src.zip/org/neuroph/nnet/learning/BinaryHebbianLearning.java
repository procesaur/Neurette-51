/*    */ package org.neuroph.nnet.learning;
/*    */ 
/*    */ import org.neuroph.core.Connection;
/*    */ import org.neuroph.core.Neuron;
/*    */ import org.neuroph.core.Weight;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BinaryHebbianLearning
/*    */   extends UnsupervisedHebbianLearning
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   protected void updateNeuronWeights(Neuron neuron)
/*    */   {
/* 49 */     double output = neuron.getOutput();
/* 50 */     for (Connection connection : neuron.getInputConnections()) {
/* 51 */       double input = connection.getInput();
/*    */       
/* 53 */       if (((input > 0.0D) && (output > 0.0D)) || ((input <= 0.0D) && (output <= 0.0D))) {
/* 54 */         connection.getWeight().inc(this.learningRate);
/*    */       } else {
/* 56 */         connection.getWeight().dec(this.learningRate);
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\nnet\learning\BinaryHebbianLearning.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */