/*    */ package org.neuroph.nnet.learning;
/*    */ 
/*    */ import org.neuroph.core.Connection;
/*    */ import org.neuroph.core.Neuron;
/*    */ import org.neuroph.core.Weight;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OjaLearning
/*    */   extends UnsupervisedHebbianLearning
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   protected void updateNeuronWeights(Neuron neuron)
/*    */   {
/* 51 */     double output = neuron.getOutput();
/* 52 */     for (Connection connection : neuron.getInputConnections()) {
/* 53 */       double input = connection.getInput();
/* 54 */       double weight = connection.getWeight().getValue();
/* 55 */       double deltaWeight = (input - output * weight) * output * this.learningRate;
/* 56 */       connection.getWeight().inc(deltaWeight);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\nnet\learning\OjaLearning.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */