/*    */ package org.neuroph.nnet.learning;
/*    */ 
/*    */ import org.neuroph.core.Neuron;
/*    */ import org.neuroph.nnet.comp.neuron.ThresholdNeuron;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PerceptronLearning
/*    */   extends LMS
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public void updateNeuronWeights(Neuron neuron)
/*    */   {
/* 54 */     super.updateNeuronWeights(neuron);
/*    */     
/*    */ 
/* 57 */     ThresholdNeuron thresholdNeuron = (ThresholdNeuron)neuron;
/*    */     
/* 59 */     double neuronError = thresholdNeuron.getError();
/*    */     
/* 61 */     double thresh = thresholdNeuron.getThresh();
/*    */     
/* 63 */     thresh -= this.learningRate * neuronError;
/*    */     
/* 65 */     thresholdNeuron.setThresh(thresh);
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\nnet\learning\PerceptronLearning.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */