/*    */ package org.neuroph.nnet.learning.knn;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.neuroph.nnet.learning.kmeans.KVector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class KNearestNeighbour
/*    */ {
/*    */   private List<KVector> dataSet;
/*    */   
/*    */   public KVector[] getKNearestNeighbours(KVector vector, int k)
/*    */   {
/* 25 */     KVector[] nearestNeighbours = new KVector[k];
/*    */     
/*    */ 
/* 28 */     for (KVector otherVector : this.dataSet) {
/* 29 */       double distance = vector.distanceFrom(otherVector);
/* 30 */       otherVector.setDistance(distance);
/*    */     }
/*    */     
/* 33 */     for (int i = 0; i < k; i++) {
/* 34 */       int minIndex = i;
/* 35 */       KVector minVector = (KVector)this.dataSet.get(i);
/* 36 */       double minDistance = minVector.getDistance();
/*    */       
/* 38 */       for (int j = i + 1; j < this.dataSet.size(); j++) {
/* 39 */         if (((KVector)this.dataSet.get(j)).getDistance() <= minDistance) {
/* 40 */           minVector = (KVector)this.dataSet.get(j);
/* 41 */           minDistance = minVector.getDistance();
/* 42 */           minIndex = j;
/*    */         }
/*    */       }
/*    */       
/*    */ 
/* 47 */       KVector temp = (KVector)this.dataSet.get(i);
/* 48 */       this.dataSet.set(i, this.dataSet.get(minIndex));
/* 49 */       this.dataSet.set(minIndex, temp);
/*    */       
/* 51 */       nearestNeighbours[i] = ((KVector)this.dataSet.get(i));
/*    */     }
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 66 */     return nearestNeighbours;
/*    */   }
/*    */   
/*    */   public List<KVector> getDataSet() {
/* 70 */     return this.dataSet;
/*    */   }
/*    */   
/*    */   public void setDataSet(List<KVector> dataSet) {
/* 74 */     this.dataSet = dataSet;
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\nnet\learning\knn\KNearestNeighbour.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */