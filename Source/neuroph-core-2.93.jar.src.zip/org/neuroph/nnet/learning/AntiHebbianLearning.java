/*    */ package org.neuroph.nnet.learning;
/*    */ 
/*    */ import org.neuroph.core.Connection;
/*    */ import org.neuroph.core.Neuron;
/*    */ import org.neuroph.core.Weight;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AntiHebbianLearning
/*    */   extends UnsupervisedHebbianLearning
/*    */ {
/*    */   protected void updateNeuronWeights(Neuron neuron)
/*    */   {
/* 37 */     double output = neuron.getOutput();
/*    */     
/* 39 */     for (Connection connection : neuron.getInputConnections()) {
/* 40 */       double input = connection.getInput();
/* 41 */       double deltaWeight = input * output * this.learningRate;
/* 42 */       connection.getWeight().dec(deltaWeight);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\nnet\learning\AntiHebbianLearning.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */