/*     */ package org.neuroph.nnet.learning;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.neuroph.core.Connection;
/*     */ import org.neuroph.core.Layer;
/*     */ import org.neuroph.core.NeuralNetwork;
/*     */ import org.neuroph.core.Neuron;
/*     */ import org.neuroph.core.Weight;
/*     */ import org.neuroph.core.transfer.TransferFunction;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BackPropagation
/*     */   extends LMS
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   
/*     */   protected void calculateWeightChanges(double[] outputError)
/*     */   {
/*  54 */     calculateErrorAndUpdateOutputNeurons(outputError);
/*  55 */     calculateErrorAndUpdateHiddenNeurons();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void calculateErrorAndUpdateOutputNeurons(double[] outputError)
/*     */   {
/*  67 */     int i = 0;
/*     */     
/*     */ 
/*  70 */     List<Neuron> outputNeurons = this.neuralNetwork.getOutputNeurons();
/*  71 */     for (Neuron neuron : outputNeurons)
/*     */     {
/*  73 */       if (outputError[i] == 0.0D) {
/*  74 */         neuron.setError(0.0D);
/*  75 */         i++;
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/*  80 */         TransferFunction transferFunction = neuron.getTransferFunction();
/*  81 */         double neuronInput = neuron.getNetInput();
/*  82 */         double delta = outputError[i] * transferFunction.getDerivative(neuronInput);
/*  83 */         neuron.setError(delta);
/*     */         
/*     */ 
/*  86 */         updateNeuronWeights(neuron);
/*  87 */         i++;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected void calculateErrorAndUpdateHiddenNeurons()
/*     */   {
/*  95 */     List<Layer> layers = this.neuralNetwork.getLayers();
/*  96 */     for (int layerIdx = layers.size() - 2; layerIdx > 0; layerIdx--) {
/*  97 */       for (Neuron neuron : ((Layer)layers.get(layerIdx)).getNeurons())
/*     */       {
/*  99 */         double neuronError = calculateHiddenNeuronError(neuron);
/* 100 */         neuron.setError(neuronError);
/* 101 */         updateNeuronWeights(neuron);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected double calculateHiddenNeuronError(Neuron neuron)
/*     */   {
/* 113 */     double deltaSum = 0.0D;
/* 114 */     for (Connection connection : neuron.getOutConnections())
/*     */     {
/* 116 */       double delta = connection.getToNeuron().getError() * connection.getWeight().value;
/* 117 */       deltaSum += delta;
/*     */     }
/*     */     
/* 120 */     TransferFunction transferFunction = neuron.getTransferFunction();
/* 121 */     double netInput = neuron.getNetInput();
/* 122 */     double f1 = transferFunction.getDerivative(netInput);
/* 123 */     double neuronError = f1 * deltaSum;
/* 124 */     return neuronError;
/*     */   }
/*     */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\nnet\learning\BackPropagation.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */