/*    */ package org.neuroph.nnet.learning;
/*    */ 
/*    */ import org.neuroph.core.NeuralNetwork;
/*    */ import org.neuroph.core.Neuron;
/*    */ import org.neuroph.core.transfer.TransferFunction;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SigmoidDeltaRule
/*    */   extends LMS
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   protected void calculateWeightChanges(double[] outputError)
/*    */   {
/* 55 */     int i = 0;
/*    */     
/* 57 */     for (Neuron neuron : this.neuralNetwork.getOutputNeurons())
/*    */     {
/* 59 */       if (outputError[i] == 0.0D) {
/* 60 */         neuron.setError(0.0D);
/* 61 */         i++;
/*    */ 
/*    */       }
/*    */       else
/*    */       {
/* 66 */         TransferFunction transferFunction = neuron.getTransferFunction();
/* 67 */         double neuronInput = neuron.getNetInput();
/* 68 */         double delta = outputError[i] * transferFunction.getDerivative(neuronInput);
/* 69 */         neuron.setError(delta);
/*    */         
/*    */ 
/* 72 */         updateNeuronWeights(neuron);
/* 73 */         i++;
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\nnet\learning\SigmoidDeltaRule.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */