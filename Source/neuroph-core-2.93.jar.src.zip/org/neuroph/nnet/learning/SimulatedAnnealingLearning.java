/*     */ package org.neuroph.nnet.learning;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import org.neuroph.core.NeuralNetwork;
/*     */ import org.neuroph.core.data.DataSet;
/*     */ import org.neuroph.core.data.DataSetRow;
/*     */ import org.neuroph.core.learning.SupervisedLearning;
/*     */ import org.neuroph.core.learning.error.ErrorFunction;
/*     */ import org.neuroph.util.NeuralNetworkCODEC;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SimulatedAnnealingLearning
/*     */   extends SupervisedLearning
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private double startTemperature;
/*     */   private double stopTemperature;
/*     */   private int cycles;
/*     */   protected double temperature;
/*     */   private double[] weights;
/*     */   private double[] bestWeights;
/*     */   
/*     */   public SimulatedAnnealingLearning(NeuralNetwork network, double startTemp, double stopTemp, int cycles)
/*     */   {
/*  78 */     setNeuralNetwork(network);
/*  79 */     this.temperature = startTemp;
/*  80 */     this.startTemperature = startTemp;
/*  81 */     this.stopTemperature = stopTemp;
/*  82 */     this.cycles = cycles;
/*     */     
/*     */ 
/*  85 */     this.weights = new double[NeuralNetworkCODEC.determineArraySize(network)];
/*     */     
/*  87 */     this.bestWeights = new double[NeuralNetworkCODEC.determineArraySize(network)];
/*     */     
/*  89 */     NeuralNetworkCODEC.network2array(network, this.weights);
/*  90 */     NeuralNetworkCODEC.network2array(network, this.bestWeights);
/*     */   }
/*     */   
/*     */   public SimulatedAnnealingLearning(NeuralNetwork network) {
/*  94 */     this(network, 10.0D, 2.0D, 1000);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NeuralNetwork getNetwork()
/*     */   {
/* 103 */     return getNeuralNetwork();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void randomize(double randomChance)
/*     */   {
/* 115 */     for (int i = 0; i < this.weights.length; i++) {
/* 116 */       if (Math.random() < randomChance)
/*     */       {
/* 118 */         double add = 0.5D - Math.random();
/* 119 */         add /= this.startTemperature;
/* 120 */         add *= this.temperature;
/* 121 */         this.weights[i] += add;
/*     */       }
/*     */     }
/* 124 */     NeuralNetworkCODEC.array2network(this.weights, getNetwork());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private double determineError(DataSet trainingSet)
/*     */   {
/* 134 */     double result = 0.0D;
/*     */     
/* 136 */     Iterator<DataSetRow> iterator = trainingSet.iterator();
/* 137 */     while ((iterator.hasNext()) && (!isStopped())) {
/* 138 */       DataSetRow trainingSetRow = (DataSetRow)iterator.next();
/* 139 */       double[] input = trainingSetRow.getInput();
/* 140 */       getNetwork().setInput(input);
/* 141 */       getNetwork().calculate();
/* 142 */       double[] output = getNetwork().getOutput();
/*     */       
/* 144 */       double[] desiredOutput = trainingSetRow.getDesiredOutput();
/*     */       
/* 146 */       double[] patternError = getErrorFunction().calculatePatternError(desiredOutput, output);
/* 147 */       double sqrErrorSum = 0.0D;
/* 148 */       for (double error : patternError) {
/* 149 */         sqrErrorSum += error * error;
/*     */       }
/* 151 */       result += sqrErrorSum / (2 * patternError.length);
/*     */     }
/*     */     
/*     */ 
/* 155 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void doLearningEpoch(DataSet trainingSet)
/*     */   {
/* 164 */     doLearningEpoch(trainingSet, 0.5D);
/*     */   }
/*     */   
/*     */   public void doLearningEpoch(DataSet trainingSet, double randomChance)
/*     */   {
/* 169 */     System.arraycopy(this.weights, 0, this.bestWeights, 0, this.weights.length);
/*     */     
/*     */ 
/* 172 */     double bestError = determineError(trainingSet);
/*     */     
/* 174 */     this.temperature = this.startTemperature;
/*     */     
/* 176 */     for (int i = 0; i < this.cycles; i++)
/*     */     {
/* 178 */       randomize(randomChance);
/* 179 */       double currentError = determineError(trainingSet);
/*     */       
/* 181 */       if (currentError < bestError) {
/* 182 */         System.arraycopy(this.weights, 0, this.bestWeights, 0, this.weights.length);
/*     */         
/* 184 */         bestError = currentError;
/*     */       } else {
/* 186 */         System.arraycopy(this.bestWeights, 0, this.weights, 0, this.weights.length);
/*     */       }
/*     */       
/* 189 */       NeuralNetworkCODEC.array2network(this.bestWeights, getNetwork());
/*     */       
/* 191 */       double ratio = Math.exp(Math.log(this.stopTemperature / this.startTemperature) / (this.cycles - 1));
/*     */       
/*     */ 
/* 194 */       this.temperature *= ratio;
/*     */     }
/*     */     
/*     */ 
/* 198 */     this.previousEpochError = getErrorFunction().getTotalError();
/*     */     
/*     */ 
/*     */ 
/* 202 */     if (hasReachedStopCondition()) {
/* 203 */       stopLearning();
/*     */     }
/*     */   }
/*     */   
/*     */   protected void calculateWeightChanges(double[] patternError) {}
/*     */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\nnet\learning\SimulatedAnnealingLearning.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */