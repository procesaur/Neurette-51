/*     */ package org.neuroph.nnet.learning;
/*     */ 
/*     */ import org.neuroph.core.data.DataSet;
/*     */ import org.neuroph.core.learning.error.ErrorFunction;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DynamicBackPropagation
/*     */   extends MomentumBackpropagation
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  30 */   private double maxLearningRate = 0.9D;
/*  31 */   private double minLearningRate = 0.1D;
/*  32 */   private double learningRateChange = 0.99926D;
/*  33 */   private boolean useDynamicLearningRate = true;
/*     */   
/*  35 */   private double maxMomentum = 0.9D;
/*  36 */   private double minMomentum = 0.1D;
/*  37 */   private double momentumChange = 0.99926D;
/*  38 */   private boolean useDynamicMomentum = true;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void adjustLearningRate()
/*     */   {
/*  63 */     double errorChange = this.previousEpochError - getErrorFunction().getTotalError();
/*  64 */     this.learningRate += errorChange * this.learningRateChange;
/*     */     
/*  66 */     if (this.learningRate > this.maxLearningRate) {
/*  67 */       this.learningRate = this.maxLearningRate;
/*     */     }
/*  69 */     if (this.learningRate < this.minLearningRate) {
/*  70 */       this.learningRate = this.minLearningRate;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void adjustMomentum()
/*     */   {
/* 123 */     double errorChange = this.previousEpochError - getErrorFunction().getTotalError();
/* 124 */     this.momentum += errorChange * this.momentumChange;
/*     */     
/* 126 */     if (this.momentum > this.maxMomentum) {
/* 127 */       this.momentum = this.maxMomentum;
/*     */     }
/* 129 */     if (this.momentum < this.minMomentum) {
/* 130 */       this.momentum = this.minMomentum;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void doLearningEpoch(DataSet trainingSet)
/*     */   {
/* 146 */     super.doLearningEpoch(trainingSet);
/*     */     
/* 148 */     if (this.currentIteration > 0) {
/* 149 */       if (this.useDynamicLearningRate) adjustLearningRate();
/* 150 */       if (this.useDynamicMomentum) { adjustMomentum();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public double getLearningRateChange()
/*     */   {
/* 157 */     return this.learningRateChange;
/*     */   }
/*     */   
/*     */   public void setLearningRateChange(double learningRateChange) {
/* 161 */     this.learningRateChange = learningRateChange;
/*     */   }
/*     */   
/*     */   public double getMaxLearningRate() {
/* 165 */     return this.maxLearningRate;
/*     */   }
/*     */   
/*     */   public void setMaxLearningRate(double maxLearningRate) {
/* 169 */     this.maxLearningRate = maxLearningRate;
/*     */   }
/*     */   
/*     */   public double getMaxMomentum() {
/* 173 */     return this.maxMomentum;
/*     */   }
/*     */   
/*     */   public void setMaxMomentum(double maxMomentum) {
/* 177 */     this.maxMomentum = maxMomentum;
/*     */   }
/*     */   
/*     */   public double getMinLearningRate() {
/* 181 */     return this.minLearningRate;
/*     */   }
/*     */   
/*     */   public void setMinLearningRate(double minLearningRate) {
/* 185 */     this.minLearningRate = minLearningRate;
/*     */   }
/*     */   
/*     */   public double getMinMomentum() {
/* 189 */     return this.minMomentum;
/*     */   }
/*     */   
/*     */   public void setMinMomentum(double minMomentum) {
/* 193 */     this.minMomentum = minMomentum;
/*     */   }
/*     */   
/*     */   public double getMomentumChange() {
/* 197 */     return this.momentumChange;
/*     */   }
/*     */   
/*     */   public void setMomentumChange(double momentumChange) {
/* 201 */     this.momentumChange = momentumChange;
/*     */   }
/*     */   
/*     */   public boolean getUseDynamicLearningRate() {
/* 205 */     return this.useDynamicLearningRate;
/*     */   }
/*     */   
/*     */   public void setUseDynamicLearningRate(boolean useDynamicLearningRate) {
/* 209 */     this.useDynamicLearningRate = useDynamicLearningRate;
/*     */   }
/*     */   
/*     */   public boolean getUseDynamicMomentum() {
/* 213 */     return this.useDynamicMomentum;
/*     */   }
/*     */   
/*     */   public void setUseDynamicMomentum(boolean useDynamicMomentum) {
/* 217 */     this.useDynamicMomentum = useDynamicMomentum;
/*     */   }
/*     */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\nnet\learning\DynamicBackPropagation.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */