/*    */ package org.neuroph.nnet.learning;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import org.neuroph.core.Connection;
/*    */ import org.neuroph.core.Layer;
/*    */ import org.neuroph.core.NeuralNetwork;
/*    */ import org.neuroph.core.Neuron;
/*    */ import org.neuroph.core.Weight;
/*    */ import org.neuroph.core.transfer.Gaussian;
/*    */ import org.neuroph.nnet.learning.kmeans.Cluster;
/*    */ import org.neuroph.nnet.learning.kmeans.KMeansClustering;
/*    */ import org.neuroph.nnet.learning.kmeans.KVector;
/*    */ import org.neuroph.nnet.learning.knn.KNearestNeighbour;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RBFLearning
/*    */   extends LMS
/*    */ {
/* 27 */   int k = 2;
/*    */   
/*    */   protected void onStart()
/*    */   {
/* 31 */     super.onStart();
/*    */     
/*    */ 
/* 34 */     KMeansClustering kmeans = new KMeansClustering(getTrainingSet());
/* 35 */     kmeans.setNumberOfClusters(this.neuralNetwork.getLayerAt(1).getNeuronsCount());
/* 36 */     kmeans.doClustering();
/*    */     
/*    */ 
/* 39 */     Cluster[] clusters = kmeans.getClusters();
/*    */     
/*    */ 
/*    */ 
/* 43 */     Layer rbfLayer = this.neuralNetwork.getLayerAt(1);
/* 44 */     int i = 0;
/* 45 */     for (Iterator localIterator1 = rbfLayer.getNeurons().iterator(); localIterator1.hasNext();) { neuron = (Neuron)localIterator1.next();
/* 46 */       centroid = clusters[i].getCentroid();
/* 47 */       weightValues = centroid.getValues();
/* 48 */       int c = 0;
/* 49 */       for (Connection conn : neuron.getInputConnections()) {
/* 50 */         conn.getWeight().setValue(weightValues[c]);
/* 51 */         c++;
/*    */       }
/* 53 */       i++;
/*    */     }
/*    */     
/*    */ 
/* 57 */     Object centroids = new ArrayList();
/* 58 */     Neuron neuron = clusters;KVector centroid = neuron.length; for (double[] weightValues = 0; weightValues < centroid; weightValues++) { Cluster cluster = neuron[weightValues];
/* 59 */       ((List)centroids).add(cluster.getCentroid());
/*    */     }
/*    */     
/*    */ 
/* 63 */     KNearestNeighbour knn = new KNearestNeighbour();
/* 64 */     knn.setDataSet((List)centroids);
/*    */     
/* 66 */     int n = 0;
/* 67 */     for (KVector centroid : (List)centroids)
/*    */     {
/* 69 */       KVector[] nearestNeighbours = knn.getKNearestNeighbours(centroid, this.k);
/* 70 */       double sigma = calculateSigma(centroid, nearestNeighbours);
/* 71 */       Neuron neuron = rbfLayer.getNeuronAt(n);
/* 72 */       ((Gaussian)neuron.getTransferFunction()).setSigma(sigma);
/* 73 */       i++;
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private double calculateSigma(KVector centroid, KVector[] nearestNeighbours)
/*    */   {
/* 87 */     double sigma = 0.0D;
/*    */     
/* 89 */     for (KVector nn : nearestNeighbours) {
/* 90 */       sigma += Math.pow(centroid.distanceFrom(nn), 2.0D);
/*    */     }
/*    */     
/* 93 */     sigma = Math.sqrt(1.0D / nearestNeighbours.length * sigma);
/*    */     
/* 95 */     return sigma;
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\nnet\learning\RBFLearning.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */