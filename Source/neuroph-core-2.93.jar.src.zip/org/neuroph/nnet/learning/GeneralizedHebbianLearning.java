/*    */ package org.neuroph.nnet.learning;
/*    */ 
/*    */ import org.neuroph.core.Connection;
/*    */ import org.neuroph.core.Neuron;
/*    */ import org.neuroph.core.Weight;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GeneralizedHebbianLearning
/*    */   extends UnsupervisedHebbianLearning
/*    */ {
/*    */   protected void updateNeuronWeights(Neuron neuron)
/*    */   {
/* 38 */     double output = neuron.getOutput();
/* 39 */     for (Connection connection : neuron.getInputConnections()) {
/* 40 */       double input = connection.getInput();
/* 41 */       double netInput = neuron.getNetInput();
/* 42 */       double deltaWeight = (input - netInput) * output * this.learningRate;
/* 43 */       connection.getWeight().inc(deltaWeight);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\nnet\learning\GeneralizedHebbianLearning.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */