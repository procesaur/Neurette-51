/*    */ package org.neuroph.nnet.learning;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.neuroph.core.Connection;
/*    */ import org.neuroph.core.Layer;
/*    */ import org.neuroph.core.NeuralNetwork;
/*    */ import org.neuroph.core.Neuron;
/*    */ import org.neuroph.core.Weight;
/*    */ import org.neuroph.nnet.comp.layer.ConvolutionalLayer;
/*    */ 
/*    */ public class ConvolutionalBackpropagation extends MomentumBackpropagation
/*    */ {
/*    */   private static final long serialVersionUID = -7134947805154423695L;
/*    */   
/*    */   protected void calculateErrorAndUpdateHiddenNeurons()
/*    */   {
/* 17 */     List<Layer> layers = this.neuralNetwork.getLayers();
/* 18 */     for (int layerIdx = layers.size() - 2; layerIdx > 0; layerIdx--) {
/* 19 */       for (Neuron neuron : ((Layer)layers.get(layerIdx)).getNeurons()) {
/* 20 */         double neuronError = calculateHiddenNeuronError(neuron);
/* 21 */         neuron.setError(neuronError);
/* 22 */         if ((layers.get(layerIdx) instanceof ConvolutionalLayer)) {
/* 23 */           updateNeuronWeights(neuron);
/*    */         }
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected double calculateHiddenNeuronError(Neuron neuron)
/*    */   {
/* 35 */     if ((neuron.getParentLayer() instanceof ConvolutionalLayer)) {
/* 36 */       return super.calculateHiddenNeuronError(neuron);
/*    */     }
/*    */     
/*    */ 
/* 40 */     double deltaSum = 0.0D;
/* 41 */     for (Connection connection : neuron.getOutConnections())
/*    */     {
/* 43 */       double delta = connection.getToNeuron().getError() * connection.getWeight().value;
/* 44 */       deltaSum += delta;
/*    */     }
/*    */     
/* 47 */     return deltaSum;
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\nnet\learning\ConvolutionalBackpropagation.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */