/*     */ package org.neuroph.nnet.learning;
/*     */ 
/*     */ import org.neuroph.core.Connection;
/*     */ import org.neuroph.core.NeuralNetwork;
/*     */ import org.neuroph.core.Neuron;
/*     */ import org.neuroph.core.Weight;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SupervisedHebbianLearning
/*     */   extends LMS
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   
/*     */   protected void calculateWeightChanges(double[] desiredOutput)
/*     */   {
/*  86 */     int i = 0;
/*  87 */     for (Neuron neuron : this.neuralNetwork.getOutputNeurons()) {
/*  88 */       updateNeuronWeights(neuron, desiredOutput[i]);
/*  89 */       i++;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void updateNeuronWeights(Neuron neuron, double desiredOutput)
/*     */   {
/* 103 */     for (Connection connection : neuron.getInputConnections()) {
/* 104 */       double input = connection.getInput();
/* 105 */       double deltaWeight = input * desiredOutput * this.learningRate;
/* 106 */       connection.getWeight().inc(deltaWeight);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\nnet\learning\SupervisedHebbianLearning.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */