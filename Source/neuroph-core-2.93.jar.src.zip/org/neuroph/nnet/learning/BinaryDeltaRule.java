/*     */ package org.neuroph.nnet.learning;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.neuroph.core.NeuralNetwork;
/*     */ import org.neuroph.core.Neuron;
/*     */ import org.neuroph.nnet.comp.neuron.ThresholdNeuron;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BinaryDeltaRule
/*     */   extends PerceptronLearning
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  43 */   private double errorCorrection = 0.1D;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void calculateWeightChanges(double[] patternError)
/*     */   {
/*  67 */     int i = 0;
/*  68 */     List<Neuron> outputNeurons = this.neuralNetwork.getOutputNeurons();
/*  69 */     for (Neuron outputNeuron : outputNeurons) {
/*  70 */       ThresholdNeuron neuron = (ThresholdNeuron)outputNeuron;
/*  71 */       double outErr = patternError[i];
/*  72 */       double thresh = neuron.getThresh();
/*  73 */       double netInput = neuron.getNetInput();
/*  74 */       double threshError = thresh - netInput;
/*     */       
/*     */ 
/*  77 */       double neuronError = outErr * (Math.abs(threshError) + this.errorCorrection);
/*     */       
/*     */ 
/*     */ 
/*  81 */       neuron.setError(neuronError);
/*  82 */       updateNeuronWeights(neuron);
/*     */       
/*  84 */       i++;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public double getErrorCorrection()
/*     */   {
/*  94 */     return this.errorCorrection;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setErrorCorrection(double errorCorrection)
/*     */   {
/* 104 */     this.errorCorrection = errorCorrection;
/*     */   }
/*     */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\nnet\learning\BinaryDeltaRule.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */