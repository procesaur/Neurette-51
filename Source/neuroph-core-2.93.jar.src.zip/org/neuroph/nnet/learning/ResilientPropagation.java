/*     */ package org.neuroph.nnet.learning;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.neuroph.core.Connection;
/*     */ import org.neuroph.core.Layer;
/*     */ import org.neuroph.core.NeuralNetwork;
/*     */ import org.neuroph.core.Neuron;
/*     */ import org.neuroph.core.Weight;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResilientPropagation
/*     */   extends BackPropagation
/*     */ {
/*  18 */   private double decreaseFactor = 0.5D;
/*  19 */   private double increaseFactor = 1.2D;
/*  20 */   private double initialDelta = 0.1D;
/*  21 */   private double maxDelta = 1.0D;
/*  22 */   private double minDelta = 1.0E-6D;
/*     */   private static final double ZERO_TOLERANCE = 1.0E-27D;
/*     */   
/*     */   public ResilientPropagation()
/*     */   {
/*  27 */     super.setBatchMode(true);
/*     */   }
/*     */   
/*     */   private int sign(double value) {
/*  31 */     if (Math.abs(value) < 1.0E-27D)
/*  32 */       return 0;
/*  33 */     if (value > 0.0D) {
/*  34 */       return 1;
/*     */     }
/*  36 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */   protected void onStart()
/*     */   {
/*  42 */     super.onStart();
/*     */     
/*     */ 
/*  45 */     for (Layer layer : this.neuralNetwork.getLayers()) {
/*  46 */       for (Neuron neuron : layer.getNeurons()) {
/*  47 */         for (Connection connection : neuron.getInputConnections()) {
/*  48 */           connection.getWeight().setTrainingData(new ResilientWeightTrainingtData());
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void updateNeuronWeights(Neuron neuron)
/*     */   {
/*  60 */     for (Connection connection : neuron.getInputConnections()) {
/*  61 */       double input = connection.getInput();
/*  62 */       if (input != 0.0D)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*  67 */         double neuronError = neuron.getError();
/*     */         
/*  69 */         Weight weight = connection.getWeight();
/*     */         
/*  71 */         ResilientWeightTrainingtData weightData = (ResilientWeightTrainingtData)weight.getTrainingData();
/*     */         
/*     */ 
/*  74 */         weightData.gradient += neuronError * input;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   protected void doBatchWeightsUpdate()
/*     */   {
/*  81 */     List<Layer> layers = this.neuralNetwork.getLayers();
/*  82 */     for (int i = this.neuralNetwork.getLayersCount() - 1; i > 0; i--)
/*     */     {
/*  84 */       for (Neuron neuron : ((Layer)layers.get(i)).getNeurons())
/*     */       {
/*  86 */         for (Connection connection : neuron.getInputConnections())
/*     */         {
/*  88 */           Weight weight = connection.getWeight();
/*  89 */           resillientWeightUpdate(weight);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void resillientWeightUpdate(Weight weight)
/*     */   {
/* 102 */     ResilientWeightTrainingtData weightData = (ResilientWeightTrainingtData)weight.getTrainingData();
/*     */     
/*     */ 
/*     */ 
/* 106 */     int gradientSignChange = sign(weightData.previousGradient * weightData.gradient);
/*     */     
/* 108 */     double weightChange = 0.0D;
/*     */     
/*     */ 
/* 111 */     if (gradientSignChange > 0)
/*     */     {
/* 113 */       double delta = Math.min(weightData.previousDelta * this.increaseFactor, this.maxDelta);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 118 */       weightChange = sign(weightData.gradient) * delta;
/* 119 */       weightData.previousDelta = delta;
/* 120 */     } else if (gradientSignChange < 0)
/*     */     {
/* 122 */       double delta = Math.max(weightData.previousDelta * this.decreaseFactor, this.minDelta);
/*     */       
/*     */ 
/*     */ 
/* 126 */       weightChange = -weightData.previousWeightChange;
/*     */       
/* 128 */       weightData.gradient = 0.0D;
/* 129 */       weightData.previousGradient = 0.0D;
/*     */       
/*     */ 
/* 132 */       weightData.previousDelta = delta;
/* 133 */     } else if (gradientSignChange == 0)
/*     */     {
/* 135 */       double delta = weightData.previousDelta;
/*     */       
/* 137 */       weightChange = sign(weightData.gradient) * delta;
/*     */     }
/*     */     
/* 140 */     weight.value += weightChange;
/* 141 */     weightData.previousWeightChange = weightChange;
/* 142 */     weightData.previousGradient = weightData.gradient;
/* 143 */     weightData.gradient = 0.0D;
/*     */   }
/*     */   
/*     */   public double getDecreaseFactor() {
/* 147 */     return this.decreaseFactor;
/*     */   }
/*     */   
/*     */   public void setDecreaseFactor(double decreaseFactor) {
/* 151 */     this.decreaseFactor = decreaseFactor;
/*     */   }
/*     */   
/*     */   public double getIncreaseFactor() {
/* 155 */     return this.increaseFactor;
/*     */   }
/*     */   
/*     */   public void setIncreaseFactor(double increaseFactor) {
/* 159 */     this.increaseFactor = increaseFactor;
/*     */   }
/*     */   
/*     */   public double getInitialDelta() {
/* 163 */     return this.initialDelta;
/*     */   }
/*     */   
/*     */   public void setInitialDelta(double initialDelta) {
/* 167 */     this.initialDelta = initialDelta;
/*     */   }
/*     */   
/*     */   public double getMaxDelta() {
/* 171 */     return this.maxDelta;
/*     */   }
/*     */   
/*     */   public void setMaxDelta(double maxDelta) {
/* 175 */     this.maxDelta = maxDelta;
/*     */   }
/*     */   
/*     */   public double getMinDelta() {
/* 179 */     return this.minDelta;
/*     */   }
/*     */   
/*     */   public void setMinDelta(double minDelta) {
/* 183 */     this.minDelta = minDelta;
/*     */   }
/*     */   
/*     */   public class ResilientWeightTrainingtData {
/*     */     public double gradient;
/*     */     public double previousGradient;
/*     */     public double previousWeightChange;
/* 190 */     public double previousDelta = ResilientPropagation.this.initialDelta;
/*     */     
/*     */     public ResilientWeightTrainingtData() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\nnet\learning\ResilientPropagation.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */