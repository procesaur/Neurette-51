/*    */ package org.neuroph.nnet.learning;
/*    */ 
/*    */ import org.neuroph.core.Connection;
/*    */ import org.neuroph.core.Layer;
/*    */ import org.neuroph.core.NeuralNetwork;
/*    */ import org.neuroph.core.Neuron;
/*    */ import org.neuroph.core.Weight;
/*    */ import org.neuroph.core.data.DataSet;
/*    */ import org.neuroph.core.data.DataSetRow;
/*    */ import org.neuroph.core.learning.LearningRule;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HopfieldLearning
/*    */   extends LearningRule
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public void learn(DataSet trainingSet)
/*    */   {
/* 56 */     int M = trainingSet.size();
/* 57 */     int N = this.neuralNetwork.getLayerAt(0).getNeuronsCount();
/* 58 */     Layer hopfieldLayer = this.neuralNetwork.getLayerAt(0);
/*    */     
/* 60 */     for (int i = 0; i < N; i++) {
/* 61 */       for (int j = 0; j < N; j++) {
/* 62 */         if (j != i)
/*    */         {
/* 64 */           Neuron ni = hopfieldLayer.getNeuronAt(i);
/* 65 */           Neuron nj = hopfieldLayer.getNeuronAt(j);
/* 66 */           Connection cij = nj.getConnectionFrom(ni);
/* 67 */           Connection cji = ni.getConnectionFrom(nj);
/* 68 */           double w = 0.0D;
/* 69 */           for (int k = 0; k < M; k++) {
/* 70 */             DataSetRow trainingSetRow = trainingSet.getRowAt(k);
/* 71 */             double pki = trainingSetRow.getInput()[i];
/* 72 */             double pkj = trainingSetRow.getInput()[j];
/* 73 */             w += pki * pkj;
/*    */           }
/* 75 */           cij.getWeight().setValue(w);
/* 76 */           cji.getWeight().setValue(w);
/*    */         }
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\nnet\learning\HopfieldLearning.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */