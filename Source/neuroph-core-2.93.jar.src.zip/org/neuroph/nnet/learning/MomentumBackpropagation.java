/*     */ package org.neuroph.nnet.learning;
/*     */ 
/*     */ import org.neuroph.core.Connection;
/*     */ import org.neuroph.core.Layer;
/*     */ import org.neuroph.core.NeuralNetwork;
/*     */ import org.neuroph.core.Neuron;
/*     */ import org.neuroph.core.Weight;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MomentumBackpropagation
/*     */   extends BackPropagation
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  38 */   protected double momentum = 0.25D;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void updateNeuronWeights(Neuron neuron)
/*     */   {
/*  55 */     for (Connection connection : neuron.getInputConnections()) {
/*  56 */       double input = connection.getInput();
/*  57 */       if (input != 0.0D)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*  62 */         double neuronError = neuron.getError();
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  68 */         Weight weight = connection.getWeight();
/*  69 */         MomentumWeightTrainingData weightTrainingData = (MomentumWeightTrainingData)weight.getTrainingData();
/*     */         
/*     */ 
/*  72 */         double previousWeightValue = weightTrainingData.previousValue;
/*  73 */         double weightChange = this.learningRate * neuronError * input + this.momentum * (weight.value - previousWeightValue);
/*     */         
/*     */ 
/*     */ 
/*  77 */         weightTrainingData.previousValue = weight.value;
/*     */         
/*     */ 
/*     */ 
/*  81 */         if (!isInBatchMode()) {
/*  82 */           weight.weightChange = weightChange;
/*  83 */           weight.value += weightChange;
/*     */         } else {
/*  85 */           weight.weightChange += weightChange;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public double getMomentum()
/*     */   {
/*  96 */     return this.momentum;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMomentum(double momentum)
/*     */   {
/* 105 */     this.momentum = momentum;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void onStart()
/*     */   {
/* 115 */     super.onStart();
/*     */     
/* 117 */     for (Layer layer : this.neuralNetwork.getLayers()) {
/* 118 */       for (Neuron neuron : layer.getNeurons()) {
/* 119 */         for (Connection connection : neuron.getInputConnections()) {
/* 120 */           connection.getWeight().setTrainingData(new MomentumWeightTrainingData());
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public static class MomentumWeightTrainingData
/*     */   {
/*     */     public double previousValue;
/*     */   }
/*     */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\nnet\learning\MomentumBackpropagation.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */