/*    */ package org.neuroph.nnet.learning;
/*    */ 
/*    */ import org.neuroph.core.Connection;
/*    */ import org.neuroph.core.Neuron;
/*    */ import org.neuroph.core.Weight;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OutstarLearning
/*    */   extends UnsupervisedHebbianLearning
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public OutstarLearning()
/*    */   {
/* 40 */     setLearningRate(0.1D);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected void updateNeuronWeights(Neuron neuron)
/*    */   {
/* 52 */     double output = neuron.getOutput();
/* 53 */     for (Connection connection : neuron.getInputConnections()) {
/* 54 */       double input = connection.getInput();
/* 55 */       double weight = connection.getWeight().getValue();
/* 56 */       double deltaWeight = this.learningRate * input * (output - weight);
/* 57 */       connection.getWeight().inc(deltaWeight);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\nnet\learning\OutstarLearning.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */