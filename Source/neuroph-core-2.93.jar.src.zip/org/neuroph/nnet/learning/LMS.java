/*     */ package org.neuroph.nnet.learning;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.List;
/*     */ import org.neuroph.core.Connection;
/*     */ import org.neuroph.core.NeuralNetwork;
/*     */ import org.neuroph.core.Neuron;
/*     */ import org.neuroph.core.Weight;
/*     */ import org.neuroph.core.learning.SupervisedLearning;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LMS
/*     */   extends SupervisedLearning
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 2L;
/*     */   
/*     */   protected void calculateWeightChanges(double[] outputError)
/*     */   {
/*  60 */     int i = 0;
/*     */     
/*  62 */     List<Neuron> outputNeurons = this.neuralNetwork.getOutputNeurons();
/*  63 */     for (Neuron neuron : outputNeurons) {
/*  64 */       neuron.setError(outputError[i]);
/*  65 */       updateNeuronWeights(neuron);
/*  66 */       i++;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void updateNeuronWeights(Neuron neuron)
/*     */   {
/*  86 */     double neuronError = neuron.getError();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  93 */     for (Connection connection : neuron.getInputConnections())
/*     */     {
/*  95 */       double input = connection.getInput();
/*     */       
/*  97 */       double weightChange = this.learningRate * neuronError * input;
/*     */       
/*     */ 
/* 100 */       Weight weight = connection.getWeight();
/*     */       
/* 102 */       if (!isInBatchMode()) {
/* 103 */         weight.weightChange = weightChange;
/* 104 */         weight.value += weightChange;
/*     */       } else {
/* 106 */         weight.weightChange += weightChange;
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\nnet\learning\LMS.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */