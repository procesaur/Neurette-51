/*     */ package org.neuroph.nnet;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Vector;
/*     */ import org.neuroph.core.Layer;
/*     */ import org.neuroph.core.NeuralNetwork;
/*     */ import org.neuroph.core.Neuron;
/*     */ import org.neuroph.core.input.Min;
/*     */ import org.neuroph.core.input.WeightedSum;
/*     */ import org.neuroph.core.transfer.Linear;
/*     */ import org.neuroph.core.transfer.Trapezoid;
/*     */ import org.neuroph.nnet.learning.LMS;
/*     */ import org.neuroph.util.ConnectionFactory;
/*     */ import org.neuroph.util.LayerFactory;
/*     */ import org.neuroph.util.NeuralNetworkFactory;
/*     */ import org.neuroph.util.NeuralNetworkType;
/*     */ import org.neuroph.util.NeuronProperties;
/*     */ import org.neuroph.util.TransferFunctionType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NeuroFuzzyPerceptron
/*     */   extends NeuralNetwork
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   
/*     */   public NeuroFuzzyPerceptron(double[][] pointsSets, double[][] timeSets)
/*     */   {
/*  53 */     List<Integer> inputSets = new ArrayList();
/*  54 */     inputSets.add(Integer.valueOf(4));
/*  55 */     inputSets.add(Integer.valueOf(3));
/*     */     
/*  57 */     createStudentNFR(2, inputSets, 4, pointsSets, timeSets);
/*     */   }
/*     */   
/*     */   public NeuroFuzzyPerceptron(int inputNum, Vector<Integer> inputSets, int outNum) {
/*  61 */     createNetwork(inputNum, inputSets, outNum);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void createStudentNFR(int inputNum, List<Integer> inputSets, int outNum, double[][] pointsSets, double[][] timeSets)
/*     */   {
/*  69 */     setNetworkType(NeuralNetworkType.NEURO_FUZZY_REASONER);
/*     */     
/*     */ 
/*  72 */     NeuronProperties neuronProperties = new NeuronProperties();
/*  73 */     Layer inLayer = LayerFactory.createLayer(inputNum, neuronProperties);
/*  74 */     addLayer(inLayer);
/*     */     
/*     */ 
/*  77 */     neuronProperties.setProperty("transferFunction", TransferFunctionType.TRAPEZOID);
/*     */     
/*  79 */     Iterator<Integer> e = inputSets.iterator();
/*  80 */     int fuzzySetsNum = 0;
/*  81 */     while (e.hasNext()) {
/*  82 */       Integer i = (Integer)e.next();
/*  83 */       fuzzySetsNum += i.intValue();
/*     */     }
/*  85 */     Layer setLayer = LayerFactory.createLayer(fuzzySetsNum, neuronProperties);
/*     */     
/*  87 */     addLayer(setLayer);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  94 */     int c = 0;
/*  95 */     for (Neuron cell : setLayer.getNeurons())
/*     */     {
/*     */ 
/*  98 */       Trapezoid tf = (Trapezoid)cell.getTransferFunction();
/*     */       
/* 100 */       if (c <= 3) {
/* 101 */         tf.setLeftLow(pointsSets[c][0]);
/* 102 */         tf.setLeftHigh(pointsSets[c][1]);
/* 103 */         tf.setRightLow(pointsSets[c][3]);
/* 104 */         tf.setRightHigh(pointsSets[c][2]);
/*     */       } else {
/* 106 */         tf.setLeftLow(timeSets[(c - 4)][0]);
/* 107 */         tf.setLeftHigh(timeSets[(c - 4)][1]);
/* 108 */         tf.setRightLow(timeSets[(c - 4)][3]);
/* 109 */         tf.setRightHigh(timeSets[(c - 4)][2]);
/*     */       }
/* 111 */       c++;
/*     */     }
/*     */     
/*     */ 
/* 115 */     int s = 0;
/* 116 */     for (int i = 0; i < inputNum; i++) {
/* 117 */       Neuron from = inLayer.getNeuronAt(i);
/* 118 */       int jmax = ((Integer)inputSets.get(i)).intValue();
/* 119 */       for (int j = 0; j < jmax; j++) {
/* 120 */         Neuron to = setLayer.getNeuronAt(s);
/* 121 */         ConnectionFactory.createConnection(from, to, 1.0D);
/* 122 */         s++;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 129 */     NeuronProperties ruleNeuronProperties = new NeuronProperties(Neuron.class, WeightedSum.class, Linear.class);
/*     */     
/*     */ 
/*     */ 
/* 133 */     Iterator<Integer> en = inputSets.iterator();
/* 134 */     int fuzzyAntNum = 1;
/* 135 */     while (en.hasNext()) {
/* 136 */       Integer i = (Integer)en.next();
/* 137 */       fuzzyAntNum *= i.intValue();
/*     */     }
/* 139 */     Layer ruleLayer = LayerFactory.createLayer(fuzzyAntNum, ruleNeuronProperties);
/*     */     
/* 141 */     addLayer(ruleLayer);
/*     */     
/* 143 */     int scIdx = 0;
/*     */     
/* 145 */     for (int i = 0; i < inputNum; i++)
/*     */     {
/* 147 */       int setsNum = ((Integer)inputSets.get(i)).intValue();
/*     */       
/* 149 */       for (int si = 0; si < setsNum; si++)
/*     */       {
/* 151 */         if (i == 0) {
/* 152 */           Neuron from = setLayer.getNeuronAt(si);
/* 153 */           int connPerCell = fuzzyAntNum / setsNum;
/* 154 */           scIdx = si;
/*     */           
/* 156 */           for (int k = 0; k < connPerCell; k++)
/*     */           {
/* 158 */             Neuron to = ruleLayer.getNeuronAt(si * connPerCell + k);
/* 159 */             ConnectionFactory.createConnection(from, to, 1.0D);
/*     */           }
/*     */         }
/*     */         else {
/* 163 */           scIdx++;
/* 164 */           Neuron from = setLayer.getNeuronAt(scIdx);
/* 165 */           int connPerCell = fuzzyAntNum / setsNum;
/*     */           
/* 167 */           for (int k = 0; k < connPerCell; k++)
/*     */           {
/* 169 */             int toIdx = si + k * setsNum;
/* 170 */             Neuron to = ruleLayer.getNeuronAt(toIdx);
/* 171 */             ConnectionFactory.createConnection(from, to, 1.0D);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 178 */     neuronProperties = new NeuronProperties();
/* 179 */     neuronProperties.setProperty("transferFunction", TransferFunctionType.STEP);
/*     */     
/* 181 */     Layer outLayer = LayerFactory.createLayer(outNum, neuronProperties);
/* 182 */     addLayer(outLayer);
/*     */     
/* 184 */     ConnectionFactory.fullConnect(ruleLayer, outLayer);
/*     */     
/*     */ 
/* 187 */     NeuralNetworkFactory.setDefaultIO(this);
/*     */     
/* 189 */     setLearningRule(new LMS());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void createNetwork(int inputNum, Vector<Integer> inputSets, int outNum)
/*     */   {
/* 205 */     setNetworkType(NeuralNetworkType.NEURO_FUZZY_REASONER);
/*     */     
/*     */ 
/* 208 */     NeuronProperties neuronProperties = new NeuronProperties();
/* 209 */     Layer inLayer = LayerFactory.createLayer(inputNum, neuronProperties);
/* 210 */     addLayer(inLayer);
/*     */     
/*     */ 
/* 213 */     neuronProperties.setProperty("transferFunction", TransferFunctionType.TRAPEZOID);
/*     */     
/* 215 */     Enumeration<Integer> e = inputSets.elements();
/* 216 */     int fuzzySetsNum = 0;
/* 217 */     while (e.hasMoreElements()) {
/* 218 */       Integer i = (Integer)e.nextElement();
/* 219 */       fuzzySetsNum += i.intValue();
/*     */     }
/* 221 */     Layer setLayer = LayerFactory.createLayer(fuzzySetsNum, neuronProperties);
/* 222 */     addLayer(setLayer);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 229 */     int c = 0;
/* 230 */     for (Neuron cell : setLayer.getNeurons())
/*     */     {
/*     */ 
/* 233 */       tf = (Trapezoid)cell.getTransferFunction();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     Trapezoid tf;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 244 */     int s = 0;
/* 245 */     for (int i = 0; i < inputNum; i++) {
/* 246 */       Neuron from = inLayer.getNeuronAt(i);
/* 247 */       int jmax = ((Integer)inputSets.elementAt(i)).intValue();
/* 248 */       for (int j = 0; j < jmax; j++) {
/* 249 */         Neuron to = setLayer.getNeuronAt(s);
/* 250 */         ConnectionFactory.createConnection(from, to, 1.0D);
/* 251 */         s++;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 258 */     neuronProperties.setProperty("inputFunction", Min.class);
/* 259 */     neuronProperties.setProperty("transferFunction", Linear.class);
/*     */     
/* 261 */     Enumeration<Integer> en = inputSets.elements();
/* 262 */     int fuzzyAntNum = 1;
/* 263 */     while (en.hasMoreElements()) {
/* 264 */       Integer i = (Integer)en.nextElement();
/* 265 */       fuzzyAntNum *= i.intValue();
/*     */     }
/* 267 */     Layer ruleLayer = LayerFactory.createLayer(fuzzyAntNum, neuronProperties);
/* 268 */     addLayer(ruleLayer);
/*     */     
/*     */ 
/*     */ 
/* 272 */     int scIdx = 0;
/*     */     
/* 274 */     for (int i = 0; i < inputNum; i++)
/*     */     {
/* 276 */       int setsNum = ((Integer)inputSets.elementAt(i)).intValue();
/*     */       
/* 278 */       for (int si = 0; si < setsNum; si++)
/*     */       {
/* 280 */         if (i == 0) {
/* 281 */           Neuron from = setLayer.getNeuronAt(si);
/* 282 */           int connPerCell = fuzzyAntNum / setsNum;
/* 283 */           scIdx = si;
/*     */           
/* 285 */           for (int k = 0; k < connPerCell; k++)
/*     */           {
/* 287 */             Neuron to = ruleLayer.getNeuronAt(si * connPerCell + k);
/* 288 */             ConnectionFactory.createConnection(from, to, 1.0D);
/*     */           }
/*     */         }
/*     */         else {
/* 292 */           scIdx++;
/* 293 */           Neuron from = setLayer.getNeuronAt(scIdx);
/* 294 */           int connPerCell = fuzzyAntNum / setsNum;
/*     */           
/* 296 */           for (int k = 0; k < connPerCell; k++)
/*     */           {
/* 298 */             int toIdx = si + k * setsNum;
/* 299 */             Neuron to = ruleLayer.getNeuronAt(toIdx);
/* 300 */             ConnectionFactory.createConnection(from, to, 1.0D);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 307 */     neuronProperties = new NeuronProperties();
/* 308 */     neuronProperties.setProperty("transferFunction", TransferFunctionType.STEP);
/* 309 */     Layer outLayer = LayerFactory.createLayer(outNum, neuronProperties);
/* 310 */     addLayer(outLayer);
/*     */     
/* 312 */     ConnectionFactory.fullConnect(ruleLayer, outLayer);
/*     */     
/*     */ 
/* 315 */     NeuralNetworkFactory.setDefaultIO(this);
/*     */     
/* 317 */     setLearningRule(new LMS());
/*     */   }
/*     */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\nnet\NeuroFuzzyPerceptron.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */