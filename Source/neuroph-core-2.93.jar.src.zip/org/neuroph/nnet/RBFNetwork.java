/*     */ package org.neuroph.nnet;
/*     */ 
/*     */ import org.neuroph.core.Layer;
/*     */ import org.neuroph.core.NeuralNetwork;
/*     */ import org.neuroph.core.input.Difference;
/*     */ import org.neuroph.core.transfer.Gaussian;
/*     */ import org.neuroph.nnet.learning.RBFLearning;
/*     */ import org.neuroph.util.ConnectionFactory;
/*     */ import org.neuroph.util.LayerFactory;
/*     */ import org.neuroph.util.NeuralNetworkFactory;
/*     */ import org.neuroph.util.NeuralNetworkType;
/*     */ import org.neuroph.util.NeuronProperties;
/*     */ import org.neuroph.util.TransferFunctionType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RBFNetwork
/*     */   extends NeuralNetwork
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   
/*     */   public RBFNetwork(int inputNeuronsCount, int rbfNeuronsCount, int outputNeuronsCount)
/*     */   {
/*  59 */     createNetwork(inputNeuronsCount, rbfNeuronsCount, outputNeuronsCount);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void createNetwork(int inputNeuronsCount, int rbfNeuronsCount, int outputNeuronsCount)
/*     */   {
/*  76 */     NeuronProperties rbfNeuronProperties = new NeuronProperties();
/*  77 */     rbfNeuronProperties.setProperty("inputFunction", Difference.class);
/*  78 */     rbfNeuronProperties.setProperty("transferFunction", Gaussian.class);
/*     */     
/*     */ 
/*  81 */     setNetworkType(NeuralNetworkType.RBF_NETWORK);
/*     */     
/*     */ 
/*  84 */     Layer inputLayer = LayerFactory.createLayer(inputNeuronsCount, TransferFunctionType.LINEAR);
/*  85 */     addLayer(inputLayer);
/*     */     
/*     */ 
/*  88 */     Layer rbfLayer = LayerFactory.createLayer(rbfNeuronsCount, rbfNeuronProperties);
/*  89 */     addLayer(rbfLayer);
/*     */     
/*     */ 
/*  92 */     Layer outputLayer = LayerFactory.createLayer(outputNeuronsCount, TransferFunctionType.LINEAR);
/*  93 */     addLayer(outputLayer);
/*     */     
/*     */ 
/*  96 */     ConnectionFactory.fullConnect(inputLayer, rbfLayer);
/*     */     
/*  98 */     ConnectionFactory.fullConnect(rbfLayer, outputLayer);
/*     */     
/*     */ 
/* 101 */     NeuralNetworkFactory.setDefaultIO(this);
/*     */     
/*     */ 
/* 104 */     setLearningRule(new RBFLearning());
/*     */   }
/*     */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\neuroph-core-2.93.jar!\org\neuroph\nnet\RBFNetwork.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */