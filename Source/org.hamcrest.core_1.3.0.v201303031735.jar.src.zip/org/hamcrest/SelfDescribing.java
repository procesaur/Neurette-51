package org.hamcrest;

public abstract interface SelfDescribing
{
  public abstract void describeTo(Description paramDescription);
}


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\org.hamcrest.core_1.3.0.v201303031735.jar!\org\hamcrest\SelfDescribing.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */