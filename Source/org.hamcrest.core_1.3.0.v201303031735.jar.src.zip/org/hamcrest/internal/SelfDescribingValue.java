/*    */ package org.hamcrest.internal;
/*    */ 
/*    */ import org.hamcrest.Description;
/*    */ 
/*    */ public class SelfDescribingValue<T> implements org.hamcrest.SelfDescribing
/*    */ {
/*    */   private T value;
/*    */   
/*    */   public SelfDescribingValue(T value) {
/* 10 */     this.value = value;
/*    */   }
/*    */   
/*    */   public void describeTo(Description description)
/*    */   {
/* 15 */     description.appendValue(this.value);
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\org.hamcrest.core_1.3.0.v201303031735.jar!\org\hamcrest\internal\SelfDescribingValue.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */