package org.hamcrest;

public abstract interface Matcher<T>
  extends SelfDescribing
{
  public abstract boolean matches(Object paramObject);
  
  public abstract void describeMismatch(Object paramObject, Description paramDescription);
  
  @Deprecated
  public abstract void _dont_implement_Matcher___instead_extend_BaseMatcher_();
}


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\org.hamcrest.core_1.3.0.v201303031735.jar!\org\hamcrest\Matcher.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */