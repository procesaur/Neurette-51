/*    */ package ch.qos.logback.core.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DynamicClassLoadingException
/*    */   extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = 4962278449162476114L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public DynamicClassLoadingException(String desc, Throwable root)
/*    */   {
/* 21 */     super(desc, root);
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\logback-core-1.1.2.jar!\ch\qos\logback\core\util\DynamicClassLoadingException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */