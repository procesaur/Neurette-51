/*    */ package ch.qos.logback.core.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SystemInfo
/*    */ {
/*    */   public static String getJavaVendor()
/*    */   {
/* 21 */     return OptionHelper.getSystemProperty("java.vendor", null);
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\logback-core-1.1.2.jar!\ch\qos\logback\core\util\SystemInfo.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */