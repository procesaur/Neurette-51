package ch.qos.logback.core.util;

public enum AggregationType
{
  NOT_FOUND,  AS_BASIC_PROPERTY,  AS_COMPLEX_PROPERTY,  AS_BASIC_PROPERTY_COLLECTION,  AS_COMPLEX_PROPERTY_COLLECTION;
  
  private AggregationType() {}
}


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\logback-core-1.1.2.jar!\ch\qos\logback\core\util\AggregationType.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */