/*     */ package ch.qos.logback.core;
/*     */ 
/*     */ import ch.qos.logback.core.helpers.CyclicBuffer;
/*     */ import ch.qos.logback.core.spi.LogbackLock;
/*     */ import ch.qos.logback.core.status.Status;
/*     */ import ch.qos.logback.core.status.StatusListener;
/*     */ import ch.qos.logback.core.status.StatusManager;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BasicStatusManager
/*     */   implements StatusManager
/*     */ {
/*     */   public static final int MAX_HEADER_COUNT = 150;
/*     */   public static final int TAIL_SIZE = 150;
/*  30 */   int count = 0;
/*     */   
/*     */ 
/*  33 */   protected final List<Status> statusList = new ArrayList();
/*  34 */   protected final CyclicBuffer<Status> tailBuffer = new CyclicBuffer(150);
/*     */   
/*  36 */   protected final LogbackLock statusListLock = new LogbackLock();
/*     */   
/*  38 */   int level = 0;
/*     */   
/*     */ 
/*  41 */   protected final List<StatusListener> statusListenerList = new ArrayList();
/*  42 */   protected final LogbackLock statusListenerListLock = new LogbackLock();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void add(Status newStatus)
/*     */   {
/*  59 */     fireStatusAddEvent(newStatus);
/*     */     
/*  61 */     this.count += 1;
/*  62 */     if (newStatus.getLevel() > this.level) {
/*  63 */       this.level = newStatus.getLevel();
/*     */     }
/*     */     
/*  66 */     synchronized (this.statusListLock) {
/*  67 */       if (this.statusList.size() < 150) {
/*  68 */         this.statusList.add(newStatus);
/*     */       } else {
/*  70 */         this.tailBuffer.add(newStatus);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public List<Status> getCopyOfStatusList()
/*     */   {
/*  77 */     synchronized (this.statusListLock) {
/*  78 */       List<Status> tList = new ArrayList(this.statusList);
/*  79 */       tList.addAll(this.tailBuffer.asList());
/*  80 */       return tList;
/*     */     }
/*     */   }
/*     */   
/*     */   private void fireStatusAddEvent(Status status) {
/*  85 */     synchronized (this.statusListenerListLock) {
/*  86 */       for (StatusListener sl : this.statusListenerList) {
/*  87 */         sl.addStatusEvent(status);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void clear() {
/*  93 */     synchronized (this.statusListLock) {
/*  94 */       this.count = 0;
/*  95 */       this.statusList.clear();
/*  96 */       this.tailBuffer.clear();
/*     */     }
/*     */   }
/*     */   
/*     */   public int getLevel() {
/* 101 */     return this.level;
/*     */   }
/*     */   
/*     */   public int getCount() {
/* 105 */     return this.count;
/*     */   }
/*     */   
/*     */   public void add(StatusListener listener) {
/* 109 */     synchronized (this.statusListenerListLock) {
/* 110 */       this.statusListenerList.add(listener);
/*     */     }
/*     */   }
/*     */   
/*     */   public void remove(StatusListener listener) {
/* 115 */     synchronized (this.statusListenerListLock) {
/* 116 */       this.statusListenerList.remove(listener);
/*     */     }
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public List<StatusListener> getCopyOfStatusListenerList()
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield 14	ch/qos/logback/core/BasicStatusManager:statusListenerListLock	Lch/qos/logback/core/spi/LogbackLock;
/*     */     //   4: dup
/*     */     //   5: astore_1
/*     */     //   6: monitorenter
/*     */     //   7: new 3	java/util/ArrayList
/*     */     //   10: dup
/*     */     //   11: aload_0
/*     */     //   12: getfield 13	ch/qos/logback/core/BasicStatusManager:statusListenerList	Ljava/util/List;
/*     */     //   15: invokespecial 20	java/util/ArrayList:<init>	(Ljava/util/Collection;)V
/*     */     //   18: aload_1
/*     */     //   19: monitorexit
/*     */     //   20: areturn
/*     */     //   21: astore_2
/*     */     //   22: aload_1
/*     */     //   23: monitorexit
/*     */     //   24: aload_2
/*     */     //   25: athrow
/*     */     // Line number table:
/*     */     //   Java source line #121	-> byte code offset #0
/*     */     //   Java source line #122	-> byte code offset #7
/*     */     //   Java source line #123	-> byte code offset #21
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	26	0	this	BasicStatusManager
/*     */     //   5	18	1	Ljava/lang/Object;	Object
/*     */     //   21	4	2	localObject1	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   7	20	21	finally
/*     */     //   21	24	21	finally
/*     */   }
/*     */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\logback-core-1.1.2.jar!\ch\qos\logback\core\BasicStatusManager.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */