package ch.qos.logback.core.helpers;

import ch.qos.logback.core.AppenderBase;

public final class NOPAppender<E>
  extends AppenderBase<E>
{
  protected void append(E eventObject) {}
}


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\logback-core-1.1.2.jar!\ch\qos\logback\core\helpers\NOPAppender.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */