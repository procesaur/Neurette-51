package ch.qos.logback.core.status;

public abstract interface StatusListener
{
  public abstract void addStatusEvent(Status paramStatus);
}


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\logback-core-1.1.2.jar!\ch\qos\logback\core\status\StatusListener.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */