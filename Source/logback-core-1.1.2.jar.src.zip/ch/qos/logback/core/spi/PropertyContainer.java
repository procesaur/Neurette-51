package ch.qos.logback.core.spi;

import java.util.Map;

public abstract interface PropertyContainer
{
  public abstract String getProperty(String paramString);
  
  public abstract Map<String, String> getCopyOfPropertyMap();
}


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\logback-core-1.1.2.jar!\ch\qos\logback\core\spi\PropertyContainer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */