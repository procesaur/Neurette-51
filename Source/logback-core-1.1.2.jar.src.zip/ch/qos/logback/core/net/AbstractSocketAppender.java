/*     */ package ch.qos.logback.core.net;
/*     */ 
/*     */ import ch.qos.logback.core.AppenderBase;
/*     */ import ch.qos.logback.core.Context;
/*     */ import ch.qos.logback.core.spi.PreSerializationTransformer;
/*     */ import ch.qos.logback.core.util.CloseUtil;
/*     */ import ch.qos.logback.core.util.Duration;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.Serializable;
/*     */ import java.net.ConnectException;
/*     */ import java.net.InetAddress;
/*     */ import java.net.Socket;
/*     */ import java.net.UnknownHostException;
/*     */ import java.util.concurrent.ArrayBlockingQueue;
/*     */ import java.util.concurrent.BlockingQueue;
/*     */ import java.util.concurrent.ExecutionException;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Future;
/*     */ import java.util.concurrent.RejectedExecutionException;
/*     */ import java.util.concurrent.SynchronousQueue;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import javax.net.SocketFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractSocketAppender<E>
/*     */   extends AppenderBase<E>
/*     */   implements Runnable, SocketConnector.ExceptionHandler
/*     */ {
/*     */   public static final int DEFAULT_PORT = 4560;
/*     */   public static final int DEFAULT_RECONNECTION_DELAY = 30000;
/*     */   public static final int DEFAULT_QUEUE_SIZE = 128;
/*     */   private static final int DEFAULT_ACCEPT_CONNECTION_DELAY = 5000;
/*     */   private static final int DEFAULT_EVENT_DELAY_TIMEOUT = 100;
/*     */   private String remoteHost;
/*  82 */   private int port = 4560;
/*     */   private InetAddress address;
/*  84 */   private Duration reconnectionDelay = new Duration(30000L);
/*  85 */   private int queueSize = 128;
/*  86 */   private int acceptConnectionTimeout = 5000;
/*  87 */   private Duration eventDelayLimit = new Duration(100L);
/*     */   
/*     */ 
/*     */   private BlockingQueue<E> queue;
/*     */   
/*     */ 
/*     */   private String peerId;
/*     */   
/*     */ 
/*     */   private Future<?> task;
/*     */   
/*     */ 
/*     */   private Future<Socket> connectorTask;
/*     */   
/*     */   private volatile Socket socket;
/*     */   
/*     */ 
/*     */   public void start()
/*     */   {
/* 106 */     if (isStarted()) return;
/* 107 */     int errorCount = 0;
/* 108 */     if (this.port <= 0) {
/* 109 */       errorCount++;
/* 110 */       addError("No port was configured for appender" + this.name + " For more information, please visit http://logback.qos.ch/codes.html#socket_no_port");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 115 */     if (this.remoteHost == null) {
/* 116 */       errorCount++;
/* 117 */       addError("No remote host was configured for appender" + this.name + " For more information, please visit http://logback.qos.ch/codes.html#socket_no_host");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 122 */     if (this.queueSize < 0) {
/* 123 */       errorCount++;
/* 124 */       addError("Queue size must be non-negative");
/*     */     }
/*     */     
/* 127 */     if (errorCount == 0) {
/*     */       try {
/* 129 */         this.address = InetAddress.getByName(this.remoteHost);
/*     */       } catch (UnknownHostException ex) {
/* 131 */         addError("unknown host: " + this.remoteHost);
/* 132 */         errorCount++;
/*     */       }
/*     */     }
/*     */     
/* 136 */     if (errorCount == 0) {
/* 137 */       this.queue = newBlockingQueue(this.queueSize);
/* 138 */       this.peerId = ("remote peer " + this.remoteHost + ":" + this.port + ": ");
/* 139 */       this.task = getContext().getExecutorService().submit(this);
/* 140 */       super.start();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void stop()
/*     */   {
/* 149 */     if (!isStarted()) return;
/* 150 */     CloseUtil.closeQuietly(this.socket);
/* 151 */     this.task.cancel(true);
/* 152 */     if (this.connectorTask != null)
/* 153 */       this.connectorTask.cancel(true);
/* 154 */     super.stop();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void append(E event)
/*     */   {
/* 162 */     if ((event == null) || (!isStarted())) return;
/*     */     try
/*     */     {
/* 165 */       boolean inserted = this.queue.offer(event, this.eventDelayLimit.getMilliseconds(), TimeUnit.MILLISECONDS);
/* 166 */       if (!inserted) {
/* 167 */         addInfo("Dropping event due to timeout limit of [" + this.eventDelayLimit + "] milliseconds being exceeded");
/*     */       }
/*     */     }
/*     */     catch (InterruptedException e) {
/* 171 */       addError("Interrupted while appending event to SocketAppender", e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final void run()
/*     */   {
/* 179 */     signalEntryInRunMethod();
/*     */     try {
/* 181 */       while (!Thread.currentThread().isInterrupted()) {
/* 182 */         SocketConnector connector = createConnector(this.address, this.port, 0, this.reconnectionDelay.getMilliseconds());
/*     */         
/*     */ 
/* 185 */         this.connectorTask = activateConnector(connector);
/* 186 */         if (this.connectorTask == null) {
/*     */           break;
/*     */         }
/* 189 */         this.socket = waitForConnectorToReturnASocket();
/* 190 */         if (this.socket == null)
/*     */           break;
/* 192 */         dispatchEvents();
/*     */       }
/*     */     }
/*     */     catch (InterruptedException ex) {}
/*     */     
/* 197 */     addInfo("shutting down");
/*     */   }
/*     */   
/*     */ 
/*     */   protected void signalEntryInRunMethod() {}
/*     */   
/*     */ 
/*     */   private SocketConnector createConnector(InetAddress address, int port, int initialDelay, long retryDelay)
/*     */   {
/* 206 */     SocketConnector connector = newConnector(address, port, initialDelay, retryDelay);
/*     */     
/* 208 */     connector.setExceptionHandler(this);
/* 209 */     connector.setSocketFactory(getSocketFactory());
/* 210 */     return connector;
/*     */   }
/*     */   
/*     */   private Future<Socket> activateConnector(SocketConnector connector) {
/*     */     try {
/* 215 */       return getContext().getExecutorService().submit(connector);
/*     */     } catch (RejectedExecutionException ex) {}
/* 217 */     return null;
/*     */   }
/*     */   
/*     */   private Socket waitForConnectorToReturnASocket() throws InterruptedException
/*     */   {
/*     */     try {
/* 223 */       Socket s = (Socket)this.connectorTask.get();
/* 224 */       this.connectorTask = null;
/* 225 */       return s;
/*     */     } catch (ExecutionException e) {}
/* 227 */     return null;
/*     */   }
/*     */   
/*     */   private void dispatchEvents() throws InterruptedException
/*     */   {
/*     */     try {
/* 233 */       this.socket.setSoTimeout(this.acceptConnectionTimeout);
/* 234 */       ObjectOutputStream oos = new ObjectOutputStream(this.socket.getOutputStream());
/* 235 */       this.socket.setSoTimeout(0);
/* 236 */       addInfo(this.peerId + "connection established");
/* 237 */       int counter = 0;
/*     */       for (;;) {
/* 239 */         E event = this.queue.take();
/* 240 */         postProcessEvent(event);
/* 241 */         Serializable serEvent = getPST().transform(event);
/* 242 */         oos.writeObject(serEvent);
/* 243 */         oos.flush();
/* 244 */         counter++; if (counter >= 70)
/*     */         {
/*     */ 
/* 247 */           oos.reset();
/* 248 */           counter = 0;
/*     */         }
/*     */       }
/*     */     } catch (IOException ex) {
/* 252 */       addInfo(this.peerId + "connection failed: " + ex);
/*     */     } finally {
/* 254 */       CloseUtil.closeQuietly(this.socket);
/* 255 */       this.socket = null;
/* 256 */       addInfo(this.peerId + "connection closed");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void connectionFailed(SocketConnector connector, Exception ex)
/*     */   {
/* 264 */     if ((ex instanceof InterruptedException)) {
/* 265 */       addInfo("connector interrupted");
/* 266 */     } else if ((ex instanceof ConnectException)) {
/* 267 */       addInfo(this.peerId + "connection refused");
/*     */     } else {
/* 269 */       addInfo(this.peerId + ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected SocketConnector newConnector(InetAddress address, int port, long initialDelay, long retryDelay)
/*     */   {
/* 290 */     return new DefaultSocketConnector(address, port, initialDelay, retryDelay);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected SocketFactory getSocketFactory()
/*     */   {
/* 299 */     return SocketFactory.getDefault();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   BlockingQueue<E> newBlockingQueue(int queueSize)
/*     */   {
/* 316 */     return queueSize <= 0 ? new SynchronousQueue() : new ArrayBlockingQueue(queueSize);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract void postProcessEvent(E paramE);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract PreSerializationTransformer<E> getPST();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   protected static InetAddress getAddressByName(String host)
/*     */   {
/*     */     try
/*     */     {
/* 342 */       return InetAddress.getByName(host);
/*     */     }
/*     */     catch (Exception e) {}
/* 345 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRemoteHost(String host)
/*     */   {
/* 353 */     this.remoteHost = host;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getRemoteHost()
/*     */   {
/* 360 */     return this.remoteHost;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPort(int port)
/*     */   {
/* 368 */     this.port = port;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getPort()
/*     */   {
/* 375 */     return this.port;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setReconnectionDelay(Duration delay)
/*     */   {
/* 387 */     this.reconnectionDelay = delay;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Duration getReconnectionDelay()
/*     */   {
/* 394 */     return this.reconnectionDelay;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setQueueSize(int queueSize)
/*     */   {
/* 410 */     this.queueSize = queueSize;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getQueueSize()
/*     */   {
/* 417 */     return this.queueSize;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setEventDelayLimit(Duration eventDelayLimit)
/*     */   {
/* 428 */     this.eventDelayLimit = eventDelayLimit;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Duration getEventDelayLimit()
/*     */   {
/* 435 */     return this.eventDelayLimit;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void setAcceptConnectionTimeout(int acceptConnectionTimeout)
/*     */   {
/* 448 */     this.acceptConnectionTimeout = acceptConnectionTimeout;
/*     */   }
/*     */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\logback-core-1.1.2.jar!\ch\qos\logback\core\net\AbstractSocketAppender.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */