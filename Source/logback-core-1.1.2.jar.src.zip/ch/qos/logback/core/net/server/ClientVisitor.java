package ch.qos.logback.core.net.server;

public abstract interface ClientVisitor<T extends Client>
{
  public abstract void visit(T paramT);
}


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\logback-core-1.1.2.jar!\ch\qos\logback\core\net\server\ClientVisitor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */