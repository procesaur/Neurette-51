/*     */ package ch.qos.logback.core.net;
/*     */ 
/*     */ import ch.qos.logback.core.AppenderBase;
/*     */ import ch.qos.logback.core.Layout;
/*     */ import ch.qos.logback.core.boolex.EvaluationException;
/*     */ import ch.qos.logback.core.boolex.EventEvaluator;
/*     */ import ch.qos.logback.core.helpers.CyclicBuffer;
/*     */ import ch.qos.logback.core.pattern.PatternLayoutBase;
/*     */ import ch.qos.logback.core.sift.DefaultDiscriminator;
/*     */ import ch.qos.logback.core.sift.Discriminator;
/*     */ import ch.qos.logback.core.spi.CyclicBufferTracker;
/*     */ import ch.qos.logback.core.util.ContentTypeUtil;
/*     */ import ch.qos.logback.core.util.OptionHelper;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Date;
/*     */ import java.util.List;
/*     */ import java.util.Properties;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import javax.mail.Message;
/*     */ import javax.mail.Message.RecipientType;
/*     */ import javax.mail.MessagingException;
/*     */ import javax.mail.Multipart;
/*     */ import javax.mail.Session;
/*     */ import javax.mail.Transport;
/*     */ import javax.mail.internet.AddressException;
/*     */ import javax.mail.internet.InternetAddress;
/*     */ import javax.mail.internet.MimeBodyPart;
/*     */ import javax.mail.internet.MimeMessage;
/*     */ import javax.mail.internet.MimeMultipart;
/*     */ import javax.naming.InitialContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class SMTPAppenderBase<E>
/*     */   extends AppenderBase<E>
/*     */ {
/*  64 */   static InternetAddress[] EMPTY_IA_ARRAY = new InternetAddress[0];
/*     */   static final int MAX_DELAY_BETWEEN_STATUS_MESSAGES = 1228800000;
/*     */   
/*     */   public SMTPAppenderBase() {
/*  68 */     this.lastTrackerStatusPrint = 0L;
/*  69 */     this.delayBetweenStatusMessages = 300000;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  74 */     this.toPatternLayoutList = new ArrayList();
/*     */     
/*  76 */     this.subjectStr = null;
/*     */     
/*  78 */     this.smtpPort = 25;
/*  79 */     this.starttls = false;
/*  80 */     this.ssl = false;
/*  81 */     this.sessionViaJNDI = false;
/*  82 */     this.jndiLocation = "java:comp/env/mail/Session";
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  89 */     this.asynchronousSending = true;
/*     */     
/*  91 */     this.charsetEncoding = "UTF-8";
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  97 */     this.discriminator = new DefaultDiscriminator();
/*     */     
/*     */ 
/* 100 */     this.errorCount = 0;
/*     */   }
/*     */   
/*     */   long lastTrackerStatusPrint;
/*     */   int delayBetweenStatusMessages;
/*     */   protected Layout<E> subjectLayout;
/*     */   protected Layout<E> layout;
/*     */   private List<PatternLayoutBase<E>> toPatternLayoutList;
/*     */   private String from;
/*     */   private String subjectStr;
/*     */   private String smtpHost;
/*     */   private int smtpPort;
/*     */   private boolean starttls;
/*     */   private boolean ssl;
/*     */   protected abstract Layout<E> makeSubjectLayout(String paramString);
/*     */   
/*     */   public void start() {
/* 117 */     if (this.cbTracker == null) {
/* 118 */       this.cbTracker = new CyclicBufferTracker();
/*     */     }
/*     */     
/* 121 */     Session session = null;
/* 122 */     if (this.sessionViaJNDI) {
/* 123 */       session = lookupSessionInJNDI();
/*     */     } else {
/* 125 */       session = buildSessionFromProperties();
/*     */     }
/* 127 */     if (session == null) {
/* 128 */       addError("Failed to obtain javax.mail.Session. Cannot start.");
/* 129 */       return;
/*     */     }
/* 131 */     this.mimeMsg = new MimeMessage(session);
/*     */     try
/*     */     {
/* 134 */       if (this.from != null) {
/* 135 */         this.mimeMsg.setFrom(getAddress(this.from));
/*     */       } else {
/* 137 */         this.mimeMsg.setFrom();
/*     */       }
/*     */       
/* 140 */       this.subjectLayout = makeSubjectLayout(this.subjectStr);
/*     */       
/* 142 */       this.started = true;
/*     */     }
/*     */     catch (MessagingException e) {
/* 145 */       addError("Could not activate SMTPAppender options.", e);
/*     */     }
/*     */   }
/*     */   
/*     */   private Session lookupSessionInJNDI() {
/* 150 */     addInfo("Looking up javax.mail.Session at JNDI location [" + this.jndiLocation + "]");
/*     */     try {
/* 152 */       javax.naming.Context initialContext = new InitialContext();
/* 153 */       Object obj = initialContext.lookup(this.jndiLocation);
/* 154 */       return (Session)obj;
/*     */     } catch (Exception e) {
/* 156 */       addError("Failed to obtain javax.mail.Session from JNDI location [" + this.jndiLocation + "]"); }
/* 157 */     return null;
/*     */   }
/*     */   
/*     */   private Session buildSessionFromProperties()
/*     */   {
/* 162 */     Properties props = new Properties(OptionHelper.getSystemProperties());
/* 163 */     if (this.smtpHost != null) {
/* 164 */       props.put("mail.smtp.host", this.smtpHost);
/*     */     }
/* 166 */     props.put("mail.smtp.port", Integer.toString(this.smtpPort));
/*     */     
/* 168 */     if (this.localhost != null) {
/* 169 */       props.put("mail.smtp.localhost", this.localhost);
/*     */     }
/*     */     
/* 172 */     LoginAuthenticator loginAuthenticator = null;
/*     */     
/* 174 */     if (this.username != null) {
/* 175 */       loginAuthenticator = new LoginAuthenticator(this.username, this.password);
/* 176 */       props.put("mail.smtp.auth", "true");
/*     */     }
/*     */     
/* 179 */     if ((isSTARTTLS()) && (isSSL())) {
/* 180 */       addError("Both SSL and StartTLS cannot be enabled simultaneously");
/*     */     } else {
/* 182 */       if (isSTARTTLS())
/*     */       {
/* 184 */         props.put("mail.smtp.starttls.enable", "true");
/*     */       }
/* 186 */       if (isSSL()) {
/* 187 */         String SSL_FACTORY = "javax.net.ssl.SSLSocketFactory";
/* 188 */         props.put("mail.smtp.socketFactory.port", Integer.toString(this.smtpPort));
/* 189 */         props.put("mail.smtp.socketFactory.class", SSL_FACTORY);
/* 190 */         props.put("mail.smtp.socketFactory.fallback", "true");
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 196 */     return Session.getInstance(props, loginAuthenticator);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void append(E eventObject)
/*     */   {
/* 205 */     if (!checkEntryConditions()) {
/* 206 */       return;
/*     */     }
/*     */     
/* 209 */     String key = this.discriminator.getDiscriminatingValue(eventObject);
/* 210 */     long now = System.currentTimeMillis();
/* 211 */     CyclicBuffer<E> cb = (CyclicBuffer)this.cbTracker.getOrCreate(key, now);
/* 212 */     subAppend(cb, eventObject);
/*     */     try
/*     */     {
/* 215 */       if (this.eventEvaluator.evaluate(eventObject))
/*     */       {
/* 217 */         CyclicBuffer<E> cbClone = new CyclicBuffer(cb);
/*     */         
/* 219 */         cb.clear();
/*     */         
/* 221 */         if (this.asynchronousSending)
/*     */         {
/* 223 */           SMTPAppenderBase<E>.SenderRunnable senderRunnable = new SenderRunnable(cbClone, eventObject);
/* 224 */           this.context.getExecutorService().execute(senderRunnable);
/*     */         }
/*     */         else {
/* 227 */           sendBuffer(cbClone, eventObject);
/*     */         }
/*     */       }
/*     */     } catch (EvaluationException ex) {
/* 231 */       this.errorCount += 1;
/* 232 */       if (this.errorCount < 4) {
/* 233 */         addError("SMTPAppender's EventEvaluator threw an Exception-", ex);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 238 */     if (eventMarksEndOfLife(eventObject)) {
/* 239 */       this.cbTracker.endOfLife(key);
/*     */     }
/*     */     
/* 242 */     this.cbTracker.removeStaleComponents(now);
/*     */     
/* 244 */     if (this.lastTrackerStatusPrint + this.delayBetweenStatusMessages < now) {
/* 245 */       addInfo("SMTPAppender [" + this.name + "] is tracking [" + this.cbTracker.getComponentCount() + "] buffers");
/* 246 */       this.lastTrackerStatusPrint = now;
/*     */       
/* 248 */       if (this.delayBetweenStatusMessages < 1228800000) {
/* 249 */         this.delayBetweenStatusMessages *= 4;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract boolean eventMarksEndOfLife(E paramE);
/*     */   
/*     */ 
/*     */ 
/*     */   protected abstract void subAppend(CyclicBuffer<E> paramCyclicBuffer, E paramE);
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean checkEntryConditions()
/*     */   {
/* 267 */     if (!this.started) {
/* 268 */       addError("Attempting to append to a non-started appender: " + getName());
/*     */       
/* 270 */       return false;
/*     */     }
/*     */     
/* 273 */     if (this.mimeMsg == null) {
/* 274 */       addError("Message object not configured.");
/* 275 */       return false;
/*     */     }
/*     */     
/* 278 */     if (this.eventEvaluator == null) {
/* 279 */       addError("No EventEvaluator is set for appender [" + this.name + "].");
/* 280 */       return false;
/*     */     }
/*     */     
/* 283 */     if (this.layout == null) {
/* 284 */       addError("No layout set for appender named [" + this.name + "]. For more information, please visit http://logback.qos.ch/codes.html#smtp_no_layout");
/*     */       
/*     */ 
/* 287 */       return false;
/*     */     }
/* 289 */     return true;
/*     */   }
/*     */   
/*     */   public synchronized void stop() {
/* 293 */     this.started = false;
/*     */   }
/*     */   
/*     */   InternetAddress getAddress(String addressStr) {
/*     */     try {
/* 298 */       return new InternetAddress(addressStr);
/*     */     } catch (AddressException e) {
/* 300 */       addError("Could not parse address [" + addressStr + "].", e); }
/* 301 */     return null;
/*     */   }
/*     */   
/*     */   private List<InternetAddress> parseAddress(E event)
/*     */   {
/* 306 */     int len = this.toPatternLayoutList.size();
/*     */     
/* 308 */     List<InternetAddress> iaList = new ArrayList();
/*     */     
/* 310 */     for (int i = 0; i < len; i++) {
/*     */       try {
/* 312 */         PatternLayoutBase<E> emailPL = (PatternLayoutBase)this.toPatternLayoutList.get(i);
/* 313 */         String emailAdrr = emailPL.doLayout(event);
/* 314 */         if ((emailAdrr == null) || (emailAdrr.length() != 0))
/*     */         {
/*     */ 
/* 317 */           InternetAddress[] tmp = InternetAddress.parse(emailAdrr, true);
/* 318 */           iaList.addAll(Arrays.asList(tmp));
/*     */         }
/* 320 */       } catch (AddressException e) { addError("Could not parse email address for [" + this.toPatternLayoutList.get(i) + "] for event [" + event + "]", e);
/* 321 */         return iaList;
/*     */       }
/*     */     }
/*     */     
/* 325 */     return iaList;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public List<PatternLayoutBase<E>> getToList()
/*     */   {
/* 332 */     return this.toPatternLayoutList;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void sendBuffer(CyclicBuffer<E> cb, E lastEventObject)
/*     */   {
/*     */     try
/*     */     {
/* 343 */       MimeBodyPart part = new MimeBodyPart();
/*     */       
/* 345 */       StringBuffer sbuf = new StringBuffer();
/*     */       
/* 347 */       String header = this.layout.getFileHeader();
/* 348 */       if (header != null) {
/* 349 */         sbuf.append(header);
/*     */       }
/* 351 */       String presentationHeader = this.layout.getPresentationHeader();
/* 352 */       if (presentationHeader != null) {
/* 353 */         sbuf.append(presentationHeader);
/*     */       }
/* 355 */       fillBuffer(cb, sbuf);
/* 356 */       String presentationFooter = this.layout.getPresentationFooter();
/* 357 */       if (presentationFooter != null) {
/* 358 */         sbuf.append(presentationFooter);
/*     */       }
/* 360 */       String footer = this.layout.getFileFooter();
/* 361 */       if (footer != null) {
/* 362 */         sbuf.append(footer);
/*     */       }
/*     */       
/* 365 */       String subjectStr = "Undefined subject";
/* 366 */       if (this.subjectLayout != null) {
/* 367 */         subjectStr = this.subjectLayout.doLayout(lastEventObject);
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 372 */         int newLinePos = subjectStr != null ? subjectStr.indexOf('\n') : -1;
/* 373 */         if (newLinePos > -1) {
/* 374 */           subjectStr = subjectStr.substring(0, newLinePos);
/*     */         }
/*     */       }
/* 377 */       this.mimeMsg.setSubject(subjectStr, this.charsetEncoding);
/*     */       
/* 379 */       List<InternetAddress> destinationAddresses = parseAddress(lastEventObject);
/* 380 */       if (destinationAddresses.isEmpty()) {
/* 381 */         addInfo("Empty destination address. Aborting email transmission");
/* 382 */         return;
/*     */       }
/*     */       
/* 385 */       InternetAddress[] toAddressArray = (InternetAddress[])destinationAddresses.toArray(EMPTY_IA_ARRAY);
/* 386 */       this.mimeMsg.setRecipients(Message.RecipientType.TO, toAddressArray);
/*     */       
/* 388 */       String contentType = this.layout.getContentType();
/*     */       
/* 390 */       if (ContentTypeUtil.isTextual(contentType)) {
/* 391 */         part.setText(sbuf.toString(), this.charsetEncoding, ContentTypeUtil.getSubType(contentType));
/*     */       }
/*     */       else {
/* 394 */         part.setContent(sbuf.toString(), this.layout.getContentType());
/*     */       }
/*     */       
/* 397 */       Multipart mp = new MimeMultipart();
/* 398 */       mp.addBodyPart(part);
/* 399 */       this.mimeMsg.setContent(mp);
/*     */       
/* 401 */       this.mimeMsg.setSentDate(new Date());
/* 402 */       addInfo("About to send out SMTP message \"" + subjectStr + "\" to " + Arrays.toString(toAddressArray));
/* 403 */       Transport.send(this.mimeMsg);
/*     */     } catch (Exception e) {
/* 405 */       addError("Error occurred while sending e-mail notification.", e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected abstract void fillBuffer(CyclicBuffer<E> paramCyclicBuffer, StringBuffer paramStringBuffer);
/*     */   
/*     */ 
/*     */   public String getFrom()
/*     */   {
/* 415 */     return this.from;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getSubject()
/*     */   {
/* 422 */     return this.subjectStr;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFrom(String from)
/*     */   {
/* 430 */     this.from = from;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSubject(String subject)
/*     */   {
/* 438 */     this.subjectStr = subject;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSMTPHost(String smtpHost)
/*     */   {
/* 447 */     setSmtpHost(smtpHost);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSmtpHost(String smtpHost)
/*     */   {
/* 455 */     this.smtpHost = smtpHost;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getSMTPHost()
/*     */   {
/* 462 */     return getSmtpHost();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getSmtpHost()
/*     */   {
/* 469 */     return this.smtpHost;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSMTPPort(int port)
/*     */   {
/* 478 */     setSmtpPort(port);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSmtpPort(int port)
/*     */   {
/* 487 */     this.smtpPort = port;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getSMTPPort()
/*     */   {
/* 496 */     return getSmtpPort();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getSmtpPort()
/*     */   {
/* 505 */     return this.smtpPort;
/*     */   }
/*     */   
/*     */ 
/* 509 */   public String getLocalhost() { return this.localhost; }
/*     */   
/*     */   private boolean sessionViaJNDI;
/*     */   private String jndiLocation;
/*     */   String username;
/*     */   String password;
/*     */   String localhost;
/*     */   boolean asynchronousSending;
/*     */   private String charsetEncoding;
/*     */   protected MimeMessage mimeMsg;
/*     */   protected EventEvaluator<E> eventEvaluator;
/*     */   protected Discriminator<E> discriminator;
/*     */   protected CyclicBufferTracker<E> cbTracker;
/*     */   private int errorCount;
/* 523 */   public void setLocalhost(String localhost) { this.localhost = localhost; }
/*     */   
/*     */ 
/*     */   public CyclicBufferTracker<E> getCyclicBufferTracker() {
/* 527 */     return this.cbTracker;
/*     */   }
/*     */   
/*     */   public void setCyclicBufferTracker(CyclicBufferTracker<E> cbTracker) {
/* 531 */     this.cbTracker = cbTracker;
/*     */   }
/*     */   
/*     */   public Discriminator<E> getDiscriminator() {
/* 535 */     return this.discriminator;
/*     */   }
/*     */   
/*     */   public void setDiscriminator(Discriminator<E> discriminator) {
/* 539 */     this.discriminator = discriminator;
/*     */   }
/*     */   
/*     */   public boolean isAsynchronousSending() {
/* 543 */     return this.asynchronousSending;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAsynchronousSending(boolean asynchronousSending)
/*     */   {
/* 554 */     this.asynchronousSending = asynchronousSending;
/*     */   }
/*     */   
/*     */   public void addTo(String to) {
/* 558 */     if ((to == null) || (to.length() == 0)) {
/* 559 */       throw new IllegalArgumentException("Null or empty <to> property");
/*     */     }
/* 561 */     PatternLayoutBase plb = makeNewToPatternLayout(to.trim());
/* 562 */     plb.setContext(this.context);
/* 563 */     plb.start();
/* 564 */     this.toPatternLayoutList.add(plb);
/*     */   }
/*     */   
/*     */   protected abstract PatternLayoutBase<E> makeNewToPatternLayout(String paramString);
/*     */   
/*     */   public List<String> getToAsListOfString() {
/* 570 */     List<String> toList = new ArrayList();
/* 571 */     for (PatternLayoutBase plb : this.toPatternLayoutList) {
/* 572 */       toList.add(plb.getPattern());
/*     */     }
/* 574 */     return toList;
/*     */   }
/*     */   
/*     */   public Message getMessage()
/*     */   {
/* 579 */     return this.mimeMsg;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setMessage(MimeMessage msg)
/*     */   {
/* 585 */     this.mimeMsg = msg;
/*     */   }
/*     */   
/*     */   public boolean isSTARTTLS() {
/* 589 */     return this.starttls;
/*     */   }
/*     */   
/*     */   public void setSTARTTLS(boolean startTLS) {
/* 593 */     this.starttls = startTLS;
/*     */   }
/*     */   
/*     */   public boolean isSSL() {
/* 597 */     return this.ssl;
/*     */   }
/*     */   
/*     */   public void setSSL(boolean ssl) {
/* 601 */     this.ssl = ssl;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setEvaluator(EventEvaluator<E> eventEvaluator)
/*     */   {
/* 611 */     this.eventEvaluator = eventEvaluator;
/*     */   }
/*     */   
/*     */   public String getUsername() {
/* 615 */     return this.username;
/*     */   }
/*     */   
/*     */   public void setUsername(String username) {
/* 619 */     this.username = username;
/*     */   }
/*     */   
/*     */   public String getPassword() {
/* 623 */     return this.password;
/*     */   }
/*     */   
/*     */   public void setPassword(String password) {
/* 627 */     this.password = password;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getCharsetEncoding()
/*     */   {
/* 635 */     return this.charsetEncoding;
/*     */   }
/*     */   
/*     */   public String getJndiLocation()
/*     */   {
/* 640 */     return this.jndiLocation;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setJndiLocation(String jndiLocation)
/*     */   {
/* 651 */     this.jndiLocation = jndiLocation;
/*     */   }
/*     */   
/*     */   public boolean isSessionViaJNDI() {
/* 655 */     return this.sessionViaJNDI;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSessionViaJNDI(boolean sessionViaJNDI)
/*     */   {
/* 665 */     this.sessionViaJNDI = sessionViaJNDI;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCharsetEncoding(String charsetEncoding)
/*     */   {
/* 675 */     this.charsetEncoding = charsetEncoding;
/*     */   }
/*     */   
/*     */   public Layout<E> getLayout() {
/* 679 */     return this.layout;
/*     */   }
/*     */   
/*     */   public void setLayout(Layout<E> layout) {
/* 683 */     this.layout = layout;
/*     */   }
/*     */   
/*     */   class SenderRunnable implements Runnable
/*     */   {
/*     */     final CyclicBuffer<E> cyclicBuffer;
/*     */     final E e;
/*     */     
/*     */     SenderRunnable(E cyclicBuffer) {
/* 692 */       this.cyclicBuffer = cyclicBuffer;
/* 693 */       this.e = e;
/*     */     }
/*     */     
/*     */     public void run() {
/* 697 */       SMTPAppenderBase.this.sendBuffer(this.cyclicBuffer, this.e);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\logback-core-1.1.2.jar!\ch\qos\logback\core\net\SMTPAppenderBase.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */