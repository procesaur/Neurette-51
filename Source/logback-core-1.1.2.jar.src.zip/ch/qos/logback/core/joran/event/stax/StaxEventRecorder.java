/*     */ package ch.qos.logback.core.joran.event.stax;
/*     */ 
/*     */ import ch.qos.logback.core.Context;
/*     */ import ch.qos.logback.core.joran.spi.ElementPath;
/*     */ import ch.qos.logback.core.joran.spi.JoranException;
/*     */ import ch.qos.logback.core.spi.ContextAwareBase;
/*     */ import java.io.InputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.stream.XMLEventReader;
/*     */ import javax.xml.stream.XMLInputFactory;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.events.Characters;
/*     */ import javax.xml.stream.events.EndElement;
/*     */ import javax.xml.stream.events.StartElement;
/*     */ import javax.xml.stream.events.XMLEvent;
/*     */ 
/*     */ public class StaxEventRecorder extends ContextAwareBase
/*     */ {
/*  21 */   List<StaxEvent> eventList = new ArrayList();
/*  22 */   ElementPath globalElementPath = new ElementPath();
/*     */   
/*     */   public StaxEventRecorder(Context context) {
/*  25 */     setContext(context);
/*     */   }
/*     */   
/*     */   public void recordEvents(InputStream inputStream) throws JoranException {
/*     */     try {
/*  30 */       XMLEventReader xmlEventReader = XMLInputFactory.newInstance().createXMLEventReader(inputStream);
/*  31 */       read(xmlEventReader);
/*     */     } catch (XMLStreamException e) {
/*  33 */       throw new JoranException("Problem parsing XML document. See previously reported errors.", e);
/*     */     }
/*     */   }
/*     */   
/*     */   public List<StaxEvent> getEventList() {
/*  38 */     return this.eventList;
/*     */   }
/*     */   
/*     */   private void read(XMLEventReader xmlEventReader) throws XMLStreamException {
/*  42 */     while (xmlEventReader.hasNext()) {
/*  43 */       XMLEvent xmlEvent = xmlEventReader.nextEvent();
/*  44 */       switch (xmlEvent.getEventType()) {
/*     */       case 1: 
/*  46 */         addStartElement(xmlEvent);
/*  47 */         break;
/*     */       case 4: 
/*  49 */         addCharacters(xmlEvent);
/*  50 */         break;
/*     */       case 2: 
/*  52 */         addEndEvent(xmlEvent);
/*     */       }
/*     */       
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private void addStartElement(XMLEvent xmlEvent)
/*     */   {
/*  61 */     StartElement se = xmlEvent.asStartElement();
/*  62 */     String tagName = se.getName().getLocalPart();
/*  63 */     this.globalElementPath.push(tagName);
/*  64 */     ElementPath current = this.globalElementPath.duplicate();
/*  65 */     StartEvent startEvent = new StartEvent(current, tagName, se.getAttributes(), se.getLocation());
/*  66 */     this.eventList.add(startEvent);
/*     */   }
/*     */   
/*     */   private void addCharacters(XMLEvent xmlEvent) {
/*  70 */     Characters characters = xmlEvent.asCharacters();
/*  71 */     StaxEvent lastEvent = getLastEvent();
/*     */     
/*  73 */     if ((lastEvent instanceof BodyEvent)) {
/*  74 */       BodyEvent be = (BodyEvent)lastEvent;
/*  75 */       be.append(characters.getData());
/*     */ 
/*     */     }
/*  78 */     else if (!characters.isWhiteSpace()) {
/*  79 */       BodyEvent bodyEvent = new BodyEvent(characters.getData(), xmlEvent.getLocation());
/*  80 */       this.eventList.add(bodyEvent);
/*     */     }
/*     */   }
/*     */   
/*     */   private void addEndEvent(XMLEvent xmlEvent)
/*     */   {
/*  86 */     EndElement ee = xmlEvent.asEndElement();
/*  87 */     String tagName = ee.getName().getLocalPart();
/*  88 */     EndEvent endEvent = new EndEvent(tagName, ee.getLocation());
/*  89 */     this.eventList.add(endEvent);
/*  90 */     this.globalElementPath.pop();
/*     */   }
/*     */   
/*     */   StaxEvent getLastEvent() {
/*  94 */     if (this.eventList.isEmpty()) {
/*  95 */       return null;
/*     */     }
/*  97 */     int size = this.eventList.size();
/*  98 */     if (size == 0)
/*  99 */       return null;
/* 100 */     return (StaxEvent)this.eventList.get(size - 1);
/*     */   }
/*     */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\logback-core-1.1.2.jar!\ch\qos\logback\core\joran\event\stax\StaxEventRecorder.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */