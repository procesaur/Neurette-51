/*    */ package ch.qos.logback.core.joran.event.stax;
/*    */ 
/*    */ import javax.xml.stream.Location;
/*    */ 
/*    */ public class BodyEvent extends StaxEvent
/*    */ {
/*    */   private String text;
/*    */   
/*    */   BodyEvent(String text, Location location)
/*    */   {
/* 11 */     super(null, location);
/* 12 */     this.text = text;
/*    */   }
/*    */   
/*    */   public String getText() {
/* 16 */     return this.text;
/*    */   }
/*    */   
/*    */   void append(String txt) {
/* 20 */     this.text += txt;
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 25 */     return "BodyEvent(" + getText() + ")" + this.location.getLineNumber() + "," + this.location.getColumnNumber();
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\logback-core-1.1.2.jar!\ch\qos\logback\core\joran\event\stax\BodyEvent.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */