/*    */ package ch.qos.logback.core.joran.event.stax;
/*    */ 
/*    */ import ch.qos.logback.core.joran.spi.ElementPath;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import javax.xml.stream.Location;
/*    */ import javax.xml.stream.events.Attribute;
/*    */ 
/*    */ public class StartEvent extends StaxEvent
/*    */ {
/*    */   List<Attribute> attributes;
/*    */   public ElementPath elementPath;
/*    */   
/*    */   StartEvent(ElementPath elementPath, String name, Iterator<Attribute> attributeIterator, Location location)
/*    */   {
/* 17 */     super(name, location);
/* 18 */     populateAttributes(attributeIterator);
/* 19 */     this.elementPath = elementPath;
/*    */   }
/*    */   
/*    */   private void populateAttributes(Iterator<Attribute> attributeIterator) {
/* 23 */     while (attributeIterator.hasNext()) {
/* 24 */       if (this.attributes == null) {
/* 25 */         this.attributes = new ArrayList(2);
/*    */       }
/* 27 */       this.attributes.add(attributeIterator.next());
/*    */     }
/*    */   }
/*    */   
/*    */   public ElementPath getElementPath() {
/* 32 */     return this.elementPath;
/*    */   }
/*    */   
/*    */   public List<Attribute> getAttributeList() {
/* 36 */     return this.attributes;
/*    */   }
/*    */   
/*    */   Attribute getAttributeByName(String name) {
/* 40 */     if (this.attributes == null) {
/* 41 */       return null;
/*    */     }
/* 43 */     for (Attribute attr : this.attributes) {
/* 44 */       if (name.equals(attr.getName().getLocalPart()))
/* 45 */         return attr;
/*    */     }
/* 47 */     return null;
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 52 */     return "StartEvent(" + getName() + ")  [" + this.location.getLineNumber() + "," + this.location.getColumnNumber() + "]";
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\logback-core-1.1.2.jar!\ch\qos\logback\core\joran\event\stax\StartEvent.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */