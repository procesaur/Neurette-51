package ch.qos.logback.core.joran.event;

public abstract interface InPlayListener
{
  public abstract void inPlay(SaxEvent paramSaxEvent);
}


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\logback-core-1.1.2.jar!\ch\qos\logback\core\joran\event\InPlayListener.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */