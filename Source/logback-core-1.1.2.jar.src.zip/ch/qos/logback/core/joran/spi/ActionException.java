/*    */ package ch.qos.logback.core.joran.spi;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ActionException
/*    */   extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = 2743349809995319806L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public ActionException() {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public ActionException(Throwable rootCause)
/*    */   {
/* 33 */     super(rootCause);
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\logback-core-1.1.2.jar!\ch\qos\logback\core\joran\spi\ActionException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */