package ch.qos.logback.core.joran.conditional;

public abstract interface Condition
{
  public abstract boolean evaluate();
}


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\logback-core-1.1.2.jar!\ch\qos\logback\core\joran\conditional\Condition.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */