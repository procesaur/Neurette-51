package ch.qos.logback.core.joran.node;

public class ComponentNode
{
  String classStr;
}


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\logback-core-1.1.2.jar!\ch\qos\logback\core\joran\node\ComponentNode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */