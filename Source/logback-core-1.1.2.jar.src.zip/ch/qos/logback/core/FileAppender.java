/*     */ package ch.qos.logback.core;
/*     */ 
/*     */ import ch.qos.logback.core.recovery.ResilientFileOutputStream;
/*     */ import ch.qos.logback.core.util.FileUtil;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.nio.channels.FileChannel;
/*     */ import java.nio.channels.FileLock;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FileAppender<E>
/*     */   extends OutputStreamAppender<E>
/*     */ {
/*  39 */   protected boolean append = true;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  44 */   protected String fileName = null;
/*     */   
/*  46 */   private boolean prudent = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFile(String file)
/*     */   {
/*  53 */     if (file == null) {
/*  54 */       this.fileName = file;
/*     */     }
/*     */     else
/*     */     {
/*  58 */       this.fileName = file.trim();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isAppend()
/*     */   {
/*  66 */     return this.append;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final String rawFileProperty()
/*     */   {
/*  76 */     return this.fileName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getFile()
/*     */   {
/*  87 */     return this.fileName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void start()
/*     */   {
/*  96 */     int errors = 0;
/*  97 */     if (getFile() != null) {
/*  98 */       addInfo("File property is set to [" + this.fileName + "]");
/*     */       
/* 100 */       if ((this.prudent) && 
/* 101 */         (!isAppend())) {
/* 102 */         setAppend(true);
/* 103 */         addWarn("Setting \"Append\" property to true on account of \"Prudent\" mode");
/*     */       }
/*     */       
/*     */       try
/*     */       {
/* 108 */         openFile(getFile());
/*     */       } catch (IOException e) {
/* 110 */         errors++;
/* 111 */         addError("openFile(" + this.fileName + "," + this.append + ") call failed.", e);
/*     */       }
/*     */     } else {
/* 114 */       errors++;
/* 115 */       addError("\"File\" property not set for appender named [" + this.name + "].");
/*     */     }
/* 117 */     if (errors == 0) {
/* 118 */       super.start();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void openFile(String file_name)
/*     */     throws IOException
/*     */   {
/* 139 */     this.lock.lock();
/*     */     try {
/* 141 */       File file = new File(file_name);
/* 142 */       if (FileUtil.isParentDirectoryCreationRequired(file)) {
/* 143 */         boolean result = FileUtil.createMissingParentDirectories(file);
/* 144 */         if (!result) {
/* 145 */           addError("Failed to create parent directories for [" + file.getAbsolutePath() + "]");
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 150 */       ResilientFileOutputStream resilientFos = new ResilientFileOutputStream(file, this.append);
/*     */       
/* 152 */       resilientFos.setContext(this.context);
/* 153 */       setOutputStream(resilientFos);
/*     */     } finally {
/* 155 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isPrudent()
/*     */   {
/* 165 */     return this.prudent;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPrudent(boolean prudent)
/*     */   {
/* 175 */     this.prudent = prudent;
/*     */   }
/*     */   
/*     */   public void setAppend(boolean append) {
/* 179 */     this.append = append;
/*     */   }
/*     */   
/*     */   private void safeWrite(E event) throws IOException {
/* 183 */     ResilientFileOutputStream resilientFOS = (ResilientFileOutputStream)getOutputStream();
/* 184 */     FileChannel fileChannel = resilientFOS.getChannel();
/* 185 */     if (fileChannel == null) {
/* 186 */       return;
/*     */     }
/* 188 */     FileLock fileLock = null;
/*     */     try {
/* 190 */       fileLock = fileChannel.lock();
/* 191 */       long position = fileChannel.position();
/* 192 */       long size = fileChannel.size();
/* 193 */       if (size != position) {
/* 194 */         fileChannel.position(size);
/*     */       }
/* 196 */       super.writeOut(event);
/*     */     } finally {
/* 198 */       if (fileLock != null) {
/* 199 */         fileLock.release();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   protected void writeOut(E event) throws IOException
/*     */   {
/* 206 */     if (this.prudent) {
/* 207 */       safeWrite(event);
/*     */     } else {
/* 209 */       super.writeOut(event);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\logback-core-1.1.2.jar!\ch\qos\logback\core\FileAppender.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */