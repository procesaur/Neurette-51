package ch.qos.logback.core.rolling.helper;

public abstract interface MonoTypedConverter
{
  public abstract boolean isApplicable(Object paramObject);
}


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\logback-core-1.1.2.jar!\ch\qos\logback\core\rolling\helper\MonoTypedConverter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */