/*     */ package ch.qos.logback.core;
/*     */ 
/*     */ import ch.qos.logback.core.spi.AppenderAttachable;
/*     */ import ch.qos.logback.core.spi.AppenderAttachableImpl;
/*     */ import java.util.Iterator;
/*     */ import java.util.concurrent.ArrayBlockingQueue;
/*     */ import java.util.concurrent.BlockingQueue;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AsyncAppenderBase<E>
/*     */   extends UnsynchronizedAppenderBase<E>
/*     */   implements AppenderAttachable<E>
/*     */ {
/*     */   AppenderAttachableImpl<E> aai;
/*     */   BlockingQueue<E> blockingQueue;
/*     */   public static final int DEFAULT_QUEUE_SIZE = 256;
/*     */   int queueSize;
/*     */   int appenderCount;
/*     */   static final int UNDEFINED = -1;
/*     */   int discardingThreshold;
/*     */   AsyncAppenderBase<E>.Worker worker;
/*     */   
/*     */   public AsyncAppenderBase()
/*     */   {
/*  41 */     this.aai = new AppenderAttachableImpl();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  48 */     this.queueSize = 256;
/*     */     
/*  50 */     this.appenderCount = 0;
/*     */     
/*     */ 
/*  53 */     this.discardingThreshold = -1;
/*     */     
/*  55 */     this.worker = new Worker();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean isDiscardable(E eventObject)
/*     */   {
/*  68 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void preprocess(E eventObject) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void start()
/*     */   {
/*  84 */     if (this.appenderCount == 0) {
/*  85 */       addError("No attached appenders found.");
/*  86 */       return;
/*     */     }
/*  88 */     if (this.queueSize < 1) {
/*  89 */       addError("Invalid queue size [" + this.queueSize + "]");
/*  90 */       return;
/*     */     }
/*  92 */     this.blockingQueue = new ArrayBlockingQueue(this.queueSize);
/*     */     
/*  94 */     if (this.discardingThreshold == -1)
/*  95 */       this.discardingThreshold = (this.queueSize / 5);
/*  96 */     addInfo("Setting discardingThreshold to " + this.discardingThreshold);
/*  97 */     this.worker.setDaemon(true);
/*  98 */     this.worker.setName("AsyncAppender-Worker-" + this.worker.getName());
/*     */     
/* 100 */     super.start();
/* 101 */     this.worker.start();
/*     */   }
/*     */   
/*     */   public void stop()
/*     */   {
/* 106 */     if (!isStarted()) {
/* 107 */       return;
/*     */     }
/*     */     
/*     */ 
/* 111 */     super.stop();
/*     */     
/*     */ 
/*     */ 
/* 115 */     this.worker.interrupt();
/*     */     try {
/* 117 */       this.worker.join(1000L);
/*     */     } catch (InterruptedException e) {
/* 119 */       addError("Failed to join worker thread", e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected void append(E eventObject)
/*     */   {
/* 126 */     if ((isQueueBelowDiscardingThreshold()) && (isDiscardable(eventObject))) {
/* 127 */       return;
/*     */     }
/* 129 */     preprocess(eventObject);
/* 130 */     put(eventObject);
/*     */   }
/*     */   
/*     */   private boolean isQueueBelowDiscardingThreshold() {
/* 134 */     return this.blockingQueue.remainingCapacity() < this.discardingThreshold;
/*     */   }
/*     */   
/*     */   private void put(E eventObject) {
/*     */     try {
/* 139 */       this.blockingQueue.put(eventObject);
/*     */     }
/*     */     catch (InterruptedException e) {}
/*     */   }
/*     */   
/*     */   public int getQueueSize() {
/* 145 */     return this.queueSize;
/*     */   }
/*     */   
/*     */   public void setQueueSize(int queueSize) {
/* 149 */     this.queueSize = queueSize;
/*     */   }
/*     */   
/*     */   public int getDiscardingThreshold() {
/* 153 */     return this.discardingThreshold;
/*     */   }
/*     */   
/*     */   public void setDiscardingThreshold(int discardingThreshold) {
/* 157 */     this.discardingThreshold = discardingThreshold;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getNumberOfElementsInQueue()
/*     */   {
/* 166 */     return this.blockingQueue.size();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getRemainingCapacity()
/*     */   {
/* 176 */     return this.blockingQueue.remainingCapacity();
/*     */   }
/*     */   
/*     */ 
/*     */   public void addAppender(Appender<E> newAppender)
/*     */   {
/* 182 */     if (this.appenderCount == 0) {
/* 183 */       this.appenderCount += 1;
/* 184 */       addInfo("Attaching appender named [" + newAppender.getName() + "] to AsyncAppender.");
/* 185 */       this.aai.addAppender(newAppender);
/*     */     } else {
/* 187 */       addWarn("One and only one appender may be attached to AsyncAppender.");
/* 188 */       addWarn("Ignoring additional appender named [" + newAppender.getName() + "]");
/*     */     }
/*     */   }
/*     */   
/*     */   public Iterator<Appender<E>> iteratorForAppenders() {
/* 193 */     return this.aai.iteratorForAppenders();
/*     */   }
/*     */   
/*     */   public Appender<E> getAppender(String name) {
/* 197 */     return this.aai.getAppender(name);
/*     */   }
/*     */   
/*     */   public boolean isAttached(Appender<E> eAppender) {
/* 201 */     return this.aai.isAttached(eAppender);
/*     */   }
/*     */   
/*     */   public void detachAndStopAllAppenders() {
/* 205 */     this.aai.detachAndStopAllAppenders();
/*     */   }
/*     */   
/*     */   public boolean detachAppender(Appender<E> eAppender) {
/* 209 */     return this.aai.detachAppender(eAppender);
/*     */   }
/*     */   
/*     */ 
/* 213 */   public boolean detachAppender(String name) { return this.aai.detachAppender(name); }
/*     */   
/*     */   class Worker extends Thread {
/*     */     Worker() {}
/*     */     
/*     */     public void run() {
/* 219 */       AsyncAppenderBase<E> parent = AsyncAppenderBase.this;
/* 220 */       AppenderAttachableImpl<E> aai = parent.aai;
/*     */       for (;;)
/*     */       {
/* 223 */         if (parent.isStarted()) {
/*     */           try {
/* 225 */             E e = parent.blockingQueue.take();
/* 226 */             aai.appendLoopOnAppenders(e);
/*     */           }
/*     */           catch (InterruptedException ie) {}
/*     */         }
/*     */       }
/*     */       
/* 232 */       AsyncAppenderBase.this.addInfo("Worker thread will flush remaining events before exiting. ");
/* 233 */       for (E e : parent.blockingQueue) {
/* 234 */         aai.appendLoopOnAppenders(e);
/*     */       }
/*     */       
/* 237 */       aai.detachAndStopAllAppenders();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\logback-core-1.1.2.jar!\ch\qos\logback\core\AsyncAppenderBase.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */