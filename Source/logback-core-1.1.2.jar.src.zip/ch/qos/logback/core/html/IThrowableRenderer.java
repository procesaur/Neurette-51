package ch.qos.logback.core.html;

public abstract interface IThrowableRenderer<E>
{
  public abstract void render(StringBuilder paramStringBuilder, E paramE);
}


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\logback-core-1.1.2.jar!\ch\qos\logback\core\html\IThrowableRenderer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */