package ch.qos.logback.core.pattern.util;

public abstract interface IEscapeUtil
{
  public abstract void escape(String paramString, StringBuffer paramStringBuffer, char paramChar, int paramInt);
}


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\logback-core-1.1.2.jar!\ch\qos\logback\core\pattern\util\IEscapeUtil.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */