package ch.qos.logback.core.sift;

import ch.qos.logback.core.spi.LifeCycle;

public abstract interface Discriminator<E>
  extends LifeCycle
{
  public abstract String getDiscriminatingValue(E paramE);
  
  public abstract String getKey();
}


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\logback-core-1.1.2.jar!\ch\qos\logback\core\sift\Discriminator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */