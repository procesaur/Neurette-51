/*    */ package org.slf4j.impl;
/*    */ 
/*    */ import org.slf4j.helpers.NOPMDCAdapter;
/*    */ import org.slf4j.spi.MDCAdapter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StaticMDCBinder
/*    */ {
/* 42 */   public static final StaticMDCBinder SINGLETON = new StaticMDCBinder();
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public MDCAdapter getMDCA()
/*    */   {
/* 52 */     return new NOPMDCAdapter();
/*    */   }
/*    */   
/*    */   public String getMDCAdapterClassStr() {
/* 56 */     return NOPMDCAdapter.class.getName();
/*    */   }
/*    */ }


/* Location:              C:\Users\mihailo\Desktop\neurette\ready\neurette51.jar!\slf4j-nop-1.7.6.jar!\org\slf4j\impl\StaticMDCBinder.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */